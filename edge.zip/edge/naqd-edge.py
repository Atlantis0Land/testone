#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NAQD-Nexus edge daemon ("Rover").

Stdlib-only (urllib/json/subprocess/socket) so it runs on a bare JetPack/Jetson or
any Linux node with python3 and no pip access.

Behaviour:
  * Idle state: send a lightweight HTTP POST heartbeat to the central server every
    HEARTBEAT_INTERVAL seconds (default 180). This is the ONLY traffic while idle —
    deliberately NOT a WebSocket, so flaky/stateful TCP can't wedge us.
  * On a "wake_up" flag in the heartbeat response, bring up a self-healing reverse
    SSH tunnel with autossh. While the flag is clear (past a grace period) tear it
    down to save power.
  * The daemon is designed to be IMMORTAL: every error is caught, logged, and the
    loop continues. systemd (Restart=always) covers a hard crash; this covers the
    soft ones.

Config is read from NAQD_HOME/config.env (KEY=VALUE lines), written by install.sh.
"""

import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

NAQD_HOME = os.environ.get("NAQD_HOME", "/opt/naqd-nexus")
CONFIG_PATH = os.path.join(NAQD_HOME, "config.env")
LOG_DIR = os.path.join(NAQD_HOME, "logs")
LOG_PATH = os.path.join(LOG_DIR, "edge.log")
PID_PATH = os.path.join(NAQD_HOME, "naqd-edge.pid")

_running = True


# --------------------------------------------------------------------------- #
# logging
# --------------------------------------------------------------------------- #
def log(msg):
    line = "%s  %s" % (time.strftime("%Y-%m-%dT%H:%M:%S%z"), msg)
    print(line, flush=True)  # journald captures stdout
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(LOG_PATH, "a") as fh:
            fh.write(line + "\n")
        try:
            os.chmod(LOG_PATH, 0o644)  # readable by the server's ssh_user for /logs tailing
        except OSError:
            pass
    except OSError:
        pass


# --------------------------------------------------------------------------- #
# config
# --------------------------------------------------------------------------- #
def load_config():
    cfg = {}
    with open(CONFIG_PATH) as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            cfg[k.strip()] = v.strip().strip('"').strip("'")
    return cfg


# --------------------------------------------------------------------------- #
# metrics (best-effort, all optional)
# --------------------------------------------------------------------------- #
def collect_meta():
    meta = {}
    try:
        meta["load"] = round(os.getloadavg()[0], 2)
    except (OSError, AttributeError):
        pass
    try:
        with open("/proc/uptime") as fh:
            meta["uptime"] = int(float(fh.read().split()[0]))
    except OSError:
        pass
    meta["kernel"] = os.uname().release if hasattr(os, "uname") else None
    return meta


# --------------------------------------------------------------------------- #
# chisel reverse tunnel
# --------------------------------------------------------------------------- #
class Tunnel:
    def __init__(self, cfg):
        self.cfg = cfg
        self.proc = None

    def is_up(self):
        return self.proc is not None and self.proc.poll() is None

    def start(self):
        if self.is_up():
            return
        cfg = self.cfg

        # Chisel server endpoint — read TUNNEL_URL directly from config.
        # This is the chisel server address (e.g. http://144.91.124.22:43871).
        tunnel_endpoint = cfg.get("TUNNEL_URL", "").strip()
        if not tunnel_endpoint:
            log("tunnel: TUNNEL_URL not set in config, cannot start tunnel")
            return

        cmd = ["chisel", "client", "--keepalive", "15s"]

        # Optional per-device auth — set TUNNEL_AUTH=user:pass in config.env.
        # Leave unset or empty to run without auth (current default while the
        # server runs chisel without --authfile). Must be updated on all rovers
        # *before* enabling --authfile on the server side.
        auth = cfg.get("TUNNEL_AUTH", "").strip()
        if auth:
            cmd += ["--auth", auth]

        local_ssh = cfg.get("LOCAL_SSH_PORT", "22").strip() or "22"
        cmd += [tunnel_endpoint, "R:%s:localhost:%s" % (cfg["TUNNEL_PORT"], local_ssh)]
        log("tunnel: starting chisel -> %s (R:%s:localhost:%s%s)" % (
            tunnel_endpoint, cfg["TUNNEL_PORT"], local_ssh, " [auth]" if auth else ""))
        self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)

    def stop(self):
        if self.proc is None:
            return
        if self.proc.poll() is None:
            log("tunnel: stopping chisel")
            self.proc.terminate()
            try:
                self.proc.wait(timeout=8)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        self.proc = None


# --------------------------------------------------------------------------- #
# port config persistence
# --------------------------------------------------------------------------- #
def _rewrite_tunnel_port(new_port):
    _rewrite_config_key("TUNNEL_PORT", str(new_port))


def _rewrite_config_key(key, value):
    try:
        with open(CONFIG_PATH) as fh:
            lines = fh.readlines()
        found = False
        with open(CONFIG_PATH, "w") as fh:
            for line in lines:
                if line.startswith(key + "="):
                    fh.write("%s=%s\n" % (key, value))
                    found = True
                else:
                    fh.write(line)
            if not found:
                fh.write("%s=%s\n" % (key, value))
    except OSError as exc:
        log("config-rewrite failed: %s" % exc)


# --------------------------------------------------------------------------- #
# heartbeat
# --------------------------------------------------------------------------- #
def heartbeat(cfg, payload):
    url = cfg["SERVER_URL"].rstrip("/") + "/api/heartbeat"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Bearer " + cfg["TOKEN"])
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


# --------------------------------------------------------------------------- #
# main loop
# --------------------------------------------------------------------------- #
def _handle_signal(signum, _frame):
    global _running
    _running = False
    log("signal %d received; shutting down" % signum)


def main():
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    try:
        cfg = load_config()
    except OSError as exc:
        log("FATAL: cannot read config %s: %s" % (CONFIG_PATH, exc))
        sys.exit(1)

    for key in ("SERVER_URL", "TUNNEL_URL", "DEVICE_UID", "TOKEN", "TUNNEL_PORT"):
        if not cfg.get(key):
            log("FATAL: missing config key %s" % key)
            sys.exit(1)

    interval = int(cfg.get("HEARTBEAT_INTERVAL", "180"))
    grace_misses = 1            # keep tunnel for this many clear beats before tearing down
    clear_streak = 0
    backoff = 5
    hostname = socket.gethostname()

    try:
        with open(PID_PATH, "w") as fh:
            fh.write(str(os.getpid()))
    except OSError:
        pass

    tunnel = Tunnel(cfg)
    last_tunnel_state = None
    log("naqd-edge starting: device=%s server=%s interval=%ss" %
        (cfg["DEVICE_UID"], cfg["SERVER_URL"], interval))

    while _running:
        up = tunnel.is_up()
        payload = {
            "device_uid": cfg["DEVICE_UID"],
            "status": "active" if up else "idle",
            "tunnel_state": "up" if up else "down",
            "hostname": hostname,
            "meta": collect_meta(),
        }
        try:
            resp = heartbeat(cfg, payload)
            backoff = 5  # reset on success

            srv_port = str(resp.get("tunnel_port", "")).strip()
            if srv_port and srv_port != str(cfg["TUNNEL_PORT"]):
                log("tunnel: port reassigned %s -> %s; restarting" % (cfg["TUNNEL_PORT"], srv_port))
                tunnel.stop()
                cfg["TUNNEL_PORT"] = srv_port
                tunnel.cfg = cfg
                _rewrite_tunnel_port(srv_port)

            srv_tunnel_url = str(resp.get("tunnel_url", "")).strip()
            if srv_tunnel_url and srv_tunnel_url != cfg.get("TUNNEL_URL", ""):
                log("tunnel: URL updated -> %s; restarting" % srv_tunnel_url)
                tunnel.stop()
                cfg["TUNNEL_URL"] = srv_tunnel_url
                tunnel.cfg = cfg
                _rewrite_config_key("TUNNEL_URL", srv_tunnel_url)

            wake = bool(resp.get("wake_up"))
            prev_up = tunnel.is_up()
            if wake:
                clear_streak = 0
                tunnel.start()
            else:
                clear_streak += 1
                if tunnel.is_up() and clear_streak > grace_misses:
                    tunnel.stop()
            if wake and not tunnel.is_up():
                log("tunnel: chisel not running while wake_up set; relaunching")
                tunnel.start()

            now_up = tunnel.is_up()
            if now_up != prev_up:
                time.sleep(2)
                confirm_up = tunnel.is_up()
                _payload = {
                    "device_uid": cfg["DEVICE_UID"],
                    "status": "active" if confirm_up else "idle",
                    "tunnel_state": "up" if confirm_up else "down",
                    "hostname": hostname,
                    "meta": collect_meta(),
                }
                try:
                    heartbeat(cfg, _payload)
                except Exception:
                    pass

            sleep_for = interval
        except urllib.error.HTTPError as exc:
            log("heartbeat HTTP %s: %s" % (exc.code, exc.reason))
            sleep_for = backoff
            backoff = min(backoff * 2, interval)
        except (urllib.error.URLError, socket.timeout, OSError) as exc:
            log("heartbeat unreachable: %s" % exc)
            sleep_for = backoff
            backoff = min(backoff * 2, interval)
        except Exception as exc:  # never let the loop die
            log("heartbeat unexpected error: %r" % exc)
            sleep_for = backoff
            backoff = min(backoff * 2, interval)

        # Interruptible sleep so SIGTERM is responsive.
        slept = 0.0
        while _running and slept < sleep_for:
            time.sleep(min(1.0, sleep_for - slept))
            slept += 1.0

    tunnel.stop()
    log("naqd-edge stopped.")


if __name__ == "__main__":
    main()
