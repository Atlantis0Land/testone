#!/usr/bin/env bash
# NAQD-Nexus edge installer — run as root on each VM.
# Usage: bash install.sh [device-name]
set -euo pipefail

DEVICE_NAME="${1:-$(hostname -s)}"
NAQD_HOME="/opt/naqd-nexus"
SERVER_URL="http://144.91.124.22:51892"
TUNNEL_URL="http://144.91.124.22:43871"
ENROLL_SECRET="naqd-enroll-change-me"

echo "=== NAQD-Nexus Edge Installer ==="
echo "Device name : $DEVICE_NAME"
echo "Server      : $SERVER_URL"
echo "Tunnel      : $TUNNEL_URL"
echo ""

# [0] Prerequisites
if ! command -v python3 &>/dev/null; then
  echo "ERROR: python3 is required but not installed"
  exit 1
fi

# [1] Create home
mkdir -p "$NAQD_HOME"/{logs,keys}

# [2] Install chisel client if missing
if [ ! -f /usr/local/bin/chisel ]; then
  echo "[1/6] Installing chisel client..."
  ARCH=$(uname -m)
  case "$ARCH" in
    x86_64)  CHISEL_ARCH="amd64" ;;
    aarch64) CHISEL_ARCH="arm64" ;;
    *)       echo "Unsupported arch: $ARCH"; exit 1 ;;
  esac
  CHISEL_VER="1.10.1"
  cd /tmp
  curl -sL "https://github.com/jpillora/chisel/releases/download/v${CHISEL_VER}/chisel_${CHISEL_VER}_linux_${CHISEL_ARCH}.gz" -o chisel.gz
  gunzip -f chisel.gz
  chmod +x chisel
  mv chisel /usr/local/bin/chisel
  echo "  chisel $(chisel --version 2>&1) installed"
else
  echo "[1/6] chisel already installed"
fi

# [3] Generate SSH key for server->rover access
if [ ! -f "$NAQD_HOME/keys/edge_key" ]; then
  echo "[2/6] Generating SSH key..."
  ssh-keygen -t ed25519 -f "$NAQD_HOME/keys/edge_key" -N "" -q -C "naqd-edge@$DEVICE_NAME"
  echo "  key generated"
else
  echo "[2/6] SSH key exists"
fi
EDGE_PUBKEY=$(cat "$NAQD_HOME/keys/edge_key.pub")

# [4] Authorize server's public key for incoming SSH
SERVER_PUBKEY="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIKaW0GRQhQFD93TN9MEy/5zqjgAt9gLrdd9mjeiBH5V6 root@vmi3114219"
mkdir -p /root/.ssh && chmod 700 /root/.ssh
if ! grep -qF "naqd-nexus-server" /root/.ssh/authorized_keys 2>/dev/null; then
  echo "$SERVER_PUBKEY naqd-nexus-server" >> /root/.ssh/authorized_keys
  chmod 600 /root/.ssh/authorized_keys
  echo "[3/6] Server pubkey authorized"
else
  echo "[3/6] Server pubkey already authorized"
fi

# [5] Register with central server
echo "[4/6] Registering with central server..."
RESPONSE=$(curl -sf -X POST "$SERVER_URL/api/register" \
  -H "Content-Type: application/json" \
  -d "{
    \"enroll_secret\": \"$ENROLL_SECRET\",
    \"name\": \"$DEVICE_NAME\",
    \"pubkey\": \"$EDGE_PUBKEY\",
    \"ssh_user\": \"root\"
  }")

if [ -z "$RESPONSE" ]; then
  echo "  ERROR: empty response from server. Is it running?"
  exit 1
fi

DEVICE_UID=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['device_uid'])" 2>/dev/null || echo "")
TOKEN=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])" 2>/dev/null || echo "")
TUNNEL_PORT=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['tunnel_port'])" 2>/dev/null || echo "")

if [ -z "$DEVICE_UID" ] || [ -z "$TOKEN" ]; then
  echo "  ERROR: registration failed. Response:"
  echo "  $RESPONSE"
  exit 1
fi

echo "  device_uid : $DEVICE_UID"
echo "  tunnel_port: $TUNNEL_PORT"

# [6] Write config
echo "[5/6] Writing config..."
cat > "$NAQD_HOME/config.env" << EOF
SERVER_URL=$SERVER_URL
TUNNEL_URL=$TUNNEL_URL
DEVICE_UID=$DEVICE_UID
TOKEN=$TOKEN
TUNNEL_PORT=$TUNNEL_PORT
HEARTBEAT_INTERVAL=60
NAQD_HOME=$NAQD_HOME
LOCAL_SSH_PORT=22
EOF
chmod 600 "$NAQD_HOME/config.env"

# [7] Copy edge daemon
echo "[6/6] Setting up systemd service..."
cp "$(dirname "$0")/naqd-edge.py" "$NAQD_HOME/naqd-edge.py" 2>/dev/null || true
chmod +x "$NAQD_HOME/naqd-edge.py"

cat > /etc/systemd/system/naqd-edge.service << 'EOF'
[Unit]
Description=NAQD-Nexus edge daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/naqd-nexus/naqd-edge.py
Restart=always
RestartSec=10
Environment=NAQD_HOME=/opt/naqd-nexus

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable naqd-edge
systemctl start naqd-edge
sleep 2

if systemctl is-active naqd-edge >/dev/null 2>&1; then
  echo ""
  echo "=== INSTALLED & RUNNING ==="
  echo "  Dashboard: $SERVER_URL"
  echo "  Device   : $DEVICE_NAME ($DEVICE_UID)"
  echo "  Port     : $TUNNEL_PORT"
  echo ""
  echo "  Check: systemctl status naqd-edge"
  echo "  Logs:  journalctl -u naqd-edge -f"
else
  echo "ERROR: service failed to start"
  journalctl -u naqd-edge --no-pager -n 10
  exit 1
fi
