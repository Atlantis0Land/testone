#!/usr/bin/env bash
# NAQD-Nexus edge installer — run as root on each VM.
# Usage: bash install.sh [device-name]
set -euo pipefail

DEVICE_NAME="${1:-$(hostname -s)}"
NAQD_HOME="/opt/naqd-nexus"
SERVER_URL="http://144.91.124.22:51892"
TUNNEL_URL="http://144.91.124.22:43871"
ENROLL_SECRET="naqd-enroll-change-me"
SERVER_PUBKEY="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIKaW0GRQhQFD93TN9MEy/5zqjgAt9gLrdd9mjeiBH5V6 root@vmi3114219"

echo "=== NAQD-Nexus Edge Installer ==="
echo "Device name : $DEVICE_NAME"
echo "Server      : $SERVER_URL"
echo "Tunnel      : $TUNNEL_URL"
echo ""

# [1/7] Prerequisites
echo "[1/7] Checking prerequisites..."
if ! command -v python3 &>/dev/null; then
  echo "  python3 not found — installing..."
  apt-get update -qq && apt-get install -y -qq python3
fi

if ! command -v tmux &>/dev/null; then
  echo "  tmux not found — installing..."
  apt-get update -qq && apt-get install -y -qq tmux
fi

if ! command -v curl &>/dev/null; then
  echo "  curl not found — installing..."
  apt-get update -qq && apt-get install -y -qq curl
fi
echo "  prerequisites OK"

# [2/7] Create home
echo "[2/7] Creating directories..."
mkdir -p "$NAQD_HOME"/{logs,keys}
echo "  done"

# [3/7] Install chisel client if missing
if [ ! -f /usr/local/bin/chisel ]; then
  echo "[3/7] Installing chisel client..."
  ARCH=$(uname -m)
  case "$ARCH" in
    x86_64)  CHISEL_ARCH="amd64" ;;
    aarch64) CHISEL_ARCH="arm64" ;;
    *)       echo "  ERROR: unsupported arch: $ARCH"; exit 1 ;;
  esac
  CHISEL_VER="1.10.1"
  cd /tmp
  curl -sL "https://github.com/jpillora/chisel/releases/download/v${CHISEL_VER}/chisel_${CHISEL_VER}_linux_${CHISEL_ARCH}.gz" -o chisel.gz
  gunzip -f chisel.gz
  chmod +x chisel
  mv chisel /usr/local/bin/chisel
  echo "  chisel installed"
else
  echo "[3/7] chisel already installed"
fi

# [4/7] Authorize server's public key for incoming SSH through tunnel
echo "[4/7] Authorizing server SSH key..."
mkdir -p /root/.ssh && chmod 700 /root/.ssh
if ! grep -qF "naqd-nexus-server" /root/.ssh/authorized_keys 2>/dev/null; then
  echo "$SERVER_PUBKEY naqd-nexus-server" >> /root/.ssh/authorized_keys
  chmod 600 /root/.ssh/authorized_keys
  echo "  server key authorized"
else
  echo "  server key already authorized"
fi

# [5/7] Register with central server
echo "[5/7] Registering with central server..."
EDGE_PUBKEY=""
if [ -f "$NAQD_HOME/keys/edge_key.pub" ]; then
  EDGE_PUBKEY=$(cat "$NAQD_HOME/keys/edge_key.pub")
fi

RESPONSE=$(curl -sf -X POST "$SERVER_URL/api/register" \
  -H "Content-Type: application/json" \
  -d "{
    \"enroll_secret\": \"$ENROLL_SECRET\",
    \"name\": \"$DEVICE_NAME\",
    \"pubkey\": \"$EDGE_PUBKEY\",
    \"ssh_user\": \"root\"
  }")

if [ -z "$RESPONSE" ]; then
  echo "  ERROR: empty response from server. Is it running?"
  exit 1
fi

DEVICE_UID=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['device_uid'])" 2>/dev/null || echo "")
TOKEN=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])" 2>/dev/null || echo "")
TUNNEL_PORT=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['tunnel_port'])" 2>/dev/null || echo "")

if [ -z "$DEVICE_UID" ] || [ -z "$TOKEN" ]; then
  echo "  ERROR: registration failed. Response:"
  echo "  $RESPONSE"
  exit 1
fi

echo "  device_uid : $DEVICE_UID"
echo "  tunnel_port: $TUNNEL_PORT"

# [6/7] Write config
echo "[6/7] Writing config..."
cat > "$NAQD_HOME/config.env" << EOF
SERVER_URL=$SERVER_URL
TUNNEL_URL=$TUNNEL_URL
DEVICE_UID=$DEVICE_UID
TOKEN=$TOKEN
TUNNEL_PORT=$TUNNEL_PORT
HEARTBEAT_INTERVAL=60
NAQD_HOME=$NAQD_HOME
LOCAL_SSH_PORT=22
EOF
chmod 600 "$NAQD_HOME/config.env"
echo "  config written"

# [7/7] Copy daemon + start service
echo "[7/7] Setting up systemd service..."
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$SCRIPT_DIR/naqd-edge.py" "$NAQD_HOME/naqd-edge.py" 2>/dev/null || true
chmod +x "$NAQD_HOME/naqd-edge.py"

# Stop old service if running
systemctl stop naqd-edge 2>/dev/null || true

cat > /etc/systemd/system/naqd-edge.service << 'EOF'
[Unit]
Description=NAQD-Nexus edge daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/naqd-nexus/naqd-edge.py
Restart=always
RestartSec=10
Environment=NAQD_HOME=/opt/naqd-nexus

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable naqd-edge
systemctl start naqd-edge
sleep 2

if systemctl is-active naqd-edge >/dev/null 2>&1; then
  echo ""
  echo "========================================="
  echo "  INSTALLED & RUNNING"
  echo "========================================="
  echo "  Dashboard : $SERVER_URL"
  echo "  Device    : $DEVICE_NAME"
  echo "  Device UID: $DEVICE_UID"
  echo "  Tunnel Port: $TUNNEL_PORT"
  echo ""
  echo "  Status: systemctl status naqd-edge"
  echo "  Logs  : journalctl -u naqd-edge -f"
  echo "========================================="
else
  echo "ERROR: service failed to start"
  journalctl -u naqd-edge --no-pager -n 10
  exit 1
fi
