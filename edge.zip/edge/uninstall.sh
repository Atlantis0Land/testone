#!/usr/bin/env bash
# NAQD-Nexus edge uninstaller — run as root on each VM.
set -euo pipefail

echo "=== NAQD-Nexus Edge Uninstaller ==="

echo "[1/4] Stopping service..."
systemctl stop naqd-edge 2>/dev/null || true
systemctl disable naqd-edge 2>/dev/null || true
rm -f /etc/systemd/system/naqd-edge.service
systemctl daemon-reload
echo "  done"

echo "[2/4] Killing chisel client..."
pkill -f "chisel client" 2>/dev/null || true
echo "  done"

echo "[3/4] Removing /opt/naqd-nexus..."
rm -rf /opt/naqd-nexus
echo "  done"

echo "[4/4] Removing server SSH key..."
sed -i '/naqd-nexus-server/d' /root/.ssh/authorized_keys 2>/dev/null || true
echo "  done"

echo ""
echo "=== UNINSTALLED ==="
