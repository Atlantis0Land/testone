# نشر الايدج على VM

## المتطلبات

- Python3 (موجود على أي Ubuntu/Debian)
- curl
- اتصال إنترنت (يخرج على البورتات دي: 51892, 43871)

## البورتات المطلوبة

| البورت | الاتجاه | الوصف |
|--------|---------|-------|
| 51892 | OUT | API server (heartbeat + register) |
| 43871 | OUT | Chisel tunnel server |

## خطوات النشر

### 1. انسخ فولدر edge للـ VM

من جهازك المحلي:

```bash
scp -r /home/ubuntu/sssm/edge/ root@VM_IP:/tmp/edge/
```

أو لو عندك أكتر من VM:

```bash
for vm in VM1_IP VM2_IP VM3_IP; do
  scp -r /home/ubuntu/sssm/edge/ root@$vm:/tmp/edge/
done
```

### 2. ادخل على الـ VM ونفّذ

```bash
cd /tmp/edge
bash install.sh اسم-الجهاز
```

مثال:

```bash
bash install.sh web-server-01
```

الاسم لازم يكون:
- حروف إنجليزية وأرقام فقط
- يبدأ بحرف أو رقم
- يسمح بـ `-` `_` `.`
- طول 1-63 حرف

### 3. تأكد إنه شغال

```bash
systemctl status naqd-edge
```

```bash
journalctl -u naqd-edge -f
```

### 4. رجع للداشبورد

افتح: `http://144.91.124.22:51892`

هتلاقي الجهاز ظاهر في القائمة.

## بعد التثبيت

الايدج هيعمل:
- heartbeat كل 60 ثانية للسيرفر
- لما تطلب wake من الداشبورد، هيفتح chisel tunnel
- النفق بيسمحلك تدخل SSH عالجهاز من الداشبورد

## الملفات اللي بيتإنشاها

| الملف | الوصف |
|-------|-------|
| `/opt/naqd-nexus/config.env` | إعدادات الجهاز (token, uid, ports) |
| `/opt/naqd-nexus/naqd-edge.py` | الـ daemon |
| `/opt/naqd-nexus/keys/edge_key` | SSH private key |
| `/opt/naqd-nexus/logs/edge.log` | لوج الـ daemon |
| `/etc/systemd/system/naqd-edge.service` | systemd service |

## أوامر مفيدة

```bash
# شوف حالة الخدمة
systemctl status naqd-edge

# شوف اللوج
journalctl -u naqd-edge -f

# رستارت
systemctl restart naqd-edge

# إيقاف
systemctl stop naqd-edge

# شوف الـ config
cat /opt/naqd-nexus/config.env
```

## إعادة التثبيت

لو عايز تعيد التسجيل (مثلاً غيّرت الاسم):

```bash
systemctl stop naqd-edge
rm -rf /opt/naqd-nexus
bash install.sh اسم-جديد
```
