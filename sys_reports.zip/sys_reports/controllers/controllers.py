# -*- coding: utf-8 -*-
# from odoo import http


# class SysReports(http.Controller):
#     @http.route('/sys_reports/sys_reports', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/sys_reports/sys_reports/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('sys_reports.listing', {
#             'root': '/sys_reports/sys_reports',
#             'objects': http.request.env['sys_reports.sys_reports'].search([]),
#         })

#     @http.route('/sys_reports/sys_reports/objects/<model("sys_reports.sys_reports"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('sys_reports.object', {
#             'object': obj
#         })
