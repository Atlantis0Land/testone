# -*- coding: utf-8 -*-

from odoo import models, fields, api


class StockPicking(models.Model):
    _inherit = "stock.picking"

    partner_id_from = fields.Many2one('res.partner','استلمت من',compute='_compute_partner_id_from',
    store=True)
    employee_id_name = fields.Many2one('hr.employee','اسم المستلم')
    number_contract = fields.Integer('الرقم')
    date_add = fields.Date('لتاريخ')

    @api.depends('partner_id')
    def _compute_partner_id_from(self):
        for rec in self:
            rec.partner_id_from = rec.partner_id

    def action_print_receipt_report(self):
        return self.env.ref('sys_reports.action_report_custom_receipt').report_action(self)

    def action_print_delivery_report(self):
        return self.env.ref('sys_reports.action_report_custom_exchange').report_action(self)

    def action_print_internal_transfer_report(self):
        return self.env.ref('sys_reports.action_report_custom_internal').report_action(self)

