import eventlet
# Monkey patch must be called before other imports
eventlet.monkey_patch()

from app import create_app, socketio

app = create_app()

if __name__ == '__main__':
    # Debug mode is True for errors, but use_reloader=False to stop constant restarting
    # allow_unsafe_werkzeug=True is needed in some envs for socketio
    socketio.run(app, debug=True, use_reloader=False, host='0.0.0.0', port=5005, allow_unsafe_werkzeug=True)