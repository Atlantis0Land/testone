#!/bin/bash

# Configuration
PYTHON_EXEC="/opt/cctv_server/venv/bin/python3"
PROJECT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SERVICE_NAME="wadh"

echo "========================================"
echo "   Setup WhatsApp Interface (WADH)"
echo "========================================"

# 1. Install Requirements
echo "[1/4] Installing Python Dependencies..."
if [ -f "$PYTHON_EXEC" ]; then
    "$PYTHON_EXEC" -m pip install -r requirements.txt
else
    echo "Error: Python executable not found at $PYTHON_EXEC"
    exit 1
fi

# 2. Compile Redis (if needed)
if [ ! -f "$PROJECT_DIR/redis-stable/src/redis-server" ]; then
    echo "[2/4] Compiling Redis..."
    if [ ! -d "redis-stable" ]; then
        wget http://download.redis.io/redis-stable.tar.gz
        tar xvzf redis-stable.tar.gz
        rm redis-stable.tar.gz
    fi
    cd redis-stable
    make
    cd ..
else
    echo "[2/4] Redis already compiled."
fi

# 3. Create Systemd Service
echo "[3/4] Creating Service File..."
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"

# Generate content dynamically
cat > wadh.service <<EOF
[Unit]
Description=WhatsApp Interface Management (WADH)
After=network.target

[Service]
User=$USER
Group=$USER
WorkingDirectory=$PROJECT_DIR
ExecStart=$PROJECT_DIR/start_system.sh
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

echo "Service file created at: $PROJECT_DIR/$SERVICE_NAME.service"
echo "To install system-wide, run:"
echo "sudo cp $PROJECT_DIR/$SERVICE_NAME.service /etc/systemd/system/"
echo "sudo systemctl daemon-reload"
echo "sudo systemctl enable $SERVICE_NAME"
echo "sudo systemctl start $SERVICE_NAME"

# 4. Make scripts executable
chmod +x start_system.sh
chmod +x setup.sh

echo "========================================"
echo "   Setup Complete!"
echo "========================================"
