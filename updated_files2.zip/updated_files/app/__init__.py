from flask import Flask
from .extensions import db, login_manager, socketio, celery
from .config import Config
from werkzeug.middleware.proxy_fix import ProxyFix

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Apply ProxyFix to handle X-Forwarded-Proto, X-Forwarded-For, and X-Forwarded-Prefix
    # x_prefix=1 is crucial for running under /wadh/
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

    # Initialize Extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'main.login' # <--- THIS IS THE FIX
    socketio.init_app(app, message_queue=app.config['CELERY_BROKER_URL'], async_mode='eventlet')
    
    # Configure Celery
    celery.conf.update(app.config)
    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)
    celery.Task = ContextTask

    # Register Blueprints (Routes)
    from .routes import main_bp
    app.register_blueprint(main_bp)

    # Create DB Tables
    with app.app_context():
        db.create_all()
        
        # Seed Settings
        from .models import User, SystemSetting
        if not SystemSetting.query.first():
            default_settings = SystemSetting(
                api_key="4ba608f6240811f09e0a020d3761eeb5",
                channel_id="24771",
                base_url="https://api.iomnihub.ai/stable/open/whatsapp/send-template-message"
            )
            db.session.add(default_settings)
            db.session.commit()

        # Create default admin if not exists
        if not User.query.filter_by(username='admin').first():
            # In production, hash this password!
            admin = User(username='admin', password='admin_password_123', is_admin=True)
            db.session.add(admin)
            db.session.commit()

    return app
