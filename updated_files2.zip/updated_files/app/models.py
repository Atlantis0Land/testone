from .extensions import db, login_manager
from flask_login import UserMixin
from datetime import datetime
import json

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    data = db.Column(db.Text)  # JSON storage for extra excel columns
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Template(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    provider_template_id = db.Column(db.String(100), nullable=False)
    channel_id = db.Column(db.String(50), nullable=True) 
    header_type = db.Column(db.String(20), default='none') # text, image, video, document, none
    variable_config = db.Column(db.Text, default='{}') # JSON
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Campaign(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    template_id = db.Column(db.Integer, db.ForeignKey('template.id'), nullable=False)
    status = db.Column(db.String(20), default='pending') # pending, processing, completed, stopped
    total_contacts = db.Column(db.Integer, default=0)
    sent_count = db.Column(db.Integer, default=0)
    failed_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    template = db.relationship('Template', backref='campaigns')

class CampaignJob(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaign.id'), nullable=False)
    contact_id = db.Column(db.Integer, db.ForeignKey('contact.id'), nullable=True) # Nullable if manual number
    phone_number = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), default='queued') # queued, sent, failed
    response_log = db.Column(db.Text) # API response
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    campaign = db.relationship('Campaign', backref='jobs')

class SystemSetting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    api_key = db.Column(db.String(200), nullable=False)
    channel_id = db.Column(db.String(50), nullable=False)
    base_url = db.Column(db.String(200), nullable=False, default="https://api.iomnihub.ai/stable/open/whatsapp/send-template-message")
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# --- New Models for Public Festival Page ---
class FestivalSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), default="مهرجان الظاهرة السياحي 2026")
    description = db.Column(db.Text, default="أهلاً بكم في الفعاليات الرسمية لمحافظة الظاهرة.")
    hero_image = db.Column(db.String(200)) # Path to hero image

class FestivalImage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(200), nullable=False)
    caption = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class PageVisit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    page_name = db.Column(db.String(50), nullable=False) # e.g., 'festival'
    ip_address = db.Column(db.String(50))
    user_agent = db.Column(db.String(200)) # Browser info
    visited_at = db.Column(db.DateTime, default=datetime.utcnow)