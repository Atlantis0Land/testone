import requests
import json
import os

def normalize_phone(mobile):
    """
    Smart Phone Normalization Logic:
    1. Clean input (remove spaces, excel .0, etc).
    2. If starts with +, keep as is.
    3. If starts with 00, replace with +.
    4. If length is exactly 8 digits (standard Oman local), prepend +968.
    5. If starts with 968 and length > 8, ensure + is there.
    6. Otherwise, assume it has a country code but missing +, so prepend +.
    """
    if not mobile:
        return None
    
    # 1. Basic Cleaning
    s = str(mobile).strip()
    s = s.replace('.0', '') # Handle Excel floats
    s = s.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
    
    # 2. Check explicit international format
    if s.startswith('+'):
        return s
    
    if s.startswith('00'):
        return f"+{s[2:]}"
    
    # Remove leading zeros for heuristic checks (e.g. 099... -> 99...)
    # Exception: Some countries use 0 as part of the actual number following country code? 
    # Usually country codes don't start with 0. 
    # Safe to strip leading zero for "Key detection".
    s_clean = s.lstrip('0')
    
    # 3. Oman Logic (8 Digits)
    # Most Oman numbers are 8 digits (9xxxxxxx, 7xxxxxxx, 2xxxxxxx)
    if len(s_clean) == 8:
        return f"+968{s_clean}"
    
    # 4. Oman Logic (Already has 968 but missing +)
    if s_clean.startswith('968') and len(s_clean) > 8:
        return f"+{s_clean}"

    # 5. General Logic (Assume Country Code Exists)
    # If number is NOT 8 digits, we assume the user provided the country code.
    # e.g. 2010xxxxxx (Egypt), 9715xxxxx (UAE)
    return f"+{s_clean}"

def send_whatsapp_msg(api_key, channel_id, template_id, mobile, base_url, body_vars=None, header_type='none', header_file=None, button_vars=None):
    """
    Sends WhatsApp message via iOmniHub.
    """
    print(f"\n--- [DEBUG] Starting Send Process for {mobile} ---")
    
    # 1. Determine Endpoint and Method
    url = base_url
    
    # If file exists, we MUST switch to the file endpoint
    has_file = False
    if header_type in ['image', 'video', 'document'] and header_file and os.path.exists(header_file):
        has_file = True
        if 'send-template-message' in url:
            print("   [DEBUG] File detected, switching endpoint to /send-template")
            url = url.replace('send-template-message', 'send-template')
    
    print(f"   [DEBUG] Target URL: {url}")
    print(f"   [DEBUG] Formatted Phone: {mobile}")

    # 2. Prepare Common Data
    params = {"api_key": api_key}
    
    try:
        response = None
        
        # SCENARIO A: Sending with File (Multipart/Form-Data)
        if has_file:
            print("   [DEBUG] Mode: Multipart (File)")
            payload = {
                "template_id": template_id,
                "channel_id": channel_id,
                "customer_phone": mobile,
                "header_type": header_type,
            }
            if body_vars: payload["body_vars"] = json.dumps(body_vars)
            if button_vars: payload["button_vars"] = json.dumps(button_vars)
            
            files = { "file": open(header_file, "rb") }
            response = requests.post(url, params=params, data=payload, files=files)
            files['file'].close()

        # SCENARIO B: Sending Text Only (JSON)
        else:
            print("   [DEBUG] Mode: JSON (Strict Legacy)")
            payload = {
                "template_id": template_id,
                "channel_id": channel_id,
                "customer_phone": mobile,
            }
            if body_vars: payload["body_vars"] = body_vars 
            if button_vars: payload["button_vars"] = button_vars

            headers = {"Content-Type": "application/json"}
            response = requests.post(url, params=params, json=payload, headers=headers, timeout=30)

        print(f"   [DEBUG] Response Status: {response.status_code}")
        print(f"   [DEBUG] Response Body: {response.text}")

        try:
            return response.json(), response.status_code
        except:
            return {"error": "Invalid JSON response", "raw": response.text}, response.status_code

    except Exception as e:
        print(f"   [ERROR] Exception during request: {str(e)}")
        return {"error": str(e)}, 500