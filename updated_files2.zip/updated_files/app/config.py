import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'super-secret-key-change-this'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///wa_marketing.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Redis Config
    CELERY_BROKER_URL = os.environ.get('CELERY_BROKER_URL') or 'redis://localhost:6385/0'
    CELERY_RESULT_BACKEND = os.environ.get('CELERY_RESULT_BACKEND') or 'redis://localhost:6385/0'

    # Uploads
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
