#!/bin/bash

# --- Configuration ---
REDIS_PORT=6385
FLASK_PORT=5005
# Custom Python Path provided by user
PYTHON_EXEC="/opt/cctv_server/venv/bin/python3"

# Get Absolute Path of the script directory
PROJECT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$PROJECT_DIR"

echo "=========================================="
echo "   Starting WhatsApp Interface (WADH)"
echo "   Python: $PYTHON_EXEC"
echo "=========================================="

# Check if Python exists
if [ ! -f "$PYTHON_EXEC" ]; then
    echo "Error: Python not found at $PYTHON_EXEC"
    exit 1
fi

# Function to kill processes on exit
cleanup() {
    echo ""
    echo "=========================================="
    echo "   Stopping System..."
    echo "=========================================="
    
    if [ ! -z "$FLASK_PID" ]; then kill $FLASK_PID 2>/dev/null; fi
    if [ ! -z "$CELERY_PID" ]; then kill $CELERY_PID 2>/dev/null; fi
    if [ ! -z "$REDIS_PID" ]; then kill $REDIS_PID 2>/dev/null; fi
    
    fuser -k $REDIS_PORT/tcp >/dev/null 2>&1
    
    echo "Done."
    exit
}
trap cleanup SIGINT

# 0. Cleanup old processes
fuser -k $REDIS_PORT/tcp >/dev/null 2>&1
fuser -k $FLASK_PORT/tcp >/dev/null 2>&1
pkill -f "celery -A celery_worker.celery" >/dev/null 2>&1

# 1. Start Redis
REDIS_SERVER="$PROJECT_DIR/redis-stable/src/redis-server"
if [ ! -f "$REDIS_SERVER" ]; then
    echo "Error: Local redis-server not found. Run setup.sh first."
    exit 1
fi

echo "[1/3] Starting Redis..."
"$REDIS_SERVER" --port $REDIS_PORT --daemonize no --loglevel notice &
REDIS_PID=$!
sleep 2

if ! ps -p $REDIS_PID > /dev/null; then
   echo "Error: Redis failed to start."
   exit 1
fi

# 2. Start Celery (Using Custom Python)
echo "[2/3] Starting Celery Worker..."
export CELERY_BROKER_URL="redis://localhost:$REDIS_PORT/0"
export CELERY_RESULT_BACKEND="redis://localhost:$REDIS_PORT/0"

# Using -m celery ensures we use the library installed in that specific venv
$PYTHON_EXEC -m celery -A celery_worker.celery worker --loglevel=info --pool=solo -c 1 &
CELERY_PID=$!

# 3. Start Flask (Using Custom Python)
echo "[3/3] Starting Flask..."
$PYTHON_EXEC run.py &
FLASK_PID=$!

echo "=========================================="
echo "   SYSTEM ONLINE"
echo "   PID: Flask($FLASK_PID) | Celery($CELERY_PID) | Redis($REDIS_PID)"
echo "=========================================="

wait $FLASK_PID