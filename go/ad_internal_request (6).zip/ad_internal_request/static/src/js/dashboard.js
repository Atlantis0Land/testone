/** @odoo-module **/

import { Component, onWillStart, useRef, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class InternalRequestDashboard extends Component {
    setup() {
        this.rpc = useService("rpc");
        this.action = useService("action");
        this.chartRef = useRef("chartCanvas");

        // Data holders
        this.totalRequests = 0;
        this.labels = [];
        this.values = [];
        this.topRequests = [];
        this.topProducts = [];
        this.top10Products = [];
        this.top10RequestsByAmount = [];
        this.totalAmountAllLines = 0;
        this.currencySymbol = "ر.ع";

//        // Reimbursement KPIs
//        this.reimbReqCount = 0;
//        this.reimbLinesTotal = 0;
//        this.reimbLinesSymbol = "ر.ع";

        onWillStart(async () => {
            const [
                chartData,
                topRequests,
                topProducts,
                top10Products,
                top10RequestsByAmount,
                totalAmountResp,
//                reimbReqCount,
//                reimbLinesTotalResp
            ] = await Promise.all([
                this.rpc('/web/dataset/call_kw', { model: 'ad.internal.request', method: 'get_request_type_data', args: [], kwargs: {} }),
                this.rpc('/web/dataset/call_kw', { model: 'ad.internal.request', method: 'get_top_requests_by_price', args: [], kwargs: {} }),
                this.rpc('/web/dataset/call_kw', { model: 'ad.internal.request', method: 'get_top_products_by_request_count', args: [], kwargs: {} }),
                this.rpc('/web/dataset/call_kw', { model: 'ad.internal.request', method: 'get_top10_products_by_request_count', args: [], kwargs: {} }),
                this.rpc('/web/dataset/call_kw', { model: 'ad.internal.request', method: 'get_top10_requests_by_total_amount', args: [], kwargs: {} }),
                this.rpc('/web/dataset/call_kw', { model: 'request.product.lines', method: 'get_total_amount_all_lines', args: [], kwargs: {} }),
//                this.rpc('/web/dataset/call_kw', { model: 'reimbursement.request', method: 'get_reimb_requests_count', args: [], kwargs: {} }),
//                this.rpc('/web/dataset/call_kw', { model: 'reimbursement.request.product.line', method: 'get_reimb_lines_total', args: [], kwargs: {} }),
            ]);

            // Assign values
            this.labels = chartData.labels || [];
            this.values = chartData.values || [];
            this.totalRequests = this.values.reduce((a, b) => a + b, 0);
            this.topRequests = topRequests || [];
            this.topProducts = topProducts || [];
            this.top10Products = top10Products || [];
            this.top10RequestsByAmount = top10RequestsByAmount || [];

            this.totalAmountAllLines = Number((totalAmountResp && totalAmountResp.total) || 0);
            this.currencySymbol = (totalAmountResp && totalAmountResp.symbol) || 'ر.ع';

//            this.reimbReqCount = Number(reimbReqCount || 0);
//            this.reimbLinesTotal = Number((reimbLinesTotalResp && reimbLinesTotalResp.total) || 0);
//            this.reimbLinesSymbol = (reimbLinesTotalResp && reimbLinesTotalResp.symbol) || 'ر.ع';
        });

        onMounted(() => {
            if (typeof Chart === "undefined") {
                console.error("❌ Chart.js is not loaded.");
                return;
            }

            const ctx = this.chartRef.el.getContext("2d");

            // 🎨 مصفوفة ألوان للأعمدة (هتتكرر تلقائياً لو الأنواع أكتر من الألوان)
            const palette = [
                "#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF",
                "#FF9F40", "#8DD17E", "#E15759", "#76B7B2", "#F28E2B",
                "#B07AA1", "#59A14F", "#EDC948", "#AF7AA1", "#F28EB2"
            ];
            const backgroundColors = this.labels.map((_, i) => palette[i % palette.length]);
            const borderColors = backgroundColors.map(c => c);

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: this.labels,
                    datasets: [{
                        label: 'الطلبات',
                        data: this.values,
                        backgroundColor: backgroundColors,
                        borderColor: borderColors,
                        borderWidth: 1,
                    }],
                },
                options: {
                    responsive: true,
                    plugins: { legend: { display: true } },
                    scales: { y: { beginAtZero: true } },
                },
            });
        });
    }

    // ===== Actions =====
    openRequestList() {
        this.action.doAction("ad_internal_request.action_request_internal");
    }

    openTotalAmountLines() {
        this.action.doAction({
            type: "ir.actions.act_window",
            name: "All Request Lines",
            res_model: "request.product.lines",
            view_mode: "tree,form",
            views: [[false, "list"], [false, "form"]],
            target: "current",
        });
    }

//    openReimbRequests() {
//        this.action.doAction({
//            type: "ir.actions.act_window",
//            name: "Reimbursement Requests",
//            res_model: "reimbursement.request",
//            view_mode: "tree,form",
//            views: [[false, "tree"], [false, "form"]],
//            target: "current",
//        });
//    }

//    openReimbLines() {
//        this.action.doAction({
//            type: "ir.actions.act_window",
//            name: "Reimbursement Lines",
//            res_model: "reimbursement.request.product.line",
//            view_mode: "tree,form",
//            views: [[false, "list"], [false, "form"]],
//            target: "current",
//        });
//    }

    openTop5List() {
        if (!this.topRequests.length) return;
        this.action.doAction({
            type: "ir.actions.act_window",
            name: "Top Expensive Requests",
            res_model: "ad.internal.request",
            view_mode: "tree,form",
            views: [[false, "list"], [false, "form"]],
            domain: [['id', 'in', this.topRequests.map(r => r.id)]],
        });
    }

    openTopProducts() {
        if (!this.topProducts.length) return;
        this.action.doAction({
            type: "ir.actions.act_window",
            name: "Top Products",
            res_model: "product.product",
            view_mode: "tree,form",
            views: [[false, "list"], [false, "form"]],
            domain: [['id', 'in', this.topProducts.map(p => p.id)]],
        });
    }
}

InternalRequestDashboard.template = "template_ad_internal_request_dashboard";
registry.category("actions").add("ad_internal_request_dashboard", InternalRequestDashboard);

export default InternalRequestDashboard;
