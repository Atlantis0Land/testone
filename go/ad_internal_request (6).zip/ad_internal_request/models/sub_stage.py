from odoo import models, fields,api,_
from odoo.exceptions import  ValidationError

class SubStage(models.Model):
    _name = 'sub.stage'
    _description = 'Sub Stage'

    name = fields.Char(string="Sub Stage ", required=True)
    approver_sub_line_ids = fields.One2many('ad.internal.request.sub.stage.line', 'sub_stage_id', string='Approver  Sub Lines')





class adSubStageLine(models.Model):
    _name = 'ad.internal.request.sub.stage.line'
    _description = 'Sub Stage Line'

    sub_stage_id = fields.Many2one('sub.stage', ondelete='cascade', required=True,
                                      string='sub Type')
    is_contract_type = fields.Boolean(string="Contract Type")

    name = fields.Char(string="Sub Stage Name", required=True)
    user_ids = fields.Many2many('res.users', string='Approver User')
    sequence = fields.Integer(string="Sequence", store=True)
    is_selected = fields.Boolean(string="Delivery Selected")
    is_selected_payment = fields.Boolean(string="Payment Selected")
    is_selected_po = fields.Boolean(string="po Selected")
    is_selected_installments = fields.Boolean(string="Installments Selected")
    show_partner_page = fields.Boolean(string="Show Partner Page")
    is_manager = fields.Boolean(string="Is Manager")
    is_department_manager = fields.Boolean(string="Is Department Manager")
    is_requester = fields.Boolean(string="Is Requester")
    is_warehouse_manager = fields.Boolean(string="Is Warehouse Manager")
    is_technical = fields.Boolean(string="Is Technical")

    is_create_request = fields.Boolean(string="Create Online Request")

    is_storekeeper = fields.Boolean(string="Treasurer", help="Allow Treasurer (requester's warehouse users) to approve this stage.")
    is_reminder = fields.Boolean(string="Reminder")


    @api.constrains('user_ids', 'is_manager', 'is_department_manager', 'is_requester', 'is_warehouse_manager','is_selected','is_technical'
                    'is_create_request','is_storekeeper')
    def _check_user_ids_required(self):
        for rec in self:
            if not any([
                rec.is_manager,
                rec.is_department_manager,
                rec.is_requester,
                rec.is_warehouse_manager,
                rec.is_create_request,
                rec.is_selected,
                rec.is_storekeeper,
                rec.is_technical,

            ]) and not rec.user_ids:
                raise ValidationError(
                    _("You must specify at least one Approver User if no system role is selected (manager/requester/etc)."))








