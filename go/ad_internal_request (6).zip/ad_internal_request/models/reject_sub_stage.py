# reject_substage_wizard.py
from odoo import models, fields, api, _
from odoo.exceptions import UserError

class RejectSubstageWizard(models.TransientModel):
    _name = 'ad.substage.reject.wizard'
    _description = 'Reject Sub-Stage Wizard'

    request_id = fields.Many2one('ad.internal.request', required=True)
    substage_type = fields.Selection([
        ('available', 'Available'),
        ('unavailable', 'Unavailable'),
        ('tender', 'Tender'),
        ('purchase', 'Purchase'),
        ('direct_assignment', 'Direct Assignment'),
    ], required=True)
    reason = fields.Text(string="Rejection Reason", required=True)

    def action_confirm_rejection(self):
        self.ensure_one()
        rec = self.request_id
        stage_type = self.substage_type

        # ✅ خريطة أسماء الحقول
        stage_field_map = {
            'available': 'available_id_stage_id',
            'unavailable': 'unavailable_id_stage_id',
            'tender': 'tender_stage_id',
            'purchase': 'purchase_stage_id',
            'direct_assignment': 'direct_assignment_stage_id',
        }
        stages_field_map = {
            'available': 'available_id_stage_ids',
            'unavailable': 'unavailable_id_stage_ids',
            'tender': 'tender_stage_ids',
            'purchase': 'purchase_stage_ids',
            'direct_assignment': 'direct_assignment_stage_ids',
        }

        stage_field = stage_field_map.get(stage_type)
        stages_field = stages_field_map.get(stage_type)

        if not stage_field or not stages_field:
            raise UserError(_("Stage configuration error."))

        # ✅ صلاحيات وقيود
        if rec.current_stages_working != stage_type:
            raise UserError(_("This reject is only allowed in the '%s' context.") % stage_type.capitalize())

        if not rec._user_can_approve(stage_type):
            raise UserError(_("You are not allowed to reject this %s sub-stage.") % stage_type.capitalize())

        cur_stage = getattr(rec, stage_field)
        all_stages = getattr(rec, stages_field)

        if not cur_stage or not all_stages:
            rec.message_post(body=_("No stages defined for this request."))
            return

        if rec._is_first_substage(cur_stage, all_stages):
            raise UserError(_("Cannot reject from the first %s sub-stage.") % stage_type.capitalize())

        idx = all_stages.ids.index(cur_stage.id)
        prev_stage = all_stages[idx - 1]

        setattr(rec, stage_field, prev_stage)

        rec.message_post(
            body=_("Stage moved back to: <b>%s</b><br/>Reason: <i>%s</i>") % (prev_stage.name or '', self.reason)
        )

        rec._mark_my_todos_done(feedback=_("تم رفض المرحلة: ") + self.reason)

        rec._schedule_substage_activity(prev_stage, _(stage_type.capitalize()))

        return {'type': 'ir.actions.act_window_close'}
