from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression
from odoo import SUPERUSER_ID
import json
from dateutil.relativedelta import relativedelta
from datetime import datetime
from collections import Counter


class AdInternalRequest(models.Model):
    _name = 'ad.internal.request'
    _description = 'Internal Request'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(
        string="Request Name",
        compute="_compute_name",
        store=True,
    )
    is_fund_available = fields.Boolean(string="Amount Available")
    is_fund_not_available = fields.Boolean(string="Amount Not Available")
    show_approve_available_button = fields.Boolean(compute="_compute_manager_approve_visibility")
    show_approve_unavailable_button = fields.Boolean(compute="_compute_manager_approve_visibility")
    show_reject_available_button = fields.Boolean(compute='_compute_reject_buttons_visibility',
                                                  string="Show Reject (Avail.)")
    show_reject_unavailable_button = fields.Boolean(compute='_compute_reject_buttons_visibility',
                                                    string="Show Reject (Unavail.)")
    # ---- Reject buttons visibility (new) ----
    show_reject_main_button = fields.Boolean(
        compute='_compute_reject_buttons_visibility', string="Show Reject (Main)")
    show_reject_tender_button = fields.Boolean(
        compute='_compute_reject_buttons_visibility', string="Show Reject (Tender)")
    show_reject_purchase_button = fields.Boolean(
        compute='_compute_reject_buttons_visibility', string="Show Reject (Purchase)")
    show_reject_direct_button = fields.Boolean(
        compute='_compute_reject_buttons_visibility', string="Show Reject (Direct)")

    installment_line_ids = fields.One2many(
        'installment.line', 'request_id', string='Installment Lines'
    )
    show_button_available = fields.Boolean(
        string="Show Button Available", compute="_compute_show_button_available")

    show_button_unavailable = fields.Boolean(
        string="Show Button Unavailable", compute="_compute_show_button_available")


    show_button_tender = fields.Boolean(
        string="Show Button Tender",
        compute="_compute_show_button_tender",
    )
    show_button_purchase = fields.Boolean(
        string="Show Button Purchase",
        compute="_compute_show_button_purchase",
    )

    show_button_direct_assign = fields.Boolean(
        string="Show Button Direct Assignment",
        compute="_compute_show_button_direct_assign",
    )

    show_button_approve_main = fields.Boolean(
        string="Show Button Approve Main",
        compute="_compute_show_button_approve_main",
    )

    available_stage_ids = fields.Many2many(
        'ad.internal.request.stage',
        compute='_compute_available_stages',
        string='Available Stages',
        store=True,
    )
    show_special_tender_button = fields.Boolean(
        string='Show Special Tender Button',
        compute='_compute_show_special_tender_button'
    )
    show_special_delivery_po_button = fields.Boolean(
        string='Show Special delivery po  Button',
        compute='_compute_show_special_delivery_po_button'
    )
    show_special_direct_button = fields.Boolean(
        string='Show Special Direct Assignment Button',
        compute='_compute_show_special_direct_button'
    )
    show_special_available_button = fields.Boolean(
        string='Show Special Available Button',
        compute='_compute_show_special_available_button'
    )
    show_special_unavailable_button = fields.Boolean(
        string='Show Special Unavailable Button',
        compute='_compute_show_special_unavailable_button'
    )

    tender_stage_id = fields.Many2one('ad.internal.request.sub.stage.line', domain="[('id', 'in', tender_stage_ids)]", )
    tender_stage_ids = fields.Many2many(
        'ad.internal.request.sub.stage.line',
        'ad_internal_request_tender_stage_rel',
        'request_id',
        'stage_id',
        string='Tender Stages',
    )

    purchase_stage_id = fields.Many2one('ad.internal.request.sub.stage.line',
                                        domain="[('id', 'in', purchase_stage_ids)]", )
    purchase_stage_ids = fields.Many2many(
        'ad.internal.request.sub.stage.line',
        'ad_internal_request_purchase_stage_rel',
        'request_id',
        'stage_id',
        string='purchase Stages',
    )
    available_id_stage_id = fields.Many2one('ad.internal.request.sub.stage.line',
                                            domain="[('id', 'in', available_id_stage_ids)]", )
    available_id_stage_ids = fields.Many2many(
        'ad.internal.request.sub.stage.line',
        'ad_internal_request_available_stage_rel',
        'request_id',
        'stage_id',
        string='Available Stages',
    )
    unavailable_id_stage_id = fields.Many2one('ad.internal.request.sub.stage.line',
                                              domain="[('id', 'in', unavailable_id_stage_ids)]", )
    unavailable_id_stage_ids = fields.Many2many(
        'ad.internal.request.sub.stage.line',
        'ad_internal_request_unavailable_stage_rel',
        'request_id',
        'stage_id',
        string='Unavailable Stages',
    )

    direct_assignment_stage_ids = fields.Many2many(
        'ad.internal.request.sub.stage.line',
        'ad_internal_request_direct_assignment_stage_rel',
        'request_id',
        'stage_id',
        string='Direct Assignment Stages',

    )

    online_request_id = fields.Many2one(
        'online.request', string="Online Request", copy=False, readonly=True
    )
    show_create_online_request_button = fields.Boolean(
        string="Show 'Create Online Request' Button",
        compute='_compute_show_create_online_request_button'
    )
    direct_assignment_stage_id = fields.Many2one('ad.internal.request.sub.stage.line',
                                                 domain="[('id', 'in', direct_assignment_stage_ids)]", )

    stage_id = fields.Many2one(
        'ad.internal.request.stage',
        string="Current Stage",
        domain="[('id', 'in', available_stage_ids)]",
        copy=False,
    )

    is_approved = fields.Boolean(string="Is Approved", default=False)
    contract_type_description = fields.Text(string="Contract Type Notes", tracking=True)
    show_contract_type_field = fields.Boolean(
        string="Show Contract Type Field",
        compute="_compute_show_contract_type_field"
    )

    @api.depends(
        # main stage
        'stage_id',
        'request_type_id.approver_line_ids.stage_id',
        'request_type_id.approver_line_ids.is_contract_type',
        'tender_stage_id.is_contract_type',
        'purchase_stage_id.is_contract_type',
        'direct_assignment_stage_id.is_contract_type',
        'available_id_stage_id.is_contract_type',
        'unavailable_id_stage_id.is_contract_type',
    )
    def _compute_show_contract_type_field(self):
        for rec in self:
            show = False

            if rec.request_type_id and rec.stage_id:
                main_lines = rec.request_type_id.approver_line_ids.filtered(
                    lambda l: l.stage_id == rec.stage_id
                )
                show = any(main_lines.mapped('is_contract_type'))

            if not show:
                current_subs = [
                    rec.tender_stage_id,
                    rec.purchase_stage_id,
                    rec.direct_assignment_stage_id,
                    rec.available_id_stage_id,
                    rec.unavailable_id_stage_id,
                ]
                show = any(s and s.is_contract_type for s in current_subs)

            rec.show_contract_type_field = bool(show)

    sub_stage_selected = fields.Many2one(
        'ad.internal.request.type',
        string='Selected Request Type Stage',
    )

    tender_id = fields.Many2one('ad.internal.request.type')
    direct_assignment_id = fields.Many2one('ad.internal.request.type', )

    request_type_id = fields.Many2one(
        'ad.internal.request.type',
        string='Request Type',
        required=True,
        domain="[('internal_request', '=', True)]"
    )
    user_id = fields.Many2one('res.users', string='Requestor', default=lambda self: self.env.user)
    date_order = fields.Date(string='Request Date', default=fields.Date.context_today)
    employee_id = fields.Many2one(
        'hr.employee',
        string='Employee',
        compute='_compute_employee_id',
        store=True,
        readonly=False
    )

    sub_stage_id = fields.Many2one(
        'ad.internal.request.stage',
        string="Current Stage",
        # domain="[('id', 'in', available_sub_stage_ids)]"

    )
    currency_id = fields.Many2one(
        'res.currency',
        string="Currency",
        default=lambda self: self.env.company.currency_id
    )
    product_line_ids = fields.One2many('request.product.lines', 'request_id', string='Requested Products')

    approval_ids = fields.One2many('ad.internal.request.approval', 'request_id', string='Approvals')

    can_approve = fields.Boolean(string="Can Approve", compute="_compute_can_approve")

    can_create_direct_assignment = fields.Boolean(compute='_compute_button_visibility')
    can_create_entry_items = fields.Boolean(compute='_compute_button_visibility')

    ref = fields.Char(string='Reference', readonly=True, copy=False)

    direct_assignment_count = fields.Integer(string="Direct Assignments", compute='_compute_related_counts')

    stage_required_complete_ids = fields.One2many(
        'ad.stage.required.complete',
        'request_id',
        string='Stage Required Completes'
    )

    current_stages_working = fields.Selection([('main', 'Main Stage'),
                                               ('tender', 'Tender'),
                                               ('purchase', 'Purchase'),
                                               ('direct_assignment', 'Direct Assignment'),
                                               ('available', 'Available'),
                                               ('unavailable', 'Unavailable'),
                                               ],
                                              string='Current Stages Working',
                                              compute='_compute_current_stages_working',
                                              default='main')

    is_same_stage_complete = fields.Boolean(compute='_compute_is_same_stage_complete', string="Is Same Stage Complete")
    description = fields.Text(string="Description")



    delivery_order_count = fields.Integer(string="Delivery Orders", compute="_compute_delivery_order_count")

    show_special_payment_tender_button = fields.Boolean(
        string='Show Special Payment Tender Button',
        compute='_compute_show_special_payment_tender_button'
    )

    show_special_payment_po_button = fields.Boolean(
        string='Show Special Payment Tender Button',
        compute='_compute_show_special_payment_po_button'
    )

    show_special_payment_direct_button = fields.Boolean(
        string='Show Special Payment Direct Button',
        compute='_compute_show_special_payment_direct_button'
    )
    show_special_payment_available_button = fields.Boolean(
        string='Show Special Payment Available Button',
        compute='_compute_show_special_payment_available_button'
    )
    show_special_payment_unavailable_button = fields.Boolean(
        string='Show Special Payment Unavailable Button',
        compute='_compute_show_special_payment_unavailable_button')

    show_special_po_tender_button = fields.Boolean(
        string='Show Special PO Tender Button',
        compute='_compute_show_special_po_tender_button'
    )
    show_special_po_direct_button = fields.Boolean(
        string='Show Special PO Direct Button',
        compute='_compute_show_special_po_direct_button'
    )
    show_special_po_available_button = fields.Boolean(
        string='Show Special PO Available Button',
        compute='_compute_show_special_po_available_button'
    )
    show_special_po_unavailable_button = fields.Boolean(
        string='Show Special PO Unavailable Button',
        compute='_compute_show_special_po_unavailable_button'
    )

    show_special_installments_tender_button = fields.Boolean(
        string='Show Special Installments Tender Button',
        compute='_compute_show_special_installments_tender_button'
    )
    show_special_installments_direct_button = fields.Boolean(
        string='Show Special Installments Direct Button',
        compute='_compute_show_special_installments_direct_button'
    )
    show_special_installments_available_button = fields.Boolean(
        string='Show Special Installments Available Button',
        compute='_compute_show_special_installments_available_button'
    )
    show_special_installments_unavailable_button = fields.Boolean(
        string='Show Special Installments Unavailable Button',
        compute='_compute_show_special_installments_unavailable_button'
    )
    show_installments_tab = fields.Boolean(
        string="Show Installments Tab",
        compute="_compute_show_installments_tab"
    )
    analytic_entry_count = fields.Integer(string="Analytic Entries", compute='_compute_related_counts')
    online_request_count = fields.Integer(
        string="Online Requests",
        compute='_compute_related_counts',
    )
    show_fund_fields = fields.Boolean(
        string="Show Fund Fields",
        compute="_compute_show_fund_fields",
        store=False,
    )
    show_partner_info_page = fields.Boolean(
        string="Show Partner Info Page",
        compute='_compute_show_partner_info_page'
    )
    partner_id = fields.Many2one('res.partner', string="Partner")
    partner_phone = fields.Char(string="Partner Phone")
    partner_mobile = fields.Char(string="Partner Mobile")
    partner_email = fields.Char(string="Partner Email")
    partner_name = fields.Char(string="Partner Name")


    show_delivery_button = fields.Boolean(compute="_compute_main_stage_action_buttons", string="Show Delivery")
    show_payment_button = fields.Boolean(compute="_compute_main_stage_action_buttons", string="Show Payment")
    show_po_button = fields.Boolean(compute="_compute_main_stage_action_buttons", string="Show PO")
    show_installments_button = fields.Boolean(compute="_compute_main_stage_action_buttons", string="Show Installments")

    stage_is_available = fields.Boolean(
        string="Stage Is Available",
        related='stage_id.is_available',
        store=False, readonly=True)

    stage_is_unavailable = fields.Boolean(
        string="Stage Is Unavailable",
        related='stage_id.is_unavailable',
        store=False, readonly=True)

    stage_is_tender = fields.Boolean(
        string="Stage Is Tender",
        related='stage_id.show_tender',
        store=False)

    stage_is_purchase = fields.Boolean(
        string="Stage Is Purchase",
        related='stage_id.show_purchase',
        store=False)

    stage_is_direct_assign = fields.Boolean(
        string="Stage Is Direct Assignment",
        related='stage_id.show_direct_assign',
        store=False)


    @api.depends(
        # main stage
        'stage_id',
        'request_type_id.approver_line_ids.stage_id',
        'request_type_id.approver_line_ids.is_reminder',
        'tender_stage_id.is_reminder',
        'purchase_stage_id.is_reminder',
        'direct_assignment_stage_id.is_reminder',
        'available_id_stage_id.is_reminder',
        'unavailable_id_stage_id.is_reminder',
    )
    def _compute_show_fund_fields(self):
        for rec in self:
            show = False

            if rec.request_type_id and rec.stage_id:
                main_lines = rec.request_type_id.approver_line_ids.filtered(
                    lambda l: l.stage_id == rec.stage_id
                )
                show = any(main_lines.mapped('is_reminder'))

            if not show:
                current_subs = [
                    rec.tender_stage_id,
                    rec.purchase_stage_id,
                    rec.direct_assignment_stage_id,
                    rec.available_id_stage_id,
                    rec.unavailable_id_stage_id,
                ]
                show = any(s and s.is_reminder for s in current_subs)

            rec.show_fund_fields = bool(show)

    # def _is_current_user_allowed_here(self):
    #     """يسمح لو اليوزر الحالي موجود في user_ids للـ main stage line أو السطر الفرعي المختار."""
    #     self.ensure_one()
    #     u = self.env.user
    #     print(f"\n👤 Checking user: {u.name} (ID: {u.id})")
    #
    #     # Check sub stages first
    #     sub_stages = {
    #         'available': self.available_id_stage_id,
    #         'unavailable': self.unavailable_id_stage_id,
    #         'tender': self.tender_stage_id,
    #         'purchase': self.purchase_stage_id,
    #         'direct_assignment': self.direct_assignment_stage_id,
    #     }
    #
    #     found_sub = False
    #     for label, sub in sub_stages.items():
    #         if sub:
    #             print(f"🔍 Sub-stage [{label}] = {sub.name} ➤ Users: {[user.name for user in sub.user_ids]}")
    #         if sub and u in sub.user_ids:
    #             print(f"✅ User is allowed via sub-stage: {label} ({sub.name})")
    #             return True
    #             found_sub = True
    #
    #     # Check main stage (only if no sub-stage matched)
    #     if self.request_type_id and self.stage_id:
    #         lines = self.request_type_id.approver_line_ids.filtered(
    #             lambda l: l.stage_id == self.stage_id and u in l.user_ids
    #         )
    #         print(f"🔍 Main stage: {self.stage_id.name} for request type: {self.request_type_id.name}")
    #         if lines:
    #             print(f"✅ Main stage match found: True => Lines: {[l.stage_id.name for l in lines]}")
    #             return True
    #         else:
    #             print("❌ Main stage match not found.")
    #
    #     print("❌ User is NOT allowed via any stage.")
    #     return False
    def _is_current_user_allowed_here(self):
        """يسمح فقط لو اليوزر الحالي موجود في الـ stage أو sub-stage الحالي (حسب current_stages_working)."""
        self.ensure_one()
        u = self.env.user
        print(f"\n👤 Checking user: {u.name} (ID: {u.id}) | Current = {self.current_stages_working}")

        # خريطة stages
        stage_map = {
            'available': self.available_id_stage_id,
            'unavailable': self.unavailable_id_stage_id,
            'tender': self.tender_stage_id,
            'purchase': self.purchase_stage_id,
            'direct_assignment': self.direct_assignment_stage_id,
            'main': self.stage_id,
        }

        current_stage = stage_map.get(self.current_stages_working)
        if not current_stage:
            print("❌ No current stage found.")
            return False

        # ✅ MAIN STAGE
        if self.current_stages_working == "main":
            if not (self.request_type_id and self.stage_id):
                print("❌ Missing request_type_id or stage_id.")
                return False

            # نحضر كل approver lines الخاصة بالمرحلة الحالية
            lines = self.request_type_id.approver_line_ids.filtered(lambda l: l.stage_id == self.stage_id)
            if not lines:
                print("⚠️ No approver lines for this stage.")
                return False

            for line in lines:
                # ✅ نجيب كل المستخدمين الحقيقيين من الـ flags
                approver_users = self._approval_targets_from_line(line)
                print(f"👥 Approver users for line {line.stage_id.name}: {[u.name for u in approver_users]}")

                # نتحقق هل المستخدم الحالي واحد منهم
                if u in approver_users:
                    print(f"✅ User {u.name} allowed via approver line {line.stage_id.name}")
                    return True

            print(f"❌ Main stage match not found for user {u.name}")
            return False

        # ✅ باقي الـ sub-stages
        if u in current_stage.user_ids:
            print(f"✅ User {u.name} is allowed in {self.current_stages_working} stage ({current_stage.name})")
            return True

        print(f"❌ User {u.name} not found in {self.current_stages_working} stage users: "
              f"{[usr.name for usr in current_stage.user_ids]}")
        return False

    def _assert_current_user_allowed_here(self):
        self.ensure_one()
        if not self._is_current_user_allowed_here():
            raise UserError(_("غير مسموح لك بتنفيذ هذا الإجراء."))

    def _compute_related_counts(self):
        for rec in self:
            rec.direct_assignment_count = self.env['ad.direct.assignment'].search_count([('request_id', '=', rec.id)])
            rec.analytic_entry_count = self.env['account.analytic.line'].search_count([('request_id', '=', rec.id)])
            rec.online_request_count = self.env['online.request'].search_count([('internal_request_id', '=', rec.id)])

    def action_view_online_requests(self):
        self.ensure_one()
        domain = [('internal_request_id', '=', self.id)]
        action = {
            'type': 'ir.actions.act_window',
            'name': _('Online Requests'),
            'res_model': 'online.request',
            'view_mode': 'tree,form',
            'domain': domain,
            'context': {'default_internal_request_id': self.id},
            'target': 'current',
        }

        return action


    def _compute_is_same_stage_complete(self):
        for rec in self:
            rec.is_same_stage_complete = False
            if not rec.stage_id:
                continue

            required_lines = rec.stage_required_complete_ids.filtered(
                lambda l: l.stage_id == rec.stage_id and l.state == 'complete'
            )


            rec.is_same_stage_complete = required_lines

    @api.depends(
        'online_request_id',
        'stage_id',
        'request_type_id.approver_line_ids',
        'request_type_id.approver_line_ids.stage_id',
        'request_type_id.approver_line_ids.is_create_request',
        'tender_stage_id.is_create_request',
        'purchase_stage_id.is_create_request',
        'direct_assignment_stage_id.is_create_request',
        'available_id_stage_id.is_create_request',
        'unavailable_id_stage_id.is_create_request',
    )
    def _compute_show_create_online_request_button(self):
        for rec in self:

            flag = False
            if rec.request_type_id and rec.stage_id:
                lines = rec.request_type_id.approver_line_ids.filtered(lambda l: l.stage_id == rec.stage_id)
                if lines:
                    flag = any(lines.mapped('is_create_request'))

            if (rec.tender_stage_id and rec.tender_stage_id.is_create_request) \
                    or (rec.purchase_stage_id and rec.purchase_stage_id.is_create_request) \
                    or (rec.direct_assignment_stage_id and rec.direct_assignment_stage_id.is_create_request) \
                    or (rec.available_id_stage_id and rec.available_id_stage_id.is_create_request) \
                    or (rec.unavailable_id_stage_id and rec.unavailable_id_stage_id.is_create_request):
                flag = True

            rec.show_create_online_request_button = bool(flag)

    def action_create_online_request(self):
        """يُنشئ Online Request من هذا الطلب ويضيف له خطوط المنتجات."""
        self.ensure_one()

        if not self.product_line_ids:
            raise UserError(_("لا توجد منتجات في هذا الطلب."))

        default_stage = self.env['online.request.stage.approve'].search([('is_default', '=', True)], limit=1)

        req_vals = {
            'name': self.name or self.ref or _("Online Request"),
            'internal_request_id': self.id,
            'description': _("Generated from Internal Request %s") % (self.name or self.id),
        }
        if default_stage:
            req_vals['stage_approve_id'] = default_stage.id  # هنا بنحط الديفولت

        online_req = self.env['online.request'].create(req_vals)

        Line = self.env['online.request.line']
        for ln in self.product_line_ids:
            if not ln.product_id:
                continue
            Line.create({
                'request_id': online_req.id,
                'product_id': ln.product_id.id,
                'quantity': int(ln.product_qty or 1),
            })

        self.online_request_id = online_req.id

        return {
            'type': 'ir.actions.act_window',
            'name': _('Online Request'),
            'res_model': 'online.request',
            'res_id': online_req.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_view_analytic_entries(self):
        self.ensure_one()
        return {
            'name': _('Analytic Entries'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.analytic.line',
            'view_mode': 'tree,form',
            'domain': [('request_id', '=', self.id)],
            'context': {'default_request_id': self.id},
        }

    @api.constrains('product_line_ids', 'request_type_id')
    def _check_max_total_lines(self):
        for rec in self:
            print("---- START CONSTRAINT CHECK ----")
            print(f"Record ID: {rec.id}")
            print(f"Request Type: {rec.request_type_id and rec.request_type_id.name}")
            print(
                f"Request Type Max Total Lines: {rec.request_type_id.max_total_lines if rec.request_type_id else 'N/A'}")
            print(f"Product Lines Count: {len(rec.product_line_ids)}")
            for l in rec.product_line_ids:
                print(
                    f"  > Product Line ID: {l.id}, Product: {l.product_id and l.product_id.display_name}, SUBTOTAL: {l.price_subtotal}")
            if rec.request_type_id and rec.request_type_id.max_total_lines:
                total_price = sum(line.price_subtotal for line in rec.product_line_ids)
                print(f"Total Price: {total_price}")
                if total_price > rec.request_type_id.max_total_lines:
                    print(">>> RAISING ValidationError <<<")
                    raise ValidationError(
                        _("المبلغ الإجمالي (%s) يتجاوز الحد الأقصى المسموح به (%s) لنوع الطلب المحدد. من فضلك اختر نوع طلب آخر.")
                        % (total_price, rec.request_type_id.max_total_lines)
                    )
            print("---- END CONSTRAINT CHECK ----")


    @api.depends(
        'stage_id',
        'request_type_id.approver_line_ids',
        'request_type_id.approver_line_ids.stage_id',
        'request_type_id.approver_line_ids.show_partner_page',
        'tender_stage_ids.show_partner_page', 'tender_stage_id.show_partner_page',
        'purchase_stage_ids.show_partner_page', 'purchase_stage_id.show_partner_page',
        'direct_assignment_stage_ids.show_partner_page', 'direct_assignment_stage_id.show_partner_page',
        'available_id_stage_ids.show_partner_page', 'available_id_stage_id.show_partner_page',
        'unavailable_id_stage_ids.show_partner_page', 'unavailable_id_stage_id.show_partner_page',
    )
    def _compute_show_partner_info_page(self):
        for rec in self:
            show = False

            # 1) من اللاينز بتوع ال Main stage
            if rec.request_type_id and rec.stage_id:
                main_lines = rec.request_type_id.approver_line_ids.filtered(
                    lambda l: l.stage_id.id == rec.stage_id.id
                )
                show = any(main_lines.mapped('show_partner_page'))

            if not show:
                show = (
                        any(rec.tender_stage_ids.mapped('show_partner_page')) or
                        any(rec.purchase_stage_ids.mapped('show_partner_page')) or
                        any(rec.direct_assignment_stage_ids.mapped('show_partner_page')) or
                        any(rec.available_id_stage_ids.mapped('show_partner_page')) or
                        any(rec.unavailable_id_stage_ids.mapped('show_partner_page'))
                )

            if not show:
                current_subs = [
                    rec.tender_stage_id,
                    rec.purchase_stage_id,
                    rec.direct_assignment_stage_id,
                    rec.available_id_stage_id,
                    rec.unavailable_id_stage_id,
                ]
                show = any(s and s.show_partner_page for s in current_subs)

            rec.show_partner_info_page = show

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        for rec in self:
            if rec.partner_id:
                rec.partner_name = rec.partner_id.name
                rec.partner_phone = rec.partner_id.phone
                rec.partner_mobile = rec.partner_id.mobile
                rec.partner_email = rec.partner_id.email
            else:
                rec.partner_name = False
                rec.partner_phone = False
                rec.partner_mobile = False
                rec.partner_email = False

    @api.depends('installment_line_ids')
    def _compute_show_installments_tab(self):
        for rec in self:
            rec.show_installments_tab = bool(rec.installment_line_ids)

    def action_open_installments_wizard(self):
        self.ensure_one()
        self._assert_current_user_allowed_here()

        return {
            'type': 'ir.actions.act_window',
            'name': _('Installments'),
            'res_model': 'ad.installments.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
            },
        }

    @api.depends('tender_stage_ids.is_selected_installments')
    def _compute_show_special_installments_tender_button(self):
        for rec in self:
            rec.show_special_installments_tender_button = any(
                line.is_selected_installments for line in rec.tender_stage_ids)

    @api.depends('direct_assignment_stage_ids.is_selected_installments')
    def _compute_show_special_installments_direct_button(self):
        for rec in self:
            rec.show_special_installments_direct_button = any(
                line.is_selected_installments for line in rec.direct_assignment_stage_ids)

    @api.depends('available_id_stage_ids.is_selected_installments')
    def _compute_show_special_installments_available_button(self):
        for rec in self:
            rec.show_special_installments_available_button = any(
                line.is_selected_installments for line in rec.available_id_stage_ids)

    @api.depends('unavailable_id_stage_ids.is_selected_installments')
    def _compute_show_special_installments_unavailable_button(self):
        for rec in self:
            rec.show_special_installments_unavailable_button = any(
                line.is_selected_installments for line in rec.unavailable_id_stage_ids)

    purchase_order_count = fields.Integer(string="Purchase Orders", compute="_compute_purchase_order_count")

    @api.depends('name')
    def _compute_purchase_order_count(self):
        for rec in self:
            rec.purchase_order_count = self.env['purchase.order'].search_count([
                ('origin', '=', rec.name)
            ])

    def action_view_purchase_orders(self):
        self.ensure_one()
        action = self.env.ref('purchase.purchase_rfq').read()[0]
        action['domain'] = [('origin', '=', self.name)]
        action['context'] = {'default_origin': self.name}
        return action

    @api.depends('purchase_stage_id.is_selected_po')
    def _compute_show_special_po_tender_button(self):
        for rec in self:
            rec.show_special_po_tender_button = bool(rec.purchase_stage_id and rec.purchase_stage_id.is_selected_po)
            print("test",rec.show_special_po_tender_button)

    @api.depends('direct_assignment_stage_id.is_selected_po')
    def _compute_show_special_po_direct_button(self):
        for rec in self:
            rec.show_special_po_direct_button = bool(
                rec.direct_assignment_stage_id and rec.direct_assignment_stage_id.is_selected_po)

    @api.depends('available_id_stage_id.is_selected_po')
    def _compute_show_special_po_available_button(self):
        for rec in self:
            rec.show_special_po_available_button = bool(
                rec.available_id_stage_id and rec.available_id_stage_id.is_selected_po)

    @api.depends('unavailable_id_stage_id.is_selected_po')
    def _compute_show_special_po_unavailable_button(self):
        for rec in self:
            rec.show_special_po_unavailable_button = bool(
                rec.unavailable_id_stage_id and rec.unavailable_id_stage_id.is_selected_po)

    @api.depends('tender_stage_id.is_selected_payment')
    def _compute_show_special_payment_tender_button(self):
        for rec in self:
            rec.show_special_payment_tender_button = bool(
                rec.tender_stage_id and rec.tender_stage_id.is_selected_payment)

    @api.depends('purchase_stage_id.is_selected_payment')
    def _compute_show_special_payment_po_button(self):
        for rec in self:
            rec.show_special_payment_po_button = bool(
                rec.purchase_stage_id and rec.purchase_stage_id.is_selected_payment)

    @api.depends('direct_assignment_stage_id.is_selected_payment')
    def _compute_show_special_payment_direct_button(self):
        for rec in self:
            rec.show_special_payment_direct_button = bool(
                rec.direct_assignment_stage_id and rec.direct_assignment_stage_id.is_selected_payment)

    @api.depends('available_id_stage_id.is_selected_payment')
    def _compute_show_special_payment_available_button(self):
        for rec in self:
            rec.show_special_payment_available_button = bool(
                rec.available_id_stage_id and rec.available_id_stage_id.is_selected_payment)

    @api.depends('unavailable_id_stage_id.is_selected_payment')
    def _compute_show_special_payment_unavailable_button(self):
        for rec in self:
            rec.show_special_payment_unavailable_button = bool(
                rec.unavailable_id_stage_id and rec.unavailable_id_stage_id.is_selected_payment)

    def action_create_payment(self):
        for rec in self:
            # rec._assert_current_user_allowed_here()

            employee = self.env['hr.employee'].search([('user_id', '=', rec.user_id.id)], limit=1)
            if not employee or not employee.stock_warehouse_id:
                raise UserError(_("لا يوجد مخزن مرتبط بمقدم الطلب."))

            allowed_users = employee.stock_warehouse_id.user_ids
            if self.env.user not in allowed_users:
                raise UserError(
                    _("أنت غير مصرح لك بإنشاء دفعة لهذا الطلب. فقط المستخدمين المصرّح لهم في المخزن يمكنهم تنفيذ هذا الإجراء."))

            # فحص وجود دفعة حالية
            active_payments = self.env['account.payment'].search([
                ('ref', '=', rec.name or rec.ref),
                ('state', 'in', ['draft', 'posted'])
            ])
            if active_payments:
                details = ", ".join(["%s[%s]" % (p.name or p.id, p.state) for p in active_payments])
                raise UserError(_(
                    "لا يمكن إنشاء دفعة جديدة لهذا الطلب لأن هناك دفعة موجودة بالفعل بحالة Draft/Posted.\n"
                    "المدفوعات الحالية: %s\n"
                    "يُسمح بإنشاء دفعة جديدة فقط بعد إلغاء (Cancel) كل الدفعات السابقة لهذا الطلب."
                ) % details)

            # التحقق من وجود Partner
            partner = rec.user_id.partner_id
            if not partner:
                raise UserError(_("المستخدم ليس له شريك (partner) مرتبط."))

            # التحقق من المبلغ
            total_amount = sum(line.price_subtotal for line in rec.product_line_ids)
            if total_amount <= 0:
                raise UserError(_("مبلغ الدفع يجب أن يكون أكبر من صفر."))

            vals = {
                'payment_type': 'outbound',
                'partner_type': 'customer',
                'partner_id': partner.id,
                'amount': total_amount,
                'currency_id': rec.currency_id.id,
                'date': fields.Date.context_today(self),
                'ref': rec.name or rec.ref,
            }

            journal = employee.stock_warehouse_id.journal_id if employee.stock_warehouse_id else False
            if journal:
                vals['journal_id'] = journal.id

            payment = self.env['account.payment'].create(vals)

            return {
                'type': 'ir.actions.act_window',
                'name': _('Payment'),
                'res_model': 'account.payment',
                'res_id': payment.id,
                'view_mode': 'form',
                'target': 'current',
                'context': {'default_ref': rec.name or rec.ref},
            }

    @api.depends(
        'stage_id',
        'request_type_id.approver_line_ids',
        'request_type_id.approver_line_ids.stage_id',
        'request_type_id.approver_line_ids.is_selected',
        'request_type_id.approver_line_ids.is_selected_payment',
        'request_type_id.approver_line_ids.is_selected_po',
        'request_type_id.approver_line_ids.is_selected_installments',
        'request_type_id.approver_line_ids.user_ids',
    )
    def _compute_main_stage_action_buttons(self):
        for rec in self:
            rec.show_delivery_button = False
            rec.show_payment_button = False
            rec.show_po_button = False
            rec.show_installments_button = False

            if not rec.request_type_id or not rec.stage_id:
                continue

            lines = rec.request_type_id.approver_line_ids.filtered(
                lambda l: l.stage_id.id == rec.stage_id.id
            )

            if not lines:
                continue

            allowed_lines = lines.filtered(
                lambda l: self.env.user in l.user_ids
            )

            if not allowed_lines:
                continue

            rec.show_delivery_button = any(allowed_lines.mapped('is_selected'))
            rec.show_payment_button = any(allowed_lines.mapped('is_selected_payment'))
            rec.show_po_button = any(allowed_lines.mapped('is_selected_po'))
            rec.show_installments_button = any(allowed_lines.mapped('is_selected_installments'))

    payment_count = fields.Integer(string="Payments", compute="_compute_payment_count")

    @api.constrains('installment_line_ids', 'product_line_ids')
    def _check_installments_total(self):
        for rec in self:
            if not rec.installment_line_ids:
                continue
            total_installments = sum(line.amount for line in rec.installment_line_ids)
            total_products = sum(line.price_subtotal for line in rec.product_line_ids)
            reminder = total_products - total_installments
            if round(total_installments, 2) != round(total_products, 2):
                raise ValidationError(_(
                    "إجمالي الدفعات (%.2f) لا يساوي إجمالي الطلب (%.2f).\n"
                    "المتبقي (Reminder): %.2f\n"
                    "يجب ضبط الدفعات بحيث تساوي الإجمالي بالضبط قبل الحفظ."
                ) % (total_installments, total_products, reminder))

    @api.depends('name')
    def _compute_payment_count(self):
        for rec in self:
            rec.payment_count = self.env['account.payment'].search_count([
                ('ref', '=', rec.name)
            ])

    def action_view_payments(self):
        self.ensure_one()
        action = self.env.ref('account.action_account_payments').read()[0]
        action['domain'] = [('ref', '=', self.name)]
        action['context'] = {'default_ref': self.name}
        return action

    @api.depends('name')
    def _compute_delivery_order_count(self):
        for rec in self:
            rec.delivery_order_count = self.env['stock.picking'].search_count([
                ('origin', '=', rec.name)
            ])

    def action_view_delivery_orders(self):
        self.ensure_one()
        action = self.env.ref('stock.action_picking_tree_all').read()[0]
        action['domain'] = [('origin', '=', self.name)]
        action['context'] = {'default_origin': self.name}
        return action

    @api.constrains('product_line_ids')
    def _check_product_lines_not_empty(self):
        for rec in self:
            if not rec.product_line_ids:
                raise ValidationError(_("يجب إضافة منتج واحد على الأقل قبل الحفظ!"))

    def _available_tender_stages(self):
        self.tender_stage_ids = self.stage_id.tender_request_type_id.approver_sub_line_ids.ids
        self.tender_stage_id = self.tender_stage_ids.sorted('id')[
            0].id if self.tender_stage_ids else False

    def _available_purchase_stages(self):
        self.purchase_stage_ids = self.stage_id.purchase_request_type_id.approver_sub_line_ids.ids
        self.purchase_stage_id = self.purchase_stage_ids.sorted('id')[
            0].id if self.purchase_stage_ids else False

    def _available_direct_assignment_stages(self):
        self.direct_assignment_stage_ids = self.stage_id.direct_assign_request_type_id.approver_sub_line_ids.ids
        self.direct_assignment_stage_id = self.direct_assignment_stage_ids.sorted('id')[
            0] if self.direct_assignment_stage_ids else False

    # def _compute_related_counts(self):
    #     for rec in self:
    #         rec.direct_assignment_count = self.env['ad.direct.assignment'].search_count([('request_id', '=', rec.id)])
    #         rec.analytic_entry_count = self.env['account.analytic.line'].search_count([('request_id', '=', rec.id)])

    def action_view_direct_assignments(self):
        self.ensure_one()
        return {
            'name': _('Direct Assignments'),
            'type': 'ir.actions.act_window',
            'res_model': 'ad.direct.assignment',
            'view_mode': 'tree,form',
            'domain': [('request_id', '=', self.id)],
            'context': {'default_request_id': self.id},
        }

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            today = datetime.today()
            date_str = f"{today.year % 100:02d}{today.month:02d}{today.day:02d}"
            req_type = vals.get('request_type_id') and self.env['ad.internal.request.type'].browse(
                vals['request_type_id'])
            code_val = req_type.code or '' if req_type else ''
            seq = self.env['ir.sequence'].next_by_code('ad.internal.request') or '000'
            vals['ref'] = f"{code_val}-{date_str}-{seq}"
            employee_id = self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1)
            vals['employee_id'] = employee_id.id if employee_id else False
        records = super().create(vals_list)
        # 👇 ما نبعّتش Activities عند الإنشاء (أول مرحلة افتراضية)
        # لو محتاجين نجرب في سيناريو معيّن، ابعتوا context={'schedule_on_create': True}
        # if self._context.get('schedule_on_create'):
        #     for rec in records:
        #         rec._schedule_stage_activities()
        return records

    def _mark_my_todos_done(self, feedback=_("تمت المعالجة")):
        self.ensure_one()
        rec = self.with_user(self.env.user.id)
        rec.activity_feedback(
            ['mail.mail_activity_data_todo'],
            user_id=self.env.user.id,
            feedback=feedback
        )

    def _schedule_stage_activities(self):
        self.ensure_one()
        deadline = fields.Date.context_today(self)
        targets = self._approval_targets('main')

        print(f"🟩 DEBUG: Scheduling Activities for {self.name or self.id}")
        print(f"🎯 Target Users: {[u.name for u in targets]}")

        for u in targets:
            self.activity_schedule(
                'mail.mail_activity_data_todo',
                user_id=u.id,
                summary=_('متابعة الطلب رقم %s') % (self.name or self.id),
                note=_('يرجى مراجعة الطلب رقم %s في المرحلة الرئيسية.') % (self.name or self.id),
                date_deadline=deadline,
            )

    @api.depends('stage_id', 'request_type_id')
    def _compute_button_visibility(self):
        """
        Compute the visibility of buttons based on stage and approver line boolean fields
        """
        for record in self:
            # Initialize all fields as False
            record.can_create_direct_assignment = False
            record.can_create_entry_items = False

            print(f"🟨 DEBUGGING: Checking button visibility for request {record.id}")
            print(f"🟨 DEBUGGING: Current stage: {record.stage_id.name if record.stage_id else 'N/A'}")
            print(f"🟨 DEBUGGING: Request type: {record.request_type_id.name if record.request_type_id else 'N/A'}")

            # Skip if no stage or request type
            if not record.stage_id or not record.request_type_id:
                print("❌ DEBUGGING: Missing stage_id or request_type_id, skipping")
                continue

            # Get approver lines for current stage
            approver_lines = record.request_type_id.approver_line_ids.filtered(
                lambda line: line.stage_id == record.stage_id
            )

            print(f"🟨 DEBUGGING: Found {len(approver_lines)} approver lines for current stage")

            for line in approver_lines:
                # print(f"🟨 DEBUGGING: Checking line for {line.user_id.name if line.user_id else 'N/A'}")
                # print(f"🟨 DEBUGGING: is_direct_assignment: {line.is_direct_assignment}")

                # if line.is_direct_assignment:
                #     record.can_create_direct_assignment = True
                #     print("✅ DEBUGGING: Can create direct assignment set to True")
                if line.is_entry_items:
                    record.can_create_entry_items = True
                    print("✅ DEBUGGING: Can create warehouse stage set to True")

            print(f"🟨 DEBUGGING: Final button visibility:")
            # print(f"🟨 DEBUGGING: can_create_direct_assignment: {record.can_create_direct_assignment}")

    @api.model
    def get_request_type_data(self):
        records = self.search([])
        data = {}
        for rec in records:
            if rec.request_type_id:
                name = rec.request_type_id.name
                data[name] = data.get(name, 0) + 1
        return {
            'labels': list(data.keys()),
            'values': list(data.values())
        }

    @api.model
    def get_top_products_by_request_count(self):
        product_counter = Counter()
        all_lines = self.env['request.product.lines'].search([])

        for line in all_lines:
            if line.product_id:
                product_counter[line.product_id.id] += 1

        top_products = product_counter.most_common(5)
        products = self.env['product.product'].browse([p[0] for p in top_products])
        result = []
        for prod in products:
            result.append({
                'id': prod.id,
                'name': prod.display_name,
                'count': product_counter[prod.id],
            })
        return result

    @api.model
    def get_top_requests_by_price(self):
        records = self.search([])
        top_records = sorted(
            records,
            key=lambda r: sum(line.price_unit * line.product_qty for line in r.product_line_ids),
            reverse=True
        )[:5]

        result = []
        for r in top_records:
            total = sum(line.price_unit * line.product_qty for line in r.product_line_ids)
            result.append({
                'id': r.id,
                # 'name': r.name,
                'total_price': total,
            })
        return result

    @api.model
    def get_top10_products_by_request_count(self):
        """أكثر 10 منتجات ظهورًا في خطوط طلبات الداخل (حسب مرات الظهور)."""
        product_counter = Counter()
        all_lines = self.env['request.product.lines'].sudo().search([])
        for line in all_lines:
            if line.product_id:
                product_counter[line.product_id.id] += 1

        top_products = product_counter.most_common(10)
        products = self.env['product.product'].browse([p[0] for p in top_products])
        result = []
        for prod in products:
            result.append({
                'id': prod.id,
                'name': prod.display_name,
                'count': product_counter[prod.id],
            })
        # نحافظ على نفس ترتيب most_common
        result.sort(key=lambda x: x['count'], reverse=True)
        return result

    @api.model
    def get_top10_requests_by_total_amount(self):
        """أعلى 10 طلبات داخلية إجمالاً حسب مجموع (price_unit * qty) عبر خطوط الطلب."""
        requests = self.search([])
        totals = {}
        for r in requests:
            total = 0.0
            for ln in r.product_line_ids:
                total += (ln.price_unit or 0.0) * (ln.product_qty or 0.0)
            totals[r.id] = total

        top_ids = sorted(totals.keys(), key=lambda rid: totals[rid], reverse=True)[:10]
        result = []
        for rid in top_ids:
            req = self.browse(rid)
            result.append({
                'id': req.id,
                'name': req.display_name or req.name or f"Request #{req.id}",
                'total_amount': totals[rid],
                'description': req.description or '',

            })
        return result

    def action_create_entry_items(self):
        AnalyticLine = self.env['account.analytic.line']
        created = self.env['account.analytic.line']
        for req in self:
            req._assert_current_user_allowed_here()

            print(f"Request: {req}")
            date = req.date_order or fields.Date.context_today(req)
            for line in req.product_line_ids:
                print(f"Line: {line}")
                analytic_dist = line.analytic_distribution
                print(f"  analytic_distribution: {analytic_dist}")
                if not analytic_dist:
                    print("   >> لا يوجد توزيع أنلاتيكي، تخطّي")
                    continue

                # لو التوزيع dict بالشكل {account_id: percent}
                if isinstance(analytic_dist, dict):
                    for acct_id, percent in analytic_dist.items():
                        print(f"   >> Entry: {acct_id} => {percent}")
                        try:
                            acct = int(acct_id)
                            pct = float(percent) / 100.0
                        except Exception:
                            print("   >> تجاهل هذا التوزيع لخطأ في الداتا")
                            continue

                        if not acct:
                            print("   >> لا يوجد account_id في هذا التوزيع")
                            continue

                        rec = AnalyticLine.create({
                            'name': req.ref,
                            'product_id': line.product_id.id,
                            'unit_amount': line.product_qty,
                            'amount': line.price_subtotal,
                            'product_uom_id': line.product_uom.id,
                            'account_id': acct,
                            'date': date,
                            'request_id': req.id,
                            'general_account_id': line.general_account_id.id,
                        })
                        print("   >> Created analytic line:", rec)
                        created |= rec

                # لو التوزيع list of dicts (نفس الكود القديم)
                elif isinstance(analytic_dist, list):
                    for entry in analytic_dist:
                        if isinstance(entry, str):
                            try:
                                entry = json.loads(entry)
                            except ValueError:
                                continue
                        if isinstance(entry, dict):
                            acct = entry.get('account_id')
                            pct = (entry.get('percent', entry.get('percentage', 0.0))) / 100.0
                        elif isinstance(entry, int):
                            acct = entry
                            pct = 1.0
                        else:
                            continue
                        if not acct:
                            continue
                        rec = AnalyticLine.create({
                            'name': req.ref,
                            'product_id': line.product_id.id,
                            'unit_amount': line.product_qty,
                            'amount': line.price_subtotal,
                            'product_uom_id': line.product_uom.id,
                            'account_id': acct,
                            'date': date,
                            'request_id': req.id,
                            'general_account_id': line.general_account_id.id,

                        })
                        print("   >> Created analytic line:", rec)
                        created |= rec
                else:
                    print("   >> شكل التوزيع غير مدعوم، تخطّي")

        tree_view_id = self.env.ref('analytic.view_account_analytic_line_tree').id
        form_view_id = self.env.ref('analytic.view_account_analytic_line_form').id

        print("Created Analytic Lines:", created)
        return {
            'type': 'ir.actions.act_window',
            'name': 'Analytic Items',
            'res_model': 'account.analytic.line',
            'view_mode': 'tree,form',
            'views': [(tree_view_id, 'tree'), (form_view_id, 'form')],
            'domain': [('id', 'in', created.ids)],
            'context': {'default_account_id': created and created[0].account_id.id if created else False},
            'target': 'current',
        }

    def action_create_direct_assignment(self):
        """Create a direct assignment record"""
        self.ensure_one()
        da_type = self.env['ad.internal.request.type'].search(
            [('direct_assignment', '=', True), ('default_type', '=', True)], limit=1
        )
        if not da_type:
            raise UserError(_('يرجى تكوين نوع طلب واحد على الأقل مع تفعيل التخصيص المباشر.'))

        lines_vals = []
        for line in self.product_line_ids:
            lines_vals.append((0, 0, {
                'product_id': line.product_id.id,
                'product_qty': line.product_qty,
                'product_uom': line.product_uom.id,
                'price_unit': line.price_unit,
                'analytic_distribution': line.analytic_distribution,
            }))
        vals = {
            'user_id': self.env.user.id,
            'date_order': fields.Date.today(),
            'line_direct_ids': lines_vals,
            'request_type_id': da_type.id,
            'request_id': self.id,

        }
        today = datetime.today()
        date_str = f"{today.year % 100:02d}{today.month:02d}{today.day:02d}"
        code_val = da_type.code or ''
        seq = self.env['ir.sequence'].next_by_code('ad.purchase.request') or '0000'
        vals['ref'] = f"{code_val}-{date_str}-{seq}"
        da = self.env['ad.direct.assignment'].create(vals)
        return {
            'type': 'ir.actions.act_window',
            'name': 'Direct Assignment',
            'res_model': 'ad.direct.assignment',
            'res_id': da.id,
            'view_mode': 'form',
            'target': 'current',
        }

    # # Compute stages
    @api.depends('request_type_id')
    def _compute_available_stages(self):
        for rec in self:
            if rec.request_type_id:
                approver_lines = rec.request_type_id.approver_line_ids.sorted('sequence')
                stage_ids = [line.stage_id.id for line in approver_lines if line.stage_id]
                rec.available_stage_ids = self.env['ad.internal.request.stage'].browse(stage_ids)
                print(f"🟨 Available stages for {rec.id}: {[s.name for s in rec.available_stage_ids]}")
            else:
                # rec.available_stage_ids = [(5, 0, 0)]
                rec.available_stage_ids = False

    @api.onchange('request_type_id')
    def _onchange_request_type_id(self):
        for rec in self:
            if rec.request_type_id:
                if rec.available_stage_ids:
                    rec.stage_id = rec.available_stage_ids.sorted('sequence')[0]
                    print(f"🟨 Stage set on change: {rec.stage_id.name}")
            else:
                rec.stage_id = False
                print("❌ Request Type not set. Stage set to False.")


    # @api.depends('stage_id',
    #              'request_type_id.approver_line_ids',
    #              'request_type_id.approver_line_ids.user_ids',
    #              'request_type_id.approver_line_ids.is_department_manager',
    #              'request_type_id.approver_line_ids.is_required_manager_department',
    #              'request_type_id.approver_line_ids.is_manager',
    #              'request_type_id.approver_line_ids.is_requester',
    #              'request_type_id.approver_line_ids.is_warehouse_manager',
    #              'request_type_id.approver_line_ids.is_technical',
    #              'employee_id', 'user_id')
    # def _compute_can_approve(self):
    #     for rec in self:
    #         if not rec.stage_id or not rec.request_type_id:
    #             rec.can_approve = False
    #             continue
    #         rec.can_approve = rec._user_can_approve('main')
    @api.depends(
        'stage_id',
        'request_type_id.approver_line_ids',
        'request_type_id.approver_line_ids.user_ids',
        'request_type_id.approver_line_ids.is_department_manager',
        'request_type_id.approver_line_ids.is_required_manager_department',
        'request_type_id.approver_line_ids.is_manager',
        'request_type_id.approver_line_ids.is_requester',
        'request_type_id.approver_line_ids.is_warehouse_manager',
        'request_type_id.approver_line_ids.is_technical',
        'employee_id',
        'user_id',
    )
    def _compute_can_approve(self):
        for rec in self:
            if not rec.stage_id or not rec.request_type_id:
                rec.can_approve = False
                continue

            current_user = rec.env.user
            rec.can_approve = rec._user_can_approve('main')

            print("══════════════════════════════════════════════")
            print(f"🔍 DEBUG: Checking approval for request ID: {rec.id}")
            print(f"👤 Current Logged User: {current_user.name}")
            print(f"🎯 Can Approve? → {rec.can_approve}")
            print("══════════════════════════════════════════════")



    def action_reject_with_reason(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Reject With Reason',
            'res_model': 'ad.internal.request.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
            }
        }

    @api.depends_context('uid')
    @api.depends('user_id')
    def _compute_employee_id(self):
        for rec in self:
            if rec.user_id and rec.user_id.employee_ids:
                employee = self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1)
                rec.employee_id = employee or rec.user_id.employee_ids[0]
            else:
                rec.employee_id = False

    @api.depends(
        'stage_id', 'stage_id.show_tender',
        'stage_required_complete_ids.name'
    )
    def _compute_show_button_tender(self):
        """Show Tender button iff:
           1) current stage has show_tender, and
           2) no main-gate requirement lines exist in any flow.
        """
        GATE = self._MAIN_GATE_COMPLETION_NAMES
        FLOWS = ('available', 'unavailable', 'tender', 'purchase', 'direct_assignment')

        for rec in self:
            stage_ok = bool(rec.stage_id and rec.stage_id.show_tender)
            if not stage_ok:
                rec.show_button_tender = False
                continue

            any_gate_exists = any(rec._has_any_required_line_exist(GATE[flow]) for flow in FLOWS)
            rec.show_button_tender = not any_gate_exists

    @api.depends( 'stage_id', 'user_id',  'stage_required_complete_ids.name')
    def _compute_show_button_purchase(self):
        """Show Purchase button iff:
           1) current stage has show_purchase, and
           2) no main-gate requirement lines exist in any flow.
        """
        GATE = self._MAIN_GATE_COMPLETION_NAMES
        FLOWS = ('available', 'unavailable', 'tender', 'purchase', 'direct_assignment')

        for rec in self:
            stage_ok = bool(rec.stage_id and rec.stage_id.show_purchase)
            if not stage_ok:
                rec.show_button_purchase = False
                continue

            any_gate_exists = any(rec._has_any_required_line_exist(GATE[flow]) for flow in FLOWS)
            rec.show_button_purchase = not any_gate_exists


    @api.depends(
        'stage_id', 'stage_id.show_tender',
        'stage_required_complete_ids.name'
    )
    def _compute_show_button_direct_assign(self):
        """Show Direct Assignment button iff:
           1) current stage has show_direct_assign, and
           2) no main-gate requirement lines exist in any flow.
        """
        GATE = self._MAIN_GATE_COMPLETION_NAMES
        FLOWS = ('available', 'unavailable', 'tender', 'purchase', 'direct_assignment')

        for rec in self:
            stage_ok = bool(rec.stage_id and rec.stage_id.show_direct_assign)
            if not stage_ok:
                rec.show_button_direct_assign = False
                continue

            any_gate_exists = any(rec._has_any_required_line_exist(GATE[flow]) for flow in FLOWS)
            rec.show_button_direct_assign = not any_gate_exists

    _MAIN_GATE_COMPLETION_NAMES = {
        'available': {
            "Available Directorate Request Type",
            "Available Municipality Request Type",
        },
        'unavailable': {
            "Unavailable Directorate Request Type",
            "Unavailable Municipality Request Type",
        },
        'tender': {
            "Tender Request Type",
        },
        'purchase': {
            "Purchase Request Type",
        },
        'direct_assignment': {
            "Direct Assignment Request Type",
        },
    }

    @api.depends(
        'current_stages_working',
        'can_approve',
        'stage_id',
        'available_stage_ids',
        'stage_is_available', 'stage_is_unavailable',
        'stage_is_tender', 'stage_is_purchase', 'stage_is_direct_assign',
        'stage_required_complete_ids',
        'stage_required_complete_ids.state',
    )
    def _compute_show_button_approve_main(self):
        """
        Show the 'Approve Main' button when:

        1) We're not in 'main' but the main stage is an Available/Unavailable fork
           and at least one of those flows has been completed, OR
        2) User can approve the main stage AND we're working in 'main'
           AND the current stage is NOT the last stage,
        """
        for rec in self:
            show = True

            # Case 1: outside 'main' but allowed to finish main after sub-flows
            # This covers Available/Unavailable as well as Tender/Purchase/Direct flows
            if not rec.stage_id.show_approve:
                if rec.stage_is_available or rec.stage_is_unavailable or rec.stage_is_tender or rec.stage_is_purchase or rec.stage_is_direct_assign:
                    completed_available = rec._has_any_completion(self._MAIN_GATE_COMPLETION_NAMES['available'])
                    completed_unavailable = rec._has_any_completion(self._MAIN_GATE_COMPLETION_NAMES['unavailable'])
                    completed_tender = rec._has_any_completion(self._MAIN_GATE_COMPLETION_NAMES['tender'])
                    completed_purchase = rec._has_any_completion(self._MAIN_GATE_COMPLETION_NAMES['purchase'])
                    completed_direct = rec._has_any_completion(self._MAIN_GATE_COMPLETION_NAMES['direct_assignment'])
                    show = bool(
                        completed_available or completed_unavailable or completed_tender or completed_purchase or completed_direct
                    )

            # Case 2: normal main flow
            if rec.can_approve and rec.current_stages_working == 'main':
                if rec.stage_id and rec.available_stage_ids:
                    last_stage = rec.available_stage_ids[-1]
                    if rec.stage_id.id == last_stage.id:
                        show = False

            rec.show_button_approve_main = show

    def _has_any_completion(self, names: set) -> bool:
        """True if any stage_required_complete line matches one of `names` and is complete."""
        self.ensure_one()
        if not self.stage_required_complete_ids:
            return False
        return any((line.name in names) and (line.state == 'done') for line in self.stage_required_complete_ids)

    def _has_any_required_line_exist(self, names: set) -> bool:
        if not self.stage_required_complete_ids:
            print("🔍 No required lines at all.")
            return False

        print(f"🔎 Checking required lines against names: {names}")
        for line in self.stage_required_complete_ids:
            stage_name = getattr(line.stage_id, 'name', "—")
            sub_stage_name = getattr(getattr(line, 'sub_stage_id', False), 'name', "—")

            print(
                f"   • Line → name={line.name}, "
                f"state={line.state}, "
                f"stage_id={stage_name}, "
                f"sub_stage_id={sub_stage_name}"
            )

            if line.name in names and line.state not in ('complete', 'done'):
                print("   ✅ Match found → This line name is in GATE set and not complete!")
                return True

        print("   ❌ No matching lines found.")
        return False

    @api.depends('ref', 'request_type_id')
    def _compute_name(self):
        for record in self:
            if record.request_type_id and record.ref:
                record.name = f"{record.ref}"
            else:
                record.name = f"New Request "

    def add_stage_available_type(self):
        """
        Build Available sub-stages based on employee.employment_type,
        select FIRST line, and schedule activities for it.
        Allowed only for users in requestor_employee.stock_warehouse_id.user_ids
        """
        for rec in self:
            allowed_users = rec._wm_users_from_requester_warehouse()
            if not allowed_users:
                raise UserError(_("لا يوجد مخزن مربوط بموظف صاحب الطلب أو لا يوجد مستخدمون محددون على المخزن.\n"
                                  "فضلاً اربط مخزن بالموظف (stock_warehouse_id) وحدد user_ids على المخزن."))
            if rec.env.user not in allowed_users:
                raise UserError(_("غير مسموح لك بتنفيذ هذا الإجراء. هذا الزر متاح فقط لمستخدمي مخزن موظف صاحب الطلب."))

            user = rec.user_id
            if not user:
                raise UserError(_("لم يتم العثور على مستخدم لهذا الطلب."))

            employee = rec.env['hr.employee'].search([('user_id', '=', user.id)], limit=1)
            if not employee:
                raise UserError(_("لم يتم العثور على موظف مرتبط بهذا المستخدم."))
            if not employee.employment_type:
                raise ValidationError(_("لم يتم تحديد نوع التوظيف لهذا الموظف."))

            sub_stage = False
            if employee.employment_type == 'directorate':
                sub_stage = rec.stage_id.sub_stage_available_directorate_id
                rec._add_stage_line_required_complete('Available Directorate Request Type')
            elif employee.employment_type == 'municipality':
                sub_stage = rec.stage_id.sub_stage_available_municipality_id
                rec._add_stage_line_required_complete('Available Municipality Request Type')
            else:
                raise ValidationError(_("نوع التوظيف غير مدعوم لمسار التوفر."))

            lines = sub_stage and sub_stage.approver_sub_line_ids or False
            if not lines:
                raise ValidationError(_("لم يتم تكوين أي مراحل فرعية لمسار التوفر."))

            rec.available_id_stage_ids = lines.ids
            rec.available_id_stage_id = lines.sorted('id')[0]
            rec._schedule_substage_activity(rec.available_id_stage_id, _("Available"))

    def add_stage_unavailable_type(self):
        """
        Build Unavailable sub-stages based on employee.employment_type,
        select FIRST line, and schedule activities for it.
        Allowed only for users in requestor_employee.stock_warehouse_id.user_ids
        """
        for rec in self:
            allowed_users = rec._wm_users_from_requester_warehouse()
            if not allowed_users:
                raise UserError(_("لا يوجد مخزن مربوط بموظف صاحب الطلب أو لا يوجد مستخدمون محددون على المخزن.\n"
                                  "فضلاً اربط مخزن بالموظف (stock_warehouse_id) وحدد user_ids على المخزن."))
            if rec.env.user not in allowed_users:
                raise UserError(_("غير مسموح لك بتنفيذ هذا الإجراء. هذا الزر متاح فقط لمستخدمي مخزن موظف صاحب الطلب."))

            user = rec.user_id
            if not user:
                raise UserError(_("لم يتم العثور على مستخدم لهذا الطلب."))

            employee = rec.env['hr.employee'].search([('user_id', '=', user.id)], limit=1)
            if not employee:
                raise UserError(_("لم يتم العثور على موظف مرتبط بهذا المستخدم."))
            if not employee.employment_type:
                raise ValidationError(_("لم يتم تحديد نوع التوظيف لهذا الموظف."))

            sub_stage = False
            if employee.employment_type == 'directorate':
                sub_stage = rec.stage_id.sub_stage_unavailable_directorate_id
                rec._add_stage_line_required_complete('Unavailable Directorate Request Type')
            elif employee.employment_type == 'municipality':
                sub_stage = rec.stage_id.sub_stage_unavailable_municipality_id
                rec._add_stage_line_required_complete('Unavailable Municipality Request Type')
            else:
                raise ValidationError(_("نوع التوظيف غير مدعوم لمسار عدم التوفر."))

            lines = sub_stage and sub_stage.approver_sub_line_ids or False
            if not lines:
                raise ValidationError(_("لم يتم تكوين أي مراحل فرعية لمسار عدم التوفر."))

            rec.unavailable_id_stage_ids = lines.ids
            rec.unavailable_id_stage_id = lines.sorted('id')[0]
            rec._schedule_substage_activity(rec.unavailable_id_stage_id, _("Unavailable"))

    @api.depends( 'stage_id', 'user_id',  'stage_required_complete_ids.name')
    def _compute_show_button_available(self):
        """Compute visibility of the Available/Unavailable entry buttons.

        Rules:
          1) A user must be among the warehouse users of the requester's warehouse.
          2) Show 'Available' if current stage has is_available and user is allowed.
          3) Show 'Unavailable' if current stage has is_unavailable and user is allowed,
             but only if *any* main-gate requirement line exists in any of the flows:
             available / unavailable / tender / purchase / direct_assignment.
        """
        GATE = self._MAIN_GATE_COMPLETION_NAMES
        FLOWS = ('available', 'unavailable', 'tender', 'purchase', 'direct_assignment')

        for rec in self:
            show_avail = False
            show_unavail = False

            stage = rec.stage_id
            if stage:
                # is the current user allowed (warehouse users of requester's warehouse)?
                allowed_users = rec._wm_users_from_requester_warehouse()
                is_allowed = bool(allowed_users and rec.env.user in allowed_users)

                # basic flags from the stage
                show_avail = bool(stage.is_available and is_allowed)
                show_unavail = bool(stage.is_unavailable and is_allowed)

                # extra guard for 'Unavailable' button:
                if show_unavail:
                    show_unavail = not any(rec._has_any_required_line_exist(GATE[flow]) for flow in FLOWS)

                if show_avail:
                    show_avail = not any(rec._has_any_required_line_exist(GATE[flow]) for flow in FLOWS)

            rec.show_button_available = show_avail
            rec.show_button_unavailable = show_unavail

    @api.depends('request_type_id')
    def _compute_available_stages(self):
        for rec in self:
            print(f"Computing available stages for record ID: {rec.id}")
            if rec.request_type_id:
                approver_lines = rec.request_type_id.approver_line_ids.sorted('sequence')
                print(f"Approver lines (sorted): {[l.id for l in approver_lines]}")
                stage_ids = [line.stage_id.id for line in approver_lines if line.stage_id]
                print(f"Initial stage IDs from approver lines: {stage_ids}")

                # Sort stages by name or another field you prefer
                # stage_ids = sorted(stage_ids,
                #                    key=lambda stage: self.env['ad.internal.request.stage'].browse(stage).name)

                rec.available_stage_ids = self.env['ad.internal.request.stage'].browse(stage_ids)
                print(f"🟨 Available stages for {rec.id}: {[s.name for s in rec.available_stage_ids]}")
            else:
                print(f"No request_type_id for record ID: {rec.id}, clearing available_stage_ids")
                rec.available_stage_ids = [(5, 0, 0)]


    def _get_request_link_for_whatsapp(self):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        return f"{base_url}/web#id={self.id}&model=ad.internal.request&view_type=form"

    def action_approve_stage(self):
        for rec in self:
            if not rec.can_approve:
                raise UserError("ليس لديك الصلاحية للموافقة على هذه المرحلة.")
            self._mark_my_todos_done(feedback=_("تمت الموافقة على الطلب"))

            self.env['ad.internal.request.approval'].create({
                'request_id': rec.id,
                'user_id': self.env.uid,
                'action': 'approved',
            })

            sorted_stages = rec.available_stage_ids
            if not sorted_stages:
                rec.message_post(body="لا توجد مراحل محددة لهذا الطلب.")

                continue

            current_index = -1
            for idx, stage in enumerate(sorted_stages):
                if stage.id == rec.stage_id.id:
                    current_index = idx
                    break

            if current_index != -1 and current_index + 1 < len(sorted_stages):
                next_stage = sorted_stages[current_index + 1]
                rec.stage_id = next_stage
                rec.message_post(body=f"تم الانتقال إلى المرحلة: <b>{next_stage.name}</b>")
                template_id = rec.request_type_id.whatsapp_template_id
                if template_id:
                    approver_lines = rec.request_type_id.approver_line_ids.filtered(lambda l: l.stage_id == next_stage)

                    all_users = rec.env['res.users']
                    for line in approver_lines:
                        users = rec._approval_targets_from_line(line)
                        all_users |= users

                    sent_users = []
                    for user in all_users:
                        phone = user.partner_id.phone
                        if not phone:
                            print(f"⛔ Skipping user {user.name} — no phone")
                            continue

                        link = rec._get_request_link_for_whatsapp()
                        reference = rec.name
                        print(f"📨 Preparing to send WhatsApp to: {user.name} | {phone}")
                        print(f"🔗 Reference: {reference}")
                        print(f"🌐 Link: {link}")
                        print(f"📋 Template ID: {template_id}")

                        gateway = rec.env['vs.otp.gateway']
                        result = gateway.send_custom_template_online_req(
                            number=phone,
                            template_id=template_id,
                            link=link,
                            reference=reference
                        )

                        print(f"📬 WhatsApp Send Result for {user.name}:")
                        print(json.dumps(result, indent=2, ensure_ascii=False))  # طباعة جميلة

                        if result.get('sent'):
                            sent_users.append(user.name)
                            print("✅ WhatsApp SENT successfully!")
                        else:
                            print("❌ WhatsApp FAILED to send.")
            else:
                rec.message_post(body="لا توجد مراحل إضافية. الطلب في المرحلة النهائية.")

            rec.is_approved = True


    def add_stage_tender_type(self):
        for rec in self:
            print("\n[DEBUG] --- add_stage_tender_type ---")
            print(f"سجل الطلب الحالي: {self.id} - الاسم: {self.name}")
            rec._add_stage_line_required_complete('Tender Request Type')
            rec._available_tender_stages()
            rec._schedule_substage_activity(rec.tender_stage_id, _("Tender"))

        print("[DEBUG] --- نهاية add_stage_tender_type ---\n")


    def add_stage_purchase_type(self):
        """
        Build Purchase sub-stages from stage.purchase_request_type_id,
        select FIRST line, and schedule activities for it.
        """
        for rec in self:
            if not rec.stage_id or not rec.stage_id.purchase_request_type_id:
                raise ValidationError(_("لم يتم تكوين نوع طلب الشراء في هذه المرحلة الرئيسية."))
            rec._add_stage_line_required_complete('Purchase Request Type')

            lines = rec.stage_id.purchase_request_type_id.approver_sub_line_ids
            if not lines:
                raise ValidationError(_("لم يتم تكوين أي مراحل فرعية لمسار الشراء."))

            rec.purchase_stage_ids = lines.ids
            rec.purchase_stage_id = lines.sorted('id')[0]
            rec._schedule_substage_activity(rec.purchase_stage_id, _("Purchase"))

    def add_stage_direct_assign_type(self):
        self._add_stage_line_required_complete('Direct Assignment Request Type')
        self._available_direct_assignment_stages()
        self._schedule_substage_activity(self.direct_assignment_stage_id, _("Direct Assignment"))

    def write(self, vals):
        old_stage = {r.id: r.stage_id for r in self}

        res = super(AdInternalRequest, self).write(vals)
        if 'stage_id' in vals:
            for rec in self:
                if old_stage.get(rec.id) != rec.stage_id:
                    rec._schedule_stage_activities()

        return res

    def copy(self, default=None):
        """When duplicating an internal request, set the stage to the
        first stage in available_stage_ids (if any).
        """
        default = dict(default or {})
        new_rec = super(AdInternalRequest, self).copy(default)

        first_stage = False
        if new_rec.available_stage_ids:
            try:
                first_stage = new_rec.available_stage_ids.sorted('sequence')[0]
            except Exception:
                first_stage = new_rec.available_stage_ids[0]

        if not first_stage and new_rec.request_type_id:
            approver_lines = new_rec.request_type_id.approver_line_ids.sorted('sequence')
            if approver_lines:
                for ln in approver_lines:
                    if ln.stage_id:
                        first_stage = ln.stage_id
                        break

        if first_stage:
            new_rec.stage_id = first_stage

        return new_rec

    def _add_stage_line_required_complete(self, name):

        rec = self.env['ad.stage.required.complete'].create({
            'request_id': self.id,
            'name': name,
            "stage_id": self.stage_id.id if self.stage_id else False,
        })

    @api.depends('stage_required_complete_ids',
                 'stage_required_complete_ids.state',
                 'stage_required_complete_ids.create_date',
                 'stage_id',
                 'stage_required_complete_ids.write_date')
    def _compute_current_stages_working(self):
        for rec in self:
            rec.current_stages_working = 'main'

            lines = rec.stage_required_complete_ids
            if not lines:
                continue

            incomplete = lines.filtered(lambda s: s.state != 'done')
            if not incomplete:
                continue

            last_stage = incomplete.sorted(
                key=lambda s: (s.create_date),
                reverse=True
            )[0]


            name = (last_stage.name or '').strip()
            if name == 'Tender Request Type':
                rec.current_stages_working = 'tender'
            elif name == 'Direct Assignment Request Type':
                rec.current_stages_working = 'direct_assignment'
            elif name == 'Purchase Request Type':
                rec.current_stages_working = 'purchase'
            elif name in ('Available Directorate Request Type', 'Available Municipality Request Type'):
                rec.current_stages_working = 'available'
            elif name in ('Unavailable Directorate Request Type', 'Unavailable Municipality Request Type'):
                rec.current_stages_working = 'unavailable'

    def action_approve_tender(self):
        for rec in self:
            if not rec._user_can_approve('tender'):
                raise UserError(_("ليس لديك الصلاحية للموافقة على مرحلة المناقصة هذه."))

            rec._mark_my_todos_done(feedback=_("تمت الموافقة على الطلب"))

            # Ensure deterministic order
            stages = rec.tender_stage_ids.sorted(key=lambda s: s.sequence) if hasattr(
                rec.tender_stage_ids._fields.get('sequence'), 'type') else rec.tender_stage_ids
            if not stages:
                rec.message_post(body="لم يتم تحديد أي مراحل لهذا الطلب.")
                continue

            if not rec.tender_stage_id:
                rec.message_post(body="لم يتم تعيين مرحلة حالية لهذا الطلب.")
                continue

            stage_ids = stages.ids
            try:
                current_index = stage_ids.index(rec.tender_stage_id.id)
            except ValueError:
                current_index = -1

            if current_index == -1:
                rec.message_post(body="المرحلة الحالية غير موجودة في قائمة المراحل المحددة.")
                continue

            last_index = len(stages) - 1

            if current_index < last_index:
                # Advance to next stage
                next_stage = stages[current_index + 1]
                rec.tender_stage_id = next_stage
                rec.message_post(body=f"تم الانتقال إلى المرحلة: <b>{next_stage.name}</b>")
                rec._schedule_substage_activity(next_stage, _("Tender"))
                template_id = rec.request_type_id.whatsapp_template_id
                print(f"📋 Tender WhatsApp Template ID: {template_id}")

                if template_id:
                    approver_lines = next_stage.sub_stage_id.approver_sub_line_ids
                    print(f"🧩 Next Stage: {next_stage.name}")
                    print(f"👥 Found {len(approver_lines)} approver lines for next stage")
                    all_users = rec.env['res.users']
                    for line in approver_lines:
                        users = rec._approval_targets_from_line(line)
                        all_users |= users

                    sent_users = []
                    for user in all_users:
                        phone = user.partner_id.phone
                        if not phone:
                            print(f"⛔ Skipping user {user.name} — no phone")
                            continue

                        link = rec._get_request_link_for_whatsapp()
                        reference = rec.name
                        print(f"📨 Preparing to send WhatsApp to: {user.name} | {phone}")
                        print(f"🔗 Reference: {reference}")
                        print(f"🌐 Link: {link}")
                        print(f"📋 Template ID: {template_id}")

                        gateway = rec.env['vs.otp.gateway']
                        result = gateway.send_custom_template_online_req(
                            number=phone,
                            template_id=template_id,
                            link=link,
                            reference=reference
                        )

                        print(f"📬 WhatsApp Send Result for {user.name}:")
                        print(json.dumps(result, indent=2, ensure_ascii=False))  # طباعة جميلة

                        if result.get('sent'):
                            sent_users.append(user.name)
                            print("✅ WhatsApp SENT successfully!")
                        else:
                            print("❌ WhatsApp FAILED to send.")


                if current_index + 1 == last_index:
                    rec.is_approved = True
                    available_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name == 'Tender Request Type'
                    )
                    if available_line:
                        available_line.sudo().write({'state': 'complete'})
                    rec.message_post(body="الطلب الآن في المرحلة النهائية.")
            else:
                if rec.current_stages_working != 'main':
                    main_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name == 'Tender Request Type'
                    )
                    if main_line and all(line.state == 'complete' for line in main_line):
                        main_line.sudo().write({'state': 'done'})

    def action_approve_purchase(self):
        for rec in self:
            if not rec._user_can_approve('purchase'):
                raise UserError(_("ليس لديك الصلاحية للموافقة على مرحلة الشراء هذه."))
            self._mark_my_todos_done(feedback=_("تمت الموافقة على الطلب"))


            sorted_stages = rec.purchase_stage_ids
            if not sorted_stages:
                rec.message_post(body="لم يتم تعريف أي مراحل لهذا الطلب.")
                continue

            current_index = -1
            for idx, stage in enumerate(sorted_stages):
                if stage.id == rec.purchase_stage_id.id:
                    current_index = idx
                    break

            if current_index != -1 and current_index + 1 < len(sorted_stages):
                # Not the last stage, move to next stage
                next_stage = sorted_stages[current_index + 1]
                rec.purchase_stage_id = next_stage
                rec.message_post(body=f"تم الانتقال إلى المرحلة: <b>{next_stage.name}</b>")
                rec._schedule_substage_activity(next_stage, _("Purchase"))
                template_id = rec.request_type_id.whatsapp_template_id
                if template_id:
                    approver_lines = next_stage.sub_stage_id.approver_sub_line_ids

                    all_users = rec.env['res.users']
                    for line in approver_lines:
                        users = rec._approval_targets_from_line(line)
                        all_users |= users

                    sent_users = []
                    for user in all_users:
                        phone = user.partner_id.phone
                        if not phone:
                            print(f"⛔ Skipping user {user.name} — no phone")
                            continue

                        link = rec._get_request_link_for_whatsapp()
                        reference = rec.name
                        print(f"📨 Preparing to send WhatsApp to: {user.name} | {phone}")
                        print(f"🔗 Reference: {reference}")
                        print(f"🌐 Link: {link}")
                        print(f"📋 Template ID: {template_id}")

                        gateway = rec.env['vs.otp.gateway']
                        result = gateway.send_custom_template_online_req(
                            number=phone,
                            template_id=template_id,
                            link=link,
                            reference=reference
                        )

                        print(f"📬 WhatsApp Send Result for {user.name}:")
                        print(json.dumps(result, indent=2, ensure_ascii=False))  # طباعة جميلة

                        if result.get('sent'):
                            sent_users.append(user.name)
                            print("✅ WhatsApp SENT successfully!")
                        else:
                            print("❌ WhatsApp FAILED to send.")

                is_last_stage = (current_index + 1 == len(sorted_stages) - 1)
                if is_last_stage:
                    rec.is_approved = True
                    available_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name == 'Purchase Request Type')
                    if available_line :
                        available_line.sudo().write({'state': 'complete'})
            else:
                if rec.current_stages_working != 'main':
                    main_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name == 'Purchase Request Type'
                    )
                    
                    if main_line and main_line.state == 'complete':
                        main_line.sudo().write({'state': 'done'})

    def action_approve_direct_assignment(self):
        for rec in self:
            # Check if user can approve
            if not rec._user_can_approve('direct_assignment'):
                raise UserError(_("ليس لديك الصلاحية للموافقة على هذه المرحلة من التخصيص المباشر."))
            self._mark_my_todos_done(feedback=_("تمت الموافقة على الطلب"))


            sorted_stages = rec.direct_assignment_stage_ids
            print(f"🟨 DEBUGGING: direct_assignment_stage_ids for request {rec.id}: {sorted_stages}")
            if not sorted_stages:
                print(f"❌ DEBUGGING: No direct_assignment stages for request {rec.id}")
                rec.message_post(body="لا توجد مراحل معرفة لهذا الطلب.")

                continue

            # Find the current stage index
            current_index = -1
            for idx, stage in enumerate(sorted_stages):
                print(f"🟨 DEBUGGING: Checking stage {stage.id} at index {idx}")
                if stage.id == rec.direct_assignment_stage_id.id:
                    current_index = idx
                    print(f"🟨 DEBUGGING: Found current stage {stage.name} at index {idx}")
                    break

            if current_index != -1 and current_index + 1 < len(sorted_stages):
                # Not the last stage, move to next stage
                next_stage = sorted_stages[current_index + 1]
                rec.direct_assignment_stage_id = next_stage
                rec.message_post(body=f"تم الانتقال إلى المرحلة: <b>{next_stage.name}</b>")
                rec._schedule_substage_activity(next_stage, _("Direct Assignment"))
                template_id = rec.request_type_id.whatsapp_template_id
                if template_id:
                    approver_lines = next_stage.sub_stage_id.approver_sub_line_ids

                    all_users = rec.env['res.users']
                    for line in approver_lines:
                        users = rec._approval_targets_from_line(line)
                        all_users |= users

                    sent_users = []
                    for user in all_users:
                        phone = user.partner_id.phone
                        if not phone:
                            print(f"⛔ Skipping user {user.name} — no phone")
                            continue

                        link = rec._get_request_link_for_whatsapp()
                        reference = rec.name
                        print(f"📨 Preparing to send WhatsApp to: {user.name} | {phone}")
                        print(f"🔗 Reference: {reference}")
                        print(f"🌐 Link: {link}")
                        print(f"📋 Template ID: {template_id}")

                        gateway = rec.env['vs.otp.gateway']
                        result = gateway.send_custom_template_online_req(
                            number=phone,
                            template_id=template_id,
                            link=link,
                            reference=reference
                        )

                        print(f"📬 WhatsApp Send Result for {user.name}:")
                        print(json.dumps(result, indent=2, ensure_ascii=False))  # طباعة جميلة

                        if result.get('sent'):
                            sent_users.append(user.name)
                            print("✅ WhatsApp SENT successfully!")
                        else:
                            print("❌ WhatsApp FAILED to send.")

                # Check if it's the last stage
                is_last_stage = (current_index + 1 == len(sorted_stages) - 1)
                if is_last_stage:
                    rec.is_approved = True
                    available_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name == 'Direct Assignment Request Type')
                    if available_line :
                        available_line.sudo().write({'state': 'complete'})
            else:
                if rec.current_stages_working != 'main':
                    main_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name == 'Direct Assignment Request Type'
                    )
                    if main_line and main_line.state == 'complete':
                        main_line.sudo().write({'state': 'done'})

    def action_approve_available(self):
        for rec in self:

            if rec.current_stages_working != 'available':
                raise UserError(_("يُسمح بالموافقة فقط ضمن سياق 'التوفر'."))
            if not rec._user_can_approve('available'):
                raise UserError(_("ليس لديك الصلاحية للموافقة على هذه المرحلة من مسار التوفر."))
            self._mark_my_todos_done(feedback=_("تمت الموافقة على الطلب"))

            if rec.available_id_stage_id and rec.available_id_stage_id.is_manager:
                emp = rec._get_request_employee()
                mgr_user = rec._get_direct_manager_user(emp)
                if not (mgr_user and rec.env.user.id == mgr_user.id):
                    raise UserError(_("فقط المدير المباشر للموظف يمكنه الموافقة على هذه المرحلة من مسار التوفر."))

            sorted_stages = rec.available_id_stage_ids
            if not sorted_stages:
                rec.message_post(body="لم يتم تعريف أي مراحل لهذا الطلب.")
                continue

            current_index = -1
            for idx, stage in enumerate(sorted_stages):
                if stage.id == rec.available_id_stage_id.id:
                    current_index = idx
                    break

            if current_index != -1 and current_index + 1 < len(sorted_stages):
                next_stage = sorted_stages[current_index + 1]
                rec.available_id_stage_id = next_stage
                rec.message_post(body=f"تم الانتقال إلى المرحلة التالية: <b>{next_stage.name}</b>")

                rec._schedule_substage_activity(next_stage, _("Available"))
                template_id = rec.request_type_id.whatsapp_template_id
                if template_id:
                    approver_lines = next_stage.sub_stage_id.approver_sub_line_ids

                    all_users = rec.env['res.users']
                    for line in approver_lines:
                        users = rec._approval_targets_from_line(line)
                        all_users |= users

                    sent_users = []
                    for user in all_users:
                        phone = user.partner_id.phone
                        if not phone:
                            print(f"⛔ Skipping user {user.name} — no phone")
                            continue

                        link = rec._get_request_link_for_whatsapp()
                        reference = rec.name
                        print(f"📨 Preparing to send WhatsApp to: {user.name} | {phone}")
                        print(f"🔗 Reference: {reference}")
                        print(f"🌐 Link: {link}")
                        print(f"📋 Template ID: {template_id}")

                        gateway = rec.env['vs.otp.gateway']
                        result = gateway.send_custom_template_online_req(
                            number=phone,
                            template_id=template_id,
                            link=link,
                            reference=reference
                        )

                        print(f"📬 WhatsApp Send Result for {user.name}:")
                        print(json.dumps(result, indent=2, ensure_ascii=False))  # طباعة جميلة

                        if result.get('sent'):
                            sent_users.append(user.name)
                            print("✅ WhatsApp SENT successfully!")
                        else:
                            print("❌ WhatsApp FAILED to send.")

                is_last_stage = (current_index + 1 == len(sorted_stages) - 1)
                if is_last_stage:
                    rec.is_approved = True
                    available_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name in ('Available Directorate Request Type',
                                             'Available Municipality Request Type'))
                    if available_line:
                        available_line.sudo().write({'state': 'complete'})
            else:
                if rec.current_stages_working != 'main':
                    main_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name in ('Available Directorate Request Type',
                                             'Available Municipality Request Type')
                    )
                    if main_line and main_line.state == 'complete':
                        main_line.sudo().write({'state': 'done'})

    def action_approve_unavailable(self):
        for rec in self:
            if rec.current_stages_working != 'unavailable':
                raise UserError(_("يُسمح بالموافقة فقط ضمن سياق 'عدم التوفر'."))

            if not rec._user_can_approve('unavailable'):
                raise UserError(_("ليس لديك الصلاحية للموافقة على هذه المرحلة من مسار عدم التوفر."))
            self._mark_my_todos_done(feedback=_("تمت الموافقة على الطلب"))


            if rec.unavailable_id_stage_id and getattr(rec.unavailable_id_stage_id, 'is_manager', False):
                emp = rec._get_request_employee()
                mgr_user = rec._get_direct_manager_user(emp)
                if not (mgr_user and rec.env.user.id == mgr_user.id):
                    raise UserError(_("فقط المدير المباشر للموظف يمكنه الموافقة على هذه المرحلة من مسار عدم التوفر."))

            sorted_lines = rec.unavailable_id_stage_ids
            if not sorted_lines:
                rec.message_post(body=_("لا توجد مراحل معرفة لهذا الطلب."))
                continue

            current_index = -1
            for idx, line in enumerate(sorted_lines):
                if line.id == rec.unavailable_id_stage_id.id:
                    current_index = idx
                    break

            if current_index != -1 and (current_index + 1) < len(sorted_lines):
                next_line = sorted_lines[current_index + 1]
                rec.unavailable_id_stage_id = next_line
                rec.message_post(body=_("تم الانتقال إلى المرحلة: <b>%s</b>") % (next_line.name or ''))

                rec._schedule_substage_activity(next_line, _("Unavailable"))
                template_id = rec.request_type_id.whatsapp_template_id
                if template_id:
                    approver_lines = next_line.sub_stage_id.approver_sub_line_ids

                    all_users = rec.env['res.users']
                    for line in approver_lines:
                        users = rec._approval_targets_from_line(line)
                        all_users |= users

                    sent_users = []
                    for user in all_users:
                        phone = user.partner_id.phone
                        if not phone:
                            print(f"⛔ Skipping user {user.name} — no phone")
                            continue

                        link = rec._get_request_link_for_whatsapp()
                        reference = rec.name
                        print(f"📨 Preparing to send WhatsApp to: {user.name} | {phone}")
                        print(f"🔗 Reference: {reference}")
                        print(f"🌐 Link: {link}")
                        print(f"📋 Template ID: {template_id}")

                        gateway = rec.env['vs.otp.gateway']
                        result = gateway.send_custom_template_online_req(
                            number=phone,
                            template_id=template_id,
                            link=link,
                            reference=reference
                        )

                        print(f"📬 WhatsApp Send Result for {user.name}:")
                        print(json.dumps(result, indent=2, ensure_ascii=False))  # طباعة جميلة

                        if result.get('sent'):
                            sent_users.append(user.name)
                            print("✅ WhatsApp SENT successfully!")
                        else:
                            print("❌ WhatsApp FAILED to send.")

                is_last = (current_index + 1 == len(sorted_lines) - 1)
                if is_last:
                    rec.is_approved = True
                    line_rec = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name in ('Unavailable Directorate Request Type',
                                             'Unavailable Municipality Request Type')
                    )
                    if line_rec:
                        line_rec.sudo().write({'state': 'complete'})
            else:
                if rec.current_stages_working != 'main':
                    main_line = rec.stage_required_complete_ids.filtered(
                        lambda l: l.name in ('Unavailable Directorate Request Type',
                                             'Unavailable Municipality Request Type')
                    )
                    if main_line and main_line.state == 'complete':
                        main_line.sudo().write({'state': 'done'})

    @api.depends('tender_stage_id.is_selected')
    def _compute_show_special_tender_button(self):
        for rec in self:
            rec.show_special_tender_button = bool(rec.tender_stage_id and rec.tender_stage_id.is_selected)

    @api.depends('purchase_stage_id.is_selected')
    def _compute_show_special_delivery_po_button(self):
        for rec in self:
            rec.show_special_delivery_po_button = bool(rec.purchase_stage_id and rec.purchase_stage_id.is_selected)

    @api.depends('direct_assignment_stage_id.is_selected')
    def _compute_show_special_direct_button(self):
        for rec in self:
            rec.show_special_direct_button = bool(
                rec.direct_assignment_stage_id and rec.direct_assignment_stage_id.is_selected)

    @api.depends('available_id_stage_id.is_selected')
    def _compute_show_special_available_button(self):
        for rec in self:
            rec.show_special_available_button = bool(
                rec.available_id_stage_id and rec.available_id_stage_id.is_selected)
            print("show_special_available_button", rec.show_special_available_button)

    @api.depends('unavailable_id_stage_id.is_selected')
    def _compute_show_special_unavailable_button(self):
        for rec in self:
            rec.show_special_unavailable_button = bool(
                rec.unavailable_id_stage_id and rec.unavailable_id_stage_id.is_selected)

    def action_create_delivery_order(self):
        for rec in self:
            rec._assert_current_user_allowed_here()

            Config = self.env['stock.warehouse.manager.config'].sudo()
            cfg_pts = Config.search([]).mapped('picking_type_ids')
            picking_type = cfg_pts.filtered(
                lambda pt: pt.code == 'outgoing' and pt.warehouse_id.company_id.id == rec.env.company.id
            )[:1]

            if not picking_type:
                raise UserError("لم يتم ضبط نوع تسليم عليه دلفيري  للمخزن.")

            partner = rec.user_id.partner_id

            move_lines = []
            for line in rec.product_line_ids:
                if not line.product_id or not line.product_uom or not line.product_qty:
                    continue
                move_lines.append((0, 0, {
                    'name': line.product_id.display_name,
                    'product_id': line.product_id.id,
                    'product_uom_qty': line.product_qty,
                    'product_uom': line.product_uom.id,
                    'location_id': picking_type.default_location_src_id.id,
                    'location_dest_id': picking_type.default_location_dest_id.id,
                }))

            if not move_lines:
                raise UserError("لا توجد بيانات صالحة في المنتجات.")

            picking = self.env['stock.picking'].create({
                'picking_type_id': picking_type.id,  # ← من الـ Config (Delivery/outgoing)
                'partner_id': partner.id,
                'origin': rec.name or rec.ref or 'Internal Request',
                'move_ids_without_package': move_lines,
            })

            return {
                'type': 'ir.actions.act_window',
                'name': 'Delivery Order',
                'res_model': 'stock.picking',
                'res_id': picking.id,
                'view_mode': 'form',
                'target': 'current',
            }

    @api.onchange('user_id')
    def _onchange_user_id(self):
        for rec in self:
            employee = rec.env['hr.employee'].search([('user_id', '=', rec.user_id.id)], limit=1)
            if employee:
                rec.employee_id = employee
                emp_type = employee.employment_type
                domain = []
                if emp_type == 'directorate':
                    domain = [('is_directorate', '=', True)]
                elif emp_type == 'municipality':
                    domain = [('is_municipality', '=', True)]
                return {'domain': {'request_type_id': domain}}
            else:
                rec.employee_id = False
                return {'domain': {'request_type_id': []}}

    def action_create_po(self):
        for rec in self:
            rec._assert_current_user_allowed_here()

            vendor = self.env['res.partner'].search([('is_vendor', '=', True)], limit=1)
            if not vendor:
                raise UserError("لا يوجد مورد (Vendor) معرف عليه أنه مورد (is_vendor = True) في النظام.")

            if not rec.product_line_ids:
                raise UserError("يجب إضافة منتج واحد على الأقل للطلب.")

            order_lines = []
            for line in rec.product_line_ids:
                order_lines.append((0, 0, {
                    'product_id': line.product_id.id,
                    'name': line.product_id.display_name,
                    'product_qty': line.product_qty,
                    'product_uom': line.product_uom.id,
                    'price_unit': line.price_unit or 0.0,
                    'date_planned': fields.Datetime.now(),
                }))

            po = self.env['purchase.order'].create({
                'partner_id': vendor.id,
                'origin': rec.name or rec.ref,
                'order_line': order_lines,
            })

            return {
                'type': 'ir.actions.act_window',
                'name': 'Purchase Order',
                'res_model': 'purchase.order',
                'res_id': po.id,
                'view_mode': 'form',
                'target': 'current',
            }

    def _get_request_employee(self):
        self.ensure_one()
        emp = self.employee_id or self.env['hr.employee'].search([('user_id', '=', self.user_id.id)], limit=1)
        return emp

    def _get_direct_manager_user(self, employee):
        """المدير المباشر فقط (parent_id)"""
        return employee.parent_id.user_id if employee and employee.parent_id and employee.parent_id.user_id else False

    @api.depends(
        'available_id_stage_id.is_manager', 'unavailable_id_stage_id.is_manager',
        'user_id', 'employee_id', 'available_id_stage_id', 'unavailable_id_stage_id'
    )
    def _compute_manager_approve_visibility(self):
        current_user = self.env.user
        for rec in self:
            rec.show_approve_available_button = False
            rec.show_approve_unavailable_button = False

            emp = rec._get_request_employee()
            mgr_user = rec._get_direct_manager_user(emp)

            if rec.available_id_stage_id and rec.available_id_stage_id.is_manager and mgr_user:
                rec.show_approve_available_button = (current_user.id == mgr_user.id)

            # Unavailable: نفس المنطق
            if rec.unavailable_id_stage_id and rec.unavailable_id_stage_id.is_manager and mgr_user:
                rec.show_approve_unavailable_button = (current_user.id == mgr_user.id)

    def _req_employee(self):
        """يرجع موظف صاحب الطلب (من employee_id أو من user_id)."""
        self.ensure_one()
        emp = self.employee_id or self.env['hr.employee'].search([('user_id', '=', self.user_id.id)], limit=1)
        print(">>> _req_employee called")
        print(">>> self.id:", self.id)
        print(">>> self.user_id:", self.user_id and self.user_id.login)
        print(">>> employee found:", emp and emp.name)
        return emp
    def _direct_manager_user(self, emp):
        """المدير المباشر: parent_id.user_id"""
        if emp and emp.parent_id and emp.parent_id.user_id:
            return emp.parent_id.user_id
        return self.env['res.users']

    def _department_manager_user(self, emp):
        """مدير القسم: department_id.manager_department_id.user_id"""
        dep = emp.department_id if emp else False
        mgr_emp = getattr(dep, 'manager_department_id', False) or False
        if mgr_emp and mgr_emp.user_id:
            return mgr_emp.user_id
        return self.env['res.users']

    def _warehouse_manager_users(self):
        """ارجع مستخدمي مدير المخزن للموظف صاحب الطلب فقط."""
        self.ensure_one()
        emp = self._req_employee()
        wh_config = emp.stock_warehouse_id
        if not wh_config:
            return self.env['res.users']
        return wh_config.warehouse_manager_ids.mapped('user_id')

    def _storekeeper_users(self):
        """ارجع مستخدمي أمين المخزن (Storekeeper) للموظف صاحب الطلب فقط."""
        self.ensure_one()
        emp = self._req_employee()
        wh_config = emp.stock_warehouse_id
        if not wh_config:
            print("⚠️ No stock_warehouse_id for employee.")
            return self.env['res.users']

        print(f"🏭 Warehouse Config: {wh_config.name} (ID: {wh_config.id})")
        print(f"📦 Storekeeper Users: {[u.name for u in wh_config.storekeeper_user_ids]}")
        return wh_config.storekeeper_user_ids

    def _technical_users(self):
        """ارجع المستخدمين الفنيين (Technical Users) للموظف صاحب الطلب فقط."""
        self.ensure_one()
        emp = self._req_employee()
        print(f"🧑‍💼 Employee: {emp.name if emp else '❌ No employee found'}")

        wh_config = getattr(emp, 'stock_warehouse_id', False)
        if not wh_config:
            print("⚠️ No stock_warehouse_id linked to employee.")
            return self.env['res.users']

        print(f"🏭 Warehouse Config: {wh_config.name} (ID: {wh_config.id})")

        tech_users = wh_config.technical_users_ids
        if not tech_users:
            print("⚠️ No Technical Users found for this warehouse config.")
        else:
            print(f"✅ Technical Users Found: {[u.name for u in tech_users]}")

        return tech_users

    # def _approval_targets_from_line(self, line):
    #     users = self.env['res.users']
    #     emp = self._req_employee()
    #     if getattr(line, 'is_warehouse_manager', False):
    #         wh_users = self._warehouse_manager_users()
    #         print(f"✅ Returning Warehouse Manager Users: {[u.name for u in wh_users]}")
    #         return wh_users
    #
    #     if getattr(line, 'is_storekeeper', False):
    #         store_users = self._storekeeper_users()
    #         return store_users
    #     if getattr(line, 'is_technical', False):
    #         tech_users = self._technical_users()
    #         print(f"✅ Returning Technical Users: {[u.name for u in tech_users]}")
    #         return tech_users
    #
    #     dept_flag = bool(
    #         getattr(line, 'is_department_manager', False) or getattr(line, 'is_required_manager_department', False)
    #     )
    #     mgr_flag = bool(getattr(line, 'is_manager', False))
    #     req_flag = bool(getattr(line, 'is_requester', False))
    #
    #     any_flag = False
    #     if dept_flag:
    #         dept_users = self._department_manager_user(emp)
    #         # print(f"✅ Dept Manager Users: {[u.name for u in dept_users]}")
    #         users |= dept_users
    #         any_flag = True
    #
    #     if mgr_flag:
    #         mgr_users = self._direct_manager_user(emp)
    #         # print(f"✅ Direct Manager Users: {[u.name for u in mgr_users]}")
    #         users |= mgr_users
    #         any_flag = True
    #
    #     if req_flag:
    #         req_user = self.user_id
    #         if req_user:
    #             # print(f"✅ Requester User: {req_user.name}")
    #             users |= req_user
    #         any_flag = True
    #
    #     if not any_flag:
    #         fallback_users = getattr(line, 'user_ids', self.env['res.users'])
    #         # print(f"✅ No flags. Using manual user_ids: {[u.name for u in fallback_users]}")
    #         users |= fallback_users
    #
    #     # print(f"🎯 Final User List: {[u.name for u in users]}")
    #     return users
    def _approval_targets_from_line(self, line):
        users = self.env['res.users']
        emp = self._req_employee()
        print("──────────────────────────────────────────────")
        print(
            f"🧩 DEBUG: Evaluating Approver Line → Stage: {line.stage_id.name if hasattr(line, 'stage_id') else 'N/A'}")
        print(f"👤 Request Employee: {emp.name if emp else '❌ No Employee Found'}")
        print(f"🔑 Flags → Warehouse: {getattr(line, 'is_warehouse_manager', False)} | "
              f"Storekeeper: {getattr(line, 'is_storekeeper', False)} | "
              f"Technical: {getattr(line, 'is_technical', False)} | "
              f"Dept: {getattr(line, 'is_department_manager', False)} | "
              f"Mgr: {getattr(line, 'is_manager', False)} | "
              f"Requester: {getattr(line, 'is_requester', False)}")

        # Warehouse Manager
        if getattr(line, 'is_warehouse_manager', False):
            wh_users = self._warehouse_manager_users()
            print(f"🏭 Warehouse Manager Users: {[u.name for u in wh_users]}")
            return wh_users

        # Storekeeper
        if getattr(line, 'is_storekeeper', False):
            store_users = self._storekeeper_users()
            print(f"📦 Storekeeper Users: {[u.name for u in store_users]}")
            return store_users

        # Technical
        if getattr(line, 'is_technical', False):
            tech_users = self._technical_users()
            print(f"⚙️ Technical Users: {[u.name for u in tech_users]}")
            return tech_users

        # Manager / Dept / Requester logic
        dept_flag = bool(
            getattr(line, 'is_department_manager', False)
            or getattr(line, 'is_required_manager_department', False)
        )
        mgr_flag = bool(getattr(line, 'is_manager', False))
        req_flag = bool(getattr(line, 'is_requester', False))

        any_flag = False

        if dept_flag:
            dept_users = self._department_manager_user(emp)
            print(f"🏢 Department Managers: {[u.name for u in dept_users]}")
            users |= dept_users
            any_flag = True

        if mgr_flag:
            mgr_users = self._direct_manager_user(emp)
            print(f"👔 Direct Managers: {[u.name for u in mgr_users]}")
            users |= mgr_users
            any_flag = True

        if req_flag:
            req_user = self.user_id
            if req_user:
                print(f"🧾 Requester User: {req_user.name}")
                users |= req_user
            else:
                print("⚠️ No Requester User Found!")
            any_flag = True

        if not any_flag:
            fallback_users = getattr(line, 'user_ids', self.env['res.users'])
            print(f"🪣 Fallback Manual Users: {[u.name for u in fallback_users]}")
            users |= fallback_users

        print(f"🎯 Final User List for this line: {[u.name for u in users]}")
        print("──────────────────────────────────────────────")
        return users

    def _wm_users_from_requester_warehouse(self):
        """Users لزراري Available/Unavailable (من مخزن موظف الطلب)."""
        self.ensure_one()
        emp = self._req_employee()
        wh = getattr(emp, 'stock_warehouse_id', False)

        print(">>> _wm_users_from_requester_warehouse called")
        print(">>> employee:", emp and emp.name)
        print(">>> warehouse:", wh and wh.display_name)
        print(">>> users in warehouse:", wh.user_ids.mapped("login") if wh else "No warehouse")
        return wh.sudo().user_ids if wh else self.env['res.users']

    def _approval_targets(self, kind='main'):
        """
        kind: 'main' | 'tender' | 'purchase' | 'direct_assignment' | 'available' | 'unavailable'
        يجمع كل اليوزرز المسموح لهم بالتصرف حسب السياق.
        """
        self.ensure_one()
        users = self.env['res.users']

        if kind == 'main':
            if not self.request_type_id or not self.stage_id:
                return users
            lines = self.request_type_id.approver_line_ids.filtered(lambda l: l.stage_id == self.stage_id)
            for ln in lines:
                users |= self._approval_targets_from_line(ln)
            return users

        # سطر Sub-Stage واحد
        line = {
            'tender': self.tender_stage_id,
            'purchase': self.purchase_stage_id,
            'direct_assignment': self.direct_assignment_stage_id,
            'available': self.available_id_stage_id,
            'unavailable': self.unavailable_id_stage_id,
        }.get(kind)

        if line:
            users |= self._approval_targets_from_line(line)
        return users

    def _user_can_approve(self, kind='main'):
        """هل اليوزر الحالي ضمن المستهدفين؟"""
        self.ensure_one()
        return self.env.user in self._approval_targets(kind)

    def _is_first_substage(self, current_line, lines):
        if not current_line or not lines:
            return True
        ids_order = [l.id for l in lines]
        try:
            return ids_order.index(current_line.id) == 0
        except ValueError:
            return True

    def _is_last_substage(self, current_line, lines):
        if not current_line or not lines:
            return False
        ids_order = [l.id for l in lines]
        try:
            return ids_order.index(current_line.id) == len(ids_order) - 1
        except ValueError:
            return False

    @api.depends(
        'current_stages_working',
        'stage_id', 'available_stage_ids',
        'tender_stage_id', 'tender_stage_ids',
        'purchase_stage_id', 'purchase_stage_ids',
        'direct_assignment_stage_id', 'direct_assignment_stage_ids',
        'available_id_stage_id', 'available_id_stage_ids',
        'unavailable_id_stage_id', 'unavailable_id_stage_ids'
    )
    def _compute_reject_buttons_visibility(self):
        for rec in self:
            # reset
            rec.show_reject_main_button = False
            rec.show_reject_tender_button = False
            rec.show_reject_purchase_button = False
            rec.show_reject_direct_button = False
            rec.show_reject_available_button = False
            rec.show_reject_unavailable_button = False

            # -------- Main --------
            if rec.stage_id and rec.available_stage_ids:
                ids_order = [s.id for s in rec.available_stage_ids]
                if rec.stage_id.id in ids_order:
                    idx = ids_order.index(rec.stage_id.id)
                    not_first = idx > 0
                    if not_first and rec._user_can_approve('main'):
                        rec.show_reject_main_button = True

            # -------- Tender --------
            if rec.current_stages_working == 'tender' and rec.tender_stage_id and rec.tender_stage_ids:
                not_first = not rec._is_first_substage(rec.tender_stage_id, rec.tender_stage_ids)
                if not_first and rec._user_can_approve('tender'):
                    rec.show_reject_tender_button = True

            # -------- Purchase --------
            if rec.current_stages_working == 'purchase' and rec.purchase_stage_id and rec.purchase_stage_ids:
                not_first = not rec._is_first_substage(rec.purchase_stage_id, rec.purchase_stage_ids)
                if not_first and rec._user_can_approve('purchase'):
                    rec.show_reject_purchase_button = True

            # -------- Direct Assignment --------
            if rec.current_stages_working == 'direct_assignment' and rec.direct_assignment_stage_id and rec.direct_assignment_stage_ids:
                not_first = not rec._is_first_substage(rec.direct_assignment_stage_id, rec.direct_assignment_stage_ids)
                if not_first and rec._user_can_approve('direct_assignment'):
                    rec.show_reject_direct_button = True

            # -------- Available --------
            if rec.current_stages_working == 'available' and rec.available_id_stage_id:
                not_first = not rec._is_first_substage(rec.available_id_stage_id, rec.available_id_stage_ids)
                can_act = rec._user_can_act_on_substage('available')  # نفس منطق approve/manager
                rec.show_reject_available_button = bool(not_first and can_act)

            # -------- Unavailable --------
            if rec.current_stages_working == 'unavailable' and rec.unavailable_id_stage_id:
                not_first = not rec._is_first_substage(rec.unavailable_id_stage_id, rec.unavailable_id_stage_ids)
                can_act = rec._user_can_act_on_substage('unavailable')  # نفس منطق approve/manager
                rec.show_reject_unavailable_button = bool(not_first and can_act)


    def action_reject_available_stage(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Reject Available Stage',
            'res_model': 'ad.substage.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
                'default_substage_type': 'available',
            }
        }


    def action_reject_unavailable_stage(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Reject Unavailable Stage',
            'res_model': 'ad.substage.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
                'default_substage_type': 'unavailable',
            }
        }


    def action_reject_tender(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Reject Tender Stage',
            'res_model': 'ad.substage.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
                'default_substage_type': 'tender',
            }
        }


    def action_reject_purchase(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Reject Purchase Stage',
            'res_model': 'ad.substage.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
                'default_substage_type': 'purchase',
            }
        }

    def action_reject_direct_assignment(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Reject Direct Assignment Stage',
            'res_model': 'ad.substage.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
                'default_substage_type': 'direct_assignment',
            }
        }



    def _schedule_substage_activity(self, next_substage_line, stage_label):
        """
        Schedule activities to users responsible for a sub-stage line via flags or user_ids;
        fallback to kind-level targets if needed.
        """
        self.ensure_one()
        if not next_substage_line:
            return

        label = (stage_label or '').strip().lower()
        if 'tender' in label:
            kind = 'tender'
        elif 'purchase' in label:
            kind = 'purchase'
        elif 'direct' in label:
            kind = 'direct_assignment'
        elif 'available' in label:
            kind = 'available'
        elif 'unavailable' in label:
            kind = 'unavailable'
        else:
            kind = 'main'

        targets = self._approval_targets_from_line(next_substage_line) or self._approval_targets(kind)
        if not targets:
            self.message_post(
                body=_("لا يوجد مستخدمون مستهدفون لإشعارهم بالمرحلة الفرعية التالية: %s") % (stage_label or ''))
            return

        deadline = fields.Date.context_today(self)
        for u in targets:
            self.activity_schedule(
                'mail.mail_activity_data_todo',
                user_id=u.id,
                summary=_('متابعة %s | %s') % (stage_label or 'مرحلة فرعية', self.name or self.id),
                note=_('يرجى مراجعة الطلب %s في المرحلة الفرعية %s.') % (self.name or self.id, stage_label or ''),
                date_deadline=deadline,
            )





    def _user_can_act_on_substage(self, kind):

        self.ensure_one()

        if not self._user_can_approve(kind):
            return False

        line = {
            'available': self.available_id_stage_id,
            'unavailable': self.unavailable_id_stage_id,
            'tender': self.tender_stage_id,
            'purchase': self.purchase_stage_id,
            'direct_assignment': self.direct_assignment_stage_id,
        }.get(kind)

        if not line:
            return True

        if getattr(line, 'is_manager', False):
            emp = self._get_request_employee()
            mgr_user = self._get_direct_manager_user(emp)
            return bool(mgr_user and self.env.user.id == mgr_user.id)

        return True

    def _get_visibility_domain(self):
        user = self.env.user
        domain_parts = []

        if user.has_group('ad_internal_request.group_internal_admin'):
            return []
        domain_parts.append(('create_uid', '=', user.id))

        domain_parts.append(('employee_id.parent_id.user_id', '=', user.id))

        domain_parts.append(('employee_id.department_id.manager_department_id.user_id', '=', user.id))

        if user.has_group('ad_internal_request.group_internal_follower'):
            domain_parts.append(('message_partner_ids', 'in', [user.partner_id.id]))

        return expression.OR([[d] for d in domain_parts])

    def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
        if args is None:
            args = []
        visibility_domain = self._get_visibility_domain()
        combined_domain = expression.AND([args, visibility_domain]) if visibility_domain else args
        return super(AdInternalRequest, self)._search(
            combined_domain, offset=offset, limit=limit, order=order, count=count, access_rights_uid=access_rights_uid
        )

    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        visibility_domain = self._get_visibility_domain()
        if visibility_domain:
            base_domain = domain or []
            domain = expression.AND([base_domain, visibility_domain])
        return super(AdInternalRequest, self).read_group(
            domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy
        )

    can_approve_main = fields.Boolean(compute="_compute_stage_permissions", store=False)
    can_reject_main = fields.Boolean(compute="_compute_stage_permissions", store=False)

    can_approve_tender = fields.Boolean(compute="_compute_stage_permissions", store=False)
    can_reject_tender = fields.Boolean(compute="_compute_stage_permissions", store=False)

    can_approve_purchase = fields.Boolean(compute="_compute_stage_permissions", store=False)
    can_reject_purchase = fields.Boolean(compute="_compute_stage_permissions", store=False)

    can_approve_direct = fields.Boolean(compute="_compute_stage_permissions", store=False)
    can_reject_direct = fields.Boolean(compute="_compute_stage_permissions", store=False)

    can_approve_available = fields.Boolean(compute="_compute_stage_permissions", store=False)
    can_reject_available = fields.Boolean(compute="_compute_stage_permissions", store=False)

    can_approve_unavailable = fields.Boolean(compute="_compute_stage_permissions", store=False)
    can_reject_unavailable = fields.Boolean(compute="_compute_stage_permissions", store=False)

    @api.depends(
        'current_stages_working',
        'stage_id',
        'tender_stage_id',
        'purchase_stage_id',
        'direct_assignment_stage_id',
        'available_id_stage_id',
        'unavailable_id_stage_id'
    )
    def _compute_stage_permissions(self):
        for rec in self:
            # default False
            rec.can_approve_main = rec.can_reject_main = False
            rec.can_approve_tender = rec.can_reject_tender = False
            rec.can_approve_purchase = rec.can_reject_purchase = False
            rec.can_approve_direct = rec.can_reject_direct = False
            rec.can_approve_available = rec.can_reject_available = False
            rec.can_approve_unavailable = rec.can_reject_unavailable = False

            # Debug logs
            print("🔎 Request %s | Stage Working = %s | User = %s",
                            rec.id, rec.current_stages_working, self.env.user.name)

            allowed = rec._is_current_user_allowed_here()
            print("👉 _is_current_user_allowed_here() returned: %s", allowed)

            if allowed:
                if rec.current_stages_working == "main":
                    rec.can_approve_main = rec.can_reject_main = True
                elif rec.current_stages_working == "tender":
                    rec.can_approve_tender = rec.can_reject_tender = True
                elif rec.current_stages_working == "purchase":
                    rec.can_approve_purchase = rec.can_reject_purchase = True
                elif rec.current_stages_working == "direct_assignment":
                    rec.can_approve_direct = rec.can_reject_direct = True
                elif rec.current_stages_working == "available":
                    rec.can_approve_available = rec.can_reject_available = True
                elif rec.current_stages_working == "unavailable":
                    rec.can_approve_unavailable = rec.can_reject_unavailable = True

            print(
                "✅ Permissions Result: main=%s/%s | tender=%s/%s | purchase=%s/%s | direct=%s/%s | available=%s/%s | unavailable=%s/%s",
                rec.can_approve_main, rec.can_reject_main,
                rec.can_approve_tender, rec.can_reject_tender,
                rec.can_approve_purchase, rec.can_reject_purchase,
                rec.can_approve_direct, rec.can_reject_direct,
                rec.can_approve_available, rec.can_reject_available,
                rec.can_approve_unavailable, rec.can_reject_unavailable,
            )
