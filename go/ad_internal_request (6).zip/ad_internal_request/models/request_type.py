from odoo import models, fields

class adRequestType(models.Model):
    _name = 'ad.internal.request.type'
    _description = 'Internal Request Type'

    name = fields.Char(string='Request Type', required=True, copy=True)
    stage_id = fields.Many2one('ad.internal.request.stage', string="Stage", copy=True)
    approver_line_ids = fields.One2many('ad.internal.request.type.approver', 'request_type_id', string='Approver Lines', copy=True)
    internal_request = fields.Boolean(string='Internal Request', copy=True)
    code = fields.Char(string='Code', copy=True)
    is_stage = fields.Boolean(string='Is Stage', default=False, copy=True)
    is_directorate = fields.Boolean("Directorate", copy=True)
    is_municipality = fields.Boolean("Municipality", copy=True)
    # is_reimbursement = fields.Boolean("Reimbursement", copy=True)
    max_total_lines = fields.Float(string="Max Total Lines", copy=True)

    whatsapp_template_id = fields.Char(
        string="WhatsApp Template ID",
        help="Template ID to use when sending approval WhatsApp messages."
    )

