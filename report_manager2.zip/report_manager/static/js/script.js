document.addEventListener('DOMContentLoaded', function() {
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 5000);
    });
    
    // Confirm file upload
    const uploadForm = document.querySelector('form[action*="upload"]');
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            const fileInput = this.querySelector('input[type="file"]');
            if (fileInput && fileInput.files.length > 0) {
                const fileName = fileInput.files[0].name;
                const fileExt = fileName.split('.').pop().toLowerCase();
                
                if (fileExt !== 'html') {
                    e.preventDefault();
                    alert('يرجى اختيار ملف HTML فقط');
                }
            }
        });
    }
    
    // Preview file name when selected
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            if (this.files.length > 0) {
                const fileName = this.files[0].name;
                const titleInput = this.closest('form').querySelector('input[name="title"]');
                
                if (titleInput && !titleInput.value) {
                    // Extract filename without extension and use as default title
                    const defaultTitle = fileName.replace(/\.[^/.]+$/, "");
                    titleInput.value = defaultTitle;
                    titleInput.focus();
                }
            }
        });
    });
});