#!/usr/bin/env python3
"""
Script to update admin username and password
"""

import os
import sys

def update_admin_credentials():
    # Import app and models
    from app import create_app
    from models import db, User
    
    # Create app context
    app = create_app()
    
    with app.app_context():
        # Find the admin user (first user or user with is_admin=True)
        admin_user = User.query.filter_by(is_admin=True).first()
        
        if not admin_user:
            # If no admin exists, get the first user
            admin_user = User.query.first()
            
        if not admin_user:
            # If no users exist at all, create new admin
            print("No users found. Creating new admin user...")
            admin_user = User(username='raid', is_admin=True)
            admin_user.set_password('rr2244RRp')
            db.session.add(admin_user)
            db.session.commit()
            print("✅ Admin user created successfully!")
            print("Username: raid")
            print("Password: rr2244RRp")
        else:
            # Update existing admin user
            old_username = admin_user.username
            admin_user.username = 'raid'
            admin_user.set_password('rr2244RRp')
            admin_user.is_admin = True
            
            try:
                db.session.commit()
                print(f"✅ Admin credentials updated successfully!")
                print(f"Old username: {old_username}")
                print(f"New username: raid")
                print(f"New password: rr2244RRp")
            except Exception as e:
                db.session.rollback()
                if "UNIQUE constraint failed" in str(e):
                    print("❌ Error: Username 'raid' already exists.")
                    print("Trying to update the existing 'raid' user...")
                    
                    # Find and update the existing 'raid' user
                    existing_raid = User.query.filter_by(username='raid').first()
                    if existing_raid:
                        existing_raid.set_password('rr2244RRp')
                        existing_raid.is_admin = True
                        db.session.commit()
                        print("✅ Existing 'raid' user password updated successfully!")
                        print("Username: raid")
                        print("Password: rr2244RRp")
                else:
                    print(f"❌ Error updating admin: {e}")
                    sys.exit(1)

if __name__ == "__main__":
    update_admin_credentials()