import os
import re
from flask import current_app
from werkzeug.utils import secure_filename
from models import db, Report, Setting

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

def save_file(file, title=None):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        
        # Create a unique filename if it already exists
        base_path = os.path.join(current_app.config['UPLOAD_FOLDER'])
        if not os.path.exists(base_path):
            os.makedirs(base_path)
            
        # Check if filename already exists
        counter = 1
        original_filename = filename
        while os.path.exists(os.path.join(base_path, filename)):
            name_parts = original_filename.rsplit('.', 1)
            filename = f"{name_parts[0]}_{counter}.{name_parts[1]}"
            counter += 1
            
        file_path = os.path.join(base_path, filename)
        file.save(file_path)
        
        # Get the next display order
        max_order = db.session.query(db.func.max(Report.display_order)).scalar() or 0
        
        # Use filename as title if none provided (without extension)
        if not title:
            title = os.path.splitext(filename)[0]
            
        return filename, title, max_order + 1
    return None, None, None

def is_public_view():
    setting = Setting.query.first()
    if not setting:
        setting = Setting(public_view=False)
        db.session.add(setting)
        db.session.commit()
    return setting.public_view

def toggle_public_view():
    setting = Setting.query.first()
    if not setting:
        setting = Setting(public_view=False)
        db.session.add(setting)
    else:
        setting.public_view = not setting.public_view
    db.session.commit()
    return setting.public_view

def is_new_tab():
    setting = Setting.query.first()
    if not setting:
        setting = Setting(open_in_new_tab=False)
        db.session.add(setting)
        db.session.commit()
    return setting.open_in_new_tab

def toggle_new_tab():
    setting = Setting.query.first()
    if not setting:
        setting = Setting(open_in_new_tab=False)
        db.session.add(setting)
    else:
        setting.open_in_new_tab = not setting.open_in_new_tab
    db.session.commit()
    return setting.open_in_new_tab

def sanitize_html_content(html_content):
    # Basic sanitization to prevent XSS
    # Remove script tags
    html_content = re.sub(r'<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>', '', html_content)
    return html_content

def get_html_content(filename, referrer='/view'):
    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            
            # Add a simple back button at the top left
            back_button = f"""
            <style>
                .simple-back-btn {{
                    position: fixed;
                    top: 10px;
                    left: 10px;
                    width: 30px;
                    height: 30px;
                    background: rgba(255, 255, 255, 0.9);
                    border: 1px solid #ddd;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    z-index: 999999;
                    text-decoration: none;
                    transition: all 0.2s ease;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }}
                .simple-back-btn:hover {{
                    background: #f0f0f0;
                    transform: scale(1.1);
                }}
                .simple-back-btn svg {{
                    width: 16px;
                    height: 16px;
                    fill: #333;
                }}
            </style>
            <a href="{referrer}" class="simple-back-btn">
                <svg viewBox="0 0 24 24">
                    <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/>
                </svg>
            </a>
            """
            
            # Insert the back button right after <body> tag if exists, otherwise at the beginning
            if '<body' in content.lower():
                # Find the end of body tag
                body_index = content.lower().find('<body')
                closing_bracket = content.find('>', body_index)
                if closing_bracket != -1:
                    content = content[:closing_bracket+1] + back_button + content[closing_bracket+1:]
                else:
                    content = back_button + content
            else:
                # If no body tag, just add at the beginning
                content = back_button + content
                
            return content
    return None