#!/bin/bash

echo "=========================================="
echo "   مدير التقارير - Report Manager Setup"
echo "=========================================="

# Check Python version
echo "Checking Python version..."
python3 --version

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip

# Install requirements
echo "Installing requirements..."
pip install -r requirements.txt

# Create instance directory if not exists
echo "Creating instance directory..."
mkdir -p instance

# Run database migration
echo "Setting up database..."
python3 migrate_db.py

# Update admin credentials
echo "Setting up admin user..."
python3 update_admin.py

echo ""
echo "=========================================="
echo "✅ Installation completed successfully!"
echo "=========================================="
echo ""
echo "To run the application:"
echo "1. Activate virtual environment: source venv/bin/activate"
echo "2. Run: python3 app.py"
echo ""
echo "Admin credentials:"
echo "Username: raid"
echo "Password: rr2244RRp"
echo ""
echo "The application will run on: http://localhost:5100"
echo "=========================================="