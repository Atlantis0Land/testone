#!/usr/bin/env python3
"""
Script to migrate the database and add new columns
"""

import sqlite3
import os

def migrate_database():
    # Get the database file path
    db_path = 'instance/report_manager.db'
    
    if not os.path.exists(db_path):
        print("Database file not found. Creating new database...")
        from app import create_app
        app = create_app()
        with app.app_context():
            from models import db
            db.create_all()
        print("Database created successfully!")
        return
    
    # Connect to the database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Check if is_published column exists in report table
        cursor.execute("PRAGMA table_info(report)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'is_published' not in columns:
            print("Adding is_published column to report table...")
            cursor.execute("ALTER TABLE report ADD COLUMN is_published BOOLEAN DEFAULT 1")
            conn.commit()
            print("is_published column added successfully!")
        else:
            print("is_published column already exists in report table")
        
        # Check if open_in_new_tab column exists in setting table
        cursor.execute("PRAGMA table_info(setting)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'open_in_new_tab' not in columns:
            print("Adding open_in_new_tab column to setting table...")
            cursor.execute("ALTER TABLE setting ADD COLUMN open_in_new_tab BOOLEAN DEFAULT 0")
            conn.commit()
            print("open_in_new_tab column added successfully!")
        else:
            print("open_in_new_tab column already exists in setting table")
        
        print("\nDatabase migration completed successfully!")
        
    except Exception as e:
        print(f"Error during migration: {e}")
        conn.rollback()
        
    finally:
        conn.close()

if __name__ == "__main__":
    migrate_database()