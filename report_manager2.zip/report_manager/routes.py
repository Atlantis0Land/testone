from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify, abort, current_app
from flask_login import login_user, logout_user, login_required, current_user
from urllib.parse import urlsplit
from models import db, User, Report, Setting
from utils import save_file, is_public_view, toggle_public_view, get_html_content, is_new_tab, toggle_new_tab
import os

main = Blueprint('main', __name__)

@main.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('main.login'))

@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user is None or not user.check_password(password):
            flash('اسم المستخدم أو كلمة المرور غير صحيحة', 'danger')
            return redirect(url_for('main.login'))
        
        login_user(user, remember=True)
        
        next_page = request.args.get('next')
        if not next_page or urlsplit(next_page).netloc != '':
            next_page = url_for('main.dashboard')
        
        return redirect(next_page)
    
    return render_template('login.html')

@main.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.login'))

@main.route('/dashboard')
@login_required
def dashboard():
    reports = Report.query.filter_by(user_id=current_user.id).order_by(Report.display_order).all()
    public_view = is_public_view()
    new_tab = is_new_tab()
    return render_template('dashboard.html', reports=reports, public_view=public_view, new_tab=new_tab)

@main.route('/view')
def view():
    if not is_public_view() and not current_user.is_authenticated:
        return redirect(url_for('main.login', next=request.url))
    
    reports = Report.query.filter_by(is_published=True).order_by(Report.display_order).all()
    new_tab = is_new_tab()
    return render_template('view.html', reports=reports, new_tab=new_tab)

@main.route('/view/<filename>')
def view_report(filename):
    # Security check - prevent direct file access
    report = Report.query.filter_by(filename=filename).first_or_404()
    
    # Check permissions
    if not is_public_view() and not current_user.is_authenticated:
        return redirect(url_for('main.login', next=request.url))
    
    # Check if report is published for public view
    if not current_user.is_authenticated and not report.is_published:
        abort(403)
    
    # Get referrer to pass to back button
    referrer = request.referrer or url_for('main.view')
    if '/dashboard' in referrer:
        referrer = url_for('main.dashboard')
    else:
        referrer = url_for('main.view')
    
    content = get_html_content(filename, referrer=referrer)
    
    if not content:
        abort(404)
    
    return content

@main.route('/upload', methods=['POST'])
@login_required
def upload():
    if 'file' not in request.files:
        flash('لم يتم اختيار ملف', 'danger')
        return redirect(url_for('main.dashboard'))
    
    file = request.files['file']
    title = request.form.get('title', '').strip()
    
    if file.filename == '':
        flash('لم يتم اختيار ملف', 'danger')
        return redirect(url_for('main.dashboard'))
    
    filename, title, order = save_file(file, title)
    
    if filename:
        new_report = Report(
            title=title,
            filename=filename,
            display_order=order,
            user_id=current_user.id
        )
        db.session.add(new_report)
        db.session.commit()
        flash('تم رفع الملف بنجاح', 'success')
    else:
        flash('صيغة الملف غير مسموح بها', 'danger')
    
    return redirect(url_for('main.dashboard'))

@main.route('/update/<int:report_id>', methods=['POST'])
@login_required
def update_report(report_id):
    report = Report.query.get_or_404(report_id)
    
    if report.user_id != current_user.id:
        abort(403)
    
    title = request.form.get('title', '').strip()
    order = request.form.get('order', type=int)
    
    if title:
        report.title = title
    
    if order is not None:
        report.display_order = order
    
    db.session.commit()
    flash('تم تحديث التقرير بنجاح', 'success')
    
    return redirect(url_for('main.dashboard'))

@main.route('/delete/<int:report_id>', methods=['POST'])
@login_required
def delete_report(report_id):
    report = Report.query.get_or_404(report_id)
    
    if report.user_id != current_user.id:
        abort(403)
    
    # Delete the file
    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], report.filename)
    if os.path.exists(file_path):
        os.remove(file_path)
    
    db.session.delete(report)
    db.session.commit()
    
    flash('تم حذف التقرير بنجاح', 'success')
    return redirect(url_for('main.dashboard'))

@main.route('/toggle-public', methods=['POST'])
@login_required
def toggle_public():
    is_public = toggle_public_view()
    return jsonify({'public': is_public})

@main.route('/toggle-new-tab', methods=['POST'])
@login_required
def toggle_new_tab_route():
    new_tab = toggle_new_tab()
    return jsonify({'new_tab': new_tab})

@main.route('/toggle-publish/<int:report_id>', methods=['POST'])
@login_required
def toggle_publish(report_id):
    report = Report.query.get_or_404(report_id)
    
    if report.user_id != current_user.id:
        abort(403)
    
    report.is_published = not report.is_published
    db.session.commit()
    
    return jsonify({'published': report.is_published})