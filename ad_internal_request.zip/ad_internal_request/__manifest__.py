# -*- coding: utf-8 -*-
{
    'name': 'Internal Requests Management',
    'version': '16.0.1.0.0',
    'summary': 'Manage internal requests with multi-level approval stages and sub-stages',
    'description': """
Internal Requests Workflow
==========================
This module allows managing internal service/product requests with:
- Main approval stages
- Sub-stages per main stage
- Approver assignment per stage
- Request rejection with reason (wizard)
- Integration with sale.order.line for requested products
""",
    "author": "Sysgates _ Ahmed Eldweek",
    "license": "LGPL-3",
    "website": "https://www.sysgates.com",
    'category': 'Operations/Request Management',
    'depends': [
        'base',
        'mail',
        'hr',
        'stock',
        'account',
        'analytic','ad_online_request', 'vs_res_partner'
    ],
    'data': [
        'security/groups.xml',
        'security/ir.model.access.csv',
        'data/data.xml',
        'views/ad_internal_request_views.xml',
        'views/ad_request_type_views.xml',
        'views/ad_request_stage_views.xml',
        'views/sub_stage_views.xml',
        'views/wizard_reject_button.xml',
        'views/ad_direct_assignment_views.xml',
        'views/employee.xml',
        'views/stock_picking_type.xml',
        'views/res_partner_views.xml',
        'views/wizard_payment.xml',
        'views/payment_lines_views.xml',
        'views/account_line_views.xml',
        'views/reimbursement_views.xml',
        'views/reimbursement_stage_views.xml',
        'views/dashborad.xml',
        'views/hr_department_views.xml',
        'views/warehouse_manager_config_views.xml',
        'views/online_request_views.xml',
        # 'views/action.xml',
    ],
'assets': {
    'web.assets_backend': [
        'ad_internal_request/static/src/js/lib/chart.min.js',
        'ad_internal_request/static/src/js/dashboard.js',
        # 'vs_internal_request/static/src/js/vs_statusbar_dynamic_widget.js',
        'ad_internal_request/static/src/xml/dashboard_templates.xml',
        # 'ad_internal_request/static/src/xml/action.xml',
        # 'vs_internal_request/static/src/xml/stage_widget.xml',
    ],

},


    'installable': True,
    'application': True,
    'auto_install': False,
}
