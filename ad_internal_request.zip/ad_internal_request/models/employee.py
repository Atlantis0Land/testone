from odoo import models, fields

class HrEmployee(models.Model):
    _inherit = 'hr.employee'


    employment_type = fields.Selection(
        [
            ('directorate', 'Directorate'),
            ('municipality', 'Municipality')
        ],
        string='Employment Type',
        required=True,
        default='directorate'
    )


    stock_warehouse_id = fields.Many2one('stock.warehouse.manager.config')


