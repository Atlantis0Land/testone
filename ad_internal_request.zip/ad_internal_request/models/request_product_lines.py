from odoo import models, fields, api

class RequestProductLine(models.Model):
    _name = 'request.product.lines'
    _description = 'Request Product Line'

    request_id = fields.Many2one('ad.internal.request', string="Internal Request", ondelete='cascade')
    ref = fields.Char(related='request_id.ref')

    product_id = fields.Many2one('product.product', string="Product", required=True)
    product_template_id = fields.Many2one('product.template', string="Product Template")

    product_uom = fields.Many2one('uom.uom', string="Unit of Measure", required=True)
    price_unit = fields.Float(string="Unit Price", required=True)
    product_qty = fields.Float(string="Quantity", required=True, default=1.0)

    price_subtotal = fields.Monetary(string="Subtotal", compute='_compute_price_subtotal', store=True)
    currency_id = fields.Many2one('res.currency', string="Currency", related='request_id.currency_id', store=True)
    income_analytic_account_id = fields.Many2one(
        'account.analytic.account',
        string="Analytic Account",

    )
    analytic_distribution = fields.Json(
        string="Analytic Distribution",
    default=list,

    )
    analytic_precision = fields.Integer(
        string="Analytic Precision",
        related='currency_id.decimal_places',
        readonly=True,
    )
    general_account_id = fields.Many2one('account.account', string="Financial Account")
    budget_remaining_amount = fields.Float(string='Budget Remaining', compute='_compute_budget_remaining', store=False)

    show_budget_remaining = fields.Boolean(
        string="Show Budget Remaining",
        compute='_compute_show_budget_remaining',
        store=False
    )

    @api.depends('request_id.stage_id')
    def _compute_show_budget_remaining(self):
        """Show budget only if the stage (via approver line) has is_budget_remaining=True."""
        for line in self:
            approver = self.env['ad.internal.request.type.approver'].search([
                ('stage_id', '=', line.request_id.stage_id.id),
                ('is_reminder', '=', True)
            ], limit=1)
            line.show_budget_remaining = bool(approver)

    @api.depends('income_analytic_account_id', 'request_id.stage_id')
    def _compute_budget_remaining(self):
        """Get remaining budget only if should show."""
        for line in self:
            if not line.show_budget_remaining or not line.income_analytic_account_id:
                line.budget_remaining_amount = 0.0
                continue

            budget_line = self.env['crossovered.budget.lines'].search([
                ('analytic_account_id', '=', line.income_analytic_account_id.id)
            ], limit=1)
            line.budget_remaining_amount = budget_line.remaining_amount if budget_line else 0.0

    @api.model
    def get_total_amount_all_lines(self, domain=None):
        dom = domain or []
        lines = self.sudo().search(dom)

        # Debug
        print("🔍 [get_total_amount_all_lines] Domain: %s", dom)
        print("🔍 Found %s lines", len(lines))
        for l in lines:
            print("   → Line ID: %s | Qty: %s | Unit Price: %s | Subtotal: %s",
                         l.id, l.product_qty, l.price_unit, l.price_subtotal)

        total = sum(lines.mapped('price_subtotal'))
        print("✅ Calculated Total: %s", total)

        cur = self.env.company.currency_id
        return {
            'total': float(total),
            'currency': cur.name or 'OMR',
            'symbol': cur.symbol or 'OMR',
        }
    @api.depends('product_qty', 'price_unit')
    def _compute_price_subtotal(self):
        for line in self:
            line.price_subtotal = line.product_qty * line.price_unit

    @api.onchange('product_id')
    def _onchange_product_id(self):
        print("_onchange_product_id")

        if self.product_id:
            print("test test")
            self.price_unit = self.product_id.list_price
            self.product_uom = self.product_id.uom_id

            category = self.product_id.categ_id

            distribution_model = self.env['account.analytic.distribution.model'].search([
                ('product_categ_id', '=', category.id)
            ], limit=1)

            if distribution_model:
                # ✅ set analytic distribution
                if distribution_model.analytic_distribution:
                    analytic_dict = distribution_model.analytic_distribution
                    if isinstance(analytic_dict, dict) and analytic_dict:
                        analytic_id = list(analytic_dict.keys())[0]
                        self.income_analytic_account_id = int(analytic_id)
                        self.analytic_distribution = analytic_dict

                # ✅ set financial account
                if distribution_model.general_account_id:
                    self.general_account_id = distribution_model.general_account_id
class AccountAnalyticDistributionModel(models.Model):
    _inherit = 'account.analytic.distribution.model'

    general_account_id = fields.Many2one(
        'account.account',
        string="Financial Account",
    )
