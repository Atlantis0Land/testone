from odoo import models, fields, api ,_
from odoo.exceptions import UserError

class RejectRequestWizard(models.TransientModel):
    _name = 'ad.internal.request.reject.wizard'
    _description = 'Reject Request with Reason'

    request_id = fields.Many2one('ad.internal.request', required=True, string="Request")
    reason = fields.Text(string="Reason", required=True)

    def action_submit_rejection(self):
        self.ensure_one()
        request = self.request_id

        if not request.stage_id or not request.available_stage_ids:
            raise UserError("Cannot determine previous stage.")

        # Get current and previous stages
        stages = request.available_stage_ids.sorted(lambda s: s.sequence)
        current_index = stages.ids.index(request.stage_id.id)
        if current_index == 0:
            raise UserError("Already at the first stage.")

        previous_stage = self.env['ad.internal.request.stage'].browse(stages[current_index - 1])

        # Post reason to chatter
        message = f"Request rejected by {self.env.user.name} with reason:\n{self.reason}"
        request.message_post(body=message)
        # ✅ log into approval lines
        request.approval_ids.create({
            'request_id': request.id,
            'user_id': self.env.uid,
            'date': fields.Datetime.now(),
            'action': 'rejected',
            'rejection_reason': self.reason
            ,
        })

        # Move to previous stage
        request.stage_id = previous_stage

        return {'type': 'ir.actions.act_window_close'}
class adDirectAssignmentRejectWizard(models.TransientModel):
    _name = 'ad.direct.assignment.reject.wizard'
    _description = 'Reject Direct Assignment Wizard'

    direct_id = fields.Many2one(
        'ad.direct.assignment',
        string='Direct Assignment',
        required=True,
        readonly=True,
        default=lambda self: self.env.context.get('default_direct_id'),
        ondelete='cascade',
    )
    reason = fields.Text(
        string='Rejection Reason',
        required=True,
    )

    def action_confirm_reject(self):
        for wiz in self:
            rec = wiz.direct_id
            if not rec:
                raise UserError(_('Record not found!'))
            self.env['ad.direct.approval'].create({
                'direct_id': rec.id,
                'user_id': self.env.uid,
                'action': 'rejected',
                # 'reason': wiz.reason,
            })
        return {'type': 'ir.actions.act_window_close'}

