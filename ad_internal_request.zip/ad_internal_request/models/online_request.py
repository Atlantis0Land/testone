from odoo import models, fields ,api,_
from odoo.exceptions import UserError


class OnlineRequest(models.Model):
    _inherit = 'online.request'

    internal_request_id = fields.Many2one(
        'ad.internal.request',
        string='Internal Request',
        index=True,
        ondelete='set null',
    )

    internal_request_count = fields.Integer(
        string='Internal Requests',
        compute='_compute_internal_request_count',
        store=False,
    )

    def _compute_internal_request_count(self):
        for rec in self:
            rec.internal_request_count = 1 if rec.internal_request_id else 0

    def action_open_internal_request(self):
        self.ensure_one()
        if not self.internal_request_id:
            raise UserError(_("لا يوجد Internal Request مربوط بهذا السجل."))
        return {
            'type': 'ir.actions.act_window',
            'name': _('Internal Request'),
            'res_model': 'ad.internal.request',
            'view_mode': 'form',
            'res_id': self.internal_request_id.id,
            'target': 'current',
            'context': dict(self._context),
        }
