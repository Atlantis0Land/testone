from odoo import models, fields ,api ,_
from odoo.exceptions import UserError, ValidationError


class InstallmentLine(models.Model):
    _name = 'installment.line'
    _description = 'Installment Line'

    request_id = fields.Many2one('ad.internal.request', string='Request', required=True, ondelete='cascade')
    description = fields.Char(string='Description')
    amount = fields.Float(string='Amount', required=True)
    due_date = fields.Date(string='Due Date',)
    paid = fields.Boolean(string='Paid', default=False,compute='_compute_paid',
    store=True,)
    financial_achievement = fields.Boolean(string='Financial Achievement')
    technical_achievement = fields.Boolean(string='Technical Achievement')
    financial_achievement_percent = fields.Float(string='Financial Achievement (%)')
    technical_achievement_percent = fields.Float(string='Technical Achievement (%)')

    payment_id = fields.Many2one('account.payment', string='Payment')

    def unlink(self):
        for rec in self:
            if rec.paid:
                raise UserError(_("لا يمكن حذف دفعة تم دفعها بالفعل!"))
        return super().unlink()

    @api.depends('payment_id.state')
    def _compute_paid(self):
        for rec in self:
            rec.paid = rec.payment_id and rec.payment_id.state == 'posted'

    def action_create_payment(self):
        for rec in self:
            if not rec.financial_achievement or rec.financial_achievement_percent < 100:
                raise UserError(_("لا يمكن إنشاء الدفعة قبل استكمال الإنجاز المالي وتكون النسبة 100%."))
            partner = rec.request_id.user_id.partner_id
            if not partner:
                raise UserError("المستخدم ليس له شريك (partner) مرتبط.")

            if rec.amount <= 0:
                raise UserError("مبلغ الدفع يجب أن يكون أكبر من صفر.")

            payment = self.env['account.payment'].create({
                'payment_type': 'outbound',
                'partner_type': 'customer',
                'partner_id': partner.id,
                'amount': rec.amount,
                'currency_id': rec.request_id.currency_id.id,
                'date': fields.Date.context_today(self),
                'ref': rec.request_id.name or rec.request_id.ref,
            })
            rec.payment_id = payment

            return {
                'type': 'ir.actions.act_window',
                'name': 'Payment',
                'res_model': 'account.payment',
                'res_id': payment.id,
                'view_mode': 'form',
                'target': 'current',
            }

    def action_open_payment(self):
        for rec in self:
            if not rec.payment_id:
                raise UserError("لم يتم إنشاء دفعة لهذا القسط بعد.")
            return {
                'type': 'ir.actions.act_window',
                'name': 'Payment',
                'res_model': 'account.payment',
                'res_id': rec.payment_id.id,
                'view_mode': 'form',
                'target': 'current',
            }


