from odoo import models, fields

class StockWarehouseManagerConfig(models.Model):
    _name = 'stock.warehouse.manager.config'
    _description = 'Warehouse Manager Config'
    _rec_name = 'name'

    name = fields.Char(string="Name", required=True)

    picking_type_ids = fields.Many2many(
        'stock.picking.type',
        'stock_warehouse_manager_config_picking_type_rel',
        'config_id',
        'picking_type_id',
        string="Operation Types"
    )

    user_ids = fields.Many2many(
        'res.users',
        'stock_warehouse_manager_config_user_rel',
        'config_id',
        'user_id',
        string="Users"
    )

    warehouse_manager_ids = fields.Many2many(
        'hr.employee',
        'stock_warehouse_manager_config_manager_rel',
        'config_id',
        'employee_id',
        string="Warehouse Managers",
        help="Employees who act as the warehouse managers for these operation types."
    )
    storekeeper_user_ids = fields.Many2many(
        'res.users',
        'stock_wh_manager_config_storekeeper_user_rel',
        'config_id',
        'user_id',
        string="Treasurer Users",
        help="Users who act as storekeepers for these operation types."
    )


