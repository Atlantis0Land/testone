from odoo import models, fields, api,_
from odoo.exceptions import UserError
from datetime import datetime


class adDirectAssignment(models.Model):
    _name = 'ad.direct.assignment'
    _description = 'Direct Assignment'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    request_type_id = fields.Many2one(
        'ad.internal.request.type',
        string='Request Type',

    )

    user_id = fields.Many2one('res.users', string='Requestor', default=lambda self: self.env.user)
    date_order = fields.Date(string='Request Date', default=fields.Date.context_today)
    request_id = fields.Many2one(
        'ad.internal.request',
        string='Internal Request',
        ondelete='cascade'
    )

    stage_id = fields.Many2one(
        'ad.internal.request.stage',
        string="Current Stage",
        # domain="[('id', 'in', available_stage_ids)]"
    )

    sub_stage_id = fields.Many2one(
        'ad.internal.request.stage',
        string="Current Stage",
        # domain="[('id', 'in', available_sub_stage_ids)]"
    )

    currency_id = fields.Many2one(
        'res.currency',
        string="Currency",
        default=lambda self: self.env.company.currency_id
    )

    available_stage_ids = fields.Many2many(
        'ad.internal.request.stage',
        compute='_compute_available_stages',
        string='Available Stages'
    )

    line_direct_ids = fields.One2many(
        'ad.direct.assignment.line', 'direct_assignment_id',
        string="Lines", copy=True
    )
    approval_direct_ids = fields.One2many('ad.direct.approval', 'direct_id', string='Approvals')

    can_approve = fields.Boolean(string="Can Approve", compute="_compute_can_approve")
    available_sub_stage_ids = fields.Many2many(
        'ad.internal.request.stage',
        string="Available Sub Stages",
        compute="_compute_available_sub_stages"
    )
    ref = fields.Char(string='Reference', readonly=True, copy=False)
    def action_open_internal_request(self):
        self.ensure_one()
        if not self.request_id:
            raise UserError(_("No Internal Request linked."))
        return {
            'name': _("Internal Request"),
            'type': 'ir.actions.act_window',
            'res_model': 'ad.internal.request',
            'view_mode': 'form',
            'res_id': self.request_id.id,
            'target': 'current',
        }



    @api.depends('stage_id', 'request_type_id')
    def _compute_available_sub_stages(self):
        for rec in self:
            lines = rec.request_type_id.approver_line_ids.filtered(
                lambda line: line.stage_id == rec.stage_id
            )
            sub_stages = lines.mapped('sub_stage_id')
            sub_stage_lines = sub_stages.mapped('approver_sub_line_ids')
            stages = sub_stage_lines.mapped('stage_id')
            rec.available_sub_stage_ids = stages

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            today = datetime.today()
            date_str = f"{today.year % 100:02d}{today.month:02d}{today.day:02d}"
            if vals.get('request_type_id'):
                req_type = self.env['ad.internal.request.type'].browse(vals['request_type_id'])
                code_val = req_type.code or ''
            else:
                code_val = ''
            seq = self.env['ir.sequence'].next_by_code('ad.direct.assignment') or '0000'
            vals['ref'] = f"{code_val}-{date_str}-{seq}"
        return super().create(vals_list)
    # Compute stages
    @api.depends('request_type_id')
    def _compute_available_stages(self):
        for rec in self:
            if rec.request_type_id:
                approver_lines = rec.request_type_id.approver_line_ids.sorted('sequence')
                stage_ids = [line.stage_id.id for line in approver_lines if line.stage_id]
                rec.available_stage_ids = self.env['ad.internal.request.stage'].browse(stage_ids)
                print(f"🟨 Available stages for {rec.id}: {[s.name for s in rec.available_stage_ids]}")
            else:
                rec.available_stage_ids = [(5, 0, 0)]

    @api.onchange('request_type_id')
    def _onchange_request_type_id(self):
        for rec in self:
            if rec.available_stage_ids:
                rec.stage_id = rec.available_stage_ids[0]
                print(f"🟨 Stage set on change: {rec.stage_id.name}")

    # Compute approvability
    @api.depends('request_type_id', 'stage_id')
    def _compute_can_approve(self):
        for record in self:
            record.can_approve = False
            user = self.env.user
            print(f"🟨 Checking can_approve for request {record.id}")
            print(f"🟨 Current Stage: {record.stage_id.name if record.stage_id else 'N/A'}")
            print(f"🟨 Current User: {user.name} ({user.id})")

            if not record.request_type_id or not record.stage_id:
                print("❌ Missing request_type_id or stage_id")
                continue

            approver_lines = record.request_type_id.approver_line_ids.sorted('sequence')
            all_stage_ids = approver_lines.mapped('stage_id')
            final_stage = all_stage_ids[-1] if all_stage_ids else None

            print(f"🟨 Final Stage: {final_stage.name if final_stage else 'N/A'}")
            if record.stage_id == final_stage:
                print("❌ Current stage is final. Skipping approval.")
                continue

            user_approver_lines = approver_lines.filtered(
                lambda line: line.user_id.id == record.env.user.id
            )
            allowed_stages = user_approver_lines.mapped('stage_id')
            print(f"🟨 Allowed Stages for user: {[s.name for s in allowed_stages]}")

            if record.stage_id.id in allowed_stages.ids:
                record.can_approve = True
                print("✅ User can approve this stage.")
            else:
                print("❌ User CANNOT approve this stage.")

    # Approval action
    def action_approve_stage(self):
        for rec in self:
            if not rec.can_approve:
                raise UserError("You are not allowed to approve this stage.")

            self.env['ad.direct.approval'].create({
                'direct_id': rec.id,
                'user_id': self.env.uid,
                'action': 'approved',
            })

            approver_lines = rec.request_type_id.approver_line_ids.sorted(lambda l: l.sequence)
            stage_ids_ordered = approver_lines.mapped('stage_id')

            next_stage = None
            for idx, stage in enumerate(stage_ids_ordered):
                if stage.id == rec.stage_id.id and idx + 1 < len(stage_ids_ordered):
                    next_stage = stage_ids_ordered[idx + 1]
                    break

            if next_stage:
                rec.stage_id = next_stage

    def action_reject_with_reason(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Reject Direct Assignment',
            'res_model': 'ad.direct.assignment.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_direct_id': self.id},
        }
class DirectApprovals(models.Model):
    _name = 'ad.direct.approval'
    _description = 'PUrchase Req Stage Approval'

    direct_id = fields.Many2one(
        'ad.direct.assignment',
        string=' PO Req',
        required=True,
        ondelete='cascade',
    )
    user_id = fields.Many2one(
        'res.users',
        string='User',
        default=lambda self: self.env.user,
        required=True,
    )
    date = fields.Datetime(
        string='Date',
        default=fields.Datetime.now,
    )
    action = fields.Char(
        string='Action',
        default='approve',
    )
# models/ad_direct_assignment_line.py
from odoo import models, fields, api

class adDirectAssignmentLine(models.Model):
    _name = 'ad.direct.assignment.line'
    _description = 'Direct Assignment Line'

    direct_assignment_id = fields.Many2one(
        'ad.direct.assignment', string="Direct Assignment",
        ondelete='cascade', required=True
    )
    product_id = fields.Many2one(
        'product.product', string="Product", required=True
    )
    product_template_id = fields.Many2one(
        'product.template', string="Product Template", store=True
    )
    product_uom = fields.Many2one(
        'uom.uom', string="Unit of Measure", required=True
    )
    product_qty = fields.Float(
        string="Quantity", default=1.0, required=True
    )
    price_unit = fields.Float(
        string="Unit Price", default=0.0, required=True
    )
    price_subtotal = fields.Monetary(
        string="Subtotal", compute='_compute_subtotal', store=True
    )
    currency_id = fields.Many2one('res.currency', string="Currency", related='direct_assignment_id.currency_id',
                                  store=True)

    income_analytic_account_id = fields.Many2one(
        'account.analytic.account',
        string="Analytic Account",

    )
    analytic_distribution = fields.Json(
        string="Analytic Distribution",
        default=list,

    )
    analytic_precision = fields.Integer(
        string="Analytic Precision",
        related='currency_id.decimal_places',
        readonly=True,
    )
    @api.depends('product_qty', 'price_unit')
    def _compute_subtotal(self):
        for line in self:
            line.price_subtotal = line.product_qty * line.price_unit

    @api.onchange('product_id')
    def _onchange_product_id(self):
        if self.product_id:
            self.price_unit = self.product_id.list_price
            self.product_uom = self.product_id.uom_id
