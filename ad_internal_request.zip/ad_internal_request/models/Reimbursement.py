from odoo import models, fields, api,_
from odoo.exceptions import ValidationError
import json
import copy




class reimbursementRequest(models.Model):
    _name = 'reimbursement.request'
    _description = 'reimbursement Request'

    name = fields.Char(string="Name", required=True, default="New")
    request_type_id = fields.Many2one('ad.internal.request.type', string="Request Type")
    internal_request_ids = fields.Many2many(
        'ad.internal.request',
        'substitution_internal_request_rel',
        'substitution_id',
        'internal_request_id',
        string='Internal Requests',
        domain="[('request_type_id.is_reimbursement', '=', True)]",
    )
    date_order = fields.Date(string='Request Date', default=fields.Date.context_today)



    type_id = fields.Many2one('reimbursement.stage', string="Type", default=lambda self: self._get_default_stage())


    reim_stage_id = fields.Many2one(
        'reimbursement.stage.line',
        string="Current Stage",
        domain="[('id', 'in', reim_stage_ids)]",
        copy=False,
    )
    reim_stage_ids = fields.Many2many(
        'reimbursement.stage.line',
        'reimbursement_request_stage_rel',
        'request_id',
        'stage_id',
        string='Stages',
    )
    show_reim_approve_button = fields.Boolean(compute='_compute_show_reim_approve', store=False)

    @api.model
    def _get_default_stage(self):
        return self.env['reimbursement.stage'].search([('is_default_stage', '=', True)], limit=1)

    @api.model
    def get_reimb_requests_count(self, domain=None):
        """إجمالي عدد طلبات الاستعاضة."""
        return self.sudo().search_count(domain or [])

    @api.depends('reim_stage_id', 'reim_stage_ids.user_ids', 'reim_stage_ids.sequence')
    def _compute_show_reim_approve(self):
        """يحدد ظهور زر الموافقة حسب المرحلة وصلاحيات المستخدم، ويختفي في آخر مرحلة."""
        user = self.env.user
        for rec in self:
            visible = False

            stages = rec.reim_stage_ids.sorted('sequence') if rec.reim_stage_ids else self.env[
                'reimbursement.stage.line']
            if not stages:
                rec.show_reim_approve_button = False
                continue

            current_line = rec.reim_stage_id or (stages and stages[0] or False)
            if not current_line:
                rec.show_reim_approve_button = False
                continue

            last_line = stages[-1]

            if (user in current_line.user_ids) and (current_line.id != last_line.id):
                visible = True

            rec.show_reim_approve_button = visible



    product_line_ids = fields.One2many('reimbursement.request.product.line', 'reimbursement_request_id', string="Product Lines")

    @api.onchange('type_id')
    def _onchange_type_id_load_stages(self):
        """لما تختاري النوع: يحمّل خطوط المراحل و يعيّن أول مرحلة كحالية."""
        for rec in self:
            print("\n--- ONCHANGE type_id Triggered ---")
            print(f"Record ID: {rec.id}")
            print(f"Selected type_id: {rec.type_id.id if rec.type_id else None}")

            rec.reim_stage_ids = [(5, 0, 0)]
            rec.reim_stage_id = False

            if rec.type_id:
                lines = rec.type_id.approver_stage_line_ids.sorted('sequence')
                print(f"Loaded Lines IDs: {lines.ids}")
                rec.reim_stage_ids = lines.ids
                rec.reim_stage_id = lines[:1].id if lines else False
                print(f"First Stage ID set to: {rec.reim_stage_id.id if rec.reim_stage_id else None}")
            else:
                print("No type_id selected.")

    def action_approve_reimbursement(self):
        """ينقلك للمرحلة التالية على حسب ترتيب الـ sequence."""
        for rec in self:
            stages = rec.reim_stage_ids.sorted('sequence')
            if not stages:
                continue

            if not rec.reim_stage_id:
                rec.reim_stage_id = stages[0].id
                continue

            idx = next((i for i, st in enumerate(stages) if st.id == rec.reim_stage_id.id), -1)
            if idx != -1 and (idx + 1) < len(stages):
                rec.reim_stage_id = stages[idx + 1].id


    @api.onchange('internal_request_ids')
    def _onchange_internal_request_ids(self):
        domain = [('request_type_id.is_reimbursement', '=', True)]
        if self.internal_request_ids:
            domain.append(('id', 'not in', self.internal_request_ids.ids))

        def _normalize_dist(raw_dist, line):
            """
            يحوّل أي شكل (dict / list / str JSON) إلى dict {account_id(str): percent(float)}
            """
            dist_dict = {}

            if not raw_dist:
                return dist_dict

            # 2) String JSON
            if isinstance(raw_dist, str):
                try:
                    raw_dist = json.loads(raw_dist)
                except ValueError:
                    return dist_dict

            if isinstance(raw_dist, list):
                for entry in raw_dist:
                    if isinstance(entry, str):
                        try:
                            entry = json.loads(entry)
                        except ValueError:
                            continue
                    if isinstance(entry, dict):
                        acct = entry.get('account_id')
                        pct = float(entry.get('percent', entry.get('percentage', 0.0)) or 0.0)
                        if acct and pct:
                            dist_dict[str(int(acct))] = dist_dict.get(str(int(acct)), 0.0) + pct
                    elif isinstance(entry, int):
                        # رقم = حساب كامل 100%
                        dist_dict[str(entry)] = dist_dict.get(str(entry), 0.0) + 100.0
                return dist_dict

            if isinstance(raw_dist, dict):
                for k, v in raw_dist.items():
                    try:
                        acct = str(int(k))
                        pct = float(v)
                    except Exception:
                        continue
                    if pct:
                        dist_dict[acct] = dist_dict.get(acct, 0.0) + pct
                return dist_dict

            # غير مدعوم
            return dist_dict

        lines = []
        for req in self.internal_request_ids:
            for line in req.product_line_ids:
                dist = _normalize_dist(getattr(line, 'analytic_distribution', None), line)

                if not dist and getattr(line, 'income_analytic_account_id', False):
                    dist = {str(line.income_analytic_account_id.id): 100.0}

                income_analytic_id = getattr(line, 'income_analytic_account_id', False).id if getattr(line,
                                                                                                      'income_analytic_account_id',
                                                                                                      False) else False
                general_account_id = getattr(line, 'general_account_id', False).id if getattr(line,
                                                                                              'general_account_id',
                                                                                              False) else False
                if not dist and line.product_id:
                    category = line.product_id.categ_id
                    distribution_model = self.env['account.analytic.distribution.model'].search([
                        ('product_categ_id', '=', category.id)
                    ], limit=1)
                    if distribution_model:
                        if distribution_model.analytic_distribution:
                            dm_dist = _normalize_dist(distribution_model.analytic_distribution, line)
                            if dm_dist:
                                dist = dm_dist
                                # أول حساب كافتراضي
                                try:
                                    first_acct = next(iter(dm_dist.keys()))
                                    income_analytic_id = int(first_acct)
                                except StopIteration:
                                    pass
                        if distribution_model.general_account_id:
                            general_account_id = distribution_model.general_account_id.id

                if dist and not income_analytic_id:
                    try:
                        income_analytic_id = int(next(iter(dist.keys())))
                    except Exception:
                        income_analytic_id = False

                vals = {
                    'product_id': line.product_id.id,
                    'ref': getattr(line, 'ref', False),
                    'product_uom': line.product_uom.id,
                    'product_qty': line.product_qty,
                    'price_unit': line.price_unit,
                    'internal_request_id': req.id,

                    # >>> نسخ حقول التحليل المحاسبي <<<
                    'income_analytic_account_id': income_analytic_id or False,
                    'analytic_distribution': copy.deepcopy(dist),
                    'general_account_id': general_account_id or False,
                }

                lines.append((0, 0, vals))

        self.product_line_ids = [(5, 0, 0)] + lines
        return {'domain': {'internal_request_ids': domain}}

    def action_create_entry_items(self):
        AnalyticLine = self.env['account.analytic.line']
        created = self.env['account.analytic.line'].browse()

        for req in self:
            date_val = req.date_order or fields.Date.context_today(self)

            for line in req.product_line_ids:
                entry_name = line.ref or (line.internal_request_id and line.internal_request_id.ref) or req.name

                analytic_dist = line.analytic_distribution
                if not analytic_dist:
                    continue

                base_qty = float(line.product_qty or 0.0)
                base_amount = float(getattr(line, 'price_subtotal', 0.0) or (base_qty * float(line.price_unit or 0.0)))

                # توزيع Dict: {analytic_account_id: percent}
                if isinstance(analytic_dist, dict):
                    for acct_id, percent in analytic_dist.items():
                        try:
                            acct = int(acct_id)
                            pct = float(percent) / 100.0
                        except Exception:
                            continue
                        if not acct:
                            continue

                        rec = AnalyticLine.create({
                            'name': entry_name,
                            'product_id': line.product_id.id,
                            'unit_amount': base_qty * pct,
                            'amount': base_amount * pct,
                            'product_uom_id': line.product_uom.id,
                            'account_id': acct,
                            'date': date_val,
                            # لو الحقول دي مضافة على analytic line عندك:
                            'general_account_id': line.general_account_id.id if 'general_account_id' in AnalyticLine._fields else False,
                            'request_id_remi': req.id if 'request_id_remi' in AnalyticLine._fields else False,
                        })
                        created |= rec

                # توزيع List: قد يكون dict/int/str(JSON)
                elif isinstance(analytic_dist, list):
                    for entry in analytic_dist:
                        if isinstance(entry, str):
                            try:
                                entry = json.loads(entry)
                            except ValueError:
                                continue

                        acct = None
                        pct = 1.0
                        if isinstance(entry, dict):
                            acct = entry.get('account_id')
                            pct = float(entry.get('percent', entry.get('percentage', 0.0))) / 100.0
                        elif isinstance(entry, int):
                            acct = entry
                            pct = 1.0

                        if not acct:
                            continue

                        rec = AnalyticLine.create({
                            'name': entry_name,
                            'product_id': line.product_id.id,
                            'unit_amount': base_qty * pct,
                            'amount': base_amount * pct,
                            'product_uom_id': line.product_uom.id,
                            'account_id': int(acct),
                            'date': date_val,
                            'general_account_id': line.general_account_id.id if 'general_account_id' in AnalyticLine._fields else False,
                            'request_id_remi': req.id if 'request_id_remi' in AnalyticLine._fields else False,
                        })
                        created |= rec
                else:
                    continue

        tree_view = self.env.ref('analytic.view_account_analytic_line_tree').id
        form_view = self.env.ref('analytic.view_account_analytic_line_form').id
        return {
            'type': 'ir.actions.act_window',
            'name': _('Analytic Items'),
            'res_model': 'account.analytic.line',
            'view_mode': 'tree,form',
            'views': [(tree_view, 'tree'), (form_view, 'form')],
            'domain': [('id', 'in', created.ids)],
            'context': {'default_account_id': created and created[0].account_id.id or False},
            'target': 'current',
        }

    show_reim_entry_button = fields.Boolean(
        compute='_compute_show_reim_entry_button',
        store=False
    )


    @api.depends('type_id.is_entry_button')
    def _compute_show_reim_entry_button(self):
        for rec in self:
            rec.show_reim_entry_button = bool(rec.type_id and rec.type_id.is_entry_button)



class reimbursementRequestProductLine(models.Model):
    _name = 'reimbursement.request.product.line'
    _description = 'reimbursement Request Product Line'

    reimbursement_request_id = fields.Many2one('reimbursement.request', string="reimbursement Request")
    internal_request_id = fields.Many2one('ad.internal.request', string="Internal Request", readonly=True)
    product_id = fields.Many2one('product.product', string="Product")
    product_uom = fields.Many2one('uom.uom', string="UoM")
    product_qty = fields.Float(string="Quantity")
    price_unit = fields.Float(string="Unit Price")
    ref = fields.Char()
    currency_id = fields.Many2one(
        'res.currency',
        string="Currency",
        related='internal_request_id.currency_id',
        store=True,
        readonly=True
    )
    income_analytic_account_id = fields.Many2one(
        'account.analytic.account',
        string="Analytic Account",
    )
    analytic_distribution = fields.Json(
        string="Analytic Distribution",
        default=list,  # زي الموديل التاني
    )
    analytic_precision = fields.Integer(
        string="Analytic Precision",
        related='currency_id.decimal_places',
        readonly=True,
    )
    general_account_id = fields.Many2one('account.account', string="Financial Account")

    @api.onchange('product_id')
    def _onchange_product_id(self):
        """لو المستخدم غيّر المنتج يدويًا داخل سطر الاستعاضة، حمّل الـ UoM والسعر والتوزيعة."""
        if self.product_id:
            self.price_unit = self.product_id.list_price
            self.product_uom = self.product_id.uom_id

            category = self.product_id.categ_id
            distribution_model = self.env['account.analytic.distribution.model'].search([
                ('product_categ_id', '=', category.id)
            ], limit=1)

            if distribution_model:
                if distribution_model.analytic_distribution:
                    analytic_dict = distribution_model.analytic_distribution
                    if isinstance(analytic_dict, dict) and analytic_dict:
                        analytic_id = list(analytic_dict.keys())[0]
                        self.income_analytic_account_id = int(analytic_id)
                        self.analytic_distribution = analytic_dict

                if distribution_model.general_account_id:
                    self.general_account_id = distribution_model.general_account_id

    price_subtotal = fields.Monetary(
        string="Subtotal",
        currency_field='currency_id',
        compute='_compute_price_subtotal',
        store=True,
    )

    @api.depends('product_qty', 'price_unit')
    def _compute_price_subtotal(self):
        for line in self:
            line.price_subtotal = (line.product_qty or 0.0) * (line.price_unit or 0.0)

    @api.model
    def get_reimb_lines_total(self, domain=None):
        """إجمالي مبالغ سطور الاستعاضة (sum للـ price_subtotal)."""
        lines = self.sudo().search(domain or [])
        total = sum(lines.mapped('price_subtotal'))
        cur = self.env.company.currency_id
        return {'total': float(total), 'symbol': cur.symbol or 'OMR'}
