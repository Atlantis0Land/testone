from odoo import models, fields

class SubStage(models.Model):
    _name = 'sub.stage'
    _description = 'Sub Stage'

    name = fields.Char(string="Sub Stage ", required=True)
    approver_sub_line_ids = fields.One2many('ad.internal.request.sub.stage.line', 'sub_stage_id', string='Approver  Sub Lines')





class adSubStageLine(models.Model):
    _name = 'ad.internal.request.sub.stage.line'
    _description = 'Sub Stage Line'

    sub_stage_id = fields.Many2one('sub.stage', ondelete='cascade', required=True,
                                      string='sub Type')
    name = fields.Char(string="Sub Stage Name", required=True)
    user_ids = fields.Many2many('res.users', required=True, string='Approver User')
    sequence = fields.Integer(string="Sequence", store=True)
    is_selected = fields.Boolean(string="Delivery Selected")
    is_selected_payment = fields.Boolean(string="Payment Selected")
    is_selected_po = fields.Boolean(string="po Selected")
    is_selected_installments = fields.Boolean(string="Installments Selected")
    show_partner_page = fields.Boolean(string="Show Partner Page")
    is_manager = fields.Boolean(string="Is Manager")
    is_department_manager = fields.Boolean(string="Is Department Manager")
    is_requester = fields.Boolean(string="Is Requester")
    is_warehouse_manager = fields.Boolean(string="Is Warehouse Manager")
    is_create_request = fields.Boolean(string="Create Online Request")

    is_storekeeper = fields.Boolean(string="Treasurer", help="Allow Treasurer (requester's warehouse users) to approve this stage.")





