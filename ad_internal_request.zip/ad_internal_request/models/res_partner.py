
from odoo import models, fields

class ResPartner(models.Model):
    _inherit = 'res.partner'
    _description = 'Res Partner'

    is_vendor = fields.Boolean(string="Is Vendor")


