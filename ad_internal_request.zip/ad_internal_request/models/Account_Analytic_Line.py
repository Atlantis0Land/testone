from odoo import models, fields, api, _
from odoo.exceptions import UserError


class AccountAnalyticLine(models.Model):
    _inherit = 'account.analytic.line'

    request_id = fields.Many2one(
        'ad.internal.request',
        string='Internal Request',
        readonly=True,
        ondelete='cascade',
    )
    request_id_remi= fields.Many2one(
        'reimbursement.request',
        string="Reimbursement Request",
        ondelete='cascade',
        index=True,
        readonly=True,

        required=False,
    )

    def action_open_internal_request(self):
        self.ensure_one()
        if not self.request_id:
            raise UserError(_("No Internal Request linked."))
        return {
            'name': _('Internal Request'),
            'type': 'ir.actions.act_window',
            'res_model': 'ad.internal.request',
            'view_mode': 'form',
            'res_id': self.request_id.id,
            'target': 'current',
        }
