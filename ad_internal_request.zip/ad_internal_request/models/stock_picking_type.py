from odoo import models, fields

class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    is_delivery_order = fields.Boolean(string="Is delivery  order?")
