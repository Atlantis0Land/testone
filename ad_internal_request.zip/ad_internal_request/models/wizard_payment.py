from odoo import models, fields,api ,_
from odoo.exceptions import UserError, ValidationError
import json
from dateutil.relativedelta import relativedelta

class AdInstallmentsWizard(models.TransientModel):
    _name = 'ad.installments.wizard'
    _description = 'Installments Wizard'

    request_id = fields.Many2one('ad.internal.request', string="Request", required=True)
    installment_count = fields.Integer(string="Installment Count", required=True, default=2)
    due_date = fields.Date(string='Due Date',)

    def action_generate_payments(self):
        if self.installment_count <= 0:
            raise UserError(_("Please enter a valid number of installments."))

        old_installments = self.request_id.installment_line_ids

        if any(line.paid for line in old_installments):
            raise UserError(_("لا يمكن توليد دفعات جديدة لأن هناك دفعة واحدة على الأقل مدفوعة بالفعل!"))

        paid_amount = sum(line.amount for line in old_installments if line.paid)
        unpaid_lines = old_installments.filtered(lambda l: not l.paid)

        total_amount = sum(line.price_subtotal for line in self.request_id.product_line_ids)
        if total_amount <= 0:
            raise UserError(_("Total amount must be greater than 0! Please add products."))

        unpaid_lines.unlink()

        unpaid_amount = total_amount - paid_amount

        if unpaid_amount < 0:
            raise UserError(_("Paid amount is more than total!"))

        if self.installment_count == 0:
            raise UserError(_("Please set a valid number of installments."))

        if unpaid_amount == 0:
            return {'type': 'ir.actions.act_window_close'}

        amount_per_installment = unpaid_amount / self.installment_count

        for i in range(self.installment_count):
            self.env['installment.line'].create({
                'request_id': self.request_id.id,
                'description': f'Installment {i + 1}',
                'amount': amount_per_installment,
                'due_date': fields.Date.today() + relativedelta(months=i + 1),
            })

        return {'type': 'ir.actions.act_window_close'}


