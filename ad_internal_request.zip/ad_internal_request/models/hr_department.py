from odoo import models, fields

class HrDepartment(models.Model):
    _inherit = 'hr.department'

    manager_department_id = fields.Many2one(
        'hr.employee',
        string="Manager Department",
        help="Select the employee who is the manager of this department."
    )