from odoo import models, fields, api, _


class StageRequiredComplete(models.Model):
    _name = 'ad.stage.required.complete'
    _description = 'Stage Required Complete'

    name = fields.Char(string="Name", required=True)
    state = fields.Selection([('complete', 'Complete'),
                              ('incomplete', 'Incomplete')],
                             string="State", default='incomplete')
    request_id = fields.Many2one('ad.internal.request')
    user_id = fields.Many2one('res.users', default=lambda self: self.env.uid, ondelete='cascade')

