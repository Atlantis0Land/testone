from odoo import models, fields

class adRequestType(models.Model):
    _name = 'ad.internal.request.type'
    _description = 'Internal Request Type'

    name = fields.Char(string='Request Type', required=True)
    stage_id = fields.Many2one('ad.internal.request.stage', string="Stage")

    approver_line_ids = fields.One2many('ad.internal.request.type.approver', 'request_type_id', string='Approver Lines')
    
    internal_request = fields.Boolean(string='Internal Request')
    # purchase_order = fields.Boolean(string='Purchase Order')
    # purchase_request = fields.Boolean(string='Purchase Request')
    # tender = fields.Boolean(string='Tender')
    # direct_assignment = fields.Boolean(string='Direct Assignment')
    # warehouse_stage = fields.Boolean(string='Warehouse Stage')
    code = fields.Char(string='Code')
    # default_type = fields.Boolean(string='Default Type')
    is_stage = fields.Boolean(string='Is Stage', default=False)
    is_directorate = fields.Boolean("Directorate")
    is_municipality = fields.Boolean("Municipality")
    is_reimbursement = fields.Boolean("Reimbursement")
    max_total_lines = fields.Float(string="Max Total Lines")
