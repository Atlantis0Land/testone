from odoo import models, fields

class AdInternalRequestApproval(models.Model):
    _name = 'ad.internal.request.approval'
    _description = 'Internal Request Approval'

    request_id = fields.Many2one('ad.internal.request', string='Request', ondelete='cascade',)
    user_id = fields.Many2one('res.users', string='User', default=lambda self: self.env.user)
    date = fields.Datetime(string='Date', default=fields.Datetime.now)
    action = fields.Char(string='Action', default='approve')
    rejection_reason   = fields.Text(string='Rejection Reason')

    sequence = fields.Integer(string="Sequence", compute="_compute_sequence")
    description = fields.Char(string="Description")


