from odoo import models, fields, api

class AdRequestStage(models.Model):
    _name = 'ad.internal.request.stage'
    _description = 'Internal Request Stage'

    name = fields.Char(string='Stage Name', required=True)
    description = fields.Char(string="Description")
    show_availability = fields.Boolean(string='Show Availability', default=False)

    sequence = fields.Integer(string='Sequence', default=10)
    is_available = fields.Boolean(string='Is Available', default=False)
    is_unavailable = fields.Boolean(string='Is Not Available', default=False)
    show_partner_page = fields.Boolean(string="Show Partner Page")


    available_type = fields.Selection(
        [
            ('directorate', 'Is Directorate'),
            ('municipality', 'Is Municipality'),
        ],
        string='Available Type'
    )

    unavailable_type = fields.Selection(
        [
            ('directorate', 'Is Directorate'),
            ('municipality', 'Is Municipality'),
        ],
        string='Unavailable Type'
    )

    sub_stage_available_directorate_id = fields.Many2one(
        'sub.stage',
        string='Sub Stage Available Directorate',

    )

    sub_stage_unavailable_directorate_id = fields.Many2one(
        'sub.stage',
        string='Sub Stage Unavailable Directorate',

    )

    sub_stage_available_municipality_id = fields.Many2one(
        'sub.stage',
        string='Sub Stage Available Municipality',

    )

    sub_stage_unavailable_municipality_id = fields.Many2one(
        'sub.stage',
        string='Sub Stage Unavailable Municipality',

    )
    show_tender = fields.Boolean(string='Show Tender', default=False)
    show_purchase = fields.Boolean(string='Show Purchase', default=False)
    show_direct_assign = fields.Boolean(string='Show Direct Assign', default=False)

    tender_request_type_id = fields.Many2one('sub.stage', string='Tender Request Type')
    purchase_request_type_id = fields.Many2one('sub.stage', string='Purchase Request Type')
    direct_assign_request_type_id = fields.Many2one('sub.stage', string='Direct Assign Request Type')

    @api.onchange('show_availability')
    def _onchange_show_availability(self):
        for record in self:
            if record.show_availability:
                record.is_available = False
                record.is_unavailable = False
                record.available_type = False
                record.unavailable_type = False


