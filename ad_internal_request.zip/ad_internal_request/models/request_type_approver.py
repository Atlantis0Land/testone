from odoo import models, fields,api,_
from odoo.exceptions import  ValidationError



class adRequestTypeApprover(models.Model):
    _name = 'ad.internal.request.type.approver'
    _description = 'Request Type Approver Line'

    request_type_id = fields.Many2one('ad.internal.request.type', ondelete='cascade', required=True,
                                      string='Request Type')
    stage_id = fields.Many2one('ad.internal.request.stage', required=True, string='Stage')

    # user_id = fields.Many2one('res.users', required=True, string='Approver User')
    user_ids = fields.Many2many(
        comodel_name='res.users',
        relation='ad_internal_req_type_approver_user_rel',
        column1='approver_line_id',
        column2='user_id',
        string='Approver Users',
    )
    sequence = fields.Integer(string="Sequence", related='stage_id.sequence', store=True)
    is_reminder = fields.Boolean(string="Reminder")

    # sub_stage_id = fields.Many2one('sub.stage', string="Sub Stages")

    # is_internal_req = fields.Boolean(string="Internal Request")
    is_entry_items = fields.Boolean(string="Entry Items")
    is_selected = fields.Boolean(string="Delivery Selected")
    is_selected_payment = fields.Boolean(string="Payment Selected")
    is_selected_po = fields.Boolean(string="po Selected")
    is_selected_installments = fields.Boolean(string="Installments Selected")


    is_required_manager_department = fields.Boolean(
        string="Required Manager Department"
    )
    show_partner_page = fields.Boolean(string="Show Partner Page")
    is_manager = fields.Boolean(string="Is Manager")
    is_department_manager = fields.Boolean(string="Is Department Manager")
    is_requester = fields.Boolean(string="Is Requester")
    is_warehouse_manager = fields.Boolean(string="Is Warehouse Manager")
    is_create_request = fields.Boolean(string="Create Online Request")

    is_storekeeper = fields.Boolean(string="Treasurer", help="Allow Treasurer (requester's warehouse users) to approve this stage.")

    @api.constrains('user_ids', 'is_manager', 'is_department_manager', 'is_requester', 'is_warehouse_manager',
                    'is_create_request')
    def _check_user_ids_required(self):
        for rec in self:
            if not any([
                rec.is_manager,
                rec.is_department_manager,
                rec.is_requester,
                rec.is_warehouse_manager,
                rec.is_create_request
            ]) and not rec.user_ids:
                raise ValidationError(
                    _("You must specify at least one Approver User if no system role is selected (manager/requester/etc)."))


