from odoo import models, fields,api,_

class ReimbursementStage(models.Model):
    _name = 'reimbursement.stage'
    _description = 'Reimbursement Stage'

    name = fields.Char(string="Stage Name", required=True)
    approver_stage_line_ids = fields.One2many(
        'reimbursement.stage.line',
        'stage_id',
        string='Approver Stage Lines'
    )
    is_default_stage = fields.Boolean(string="Default Stage", default=False)
    is_entry_button = fields.Boolean(string="Entry Button", default=False)





class ReimbursementStageLine(models.Model):
    _name = 'reimbursement.stage.line'
    _description = 'Reimbursement Stage Line'

    stage_id = fields.Many2one(
        'reimbursement.stage',
        ondelete='cascade',
        required=True,
        string='Stage'
    )
    name = fields.Char(string="reimbursement stage Name", required=True)
    user_ids = fields.Many2many('res.users', string='Approver Users', required=True)
    sequence = fields.Integer(string="Sequence", store=True)
    # is_selected = fields.Boolean(string="Delivery Selected")
    # is_selected_payment = fields.Boolean(string="Payment Selected")
    # is_selected_po = fields.Boolean(string="PO Selected")
    # is_selected_installments = fields.Boolean(string="Installments Selected")
    # show_partner_page = fields.Boolean(string="Show Partner Page")
