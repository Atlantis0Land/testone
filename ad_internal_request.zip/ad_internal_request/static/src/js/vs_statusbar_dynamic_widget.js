///** @odoo-module **/
//
//import { Component, onWillStart, onWillUpdateProps, useState } from "@odoo/owl";
//import { useService } from "@web/core/utils/hooks";
//import { registry } from "@web/core/registry";
//
//export class VsStatusbarDynamicWidget extends Component {
//    setup() {
//        this.rpc = useService("rpc");
//        this.state = useState({ stages: [] });
//        this.recordId = this.props.record?.data?.id;
//        this.stageId = this.props.value;
//
//        // لأول مرة عند بدء الودجت
//        onWillStart(() => this.loadStages());
//
//        // عند تغيّر الـ props (مثلاً بعد الحفظ)
//        onWillUpdateProps(async (nextProps) => {
//            const newId = nextProps.record?.data?.id;
//            if (newId && newId !== this.recordId) {
//                this.recordId = newId;
//                await this.loadStages();
//            }
//        });
//    }
//
//    async loadStages() {
//        if (this.recordId) {
//            this.state.stages = await this.rpc(`/vs/internal_request/stages_statusbar/${this.recordId}`);
//        } else {
//            this.state.stages = [];
//        }
//    }
//
//    async selectStage(stageId) {
//        if (stageId !== this.stageId) {
//            await this.props.update(stageId);
//            this.stageId = stageId;
//            await this.loadStages();
//        }
//    }
//}
//
//VsStatusbarDynamicWidget.template = "VsInternalRequest.StatusbarDynamicWidget";
//registry.category("fields").add("vs_statusbar_dynamic_widget", VsStatusbarDynamicWidget);

/** @odoo-module **/

import { Component, onWillStart, onWillUpdateProps, useState } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { registry } from "@web/core/registry";

export class VsStatusbarDynamicWidget extends Component {
    setup() {
        this.rpc = useService("rpc");
        this.state = useState({ stages: [] });
        this.recordId = this.props.record?.data?.id;
        this.stageId = this.props.value;

        onWillStart(() => this.loadStages());

        onWillUpdateProps(async (nextProps) => {
            const newId = nextProps.record?.data?.id;
            if (newId && newId !== this.recordId) {
                this.recordId = newId;
                await this.loadStages();
            }
        });
    }

    async loadStages() {
        if (this.recordId) {
            this.state.stages = await this.rpc(`/vs/internal_request/stages_statusbar/${this.recordId}`);
        } else {
            this.state.stages = [];
        }
    }

    async selectStage(stageId) {
        if (stageId !== this.stageId) {
            await this.props.update(stageId);
            this.stageId = stageId;
            await this.loadStages();
        }
    }
}

VsStatusbarDynamicWidget.template = "VsInternalRequest.StatusbarDynamicWidget";
registry.category("fields").add("vs_statusbar_dynamic_widget", VsStatusbarDynamicWidget);

