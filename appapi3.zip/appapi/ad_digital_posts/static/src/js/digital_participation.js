/** @odoo-module **/

import publicWidget from 'web.public.widget';
import ajax from 'web.ajax';

publicWidget.registry.DigitalParticipationTabs = publicWidget.Widget.extend({
    selector: '#digital-participation-topics',

    events: {
        'click .tab-link': '_onTabClick',
    },

    _onTabClick: function (event) {
        console.log('_onTabClick triggered');

        const tabs = document.querySelectorAll('.tab-link');
        const allCards = document.querySelectorAll('.participation-card');
        const allSections = document.querySelectorAll('.section-content');

        console.log('tabs:', tabs);
        console.log('allCards:', allCards);
        console.log('allSections:', allSections);

        tabs.forEach(tab => {
            console.log('Removing active class from tab:', tab);
            tab.classList.remove('active');
        });

        event.currentTarget.classList.add('active');
        console.log('Added active class to:', event.currentTarget);

        const type = event.currentTarget.getAttribute('data-type');
        console.log('Selected type:', type);

        this._filterSections(type, allSections, allCards);
    },

    _filterSections: function (type, allSections, allCards) {
        console.log('_filterSections triggered with type:', type);

        allSections.forEach(section => {
            console.log('Hiding section:', section);
            section.style.display = 'none';
        });

        allCards.forEach(card => {
            console.log('Hiding card:', card);
            card.style.display = 'none';
        });

        const selectedSection = document.querySelectorAll('.post-type-' + type);
        console.log('selectedSection:', selectedSection);

        selectedSection.forEach(card => {
            console.log('Displaying card:', card);
            card.style.display = 'flex';
        });
    },

    start: function () {
        console.log('start() triggered');

        this._super.apply(this, arguments);
        this._filterSections('digital_topic', document.querySelectorAll('.section-content'), document.querySelectorAll('.participation-card'));
        this._delegateEvents();
    },

    _delegateEvents: function () {
        $(document).on('click', '.tab-link', (event) => {
            this._onTabClick(event);
        });
    }
});
