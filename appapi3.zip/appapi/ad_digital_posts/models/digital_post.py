from odoo import models, fields, api
import base64
from bs4 import BeautifulSoup


class DigitalPost(models.Model):
    _name = 'digital.post'
    _description = 'Digital Post'

    name = fields.Char(string='Title', required=True)
    image = fields.Binary(string='Image')
    content_html = fields.Html(string='Content')
    attachment_pdf = fields.Binary(string='PDF Attachment')
    url = fields.Char(string='External URL')
    type = fields.Selection([
        ('policies', 'Policies'),
        ('digital_participation', 'Digital Participation'),
        ('digital_topic', 'Digital Topic'),
    ], string='Type', required=True)

    image_base64 = fields.Char(string='Image Base64', compute='_compute_image_base64')
    sliced_content = fields.Char(string='Sliced Content', compute='_compute_sliced_content')

    def _compute_image_base64(self):
        for post in self:
            if post.image:
                post.image_base64 = base64.b64encode(post.image).decode('utf-8')
            else:
                post.image_base64 = ''

    @api.depends('content_html')
    def _compute_sliced_content(self):
        for post in self:
            if post.content_html:
                soup = BeautifulSoup(post.content_html, 'html.parser')
                text = soup.get_text()
                post.sliced_content = text[:300] + "..." if len(text) > 300 else text
            else:
                post.sliced_content = "No content available"



    @api.model
    def create(self, vals):
        if vals.get('url') and not vals['url'].startswith(('http://', 'https://')):
            vals['url'] = 'http://' + vals['url']
        return super(DigitalPost, self).create(vals)

    def write(self, vals):
        if vals.get('url') and not vals['url'].startswith(('http://', 'https://')):
            vals['url'] = 'http://' + vals['url']
        return super(DigitalPost, self).write(vals)