from odoo import fields, models

class ResConfigSetting(models.TransientModel):
    _inherit = 'res.config.settings'

    cover_digital = fields.Image(string='Cover Digital', related='company_id.cover_digital', readonly=False)


class ResCompany(models.Model):
    _inherit = 'res.company'

    cover_digital = fields.Image(string='Cover Digital')

