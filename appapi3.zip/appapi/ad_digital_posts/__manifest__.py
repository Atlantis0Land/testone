# -*- coding: utf-8 -*-
{
    'name': 'Digital Posts',

    'summary': 'Manage digital posts (images, content, PDFs, URLs)',

    "author": "Sysgates _ Ahmed Eldweek",
    "license": "LGPL-3",
    "website": "https://www.sysgates.com",
    # 'category': 'Accounting & Finance',
    'category': 'Uncategorized',
    'version': '16.0.1.0.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'website', 'portal'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/digital_participation_template.xml',
        'views/digital_post_views.xml',
        'views/res_config_settings_views.xml',
    ],

    'assets': {
        'web.assets_frontend': [
            'ad_digital_posts/static/src/css/style.css',
            'ad_digital_posts/static/src/js/digital_participation.js',
        ],
    },

    'installable': True,
    'application': False,
    'auto_install': False,

}
