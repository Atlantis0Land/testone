from odoo import http
from odoo.http import request
from odoo.exceptions import UserError
from werkzeug.exceptions import NotFound


class DigitalController(http.Controller):

    # Route for displaying all online requests in Kanban view
    @http.route('/digital-participation', type='http', auth='user', website=True)
    def digital_participation(self, **kwargs):
        # Fetch posts from the model
        posts = request.env['digital.post'].search([], order='id desc')
        company = request.env.company



        return request.render('ad_digital_posts.digital_participation_template', {
            'posts': posts,
            'cover_digital': company.cover_digital,
        })

    @http.route('/digital-participation/download_pdf/<int:post_id>', type='http', auth='user')
    def download_pdf(self, post_id, **kwargs):
        post = request.env['digital.post'].sudo().browse(post_id)

        if not post:
            raise NotFound("Post not found.")

        query = """
        SELECT * FROM public.ir_attachment
        WHERE res_model = 'digital.post' AND res_id = %s
        ORDER BY id DESC
        LIMIT 1
        """


        request.env.cr.execute(query, (post.id,))
        attachment_data = request.env.cr.fetchone()

        if not attachment_data:
            raise NotFound("No attachment found for this post.")

        attachment = request.env['ir.attachment'].sudo().browse(attachment_data[0])
        return request.redirect('/web/content/' + str(attachment.id) + '?download=true')

    @http.route('/digital-participation/details/<int:post_id>', type='http', auth='user', website=True)
    def digital_post_details(self, post_id, **kwargs):
        post = request.env['digital.post'].sudo().browse(post_id)
        if not post:
            raise NotFound("Post not found.")

        return request.render('ad_digital_posts.digital_post_details_template', {
            'post': post
        })
