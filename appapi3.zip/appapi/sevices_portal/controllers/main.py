import base64
import logging
import traceback

from odoo import http, _
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from operator import itemgetter
from odoo.tools import groupby as groupbyelem
from werkzeug.exceptions import Forbidden

_logger = logging.getLogger(__name__)


class PortalServiceRequest(CustomerPortal):
    @http.route('/service/api_key', type='json', auth='public')
    def get_google_api_key(self):
        setting = http.request.env['service.category.config'].sudo().search([], limit=1)
        print("setting", setting)
        return {'key': setting.api_key or ''}

    def _prepare_service_domain(self):
        return [('request_owner_id', '=', request.env.user.id)]

    def _get_searchbar_sortings(self):
        return {
            'date': {'label': _('Newest'), 'order': 'create_date desc'},
            'name': {'label': _('Name'), 'order': 'name'},
            'stage': {'label': _('Stage'), 'order': 'stage_id'},
        }

    def _get_groupby_mapping(self):
        return {
            'stage': 'stage_id',
            'category': 'category_id',
        }

    def _get_search_domain(self, search_in, search):
        domain = []
        if search_in in ('name', 'all'):
            domain += [('name', 'ilike', search)]
        if search_in in ('stage', 'all'):
            domain += [('stage_id.name', 'ilike', search)]
        if search_in in ('category', 'all'):
            domain += [('category_id.name', 'ilike', search)]
        return domain

    def _get_filter_options(self):
        # safer than .sudo() unless needed
        categories = request.env['service.category'].sudo().search([])
        stages = request.env['service.stage'].sudo().search([])

        filters = {
            'all': {'label': _('All'), 'domain': []},
        }

        for cat in categories:
            filters[f'cat_{cat.id}'] = {
                'label': f'Category: {cat.name}',
                'domain': [('category_id', '=', cat.id)],
            }

        for stage in stages:
            filters[f'stage_{stage.id}'] = {
                'label': f'Stage: {stage.name}',
                'domain': [('stage_id', '=', stage.id)],
            }

        return filters

    @http.route(['/my/requests', '/my/requests/page/<int:page>'], type='http', auth="user", website=True)
    def portal_my_requests(self, page=1, sortby='date', groupby='none', search='', search_in='all', filterby='all',
                           **kwargs):
        ServiceRequest = request.env['service.request']
        domain = self._prepare_service_domain()

        # Filters
        filters = self._get_filter_options()
        if filterby in filters:
            domain += filters[filterby]['domain']

        # Search
        if search:
            domain += self._get_search_domain(search_in, search)

        # Order
        order = self._get_searchbar_sortings().get(sortby, {'order': 'create_date desc'})['order']

        # Pager
        total = ServiceRequest.search_count(domain)
        pager = portal_pager(
            url='/my/requests',
            total=total,
            page=page,
            step=self._items_per_page
        )

        # Records
        requests = ServiceRequest.search(domain, order=order, limit=self._items_per_page, offset=pager['offset'])

        # Grouping
        grouped_requests = [requests]
        groupby_field = self._get_groupby_mapping().get(groupby)
        if groupby_field:
            grouped_requests = [ServiceRequest.concat(*g) for k, g in groupbyelem(requests, itemgetter(groupby_field))]

        values = self._prepare_portal_layout_values()
        values.update({
            'grouped_requests': grouped_requests,
            'pager': pager,
            'page_name': 'request',
            'default_url': '/my/requests',
            'searchbar_sortings': self._get_searchbar_sortings(),
            'searchbar_groupby': {
                'none': {'input': 'none', 'label': _('None')},
                'stage': {'input': 'stage', 'label': _('Stage')},
                'category': {'input': 'category', 'label': _('Category')},
            },
            'searchbar_inputs': {
                'all': {'input': 'all', 'label': _('All')},
                'name': {'input': 'name', 'label': _('Name')},
                'stage': {'input': 'stage', 'label': _('Stage')},
                'category': {'input': 'category', 'label': _('Category')},
            },
            'searchbar_filters': filters,
            'search': search,
            'search_in': search_in,
            'sortby': sortby,
            'groupby': groupby,
            'filterby': filterby,
        })
        return request.render('sevices_portal.portal_my_requests', values)

    @http.route(['/my/requests/<int:request_id>'], type='http', auth="user", website=True)
    def portal_request_detail(self, request_id, **kwargs):
        service_request = request.env['service.request'].sudo().browse(request_id)

        # Security check
        if not service_request.exists() or service_request.request_owner_id.id != request.env.user.id:
            raise Forbidden()

        config = service_request.service_type_id.config_id
        all_fields = [
            'phone', 'national_id', 'location', 'government_id',
            'state_id', 'description','from_date','to_date' , 'terms_condtions_t','terms_condtions_b', 'village_name_id'
        ]

        visible_fields = []
        if config:
            for field in all_fields:
                config_field_val = getattr(config, f"has_{field}", 'no')
                field_value = getattr(service_request, field, False)
                if config_field_val in ['required', 'optional'] and field_value:
                    visible_fields.append(field)

        values = self._prepare_portal_layout_values()
        values.update({
            'service_request': service_request,
            'page_name': 'request_detail',
            'visible_fields': visible_fields,
        })
        return request.render('sevices_portal.portal_request_detail', values)

    @http.route(['/my/requests/submit'], type='http', auth="user", website=True, methods=["POST"])
    def portal_submit_request(self, **post):
        files = request.httprequest.files

        new_request = request.env['service.request'].sudo().create({
            'name': post.get('name'),
            'partner_id': request.env.user.partner_id.id,
            'category_id': int(post.get('category_id')) if post.get('category_id') else False,
            'sub_category_id': int(post.get('sub_category_id')) if post.get('sub_category_id') else False,
            'service_type_id': int(post.get('service_type_id')) if post.get('service_type_id') else False,
            'reason': post.get('reason'),
            'phone': post.get('phone'),
            'from_date': post.get('from_date') or False,
            'to_date': post.get('to_date') or False,
            'national_id': post.get('national_id'),
            'government_id': int(post.get('government_id')) if post.get('government_id') else False,
            'state_id': int(post.get('state_id')) if post.get('state_id') else False,
            'location': post.get('location'),
            'request_owner_id': request.env.user.id,
            'terms_condtions_b': post.get('terms_condtions_b'),
            'terms_condtions_t': post.get('terms_condtions_t'),
            'village_name_id': int(post.get('village_name_id')) if post.get('village_name_id') else False,

        })

        # ⬇️ المرفقات
        try:
            service_type = request.env['service.type'].sudo().browse(int(post.get('service_type_id')))
            document_types = service_type.config_id.document_type_ids
            print("document types", document_types)
            line_count = len(document_types) if document_types else 0
            print("document line_count", line_count)
        except:
            line_count = 0

        for i, doc in enumerate(document_types, start=1):
            doc_id = doc.id
            file_name = post.get(f'attachment_file_name_{i}')
            doc_name = doc.name
            uploaded_file = files.get(f'attachment_file_{i}')

            if uploaded_file:
                encoded = base64.b64encode(uploaded_file.read()).decode()
                ir_attachment = request.env['ir.attachment'].sudo().create({
                    'name': file_name or uploaded_file.filename,
                    'datas': encoded,
                    'file_name': doc_name,
                    'res_model': 'attachment.document.request',
                    'res_field': 'attachment',
                    'res_id': 0,
                    'type': 'binary',
                    'mimetype': uploaded_file.content_type,
                    'public': True,
                })

                request.env['attachment.document.request'].sudo().create({
                    'file_name': doc_name,

                    'request_id': new_request.id,
                    'document_id': doc_id,
                    'attachment_filename': doc_name or uploaded_file.filename,
                    'attachment_id': ir_attachment.id,
                })

        return request.redirect(f'/my/requests/confirmation?ref={new_request.reference}')

    @http.route('/my/requests/create', type='http', auth="user", website=True)
    def create_service_request_form(self, **post):
        partner = request.env.user.partner_id
        service_types = request.env['service.type'].sudo().search([])
        service_request = request.env['service.request']
        categories = request.env['service.category'].sudo().search([])
        config = service_types[:1].config_id if service_types else False
        country_id = request.env['res.country'].sudo().search([('code', '=', 'OM')], limit=1)
        states = request.env['res.country.state'].sudo().search([('country_id', '=', country_id.id)])
        villages = request.env['res.state.village'].sudo().search([])

        values = {
            'categories': categories,
            'service_types': service_types,
            'service_request': service_request,
            'governments': request.env['res.country.government'].sudo().search([]),
            'states': states,

            'has_phone': config.has_phone if config else False,
            'has_from_date': config.has_from_date if config else False,
            'has_map': config.has_map if config else False,
            'has_government_id': config.has_government_id if config else False,
            'has_state_id': config.has_state_id if config else False,
            'has_village_name': config.has_village_name if config else False,
            'has_description': config.has_description if config else False,
            'has_national_id': config.has_national_id if config else False,
            'line_attachment_portal': config.line_attachment_portal if config else False,
            'partner_phone': partner.phone or '',
            'partner_national_id': partner.national_id or '',
            'terms_condtions_t_value': config.has_terms_condtions_t_1 if config else " ",
            'has_terms_condtions_t': config.has_terms_condtions_t if config else '',
            'has_terms_condtions_b': config.has_terms_condtions_b if config else False,
            'villages': villages


        }
        return request.render("sevices_portal.portal_create_request", values)

    @http.route('/my/requests/confirmation', type='http', auth="user", website=True)
    def request_confirmation(self, ref=None, **kwargs):
        return request.render("sevices_portal.portal_request_confirmation", {
            'ref': ref,
        })

    @http.route('/get_sub_categories', type='json', auth='public')
    def get_sub_categories(self, category_id):
        sub_cats = request.env['sub.service.category'].sudo().search([('category_id', '=', int(category_id))])
        return {'sub_categories': [{'id': sc.id, 'name': sc.name} for sc in sub_cats]}

    @http.route('/get_service_types', type='json', auth='public')
    def get_service_types(self, sub_category_id):
        types = request.env['service.type'].sudo().search([
            ('sub_category_id', '=', int(sub_category_id)),
            ('is_published', '=', True)
        ])
        return {
            'service_types': [{'id': t.id, 'name': t.name} for t in types]
        }

    @http.route('/get_service_config', type='json', auth='public', csrf=False)
    def get_service_config(self, service_type_id=None, **kwargs):
        print(f"▶▶▶ get_service_config called with service_type_id={service_type_id!r}")

        if not service_type_id:
            print("▶▶▶ No service_type_id provided, returning {}")
            return {}

        try:
            service_type = request.env['service.type'].sudo().browse(int(service_type_id))
            config = service_type.config_id
            if not config:
                print(f">>> No config found for service_type_id={service_type_id}")
                return {}

            # اجمع قائمة document types من الـ M2M
            doc_types = [{'id': d.id, 'name': d.name} for d in config.document_type_ids]
            print(f">>> Found {len(doc_types)} document_type_ids: {doc_types!r}")

            result = {
                'has_phone': config.has_phone,
                'has_map': config.has_map,
                'has_national_id': config.has_national_id,
                'has_government_id': config.has_government_id,
                'has_state_id': config.has_state_id,
                'has_description': config.has_description,
                'has_village_name': config.has_village_name,

                'has_terms_condtions_t': config.has_terms_condtions_t,
                'terms_condtions_t_value': config.has_terms_condtions_t_1,
                'has_terms_condtions_b': config.has_terms_condtions_b,
                'has_from_date': config.has_from_date,
                'document_type_ids': doc_types,
            }
            print(f">>> get_service_config returning: {result!r}")
            return result

        except Exception as e:
            print(f"❌ Exception in get_service_config for {service_type_id!r}: {e!r}")
            traceback.print_exc()
            return {}

    @http.route('/get_stages', type='json', auth='public')
    def get_stages_by_service_type(self, service_type_id):
        service_type = request.env['service.type'].sudo().browse(int(service_type_id))
        config = service_type.config_id
        stages = config.stage_ids.sorted(key=lambda s: s.sequence) if config else []
        return {
            'stages': [{'id': s.id, 'name': s.name} for s in stages]
        }

    @http.route('/get_stages', type='json', auth='public')
    def get_stages(self, service_type_id):
        if not service_type_id:
            return {'stages': []}

        fake_request = request.env['service.request'].sudo().new({
            'service_type_id': int(service_type_id)
        })
        fake_request._compute_stage_ids()

        stages_sorted = fake_request.stage_ids.sorted(lambda s: s.sequence)
        _logger.info("📦 Sorted stages:")

        lang = request.env.context.get('lang') or request.website.language_id.code
        _logger.info("🌐 Current language: %s", lang)

        stages = []
        for stage in stages_sorted:
            stage_name = stage.with_context(lang=lang).name
            _logger.info(" - %s (sequence: %s)", stage_name, stage.sequence)
            stages.append({'id': stage.id, 'name': stage_name})

        return {'stages': stages}

    @http.route('/get_document_types', type='json', auth='public')
    def get_document_types(self):
        documents = request.env['document.type'].sudo().search([])
        return {'document_types': [{'id': doc.id, 'name': doc.name} for doc in documents]}

    @http.route('/get_villages', type='json', auth='public')
    def get_villages(self, state_id):
        villages = request.env['res.state.village'].sudo().search([('state_id', '=', int(state_id))])
        return {'villages': [{'id': v.id, 'name': v.name} for v in villages]}
