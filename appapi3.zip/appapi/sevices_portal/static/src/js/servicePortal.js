/** @odoo-module **/
import publicWidget from 'web.public.widget';
import ajax from 'web.ajax';

console.log('🐞 [Debug] ▸ service_request_filter_map.js loaded');

publicWidget.registry.ServiceRequestFilter = publicWidget.Widget.extend({
    selector: '.service_request_form',

    events: {
        'change select[name="category_id"]': '_onCategoryChange',
        'change select[name="sub_category_id"]': '_onSubCategoryChange',
        'change select[name="service_type_id"]': '_onServiceTypeChange',
    },

    _onCategoryChange: function (event) {
        const categoryId = $(event.currentTarget).val();
        const $subSelect = this.$el.find('select[name="sub_category_id"]');
        const $typeSelect = this.$el.find('select[name="service_type_id"]');

        $subSelect.empty().append('<option value=""></option>');
        $typeSelect.empty().append('<option value=""></option>');

        if (categoryId) {
            ajax.jsonRpc('/get_sub_categories', 'call', { category_id: categoryId })
                .then((data) => {
                    data.sub_categories.forEach((sc) => {
                        $subSelect.append(`<option value="${sc.id}">${sc.name}</option>`);
                    });
                })
                .catch((err) => console.error('Error loading sub-categories:', err));
        }
    },

    _onSubCategoryChange: function (event) {
        const subCategoryId = $(event.currentTarget).val();
        const $typeSelect = this.$el.find('select[name="service_type_id"]');

        $typeSelect.empty().append('<option value=""></option>');

        if (subCategoryId) {
            ajax.jsonRpc('/get_service_types', 'call', { sub_category_id: subCategoryId })
                .then((data) => {
                    data.service_types.forEach((st) => {
                        $typeSelect.append(`<option value="${st.id}">${st.name}</option>`);
                    });
                })
                .catch((err) => console.error('Error loading service types:', err));
        }
    },

    _onServiceTypeChange: function (event) {
        const serviceTypeId = $(event.currentTarget).val();
        const $stageContainer      = this.$el.find('.stage-tracker-container');
        const $attachmentWrapper   = this.$el.find('.attachment-wrapper');
        const $locationMapDiv      = this.$el.find('#location_map');
        const $locationInput       = this.$el.find('input[name="location"]');


        const allFields = [
            'phone', 'national_id', 'location', 'government_id',
            'state_id', 'description','village_name',
            'from_date', 'to_date'
        ];

        $stageContainer.empty().hide();
        $attachmentWrapper.empty();
        $locationMapDiv.hide();
        $locationInput.closest('.field-group-location').hide();

        if (serviceTypeId) {
            ajax.jsonRpc('/get_service_config', 'call', { service_type_id: serviceTypeId })
                .then((config) => {
                       allFields.forEach((field) => {
                        const $group = this.$el.find(`.field-group-${field}`);
                        const configKey = (field === 'to_date') ? 'has_from_date' : `has_${field}`;
                        const configValue = config[configKey];
                        const isRequired  = configValue === 'required';
                        const isVisible   = configValue !== 'no';

                        if (isVisible) {
                            $group.show();
                            $group.find('input, select, textarea').prop('required', isRequired);
                        } else {
                            $group.hide();
                            $group.find('input, select, textarea').prop('required', false);
                        }
                    });

                    if (config.has_map && config.has_map !== 'no') {
//                       appear field location
                        $locationInput.closest('.field-group-location').show();

                        $locationMapDiv.show();

                        this._initGoogleMap($locationMapDiv, $locationInput);
                    } else {
                        $locationMapDiv.hide();
                        $locationInput.closest('.field-group-location').hide();
                    }
                    const $termsContainer = this.$el.find('.field-group-terms_condtions_t');
                    const $termsValueDiv  = $termsContainer.find('.term-value');
                    if (config.has_terms_condtions_t) {
                            //get key value from config
                        $termsValueDiv.html(config.terms_condtions_t_value);
                        $termsContainer.show();
                    } else {
                     // disappear value
                        $termsContainer.hide();
                        $termsValueDiv.empty();
                    }

                    console.log('Config document_type_ids:', config.document_type_ids);
                    const docs = config.document_type_ids || [];
                    $attachmentWrapper.empty();
                    docs.forEach((doc) => {
                        $attachmentWrapper.append(`
                            <div class="row mb-2">
                                <div class="col-md-4 d-flex align-items-center">
                                    <strong>${doc.name}</strong>
                                </div>
                                <div class="col-md-8">
                                    <input
                                        type="file"
                                        name="attachment_file_${doc.id}"
                                        class="form-control"
                                        data-doc-id="${doc.id}"
                                        placeholder="Upload file for ${doc.name}"
                                    />
                                </div>
                            </div>
                        `);
                    });
                })
                .catch((err) => {
                    console.error('Error loading service config:', err);
                });

            // 2) Load stage progress (كما عندك بالضبط)
//            ajax.jsonRpc('/get_stages', 'call', { service_type_id: serviceTypeId })
//                .then((data) => {
//                    if (data.stages && data.stages.length > 0) {
//                        const reversedStages = data.stages.slice().reverse();
//                        const firstStageId   = data.stages[0].id;
//
//                        $stageContainer.empty();
//                        reversedStages.forEach((stage, index) => {
//                            const isLast  = index === reversedStages.length - 1;
//                            const isFirst = stage.id === firstStageId;
//                            const badgeClass = isFirst
//                                ? 'bg-success text-white'
//                                : 'bg-light text-dark border';
//
//                            const html = `
//                                <div class="d-flex align-items-center gap-2">
//                                    <div class="badge px-4 py-2 rounded-pill fw-bold fs-6 ${badgeClass}">
//                                        ${stage.name}
//                                    </div>
//                                    ${!isLast ? '<i class="fa fa-angle-right text-muted fs-5"/>' : ''}
//                                </div>`;
//                            $stageContainer.append(html);
//                        });
//                        $stageContainer.show();
//                    }
//                })
//ajax.jsonRpc('/get_stages', 'call', { service_type_id: serviceTypeId })
//    .then((data) => {
//        const htmlDir  = document.documentElement.getAttribute('dir');
//        const htmlLang = document.documentElement.getAttribute('lang');
//        const urlLang  = window.location.pathname.split('/')[1] || '';
//        const isRtl    = htmlDir === 'rtl' || (htmlLang && htmlLang.startsWith('ar')) || urlLang === 'ar';
//
//        console.log('🐞 [Debug] ➔ دخلنا في then، data:', data);
//        console.log('🐞 [Debug] ➔ htmlDir:', htmlDir, '| htmlLang:', htmlLang, '| urlLang:', urlLang);
//        console.log('🐞 [Debug] ➔ isRtl؟', isRtl);
//
//        const stagesToShow = isRtl
//            ? data.stages.slice().reverse()
//            : data.stages.slice();
//
//        console.log('🐞 [Debug] ➔ original stages array:', data.stages.map(s => s.name));
//        console.log('🐞 [Debug] ➔ stagesToShow array (بعد الترتيب):', stagesToShow.map(s => s.name));
//
//        const firstStageId = data.stages[0] && data.stages[0].id;
//        console.log('🐞 [Debug] ➔ firstStageId:', firstStageId);
//
//        $stageContainer.empty();
//        console.log('🐞 [Debug] ➔ تفريغ $stageContainer تم.');
//
//        stagesToShow.forEach((stage, index) => {
//            const isLast  = index === stagesToShow.length - 1;
//            const isFirst = stage.id === firstStageId;
//            const badgeClass = isFirst
//                ? 'bg-success text-white'
//                : 'bg-light text-dark border';
//
//            const arrowIcon = isRtl
//                ? '<i class="fa fa-angle-right text-muted fs-5" aria-hidden="true"></i>'
//                : '<i class="fa fa-angle-right text-muted fs-5" aria-hidden="true"></i>';
//
//            console.log(`🐞 [Debug] ➔ rendering stage: "${stage.name}", index=${index}, isFirst=${isFirst}, isLast=${isLast}, arrowIcon:`, isRtl ? 'left' : 'right');
//
//            const html = `
//                <div class="d-flex align-items-center gap-2">
//                    <div class="badge px-4 py-2 rounded-pill fw-bold fs-6 ${badgeClass}">
//                        ${stage.name}
//                    </div>
//                    ${!isLast ? arrowIcon : ''}
//                </div>`;
//            $stageContainer.append(html);
//        });
//
//        console.log('🐞 [Debug] ➔ إظهار $stageContainer');
//        $stageContainer.show();
//
//    })
//                .catch((err) => console.warn('Failed to load stages:', err));
ajax.jsonRpc('/get_stages', 'call', { service_type_id: serviceTypeId })
    .then((data) => {
        const htmlDir  = document.documentElement.getAttribute('dir');
        const htmlLang = document.documentElement.getAttribute('lang');
        const urlLang  = window.location.pathname.split('/')[1] || '';
        const isRtl    = htmlDir === 'rtl' || (htmlLang && htmlLang.startsWith('ar')) || urlLang === 'ar';

        console.log('🐞 [Debug] ➔ دخلنا في then، data:', data);
        console.log('🐞 [Debug] ➔ htmlDir:', htmlDir, '| htmlLang:', htmlLang, '| urlLang:', urlLang);
        console.log('🐞 [Debug] ➔ isRtl؟', isRtl);

        const stagesToShow = isRtl
            ? data.stages.slice().reverse()
            : data.stages.slice();

        console.log('🐞 [Debug] ➔ original stages array:', data.stages.map(s => s.name));
        console.log('🐞 [Debug] ➔ stagesToShow array (بعد الترتيب):', stagesToShow.map(s => s.name));

        const firstStageId = data.stages[0] && data.stages[0].id;
        console.log('🐞 [Debug] ➔ firstStageId:', firstStageId);

        $stageContainer
            .empty()
            .removeClass('flex-row flex-row-reverse')
            .addClass(`d-flex ${isRtl ? 'flex-row-reverse' : 'flex-row'} justify-content-center`);
        console.log('🐞 [Debug] ➔ تفريغ $stageContainer تم.');

        stagesToShow.forEach((stage, index) => {
            const isLast  = index === stagesToShow.length - 1;
            const isFirst = stage.id === firstStageId;
            const badgeClass = isFirst
                ? 'bg-success text-white'
                : 'bg-light text-dark border';

            const arrowIcon = '<i class="fa fa-angle-right text-muted fs-5" aria-hidden="true"></i>';

            console.log(`🐞 [Debug] ➔ rendering stage: "${stage.name}", index=${index}, isFirst=${isFirst}, isLast=${isLast}`);

            const html = `
                <div class="d-flex align-items-center gap-2">
                    <div class="badge px-4 py-2 rounded-pill fw-bold fs-6 ${badgeClass}">
                        ${stage.name}
                    </div>
                    ${(isRtl && index !== 0) || (!isRtl && index !== stagesToShow.length - 1) ? arrowIcon : ''}

                </div>`;
            $stageContainer.append(html);
        });

        console.log('🐞 [Debug] ➔ إظهار $stageContainer');
        $stageContainer.show();
    })
    .catch((err) => console.warn('Failed to load stages:', err));

        } else {
            allFields.forEach((field) => {
                const $group = this.$el.find(`.field-group-${field}`);
                $group.hide();
                $group.find('input, select, textarea').prop('required', false);
            });
            $attachmentWrapper.empty();
            $locationMapDiv.hide();
            $locationInput.closest('.field-group-location').hide();
        }
    },


    _initGoogleMap: function ($mapDivDiv, $inputEl) {
        if (this._mapInitialized) {
            return;
        }
        this._mapInitialized = true;

        window.initMap = this._createMap.bind(this, $mapDivDiv, $inputEl);
        if (!window.google || !google.maps) {
            const script     = document.createElement('script');
            script.src       = [
                'https://maps.googleapis.com/maps/api/js',
                '?key=AIzaSyC05gQhCNI0_m5-To2npWMxT_KOSOLvsS4',
                '&callback=initMap'
            ].join('');
            script.async     = true;
            script.defer     = true;
            script.onerror   = () => console.error('❌ Failed to load Google Maps API');
            document.head.appendChild(script);
        } else {
            this._createMap($mapDivDiv, $inputEl);
        }
    },


    _createMap: function ($mapDivDiv, $inputEl) {
        const map = new google.maps.Map($mapDivDiv[0], {
//        get selected location abry , al zahraa
            center: { lat: 23.2281, lng: 56.5153 },
            zoom: 12,
        });
        let marker = null;

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    const userPos = {
                        lat: pos.coords.latitude,
                        lng: pos.coords.longitude,
                    };
                    map.setCenter(userPos);
                    map.setZoom(13);
//                    put marker
                    marker = new google.maps.Marker({
                        position: userPos,
                        map: map,
                    });
                    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${userPos.lat.toFixed(6)},${userPos.lng.toFixed(6)}`;
                    $inputEl
                        .val(mapsUrl)
                        .prop('readonly', true)
                        .css('cursor', 'pointer')
                        .off('click')
                        .on('click', () => { window.open(mapsUrl, '_blank'); });
                },
                (err) => {
                    console.warn('⚠️ Geolocation failed:', err);
                    const defaultPos = { lat: 23.2281, lng: 56.5153 };
                    marker = new google.maps.Marker({
                        position: defaultPos,
                        map: map,
                    });
                    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${defaultPos.lat.toFixed(6)},${defaultPos.lng.toFixed(6)}`;
                    $inputEl
                        .val(mapsUrl)
                        .prop('readonly', true)
                        .css('cursor', 'pointer')
                        .off('click')
                        .on('click', () => { window.open(mapsUrl, '_blank'); });
                }
            );
        } else {

            const defaultPos = { lat: 23.2281, lng: 56.5153 };
            marker = new google.maps.Marker({
                position: defaultPos,
                map: map,
            });
            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${defaultPos.lat.toFixed(6)},${defaultPos.lng.toFixed(6)}`;
            $inputEl
                .val(mapsUrl)
                .prop('readonly', true)
                .css('cursor', 'pointer')
                .off('click')
                .on('click', () => { window.open(mapsUrl, '_blank'); });
        }

        map.addListener('click', (e) => {
            const lat = e.latLng.lat().toFixed(6);
            const lng = e.latLng.lng().toFixed(6);
            if (marker) {
                marker.setMap(null);
            }
            marker = new google.maps.Marker({
                position: e.latLng,
                map: map,
            });
            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
            $inputEl
                .val(mapsUrl)
                .prop('readonly', true)
                .css('cursor', 'pointer')
                .off('click')
                .on('click', () => { window.open(mapsUrl, '_blank'); });
        });
    },


    start: function () {
        this._super.apply(this, arguments);
        const $stateSelect   = this.$el.find('[name="state_id"]');
        const $villageSelect = this.$el.find('[name="village_name_id"]');

        $stateSelect.on('change', () => {
            const stateId = $stateSelect.val();
            $villageSelect.empty().append('<option value="">Select Village</option>');
            if (stateId) {
                ajax.jsonRpc('/get_villages', 'call', { state_id: stateId })
                    .then(data => {
                        data.villages.forEach(v => {
                            $villageSelect.append(`<option value="${v.id}">${v.name}</option>`);
                        });
                    })
                    .catch(err => console.warn('Failed to fetch villages:', err));
            }
        });
    },
});
