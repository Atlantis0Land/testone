/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.PortalBookingWidget = publicWidget.Widget.extend({
    selector: '.js_template',

    events: {
        'click .action_book': '_onActionBookClick',
        'click .action_cancel': '_onActionCancelClick',
    },

    start() {
        console.log("✅ PortalBookingWidget is active!");
        return this._super(...arguments);
    },

    _onActionBookClick(ev) {
        const slotId = ev.currentTarget.dataset.id;
        console.log("🟢 Book clicked for slot ID:", slotId);
            },

    _onActionCancelClick(ev) {
        const slotId = ev.currentTarget.dataset.id;
        console.log("🔴 Cancel clicked for slot ID:", slotId);
    }
});
