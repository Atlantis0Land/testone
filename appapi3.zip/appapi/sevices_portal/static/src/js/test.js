/** @odoo-module **/

import publicWidget from 'web.public.widget';
import ajax from 'web.ajax';

publicWidget.registry.CityFilter = publicWidget.Widget.extend({
    selector: '.city_filter_container',

    events: {
        'change .depend_filter': '_onStateChange',
    },

    start() {
        return this._super(...arguments);
    },

    async _onStateChange(event) {
        const stateId = $(event.currentTarget).val();

        if (stateId) {
            try {
                const data = await ajax.jsonRpc('/get_cities_by_state', 'call', { state_id: stateId });
                const $citySelect = this.$el.find('#city1'); // Select the city dropdown within the widget's DOM scope

                if ($citySelect.length && $citySelect.is(':visible')) {
                    $citySelect.empty(); // Clear existing options
                    $citySelect.append('<option value="">Select...</option>'); // Add default option

                    if (data?.cities?.length) {
                        data.cities.forEach((city) => {
                            $citySelect.append(`<option value="${city.id}">${city.name}</option>`);
                        });
                    } else {
                        console.warn("No cities found for the selected state.");
                    }
                } else {
                    console.error("City select element not found or not visible. Please check the DOM structure or the widget selector.");
                }
            } catch (error) {
                console.error("Error fetching cities:", error);
            }
        } else {
            this._resetCityDropdown();
        }
    },

    _resetCityDropdown() {
        const $citySelect = this.$el.find('#city1');
        $citySelect.html('<option value="">Select...</option>'); // Only show default option
    }
});

????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

/* @odoo-module */

import { Component, mount, whenReady, useState, onWillStart } from "@odoo/owl";
import { jsonrpc } from "@web/core/network/rpc_service";
import { templates } from "@web/core/assets";

class ClassPortalComponent extends Component {
    template = "gym_portal.portal_class_detail_view";

    setup() {
        console.log("the classportal component")
        this.state = useState({
            slots: [],
        });

}}

