/** @odoo-module **/

import publicWidget from 'web.public.widget';
import ajax from 'web.ajax';

publicWidget.registry.GoogleMapPickerLink = publicWidget.Widget.extend({
    selector: '.service_request_form',

    /**
     * Start: اجلب مفتاح Google Maps من السيرفر ثم حمّل سكريبت الخرائط
     */
    start: function () {
        this._super.apply(this, arguments);
        // لازم نعلن الفنكشن قبل تحميل السكريبت
        window.initMap = this.initMap.bind(this);

        // امنع تكرار التحميل لو ويدجت ثانية اتعملت
        if (window.google && window.google.maps) {
            this.initMap();
            return Promise.resolve();
        }
        if (window._gmapsLoading) {
            // لو التحميل شغّال بالفعل، انتظر انتهاءه ثم نفّذ initMap
            return window._gmapsLoading.then(() => this.initMap());
        }

        // اطلب الـ API key من الراوت
        window._gmapsLoading = ajax.jsonRpc('/service/api_key', 'call', {})
            .then((resp) => {
                const key = (resp && resp.key) ? resp.key.trim() : '';
                if (!key) {
                    console.error('⚠️ Google Maps API key is missing from /service/api_key.');
                    return;
                }
                // حمّل سكريبت خرائط جوجل باستخدام المفتاح القادم من الباك إند
                return this._loadGoogleScript(key);
            })
            .catch((err) => {
                console.error('⚠️ Failed to fetch Google Maps API key:', err);
            });

        return window._gmapsLoading;
    },

    /**
     * تحميل سكريبت خرائط جوجل بالديناميك كي
     */
    _loadGoogleScript(key) {
        return new Promise((resolve, reject) => {
            // لو اتضاف قبل كده، بلاش نكرره
            if (document.getElementById('gmaps-sdk-script')) {
                resolve();
                return;
            }
            const script = document.createElement('script');
            script.id = 'gmaps-sdk-script';
            script.src = [
                'https://maps.googleapis.com/maps/api/js',
                `?key=${encodeURIComponent(key)}`,
                '&callback=initMap',
            ].join('');
            script.async = true;
            script.defer = true;
            script.onload = () => resolve();
            script.onerror = (e) => reject(e);
            document.head.appendChild(script);
        });
    },

    /**
     * تهيئة الخريطة ووضع/تحديث الماركر وتعبئة الحقل برابط قابل للنقر
     */
    initMap: function () {
        const $mapEl = this.$el.find('#location_map');
        if (!$mapEl.length || !(window.google && google.maps)) {
            return;
        }

        // 1) تهيئة الخريطة (مركز مبدئي)
        this.map = new google.maps.Map($mapEl[0], {
            center: { lat: 23.2281, lng: 56.5153 }, // مركز مبدئي
            zoom: 12,
        });
        this.marker = null;

        // 2) لو فيه قيمة محفوظة في الحقل "location"
        const $locInput = this.$el.find('input[name="location"]');
        const locValRaw = ($locInput.val() || '').trim();
        if (locValRaw) {
            let lat, lng;
            if (locValRaw.includes('query=')) {
                const parts = locValRaw.split('query=')[1].split(',');
                lat = parseFloat(parts[0]);
                lng = parseFloat(parts[1]);
            } else if (locValRaw.includes(',')) {
                const parts = locValRaw.split(',');
                lat = parseFloat(parts[0]);
                lng = parseFloat(parts[1]);
            }
            if (!isNaN(lat) && !isNaN(lng)) {
                const pos = { lat: lat, lng: lng };
                this.marker = new google.maps.Marker({ position: pos, map: this.map });
                this.map.setCenter(pos);
                this.map.setZoom(13);
            }
        } else {
            // 3) لو مفيش قيمة: جرّب geolocation
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (pos) => {
                        const userPos = {
                            lat: pos.coords.latitude,
                            lng: pos.coords.longitude,
                        };
                        this.map.setCenter(userPos);
                        this.map.setZoom(13);
                        this.marker = new google.maps.Marker({ position: userPos, map: this.map });

                        const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${userPos.lat.toFixed(6)},${userPos.lng.toFixed(6)}`;
                        $locInput
                            .val(mapsUrl)
                            .prop('readonly', true)
                            .css('cursor', 'pointer')
                            .off('click')
                            .on('click', () => { window.open(mapsUrl, '_blank'); });
                    },
                    (err) => {
                        console.warn('⚠️ Geolocation failed:', err);
                        // نكتفي بالمركز الافتراضي
                    }
                );
            }
        }

        // 4) استماع للنقر على الخريطة لتغيير الإحداثيات
        this.map.addListener('click', (e) => {
            const lat = e.latLng.lat().toFixed(6);
            const lng = e.latLng.lng().toFixed(6);

            if (this.marker) {
                this.marker.setMap(null);
            }
            this.marker = new google.maps.Marker({
                position: e.latLng,
                map: this.map,
            });

            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
            $locInput
                .val(mapsUrl)
                .prop('readonly', true)
                .css('cursor', 'pointer')
                .off('click')
                .on('click', () => { window.open(mapsUrl, '_blank'); });
        });
    },
});
