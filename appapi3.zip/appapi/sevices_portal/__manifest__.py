# -*- coding: utf-8 -*-

{
    'name': 'Portal Service Request',
    'summary': 'Allow portal users to request services',

    'description': 'This module allows portal users to submit service requests through the website.',

    "author": "Sysgates _ Ahmed Eldweek",
    "license": "LGPL-3",
    "website": "https://www.sysgates.com",

    # any module necessary for this one to work correctly
    'depends': ['base', 'portal', 'web', 'website', 'multi_service'],

    # always loaded
    'data': [
        'views/my_requests.xml',
        'views/create_request.xml',
    ],
    "assets": {
        "web.assets_frontend": [
            '/sevices_portal/static/src/css/style_service.css',
            '/sevices_portal/static/src/js/servicePortal.js',
            '/sevices_portal/static/src/js/google_map_picker.js',
        ]
    },

    'installable': True,
    'application': False,
    'auto_install': False,

}
