import json
import base64
from odoo import http, _, fields
from odoo.http import request,Response
from datetime import date
from urllib.parse import quote
from urllib.parse import urlparse
from bs4 import BeautifulSoup



def _json_response(payload, status=200, headers=None):
    return Response(
        json.dumps(payload, ensure_ascii=False),
        status=status,
        content_type='application/json; charset=utf-8',
        headers=headers or []
    )
def _to_float(val, default=None):
    try:
        if val is None or val == '':
            return default
        return float(str(val).strip())
    except Exception:
        return default


def _ok_list(records, status=200):
    return _json_response({"success": True, "data": {"records": records}}, status=status)

def _ok_detail(record, status=200):
    return _json_response({"success": True, "data": record}, status=status)

def _err(message, status=400, extra=None):
    payload = {"success": False, "message": message}
    if extra:
        payload.update(extra)
    return _json_response(payload, status=status)


def get_image_from_cover(post):
    image = ""
    try:
        props = json.loads(post.cover_properties or '{}')
        bg = props.get('background-image', '')
        if bg.startswith("url("):
            image = bg[4:-1].strip("'").strip('"')
    except Exception:
        pass
    return image
def get_image_from_cover_event(event):
    """
    Extracts the cover image URL from event.cover_properties.
    """
    import json
    cover_img_url = ""
    if event.cover_properties:
        try:
            props = json.loads(event.cover_properties)
            bg_img = props.get("background-image", "")
            if bg_img.startswith("url("):
                cover_img_url = bg_img[4:-1].strip("'").strip('"')
        except Exception:
            cover_img_url = ""
    return cover_img_url



class ServicePortalController(http.Controller):
    """
    This controller defines all the API endpoints needed for the “Add New Service” flow.
    """

    # -----------------------------------------
    # 1) GET /api/main_categories
    # -----------------------------------------
    # 1) GET /api/main_categories
    @http.route('/api/main_categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_main_categories(self, **kw):
        try:
            main_cats = request.env['service.category'].sudo().search([])
            records = [{'id': c.id, 'name': c.name} for c in main_cats]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/main_categories/<int:main_id>/sub_categories', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_sub_categories(self, main_id, **kw):
        try:
            subs = request.env['sub.service.category'].sudo().search([('category_id', '=', main_id)])
            records = [{'id': s.id, 'name': s.name} for s in subs]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/sub_categories/<int:sub_id>/service_types', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_service_types(self, sub_id, **kw):
        try:
            types = request.env['service.type'].sudo().search([('sub_category_id', '=', sub_id)])
            records = [{'id': st.id, 'name': st.name} for st in types]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/service_types/<int:type_id>/fields_config', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_fields_config(self, type_id, **kw):
        try:
            st = request.env['service.type'].sudo().browse(type_id)
            if not st.exists():
                return _err("Service Type not found", 404)
            config = st.get_fields_config()
            return _ok_detail(config)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/create/service', type='http', auth='public', methods=['POST'], csrf=False)
    def create_service_request(self, **post):
        raw_json = request.httprequest.form.get('payload_json')
        try:
            payload = json.loads(raw_json or '{}')
        except Exception:
            return _err(_('Invalid JSON in payload_json'), 400)

        token = payload.get('token') or request.httprequest.form.get('token')
        if not token:
            return _err(_('Missing token in payload_json'), 401)

        partner = request.env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        if not partner:
            return _err(_('Invalid or expired token'), 401)

        category_id = payload.get('category_id')
        sub_category_id = payload.get('sub_category_id')
        service_type_id = payload.get('service_type_id')
        fields_data = payload.get('fields_data') or {}

        missing = [f for f in ('category_id', 'sub_category_id', 'service_type_id') if not payload.get(f)]
        if missing:
            return _err(_('Missing required fields: %s') % ', '.join(missing), 400, {"missing_fields": missing})

        category = request.env['service.category'].sudo().browse(int(category_id))
        sub_category = request.env['sub.service.category'].sudo().browse(int(sub_category_id))
        st = request.env['service.type'].sudo().browse(int(service_type_id))
        if not category.exists():
            return _err(_('Invalid category_id: %s') % category_id, 400)
        if not sub_category.exists():
            return _err(_('Invalid sub_category_id: %s') % sub_category_id, 400)
        if not st.exists():
            return _err(_('Invalid service_type_id: %s') % service_type_id, 400)

        try:
            field_config = st.get_fields_config()
            required_fields = [f['name'] for f in field_config.get('fields', []) if f.get('required')]
        except Exception as e:
            return _err(f'Field config error: {str(e)}', 400)

        missing_required = []
        for fname in required_fields:
            val = fields_data.get(fname)
            if val is None or (isinstance(val, str) and not val.strip()):
                missing_required.append(fname)
        if missing_required:
            return _err(_('Missing required fields: %s') % ', '.join(missing_required), 400,
                        {"missing_fields": missing_required})

        try:
            national_id = fields_data.get('national_id')
            if national_id:
                partner.sudo().write({'national_id': national_id})

            phone = partner.phone or getattr(partner, 'mobile', False) or ''

            lat = fields_data.get('lat', fields_data.get('latitude'))
            lng = fields_data.get('lng', fields_data.get('longitude'))
            if 'lat' in request.httprequest.form and lat is None:
                lat = request.httprequest.form.get('lat')
            if 'lng' in request.httprequest.form and lng is None:
                lng = request.httprequest.form.get('lng')
            if 'latitude' in request.httprequest.form and lat is None:
                lat = request.httprequest.form.get('latitude')
            if 'longitude' in request.httprequest.form and lng is None:
                lng = request.httprequest.form.get('longitude')

            lat = _to_float(lat)
            lng = _to_float(lng)

            vals = {
                'category_id': int(category_id),
                'sub_category_id': int(sub_category_id),
                'service_type_id': int(service_type_id),
                'partner_id': partner.id,  #
                'phone': phone,
                'name': st.name,
                'date': date.today(),
            }

            for k, v in fields_data.items():
                if k.endswith('_id') and str(v).isdigit():
                    vals[k] = int(v)
                elif k not in ['national_id', 'phone', 'lat', 'lng', 'latitude', 'longitude', 'token']:
                    vals[k] = v

            if lat is not None:
                vals['latitude'] = lat
            if lng is not None:
                vals['longitude'] = lng

            new_req = request.env['service.request'].sudo().create(vals)
        except Exception as e:
            return _err(str(e), 400)

        attached = []
        files_list = []
        for field_name in request.httprequest.files:
            files_list.extend(request.httprequest.files.getlist(field_name))

        doc_types = st.config_id.document_type_ids
        requirer_required = st.config_id.requirer_document == 'required'
        if requirer_required and not files_list:
            return _err(_('At least one document is required but no file was uploaded.'), 400)

        for i, fs in enumerate(files_list):
            try:
                data = fs.read()
                doc = doc_types[i] if i < len(doc_types) else None

                chatter_attachment = request.env['ir.attachment'].sudo().create({
                    'name': fs.filename,
                    'type': 'binary',
                    'datas': base64.b64encode(data).decode('utf-8'),
                    'res_model': 'service.request',
                    'res_id': new_req.id,
                    'mimetype': fs.mimetype,
                })

                doc_attachment_vals = {
                    'request_id': new_req.id,
                    'file_name': fs.filename,
                    'attachment_id': chatter_attachment.id,
                }
                if doc:
                    doc_attachment_vals['document_id'] = doc.id

                doc_attachment = request.env['attachment.document.request'].sudo().create(doc_attachment_vals)
                attached.append(doc_attachment.id)
            except Exception:
                continue

        return _ok_detail({
            'service_id': new_req.id,
            'message': _('Service request created successfully'),
            'attached_ids': attached,
        })

    @http.route('/api/my_service/services', type='http', auth='public', methods=['GET'], csrf=False)
    def myservice_all_services(self, **kw):
        """
        Return all services for this token with optional filters in query params
        (e.g. category_id, sub_category_id, service_type_id, reference)
        """
        try:
            payload = json.loads(request.httprequest.data or '{}')
        except Exception:
            return _err(_('Invalid JSON body'), 400)

        token = payload.get("token")
        if not token:
            return _err(_('Missing token'), 401)

        partner = request.env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        if not partner:
            return _err(_('Invalid or expired token'), 401)

        # === Start domain with token-based partner filter ===
        domain = [('partner_id', '=', partner.id)]

        # === Read filters from query string ===
        category_id = request.params.get("category_id")
        if category_id:
            domain.append(('category_id', '=', int(category_id)))

        sub_category_id = request.params.get("sub_category_id")
        if sub_category_id:
            domain.append(('sub_category_id', '=', int(sub_category_id)))

        service_type_id = request.params.get("service_type_id")
        if service_type_id:
            domain.append(('service_type_id', '=', int(service_type_id)))

        reference = request.params.get("reference")
        if reference:
            domain.append(('reference', 'ilike', reference))

        # === Search based on the final domain ===
        services = request.env['service.request'].sudo().search(domain, order='id desc')

        records = []
        for srv in services:
            records.append({
                "id": srv.id,
                "reference": srv.reference or "",
                "name": srv.name or "",
                "date": srv.date and srv.date.strftime("%Y-%m-%dT%H:%M:%S") or "",
                "location": srv.location or "",
                "latitude": srv.latitude,
                "longitude": srv.longitude,
                "category": (srv.category_id and {"id": srv.category_id.id, "name": srv.category_id.name}) or None,
                "sub_category": (srv.sub_category_id and {"id": srv.sub_category_id.id,
                                                          "name": srv.sub_category_id.name}) or None,
                "service_type": (srv.service_type_id and {"id": srv.service_type_id.id,
                                                          "name": srv.service_type_id.name}) or None,
                "stage": (srv.stage_id and {"id": srv.stage_id.id, "name": srv.stage_id.name}) or None,
            })

        return _ok_list(records)

    # 5) GET /api/governments
    @http.route('/api/governments', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_governments(self, **kw):
        try:
            governments = request.env['res.country.government'].sudo().search([])
            records = [{
                'id': g.id,
                'government_name': g.name,
                'country_id': g.country_id.id if g.country_id else False,
            } for g in governments]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 6) GET /api/governments/<gov_id>/states
    @http.route('/api/governments/<int:gov_id>/states', type='http', auth='public', methods=['GET'], csrf=False)
    def get_states_by_government(self, gov_id, **kw):
        try:
            states = request.env['res.country.state'].sudo().search([('government_id', '=', gov_id)])
            records = [{'id': s.id, 'state_name': s.name, 'state_code': s.code} for s in states]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/states/<int:state_id>/villages', type='http', auth='public', methods=['GET'], csrf=False)
    def get_villages_by_state(self, state_id, **kw):
        try:
            villages = request.env['res.state.village'].sudo().search([('state_id', '=', state_id)])
            records = [{'id': v.id, 'village_name': v.name, 'village_code': v.code} for v in villages]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/service_types/<int:service_type_id>/document_types', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_document_type_count(self, service_type_id, **kw):
        try:
            st = request.env['service.type'].sudo().browse(service_type_id)
            if not st.exists():
                return _err(_("Invalid service_type_id: %s") % service_type_id, 404)
            docs = st.config_id.document_type_ids
            doc_list = [{'id': d.id, 'name': d.name} for d in docs]
            return _ok_detail({
                'service_type_id': service_type_id,
                'document_type_count': len(doc_list),
                'document_types': doc_list
            })
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 9) GET /api/services
    @http.route('/api/services', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_services(self, **kwargs):
        try:
            ServiceRequest = request.env['service.request'].sudo()
            services = ServiceRequest.search([], order='id desc')
            records = []
            for srv in services:
                records.append({
                    'id': srv.id,
                    'reference': srv.reference or '',
                    'name': srv.name or '',
                    'date': srv.date and srv.date.strftime("%Y-%m-%dT%H:%M:%S") or False,
                    'category': {'id': srv.category_id.id,
                                 'name': srv.category_id.name or ''} if srv.category_id else False,
                    'sub_category': {'id': srv.sub_category_id.id,
                                     'name': srv.sub_category_id.name or ''} if srv.sub_category_id else False,
                    'service_type': {'id': srv.service_type_id.id,
                                     'name': srv.service_type_id.name or ''} if srv.service_type_id else False,
                    'stage': {'id': srv.stage_id.id, 'name': srv.stage_id.name or ''} if srv.stage_id else None,
                    # NEW
                    'latitude': srv.latitude,
                    'longitude': srv.longitude,
                })
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 10) GET /api/service_request/<request_id>
    @http.route('/api/service_request/<int:request_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_service_request_detail(self, request_id, **kwargs):
        rec = request.env['service.request'].sudo().browse(request_id)
        if not rec.exists():
            return _err(f'Service Request ID {request_id} not found', 404)

        base_url = request.httprequest.host_url.rstrip('/')

        attachments = []
        for att in rec.attachment_ids:
            file_url = ''
            view_url = ''
            image_url = ''
            pdf_gdoc_view_url = ''
            mimetype = 'application/octet-stream'
            filename = att.file_name or ''
            size = 0
            is_public = False

            if att.attachment_id:
                ia = att.attachment_id.sudo()  # ir.attachment
                mimetype = ia.mimetype or mimetype
                filename = filename or ia.name or ''
                size = getattr(ia, 'file_size', 0) or 0
                is_public = bool(getattr(ia, 'public', False))

                # access_token لو المرفق مش public
                token_param = ''
                if not is_public:
                    if not ia.access_token:
                        ia.generate_access_token()
                    token_param = f"&access_token={ia.access_token}"

                # روابط صحيحة باستخدام ID فقط
                # عرض (inline) مهم للـ PDF
                view_url = f"{base_url}/web/content/{ia.id}?filename={quote(filename)}{token_param}"
                # تحميل
                file_url = f"{base_url}/web/content/{ia.id}?download=true&filename={quote(filename)}{token_param}"
                # صور (thumbnail)
                if mimetype.startswith('image/'):
                    image_url = f"{base_url}/web/image/{ia.id}?filename={quote(filename)}{token_param}"
                # # بديل موثوق لعرض PDF داخل WebView
                # if mimetype == 'application/pdf':
                #     pdf_gdoc_view_url = f"https://docs.google.com/gview?embedded=1&url={quote(view_url, safe='')}"

            attachments.append({
                'id': att.id,
                'document_type': att.document_id.name if att.document_id else '',
                'file_name': filename,
                'mimetype': mimetype,
                'file_size': size,
                'public': is_public,
                'attachment_url': file_url,  # للتحميل
                'view_url': view_url,  # عرض مباشر (inline)
                'image_url': image_url,  # للصور
                # 'pdf_gdoc_view_url': pdf_gdoc_view_url,  # Fallback للـ PDF
            })

        responses = [{
            'response': line.response,
            'date': line.date.strftime("%Y-%m-%d") if line.date else '',
            'date_time': line.date_time.strftime("%Y-%m-%d %H:%M:%S") if line.date_time else '',
        } for line in rec.response_line_ids]

        fields_config = []
        if rec.service_type_id:
            try:
                config = rec.service_type_id.get_fields_config()
                fields_config = config.get('fields', [])
            except Exception:
                fields_config = []

        return _ok_detail({
            'id': rec.id,
            'reference': rec.reference or '',
            'name': rec.name or '',
            'date': rec.date and rec.date.strftime("%Y-%m-%d") or '',
            'phone': rec.phone or '',
            'location': rec.location or '',
            'national_id': rec.national_id or '',
            'from_date': rec.from_date and rec.from_date.strftime("%Y-%m-%d") or '',
            'to_date': rec.to_date and rec.to_date.strftime("%Y-%m-%d") or '',
            'state': rec.state_id.name if rec.state_id else '',
            'government': rec.government_id.name if rec.government_id else '',
            'village': rec.village_name_id.name if rec.village_name_id else '',
            'category': rec.category_id.name if rec.category_id else '',
            'sub_category': rec.sub_category_id.name if rec.sub_category_id else '',
            'service_type': rec.service_type_id.name if rec.service_type_id else '',
            'service_type_id': rec.service_type_id.id if rec.service_type_id else False,
            'stage': rec.stage_id.name if rec.stage_id else '',
            'partner': rec.partner_id.name if rec.partner_id else '',
            'latitude': rec.latitude,
            'longitude': rec.longitude,
            'attachments': attachments,
            'responses': responses,
            'fields_config': fields_config,
        })
    # 11) GET /api/user/info
    @http.route('/api/user/info', type='http', auth='public', methods=['GET'], csrf=False)
    def get_logged_in_user_info(self, **kwargs):
        uid = request.session.uid
        if not uid:
            return _err('User not logged in', 401)

        try:
            user = request.env['res.users'].sudo().browse(uid)
            partner = user.partner_id
            return _ok_detail({
                'user_id': user.id,
                'user_name': user.name,
                'partner_id': partner.id,
                'partner_name': partner.name,
                'national_id': partner.national_id or '',
                'phone': partner.phone or '',
            })
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})


    @http.route('/api/blogs', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_blogs(self, **kwargs):
        try:
            posts = request.env['blog.post'].sudo().search(
                [('website_published', '=', True)],
                order="create_date desc"
            )
            base_url = request.httprequest.host_url.rstrip('/')

            records = []
            for post in posts:
                records.append({
                    "id": post.id,
                    "title": post.name,
                    "author": post.author_id.name if post.author_id else "",
                    "image": get_image_from_cover(post),
                    "date": post.create_date.strftime('%Y-%m-%d'),
                    "category": post.blog_id.name if post.blog_id else "",
                    # "image": f"{base_url}/web/image/blog.post/{post.id}/image_1920" if post.image_1920 else "",
                })

            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/blog/categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_blog_categories(self, **kwargs):
        try:
            categories = request.env['blog.blog'].sudo().search([])
            records = [{
                "id": cat.id,
                "name": cat.name,
                "description": cat.subtitle or "",
            } for cat in categories]
            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/blogs/<int:blog_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_blog_detail(self, blog_id, **kwargs):
        try:
            post = request.env['blog.post'].sudo().browse(blog_id)
            if not post.exists():
                return _json_response({"success": False, "message": "Blog not found"}, status=404)

            base_url = request.httprequest.host_url.rstrip('/')
            record = {
                "id": post.id,
                "title": post.name,
                "content": post.content or "",
                "category": post.blog_id.name if post.blog_id else "",
                "image": get_image_from_cover(post),
                "url": f"{base_url}{post.website_url}",
            }
            return _json_response({"success": True, "data": record}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    # ---------- EVENTS ----------
    @http.route('/api/events/categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_event_categories(self, **kwargs):
        try:
            categories = request.env['event.type'].sudo().search([])
            records = [{"id": cat.id, "name": cat.name} for cat in categories]
            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/events', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_events(self, **kwargs):
        try:
            events = request.env['event.event'].sudo().search([], order="date_begin desc")
            base_url = request.httprequest.host_url.rstrip('/')

            records = []
            for event in events:
                records.append({
                    "id": event.id,
                    "name": event.name,
                    "date_begin": event.date_begin.strftime('%Y-%m-%d %H:%M:%S') if event.date_begin else "",
                    "date_end": event.date_end.strftime('%Y-%m-%d %H:%M:%S') if event.date_end else "",
                    "category": event.event_type_id.name if event.event_type_id else "",
                    "image": get_image_from_cover_event(event),
                    "address": event.address_id.display_name if event.address_id else "",
                    "seats_available": event.seats_available,
                    "seats_max": event.seats_max,
                    # "image": f"{base_url}/web/image/event.event/{event.id}/image_1920" if event.image_1920 else "",
                })

            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/events/<int:event_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_event_detail(self, event_id, **kwargs):
        try:
            event = request.env['event.event'].sudo().browse(event_id)
            if not event.exists():
                return _json_response({"success": False, "message": "Event not found"}, status=404)

            base_url = request.httprequest.host_url.rstrip('/')
            record = {
                "id": event.id,
                "name": event.name,
                "description": event.description or "",
                "date_begin": event.date_begin.strftime('%Y-%m-%d %H:%M:%S') if event.date_begin else "",
                "date_end": event.date_end.strftime('%Y-%m-%d %H:%M:%S') if event.date_end else "",
                "category": event.event_type_id.name if event.event_type_id else "",
                "image": get_image_from_cover_event(event),
                "address": event.address_id.display_name if event.address_id else "",
                "seats_available": event.seats_available,
                "seats_max": event.seats_max,
                "website_url": f"{base_url}{event.website_url}" if event.website_url else "",
            }
            return _json_response({"success": True, "data": record}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/events/categories/<int:category_id>/events', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_events_by_category(self, category_id, **kwargs):
        try:
            event_category = request.env['event.type'].sudo().browse(category_id)
            if not event_category.exists():
                return _json_response({"success": False, "message": "Event category not found"}, status=404)

            events = request.env['event.event'].sudo().search([
                ('event_type_id', '=', category_id)
            ], order="date_begin desc")

            base_url = request.httprequest.host_url.rstrip('/')

            records = []
            for event in events:
                records.append({
                    "id": event.id,
                    "name": event.name,
                    "description": event.description or "",
                    "date_begin": event.date_begin.strftime('%Y-%m-%d %H:%M:%S') if event.date_begin else "",
                    "date_end": event.date_end.strftime('%Y-%m-%d %H:%M:%S') if event.date_end else "",
                    "category": event_category.name,
                    "image": get_image_from_cover_event(event),
                    "address": event.address_id.display_name if event.address_id else "",
                    "seats_available": event.seats_available,
                    "seats_max": event.seats_max,
                    "url": f"{base_url}{event.website_url}" if event.website_url else "",
                })

            return _json_response({"success": True, "data": {"category": event_category.name, "records": records}},
                                  status=200)

        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/blog/categories/<int:category_id>/posts', type='http', auth='public', methods=['GET'], csrf=False)
    def get_blogs_by_category(self, category_id, **kwargs):
        try:
            blog_category = request.env['blog.blog'].sudo().browse(category_id)
            if not blog_category.exists():
                return _json_response({"success": False, "message": "Blog category not found"}, status=404)

            posts = request.env['blog.post'].sudo().search([
                ('blog_id', '=', category_id),
                ('website_published', '=', True)
            ], order="create_date desc")

            base_url = request.httprequest.host_url.rstrip('/')

            records = []
            for post in posts:
                records.append({
                    "id": post.id,
                    "title": post.name,
                    "author": post.author_id.name if post.author_id else "",
                    "image": get_image_from_cover(post),
                    "date": post.create_date.strftime('%Y-%m-%d'),
                    "category": blog_category.name,
                    "url": f"{base_url}{post.website_url}",
                })

            return _json_response({"success": True, "data": {"category": blog_category.name, "records": records}},
                                  status=200)

        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/website/page/<int:page_id>', type='http', auth='public', methods=['GET'], csrf=False,
                website=True)
    def get_page(self, page_id=None, **kwargs):
        if not page_id:
            return Response(
                json.dumps({"success": False, "message": "Missing 'id' in URL"}),
                status=400,
                content_type="application/json"
            )

        page = request.env['website.page'].sudo().search([
            ('id', '=', int(page_id)),
            ('website_id', '=', request.website.id),
        ], limit=1)

        if not page:
            return Response(
                json.dumps({"success": False, "message": "Page not found"}),
                status=404,
                content_type="application/json"
            )

        try:
            rendered_html = request.env['ir.ui.view']._render_template(
                page.view_id.key,
                {"page": page, "website": request.website}
            )
        except Exception as e:
            return Response(
                json.dumps({"success": False, "message": "Render error", "error": str(e)}),
                status=500,
                content_type="application/json"
            )

        return Response(
            json.dumps({"success": True, "data": {"full_html": rendered_html}}, ensure_ascii=False),
            status=200,
            content_type="application/json"
        )

    @http.route('/api/contact/submit', type='http', auth='public', methods=['POST'], csrf=False, website=True)
    def submit_contact_form(self, **post):
        data = request.httprequest.get_json(silent=True) or {}

        name = data.get("name")
        email = data.get("email")
        phone = data.get("phone", "")
        company = data.get("company", "")
        subject = data.get("subject", "Contact Form")
        message = data.get("message", "")

        if not name or not email or not message:
            return _json_response({
                "success": False,
                "message": "Missing required fields: name, email, or message"
            }, status=400)

        try:
            request.env['mail.mail'].sudo().create({
                'subject': f"Contact Us: {subject}",
                'body_html': f"""
                            <p><strong>Name:</strong> {name}</p>
                            <p><strong>Email:</strong> {email}</p>
                            <p><strong>Phone:</strong> {phone}</p>
                            <p><strong>Company:</strong> {company}</p>
                            <p><strong>Message:</strong><br/>{message}</p>
                        """,
                'email_to': "verovevo6@gmail.com",
                'email_from': email,
            }).send()

            return _json_response({
                "success": True,
                "data": {"message": "Email sent successfully"}
            })

        except Exception as e:
            return _json_response({
                "success": False,
                "message": "Failed to send email",
                "error": str(e)
            }, status=500)

    # @http.route('/api/services/search', type='http', auth='public', methods=['GET'], csrf=False)
    # def search_services(self, **kwargs):
    #     """
    #     Search:
    #       - reference: نص جزئي للبحث في الحقل service.request.reference (اختياري)
    #       - category_id, sub_category_id, service_type_id: فلاتر اختيارية (int)
    #       - token: فلتر اختياري لقصر النتائج على شريك معيّن
    #       - limit, page: تقسيم صفحات (defaults: 50, 1)
    #
    #     Accepts:
    #       - GET: query string (e.g. ?reference=001&category_id=3)
    #       - POST: multipart/form-data with payload_json, OR application/json body
    #     """
    #     payload = {}
    #     if request.httprequest.method == 'POST':
    #         raw_json = request.httprequest.form.get('payload_json')
    #         if raw_json is not None:
    #             try:
    #                 payload = json.loads(raw_json or '{}')
    #             except Exception:
    #                 return _err(_('Invalid JSON in payload_json'), 400)
    #         else:
    #             payload = request.httprequest.get_json(silent=True) or {}
    #     else:
    #         payload = dict(kwargs) or (request.httprequest.get_json(silent=True) or {})
    #
    #     try:
    #         # --- Params ---
    #         reference = (payload.get('reference') or payload.get('ref') or '').strip()
    #         category_id = payload.get('category_id')
    #         sub_category_id = payload.get('sub_category_id')
    #         service_type_id = payload.get('service_type_id')
    #         token = payload.get('token')
    #
    #         # Pagination
    #         limit = int(payload.get('limit') or 20)
    #         page = int(payload.get('page') or 1)
    #         offset = max(page - 1, 0) * limit
    #
    #         partner = None
    #         if token:
    #             partner = request.env['res.partner'].sudo().search([('token', '=', token)], limit=1)
    #             if not partner:
    #                 return _err(_('Invalid or expired token'), 401)
    #
    #         domain = []
    #         if reference:
    #             domain.append(('reference', 'ilike', reference))
    #         if category_id and str(category_id).isdigit():
    #             domain.append(('category_id', '=', int(category_id)))
    #         if sub_category_id and str(sub_category_id).isdigit():
    #             domain.append(('sub_category_id', '=', int(sub_category_id)))
    #         if service_type_id and str(service_type_id).isdigit():
    #             domain.append(('service_type_id', '=', int(service_type_id)))
    #         if partner:
    #             domain.append(('partner_id', '=', partner.id))
    #
    #         if not domain:
    #             return _err(
    #                 _('Provide at least one of: reference, category_id, sub_category_id, service_type_id, token'), 400)
    #
    #         ServiceRequest = request.env['service.request'].sudo()
    #         total_count = ServiceRequest.search_count(domain)
    #         services = ServiceRequest.search(domain, order='id desc', limit=limit, offset=offset)
    #
    #         records = []
    #         for srv in services:
    #             records.append({
    #                 'id': srv.id,
    #                 'reference': srv.reference or '',
    #                 'name': srv.name or '',
    #                 'date': srv.date and srv.date.strftime("%Y-%m-%dT%H:%M:%S") or False,
    #                 'category': {'id': srv.category_id.id,
    #                              'name': srv.category_id.name or ''} if srv.category_id else False,
    #                 'sub_category': {'id': srv.sub_category_id.id,
    #                                  'name': srv.sub_category_id.name or ''} if srv.sub_category_id else False,
    #                 'service_type': {'id': srv.service_type_id.id,
    #                                  'name': srv.service_type_id.name or ''} if srv.service_type_id else False,
    #                 'stage': {'id': srv.stage_id.id, 'name': srv.stage_id.name or ''} if srv.stage_id else None,
    #                 'latitude': srv.latitude,
    #                 'longitude': srv.longitude,
    #             })
    #
    #         return _json_response({
    #             "success": True,
    #             "data": {
    #                 "records": records,
    #                 "meta": {
    #                     "total": total_count,
    #                     "page": page,
    #                     "limit": limit,
    #                     "pages": (total_count // limit) + (1 if total_count % limit else 0)
    #                 }
    #             }
    #         }, status=200)
    #
    #     except Exception as e:
    #         return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
    #                               status=500)
