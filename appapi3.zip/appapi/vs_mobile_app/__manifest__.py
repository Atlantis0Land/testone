# -*- coding: utf-8 -*-
{
    'name': 'Mobile APP',
    'version': '16.0.1.0.0',
    'summary': 'Allow each stock operation type to have its own configurable stages',
    'category': 'Warehouse',
    'author': 'Eng.Veronica Safwat',
    'website': 'https://sysgates.com',
    'license': 'LGPL-3',
    'depends': [ 'base','stock',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/mobile_app_views.xml',
        'views/mobile_app_page_views.xml',
        'views/mobile_app_content_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
