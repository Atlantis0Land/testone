from odoo import models, fields

class MobileAppContent(models.Model):
    _name = "mobile.app.content"
    _description = "Mobile App Page (HTML Content)"

    name = fields.Char(string="Page Name", required=True)
    content_html = fields.Html(string="Details",)
