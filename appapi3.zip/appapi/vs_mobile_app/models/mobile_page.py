# models/mobile_app_page.py
from odoo import models, fields

class MobileAppPage(models.Model):
    _name = "mobile.page"
    _description = "Mobile App Page"

    website_page_id = fields.Many2one(
        "website.page",
        string="Website Page",
        required=True,
    )
    page_id = fields.Integer(
        string="Website Page ID",
        related="website_page_id.id",
        store=True,
        readonly=True,
    )

    name = fields.Char(
        string="Page Name",
        related="website_page_id.name",
        store=True,
        readonly=True,
    )
    page_url = fields.Char(
        string="Page URL",
        related="website_page_id.url",
        store=True,
        readonly=True,
    )
    view_id = fields.Many2one(
        "ir.ui.view",
        string="View",
        related="website_page_id.view_id",
        store=True,
        readonly=True,
    )


    image_cover = fields.Binary(string="Image Cover")
    description = fields.Text(string="Description")
