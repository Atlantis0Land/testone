{
    'name': 'Suggestions',
    'version': '1.0',
    'summary': 'Module to collect contact suggestions via API',
    'author': 'Veronica Safwat',
    'category': 'Tools',
    'depends': ['base'],
    'data': [
        'security/groups.xml',
        'security/ir.model.access.csv',
        'views/suggestions.xml',
    ],
    'installable': True,
    'application': True,
}
