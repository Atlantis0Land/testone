from odoo import http
from odoo.http import request, Response
import json


def _json_response(payload, status=200):
    return Response(
        json.dumps(payload, ensure_ascii=False),
        status=status,
        content_type='application/json; charset=utf-8'
    )


class VsSuggestionAPI(http.Controller):

    @http.route('/api/suggestion/submit', type='http', auth='public', methods=['POST'], csrf=False)
    def submit_suggestion(self, **kwargs):
        try:
            data = request.httprequest.get_json(silent=True) or {}
            print(data,"data")

            if not data.get('phone'):
                return _json_response({
                    "success": False,
                    "message": "Missing required field: phone"
                }, status=400)

            suggestion = request.env['vs.suggestion'].sudo().create({
                'name': data.get('name'),
                'phone': data['phone'],
                'email': (data.get('email') or '').strip(),
                'company': data.get('company'),
                'subject': data.get('subject'),
                'message': data.get('message'),
            })

            return _json_response({
                "success": True,
                "data": {
                    "id": suggestion.id,
                    "message": "Suggestion created successfully"
                }
            }, status=200)

        except Exception as e:
            return _json_response({
                "success": False,
                "message": "Unexpected server error",
                "detail": str(e)
            }, status=500)
