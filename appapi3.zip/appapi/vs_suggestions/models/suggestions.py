from odoo import models, fields

class VsSuggestion(models.Model):
    _name = 'vs.suggestion'
    _description = 'VS Suggestion'

    name = fields.Char(string="Name", required=True)
    email = fields.Char(string="Email",required=False)
    phone = fields.Char(string="Phone")
    company = fields.Char(string="Company")
    subject = fields.Char(string="Subject")
    message = fields.Text(string="Message")
