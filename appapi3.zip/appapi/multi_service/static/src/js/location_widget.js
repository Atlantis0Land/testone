/** @odoo-module **/

import {_t} from "@web/core/l10n/translation";
import {standardFieldProps} from "@web/views/fields/standard_field_props";
import {registry} from "@web/core/registry";
import {Component} from "@odoo/owl";
import {useService} from "@web/core/utils/hooks";
import {ConfirmationDialog} from "@web/core/confirmation_dialog/confirmation_dialog";
import {AlertDialog} from "@web/core/confirmation_dialog/confirmation_dialog";

export class LocationFieldWidget extends Component {
    static template = "multi_service.LocationFieldWidget";

    static props = {
        ...standardFieldProps,
        decorations: {type: Object, optional: true},
    };

    setup() {
        this.dialog = useService("dialog");
        console.log("📦 Widget props:", this.props);
    }

    async getLocation() {
        console.debug("📍 getLocation triggered");

        const record = this.props.record;
        const fieldName = this.props.name;

        if (!record || !fieldName) {
            console.error("❌ Missing record or field name", this.props);
            this.dialog.add(AlertDialog, {
                body: _t("Widget misconfigured. Missing record or field name."),
            });
            return;
        }

        this.dialog.add(ConfirmationDialog, {
            body: _t("This will update the location to your current position. Do you want to continue?"),
            cancel: () => console.debug("🚫 User canceled"),
            confirm: async () => {
                if (!navigator.geolocation) {
                    this.dialog.add(AlertDialog, {
                        body: _t("Geolocation is not supported by this browser."),
                    });
                    return;
                }

                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        const latitude = position.coords.latitude;
                        const longitude = position.coords.longitude;
                        const locationUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;

                        const updates = {
                            [fieldName]: locationUrl,
                        };

                        // ✅ Add lat/long only if the fields exist in the current view
                        if ("lat" in record.data) {
                            updates.lat = latitude;
                        }
                        if ("long" in record.data) {
                            updates.long = longitude;
                        }

                        record.update(updates);
                        console.log("✅ Location updated:", updates);
                    },
                    (error) => {
                        console.error("❌ Geolocation error", error);
                        this.dialog.add(AlertDialog, {
                            body: _t("Could not get your current location. Please check your browser settings."),
                        });
                    }
                );
            },
        });
    }

    openLocation() {
        const locationUrl = this.props?.record?.data?.[this.props.name];
        if (locationUrl) {
            window.open(locationUrl, '_blank');
        }
    }
}

LocationFieldWidget.supportedTypes = ["char"];
LocationFieldWidget.displayName = _t("Location");

registry.category("fields").add("location_widget", LocationFieldWidget);

console.log("✅ location_widget.js loaded");
