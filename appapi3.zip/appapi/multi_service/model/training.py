from odoo import models, fields


class TrainerState(models.Model):
    _name = "trainer.state"

    name = fields.Char("Name")

class TrainerSite(models.Model):
    _name = "trainer.site"

    name = fields.Char("Name")
