from odoo import models, fields, api,_


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    show_otp_button = fields.Boolean(config_parameter='multi_service.show_otp_button', default=False,string="Show OTP Button")
    payment_template_id = fields.Char(string="Payment Template ID", config_parameter="multi_service.payment_template_id")
    response_Appointment_template_id = fields.Char(string="Response Appointment Template ID", config_parameter="multi_service.response_Appointment_template_id")
    response_template_id = fields.Char(string="Response Template ID", config_parameter="multi_service.response_template_id")
    stage_template_id = fields.Char(string="Stage Template ID", config_parameter="multi_service.stage_template_id")
    send_sms_on_stage = fields.Boolean(string="Send SMS when stage changes",config_parameter="multi_service.send_sms_on_stage")
    send_whatsapp_on_stage = fields.Boolean(string="Send WhatsApp when stage changes",config_parameter="multi_service.send_whatsapp_on_stage")
    sms_assign_enable = fields.Boolean(
        string="Enable SMS on Assignment",
        config_parameter='multi_service.send_sms_on_assign',
    )

    whatsapp_assign_enable = fields.Boolean(
        string="Enable WhatsApp on Assignment",
        config_parameter='multi_service.send_whatsapp_on_assign',
    )
    whatsapp_service_enable = fields.Boolean(
        string="Enable WhatsApp on Service",
        config_parameter='multi_service.whatsapp_service_enable',
    )
    whatsapp_assign_template_id = fields.Char(
        string="WhatsApp Assignment Template ID",
        help="External template ID to send via WhatsApp",
        config_parameter='multi_service.assign_whatsapp_template_id',
    )
    whatsapp_service_template_id = fields.Char(
        string="WhatsApp Service Template ID",
        help="External template ID to send via WhatsApp",
        config_parameter='multi_service.whatsapp_service_template_id',
    )
