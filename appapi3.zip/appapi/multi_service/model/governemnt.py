# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import re
import logging
from odoo import api, fields, models, tools
from odoo.osv import expression

_logger = logging.getLogger(__name__)




class CountryGovernment(models.Model):
    _description = "Country government"
    _name = 'res.country.government'
    _order = 'code'

    country_id = fields.Many2one('res.country', string='Country', required=True)
    name = fields.Char(string='government Name', required=True,
               help='Administrative divisions of a country. E.g. Fed. government, Departement, Canton')
    code = fields.Char(string='government Code', help='The government code.', required=True)

    _sql_constraints = [
        ('name_code_uniq', 'unique(code)', 'The code of the government must be unique by country !')
    ]

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        args = args or []
        if self.env.context.get('country_id'):
            args = expression.AND([args, [('country_id', '=', self.env.context.get('country_id'))]])

        if operator == 'ilike' and not (name or '').strip():
            first_domain = []
            domain = []
        else:
            first_domain = [('code', '=ilike', name)]
            domain = [('name', operator, name)]

        fallback_domain = None
        if name and operator in ['ilike', '=']:
            fallback_domain = self._get_name_search_domain(name, operator)

        if name and operator in ['in', 'any']:
            fallback_domain = expression.OR([self._get_name_search_domain(n, '=') for n in name])

        first_government_ids = self._search(expression.AND([first_domain, args]), limit=limit, access_rights_uid=name_get_uid) if first_domain else []
        return list(first_government_ids) + [
            government_id
            for government_id in self._search(expression.AND([domain, args]),
                                         limit=limit, access_rights_uid=name_get_uid)
            if government_id not in first_government_ids
        ] or (
            list(self._search(expression.AND([fallback_domain, args]), limit=limit))
            if fallback_domain
            else []
        )

    def _get_name_search_domain(self, name, operator):
        m = re.fullmatch(r"(?P<name>.+)\((?P<country>.+)\)", name)
        if m:
            return [
                ('name', operator, m['name'].strip()),
                '|', ('country_id.name', 'ilike', m['country'].strip()),
                ('country_id.code', '=', m['country'].strip()),
            ]
        return None


    def name_get(self):
        result = []
        for record in self:
            result.append((record.id, "{} ({})".format(record.name, record.country_id.code)))
        return result


    @api.model_create_multi
    def create(self, vals_list):
        country_id = self.env['res.country'].search([('code', '=', 'OM')], limit=1)
        for vals in vals_list:
            vals['country_id'] = country_id.id
        return super().create(vals_list)