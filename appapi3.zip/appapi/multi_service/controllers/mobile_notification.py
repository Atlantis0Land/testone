from odoo import http, fields
from odoo.http import request, Response
import json


class MobileNotificationController(http.Controller):
    # ===============================
    # Helpers
    # ===============================
    def _http_success(self, data=None, status=200):
        payload = {
            'success': True,
            'data': data or {}
        }
        return Response(
            json.dumps(payload, ensure_ascii=False),
            status=status,
            content_type='application/json; charset=utf-8'
        )

    def _http_error(self, message, status=400):
        payload = {
            'success': False,
            'message': message
        }
        return Response(
            json.dumps(payload, ensure_ascii=False),
            status=status,
            content_type='application/json; charset=utf-8'
        )
    def _get_token_partner(self, token):
        """ Helper: Get partner from token """
        if not token:
            return None
        return request.env['res.partner'].sudo().search([('token', '=', token)], limit=1)


    @http.route('/api/notifications/create', type='http', auth='public', methods=['POST'], csrf=False)
    def create_notification(self, **kwargs):
        try:
            # استخرج JSON body من الريكوست
            raw_data = request.httprequest.data
            data = json.loads(raw_data)
        except Exception:
            return self._http_error("Invalid JSON format", status=400)

        partner_id = data.get('partner_id')
        title = data.get('title', 'New Notification')
        body = data.get('body', 'You have a new notification')

        if not partner_id:
            return self._http_error("Missing partner_id")

        partner = request.env['res.partner'].sudo().browse(partner_id)
        if not partner.exists() or not partner.fcm_token:
            return self._http_error("No FCM token for this partner")

        notif = request.env['mobile.notification'].sudo().create({
            'name': title,
            'body': body,
            'partner_id': partner_id,
            'service_request_id': data.get('service_request_id'),
            'stage_name': data.get('stage_name'),
        })

        try:
            notif.send_push()
            notif.write({'sent': True, 'sent_date': fields.Datetime.now()})
        except Exception as ex:
            notif.write({'response': str(ex)})
            return self._http_error(f'Push failed: {str(ex)}')

        return self._http_success({'notification_id': notif.id})

    @http.route('/api/notifications/user', type='http', auth='public', methods=['GET'], csrf=False)
    def get_user_notifications(self, **kwargs):
        try:
            raw_data = request.httprequest.data
            data = json.loads(raw_data)
        except Exception:
            return self._http_error("Invalid JSON format", status=400)

        token = data.get('token')
        if not token:
            return self._http_error('Missing token', status=401)

        partner = self._get_token_partner(token)
        if not partner:
            return self._http_error('Invalid or expired token', status=403)

        try:
            recs = request.env['mobile.notification'].sudo().search(
                [('partner_id', '=', partner.id)], order='sent_date desc'
            )

            notifications = [{
                'id': r.id,
                'title': r.name or '',
                'body': r.body or '',
                'sent': bool(r.sent),
                'sent_date': r.sent_date and r.sent_date.strftime("%Y-%m-%d %H:%M:%S"),
                'stage_name': r.stage_name or '',
                'service_request_id': r.service_request_id.id if r.service_request_id else None,
            } for r in recs]

            return self._http_success(notifications)

        except Exception as e:
            return self._http_error(str(e), status=500)