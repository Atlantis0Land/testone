
from odoo import models, fields

class ResPartner(models.Model):
    _inherit = 'res.partner'
    _description = 'Res Partner'

    is_investment = fields.Boolean(string="Is Investment")
    commercial_register = fields.Char(string="Commercial Register")
    tax_number = fields.Char(string="Tax Number")
    beneficiary = fields.Char(string="Beneficiary")
    # _sql_constraints = [
    #     ('unique_commercial_register', 'unique(commercial_register)', 'Commercial Register must be unique!'),
    #     ('unique_tax_number', 'unique(tax_number)', 'Tax Number must be unique!'),
    #     ('unique_beneficiary', 'unique(beneficiary)', 'Beneficiary must be unique!'),
    # ]
