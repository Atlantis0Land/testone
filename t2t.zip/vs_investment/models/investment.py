from odoo import models, fields, api ,_
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError
from odoo.tools import float_round
from odoo.exceptions import ValidationError
from odoo.tools.float_utils import float_compare
from odoo.addons.v16_ismart_sms.models.sms_sms import send_imsart_sms

from datetime import datetime



class InvestmentRecord(models.Model):
    _name = "investment.record"
    _description = "Investment Record"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    date = fields.Date(string="Date", default=fields.Date.context_today)
    whatsapp_log_ids = fields.One2many(
        'investment.whatsapp.log',
        'investment_id',
        string='WhatsApp Logs'
    )

    attachment_ids = fields.One2many(
        'investment.attachment', 'investment_id', string="Attachments")
    summery_ids = fields.One2many(
        'summary.type', 'investment_id', string="Summaries")

    name = fields.Char(
        string="Name",
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New'),
        tracking=True,
    )
    ref = fields.Char(
        string="Ref",
        copy=False,
        readonly=True

    )
    active = fields.Boolean(string="Active", default=True)


    payment_plan_id = fields.Many2one(
        'payment.plan.config',
        string='Payment Plan',
        required=True
    )
    paid_amount = fields.Float(
        string="Total Paid",
        compute="_compute_payment_totals",
        store=True,
        digits=(16, 2),
    )
    remaining_amount = fields.Float(
        string="Remaining Amount",
        compute="_compute_payment_totals",
        store=True,
        digits=(16, 2),
    )
    employee_id = fields.Many2one('hr.employee', string='Employee', default=lambda self: self.env.user.employee_id)
    user_id_payment = fields.Many2one('res.users', string="User", default=lambda self: self.env.user)

    payment_start_date = fields.Date(string=' Start Date')

    property_id = fields.Many2one('investment.property', string="Property", domain="[('state_id','=', state_id)]",required=True)
    property_code = fields.Char(related="property_id.code", string="Property Code", store=True)
    property_type_id = fields.Many2one(
        'property.type',
        related='property_id.property_type_id',
        string='Property Type',
        store=True,
        readonly=False,
    )
    property_address = fields.Char(related="property_id.address", string="Property Address", store=True)
    electricity_meter_number = fields.Char(related="property_id.electricity_meter_number",store=True,
        string=" Electricity Meter Number")
    water_meter_number = fields.Char(related="property_id.water_meter_number",store=True,
        string="Water Meter Account Number")

    activity_type_id_investment = fields.Many2one('activity.type', string="Activity")

    contract_type_id = fields.Many2one('investment.contract.type', string="Contract Type")
    state_id = fields.Many2one('res.state', string="State")

    partner_company_id = fields.Many2one('res.partner', string="Company", domain="[('is_company', '=', True),('is_investment', '=', True)]",required=True)
    owner_id = fields.Many2one('res.partner', string="Owner", domain="[('parent_id', '=', partner_company_id)]")
    phone = fields.Char(related="owner_id.phone", string="Phone", store=True, readonly=True)

    activity_type = fields.Char(string="Activity Type")
    contract_start_date = fields.Date(string="Contract Start Date" )
    contract_end_date = fields.Date(string="Contract End Date")
    # contract_end_date_activity = fields.Date(string="Contract End Date Activity", )

    amount = fields.Monetary(string="Contract Value")
    currency_id = fields.Many2one('res.currency', string="Currency", default=lambda self: self.env.company.currency_id)

    national_id = fields.Char(related="owner_id.national_id", string="ID")
    vat = fields.Char(related="owner_id.vat", string="Vat")
    membership_card = fields.Char(string="Membership Card")
    municipality_license = fields.Char(string="Municipality License")
    ownership_deed = fields.Char(string="Ownership Deed")

    notes = fields.Html(string="Notes")
    is_investment = fields.Boolean(
        string="Is Investment",
        related='partner_company_id.is_investment',
        store=True,
        readonly=False,
    )
    commercial_register_new = fields.Char(
        string="Commercial Register",
        related='partner_company_id.commercial_register',
        store=True,
        readonly=True,
    )
    # tax_number = fields.Char(
    #     string="Tax Number",
    #     related='owner_id.tax_number',
    #     store=True,
    #     readonly=True,
    # )
    beneficiary = fields.Char(
        string="Beneficiary",
        related='partner_company_id.beneficiary',
        store=True,
        readonly=True,
    )
    contract_attachment = fields.Binary("Attachment")
    contract_attachment_filename = fields.Char("Attachment File Name")
    contract_attachment_expiry = fields.Date("Attachment Expiry Date")
    cheque_returned = fields.Boolean("Cheque Returned", default=False)

    payment_line_ids = fields.One2many('payment.lines', 'investment_id', string="Payments")

    stage_id = fields.Many2one(
        'investment.stage',
        string="Current Stage",
        domain="[('id', 'in', available_stage_ids)]"
    )

    available_stage_ids = fields.Many2many(
        'investment.stage',
        compute="_compute_available_stages",
        string="Available Stages"

    )
    contract_end_date_activity = fields.Date(
        string="Reminder Date",
        compute="_compute_activity_contract_date",
        store=True,
        readonly=False,
    )
    contract_duration_years = fields.Integer(
        string="Contract Duration ",
        default=1,
        required=True,
        help="e.g. Duration for a contract"
    )
    created_by_id = fields.Many2one(
        'res.users',
        string="Created by",
        default=lambda self: self.env.user,
        readonly=True,
    )
    guarantee_value = fields.Float(
        string="Guarantee Value",
        compute="_compute_guarantee_value",
        store=True,
        help="Calculated as contract amount × guarantee percentage from settings."
    )

    @api.depends('amount')
    def _compute_guarantee_value(self):
        for rec in self:
            settings = self.env['setting.investment'].sudo().search([], limit=1)
            percentage = settings.guarantee_percentage or 0
            rec.guarantee_value = (rec.amount or 0) * (percentage / 100)

    @api.onchange('contract_end_date')
    def _compute_activity_contract_date(self):
        setting = self.env['setting.investment'].sudo().search([], limit=1)
        days = setting.duration_days_contract or 0
        print("print: duration_days_contract = %s", days)
        for rec in self:
            print("print: computing for rec %s, contract_end_date = %s", rec.id, rec.contract_end_date)
            if rec.contract_end_date:
                rec.contract_end_date_activity = rec.contract_end_date - relativedelta(days=days)
                print("print: -> contract_end_date_activity set to %s", rec.contract_end_date_activity)
            else:
                rec.contract_end_date_activity = False
                print("print: -> no contract_end_date, set activity to False")

    @api.model
    def _cron_schedule_contract_end_notifications(self):
        """
        كرون يومي: يرسل activity + رسالة SMS + واتساب للعميل إذا كان اليوم هو تاريخ التذكير للعقد ولم ينتهِ بعد.
        """
        today = fields.Date.context_today(self)
        print("🔔 Cron contract‐end notifications running for %s", today)

        group = self.env.ref('vs_investment.group_contract_end_notifiers', raise_if_not_found=False)
        if not group or not group.users:
            print("⚠️ No contract‐end notifier group or no users.")
            return

        # فقط العقود التي لها تذكير اليوم ولم تنتهي بعد
        recs = self.search([
            ('contract_end_date_activity', '=', today),
            ('contract_end_date', '>', today),
        ])
        print("🔎 %d investment(s) to notify for contract-end", len(recs))

        todo_type = self.env.ref('mail.mail_activity_data_todo').id

        # إعدادات بوابات الإرسال
        sms_gateway = self.env['sms.gateway.config'].sudo().search([], limit=1)
        icp = self.env['ir.config_parameter'].sudo()
        # wa_enabled = icp.get_param('multi_service.whatsapp_service_enable') == 'True'
        wa_gateway = self.env['vs.otp.gateway']

        for inv in recs:
            # ⬅️ خُد تمبلِت الواتساب من نوع العقد لكل سجل
            wa_tmpl_id = getattr(inv.contract_type_id, 'whatsapp_notification_template', False)
            if not wa_tmpl_id:
                # نرمي ValidationError واضح وما ناخدش من مكان تاني
                raise ValidationError(_("WhatsApp template is not configured for contract type '%s'.") % (
                        inv.contract_type_id.display_name or inv.contract_type_id.id
                ))

            # رسالة التنبيه
            summary = _("Investment '%s' contract ends on %s") % (inv.name, inv.contract_end_date)
            note = _("Reminder: contract for investment '%s' will expire on %s.") % (inv.name, inv.contract_end_date)

            # ToDo Activity لكل المستخدمين المحددين
            for user in group.users:
                inv.with_context(mail_notify=False).activity_schedule(
                    'mail.mail_activity_data_todo',
                    user_id=user.id,
                    summary=summary,
                    note=note,
                    date_deadline=today,
                )

            phone = inv.phone
            print("📱 Owner phone:", phone)

            if phone:
                # 1) SMS
                sms_msg = _("تم تذكيرك بقرب انتهاء عقد الاستثمار '%s'. تاريخ الانتهاء: %s.") % (
                    inv.name, inv.contract_end_date)
                try:
                    send_imsart_sms(phone, sms_msg, sms_gateway, 'ar_001')
                    print("📨 SMS sent to:", phone)
                except Exception as e:
                    print("❌ Error sending SMS:", e)

                # 2) WhatsApp (القالب عندك فيه 3 متغيرات: {{1}} مرجع، {{2}} اسم العميل، {{3}} المبلغ)
                try:
                    installment_ref = inv.name or getattr(inv, 'contract_ref', False) or str(inv.id)
                    customer_name = inv.owner_id.name or "عميل"
                    # اختاري أي حقل مبلغ مناسب لعندك؛ لو مفيش خليه صفر
                    amount_val = (getattr(inv, 'amount_due', False) or
                                  getattr(inv, 'amount_total', False) or
                                  getattr(inv, 'contract_amount', False) or
                                  getattr(inv, 'amount', False) or 0.0)
                    amount_text = f"{float(amount_val):,.3f} ر.ع."

                    attrs = {
                        "1": installment_ref,
                        "2": customer_name,
                        "3": amount_text,
                    }

                    res = wa_gateway.send_new_service_created_whatsapp_cron(
                        number=phone,
                        template_id=str(wa_tmpl_id),
                        attributes=attrs,
                    )
                    print("📨 WhatsApp response:", res)
                except Exception as e:
                    print("❌ Error sending WhatsApp:", e)
            else:
                print("⚠️ No phone number for owner of inv %s", inv.name)

        print("✅ Contract‐end cron completed.")

    @api.model
    def _cron_schedule_payment_notifications(self):
        today = fields.Date.context_today(self)
        print("🔔 Cron payment notifications running for %s", today)

        group = self.env.ref('vs_investment.group_payment_notifiers', raise_if_not_found=False)
        if not group or not group.users:
            print("⚠️ No payment notifier group or no users.")
            return

        # إعدادات SMS/WhatsApp
        sms_gateway = self.env['sms.gateway.config'].sudo().search([], limit=1)
        icp = self.env['ir.config_parameter'].sudo()
        # wa_enabled = icp.get_param('multi_service.whatsapp_service_enable') == 'True'
        wa_gateway = self.env['vs.otp.gateway']

        queries = {
            'due': [('payment_line_ids.payment_date', '=', today), ('payment_line_ids.is_paid', '=', False)],
            'before': [('payment_line_ids.activity_date_before', '=', today), ('payment_line_ids.is_paid', '=', False)],
            'after': [('payment_line_ids.activity_date_after', '=', today), ('payment_line_ids.is_paid', '=', False)],
        }
        summaries = {
            'due': _("Payment '%(desc)s' is due today for investment %(inv)s"),
            'before': _("Upcoming payment '%(desc)s' for %(inv)s is due soon"),
            'after': _("Payment '%(desc)s' for %(inv)s is now overdue"),
        }

        for key, domain in queries.items():
            recs = self.search(domain)
            print("🔎 %d investment(s) %s on %s", len(recs), key, today)
            for inv in recs:
                lines = inv.payment_line_ids.filtered(lambda ln: (
                        (key == 'due' and ln.payment_date == today and not ln.is_paid) or
                        (key == 'before' and ln.activity_date_before == today and not ln.is_paid) or
                        (key == 'after' and ln.activity_date_after == today and not ln.is_paid)
                ))
                for ln in lines:
                    for user in group.users:
                        summary = summaries[key] % {'desc': ln.description or _('payment'), 'inv': inv.name}
                        note = _("Please check payment '%s' of investment %s. Amount: %s") % (
                            ln.description or _('payment'),
                            inv.name,
                            ln.amount,
                        )
                        print("   • [%s] schedule for inv %s → %s", key, inv.name, summary)
                        inv.activity_schedule(
                            'mail.mail_activity_data_todo',
                            user_id=user.id,
                            summary=summary,
                            note=note,
                            date_deadline=today,
                        )

                    phone = inv.owner_id.phone
                    if phone:
                        sms_msg = _("يرجى سداد الدفعة '%s' لاستثماركم '%s' بقيمة %s ريال.") % (
                            ln.description or _('payment'), inv.name, ln.amount)
                        try:
                            send_imsart_sms(phone, sms_msg, sms_gateway, 'ar_001')
                            print("📨 SMS sent to:", phone)
                        except Exception as e:
                            print("❌ Error sending SMS:", e)

                        # ⬅️ خُد تمبلِت الواتساب من نوع العقد لكل سجل
                        wa_tmpl_id = getattr(inv.contract_type_id, 'whatsapp_notification_template', False)
                        print("test template", wa_tmpl_id)

                        if not wa_tmpl_id:
                            # نرمي ValidationError واضح وما ناخدش من مكان تاني
                            raise ValidationError(_("WhatsApp template is not configured for contract type '%s'.") % (
                                    inv.contract_type_id.display_name or inv.contract_type_id.id
                            ))

                        # تمبلِت موجود → أرسل واتساب
                        whatsapp_msg = _("عميلنا العزيز، يوجد دفعة مستحقة ('%s') لاستثماركم '%s' بمبلغ %s ريال.") % (
                            ln.description or _('payment'), inv.name, ln.amount)
                        print("whatsapp msgs test", whatsapp_msg)
                        try:
                            installment_ref = ln.description

                            customer_name = inv.owner_id.name or "عميل"

                            amount_text = f"{float(ln.amount):,.3f} ر.ع."

                            attrs = {
                                "1": installment_ref,
                                "2": customer_name,
                                "3": amount_text,
                            }

                            res = wa_gateway.send_new_service_created_whatsapp_cron(
                                number=phone,
                                template_id=str(wa_tmpl_id),
                                attributes=attrs,
                            )
                            print("📨 WhatsApp response:", res)
                        except Exception as e:
                            print("❌ Error sending WhatsApp:", e)
                    else:
                        print("⚠️ No phone number for owner of inv %s", inv.name)

        print("✅ Payment notifications cron completed.")

    @api.model
    def get_contract_stage_counts(self):
        Investment = self.env['investment.record'].sudo()
        ContractType = self.env['investment.contract.type'].sudo()

        # Map stage type to field name
        stage_type_map = {
            'active': 'is_active_contract_stage',
            'expired': 'is_expired_contract_stage',
            'signing': 'is_signing_stage',
        }

        counts = {
            'active': 0,
            'expired': 0,
            'signing': 0,
        }
        stage_ids_map = {
            'active': set(),
            'expired': set(),
            'signing': set(),
        }

        for investment in Investment.search([]):
            contract_type = investment.contract_type_id
            if not contract_type:
                continue

            for line in contract_type.approver_line_ids:
                for stage_type, field in stage_type_map.items():
                    if getattr(line, field) and investment.stage_id == line.stage_id:
                        counts[stage_type] += 1
                        stage_ids_map[stage_type].add(line.stage_id.id)

        # Debug prints
        for k, v in counts.items():
            print(f"📊 {k.capitalize()} Count: {v}")
        for k, v in stage_ids_map.items():
            print(f"📦 {k.capitalize()} Stages: {list(v)}")

        return {
            'active': counts['active'],
            'expired': counts['expired'],
            'signing': counts['signing'],
            'stage_ids': {
                'active': list(stage_ids_map['active']),
                'expired': list(stage_ids_map['expired']),
                'signing': list(stage_ids_map['signing']),
            }
        }

    @api.model
    def _cron_schedule_attachment_notifications(self):
        today = fields.Date.context_today(self)
        print("🔔 Cron Attachment→Investment running, today=%s", today)

        group = self.env.ref('vs_investment.group_attachment_expiry_notifiers')
        if not group or not group.users:
            print("⚠️ No notifier group or users.")
            return

        Attachment = self.env['investment.attachment']
        atts = Attachment.search([('activity_date', '=', today)])
        print("🔎 Found %d attachment(s) to alert", len(atts))

        todo_type = self.env.ref('mail.mail_activity_data_todo')
        for att in atts:
            inv = att.investment_id
            print("➡️ Attachment #%s (%s) → Inv #%s", att.id, att.file_name, inv.id)
            for user in group.users:
                if att.activity_date <= att.date_end:
                    summary = _("Attachment '%s' will expire on %s") % (att.file_name, att.date_end)
                    note = _("Reminder: '%s' of investment %s expires on %s.") % (
                        att.file_name, inv.name, att.date_end)
                else:
                    summary = _("Attachment '%s' has already expired on %s") % (att.file_name, att.date_end)
                    note = _("Alert: '%s' of investment %s expired on %s.") % (
                        att.file_name, inv.name, att.date_end)

                print("   • Schedule ToDo for %s: %s", user.login, summary)
                inv.with_context(mail_notify=False).activity_schedule(
                    'mail.mail_activity_data_todo',
                    user_id=user.id,
                    summary=summary,
                    note=note,
                    date_deadline=today,
                )

        print("✅ Cron finished.")

    def copy(self, default=None):
        default = dict(default or {})
        # default['name'] = "%s (Copy)" % (self.name or '')
        default['ref'] = False

        if self.contract_type_id and self.contract_type_id.approver_line_ids:
            default['stage_id'] = self.contract_type_id.approver_line_ids.sorted('sequence')[0].stage_id.id
        else:
            default['stage_id'] = False

        default.update({
            'contract_start_date': False,
            'contract_end_date': False,
            'contract_end_date_activity': False,
        })

        vals_list = [rec.copy_data(default)[0] for rec in self]
        new_recs = self.env['investment.record'] \
            .with_context(skip_property_booking_check=True, skip_date_check=True) \
            .create(vals_list)
        return new_recs

    # @api.constrains('contract_start_date', 'contract_end_date', 'contract_end_date_activity')
    # def _check_dates(self):
    #     if self.env.context.get('skip_property_booking_check') or self.env.context.get('skip_date_check'):
    #         return
    #
    #     for rec in self:
    #         if not rec.contract_start_date or not rec.contract_end_date:
    #             raise ValidationError(_("⚠️ Both start and end date must be provided."))
    #         if rec.contract_end_date < rec.contract_start_date:
    #             raise ValidationError(_("⚠️ Contract end date (%s) cannot be earlier than start date (%s).") % (
    #                 rec.contract_end_date, rec.contract_start_date))
    #         if rec.contract_end_date_activity and rec.contract_end_date_activity >= rec.contract_end_date:
    #             raise ValidationError(_("⚠️ Reminder date (%s) must be before contract end date (%s).") % (
    #                 rec.contract_end_date_activity, rec.contract_end_date))
    @api.constrains('contract_start_date', 'contract_end_date')
    def _check_dates_present(self):
        if self.env.context.get('skip_property_booking_check') or self.env.context.get('skip_date_check'):
          return
        for rec in self:
            if not rec.contract_start_date or not rec.contract_end_date:
                raise ValidationError(_("⚠️ Both start and end date must be provided."))
            if rec.contract_end_date < rec.contract_start_date:
                raise ValidationError(_(
                    "⚠️ Contract end date (%s) cannot be earlier than start date (%s)."
                ) % (rec.contract_end_date, rec.contract_start_date))


    @api.onchange('payment_line_ids', 'payment_line_ids.payment_date')
    def _onchange_unique_payment_dates(self):
        seen = set()
        for line in self.payment_line_ids:
            if not line.payment_date:
                continue
            if line.payment_date in seen:
                line.payment_date = False
                return {
                    'warning': {
                        'title': _("تكرار التاريخ"),
                        'message': _("⚠️ لا يمكنك تعيين نفس تاريخ الدفع مرتين."),
                    }
                }
            seen.add(line.payment_date)

    @api.constrains('payment_line_ids', 'amount')
    def _check_installment_total_on_save(self):
        """
        On every save of the investment:
        • allow any deletions in the tree…
        • but block the save if total_installments != contract amount,
          and show contract, sum, and difference.
        """

        for rec in self:
            if not rec.payment_line_ids:
                continue

            total = sum(rec.payment_line_ids.mapped('amount'))

            if float_compare(total, rec.amount, precision_digits=2) != 0:
                diff = rec.amount - total
                raise ValidationError(_(
                    "⚠️ Contract amount: %.2f\n"
                    "   Installments sum: %.2f\n"
                    "   Difference: %.2f\n\n"
                    "Please adjust the contract value or installment lines accordingly."
                ) % (rec.amount, total, diff))

    # @api.model
    # def create(self, vals):
    #     # debug
    #     print("🛠️ create() called with vals: %s", vals)
    #     rec = super().create(vals)
    #     print("🛠️ after super.create, rec.id=%s, rec.name=%s", rec.id, rec.name)
    #
    #     # name as before
    #     if rec.name == _('New'):
    #         ct_name = rec.contract_type_id.name or 'CT'
    #         comp_name = rec.partner_company_id.name or 'COMP'
    #         rec.name = f"{ct_name},{comp_name}"
    #         print("🛠️ renamed rec.name → %s", rec.name)
    #
    #     # only generate a ref if one wasn't provided
    #     if not vals.get('ref'):
    #         today = fields.Date.context_today(self)
    #         year_str = today.strftime('%y')  # e.g. '25'
    #         date_str = today.strftime('%y%m%d')  # e.g. '250624'
    #         ccode = rec.contract_type_id.code or ''
    #         scode = rec.state_id.code or ''
    #
    #         # look up any ref in the same year
    #         search_prefix = f"{ccode}-{scode}-{year_str}"
    #         print("🛠️ search_prefix → %s", search_prefix)
    #         last = self.sudo().search(
    #             [('ref', 'like', f"{search_prefix}%")],
    #             order='ref desc',
    #             limit=1
    #         )
    #         print("🛠️ last matching ref → %s", last and last.ref)
    #
    #         if last:
    #             last_seq = int(last.ref.split('-')[-1])
    #             seq = last_seq + 1
    #             print("🛠️ found last_seq=%s, next seq=%s", last_seq, seq)
    #         else:
    #             seq = 1
    #             print("🛠️ no last match, seq=1")
    #
    #         rec.ref = f"{ccode}-{scode}-{date_str}-{seq:04d}"
    #         print("🛠️ set rec.ref → %s", rec.ref)
    #
    #     else:
    #         print("🛠️ vals already provided a ref, skipping generation")
    #
    #     return rec
    @api.model
    def create(self, vals):
        # 1) أنشئ السجل أولاً
        rec = super().create(vals)

        # 2) عدّل الاسم إذا لزم الأمر
        if rec.name == _('New'):
            ct_name = rec.contract_type_id.name or 'CT'
            comp_name = rec.partner_company_id.name or 'COMP'
            rec.name = f"{ct_name},{comp_name}"

        # 3) خلّي توليد ref يعتمد فقط على contract_type_id
        if not vals.get('ref'):
            today = fields.Date.context_today(self)
            date_str = today.strftime('%y%m%d')  # مثلاً '250626'
            ccode = rec.contract_type_id.code or ''
            scode = rec.state_id.code or ''

            # ابحث عن آخر سجل (باستثناء هذا السجل) من نفس نوع العقد
            last = self.sudo().search([
                ('contract_type_id', '=', rec.contract_type_id.id),
                ('ref', '!=', False),
                ('id', '!=', rec.id),
            ], order='id desc', limit=1)

            if last and last.ref:
                try:
                    last_seq = int(last.ref.split('-')[-1])
                except Exception:
                    last_seq = 0
                seq = last_seq + 1
            else:
                seq = 1

            # اجمع ccode + date_str + الترقيم 4 خانات
            rec.ref = f"{ccode}-{scode}-{date_str}-{seq:04d}"

        return rec

    @api.constrains('property_id', 'contract_start_date', 'contract_end_date')
    def _check_property_not_double_booked(self):
        if self.env.context.get('skip_property_booking_check'):
            return
        for rec in self:
            if not rec.property_id or not rec.contract_start_date or not rec.contract_end_date:
                continue
            overlapping = self.search([
                ('id', '!=', rec.id),
                ('property_id', '=', rec.property_id.id),
                ('contract_start_date', '<=', rec.contract_end_date),
                ('contract_end_date', '>=', rec.contract_start_date),
            ], limit=1)
            if overlapping:
                raise ValidationError(_(
                    "⚠️ Property ‘%s’ is already rented from %s to %s."
                ) % (
                                          rec.property_id.name,
                                          overlapping.contract_start_date,
                                          overlapping.contract_end_date,
                                      ))
    _sql_constraints = [
        (
            'amount_positive',
            'CHECK(amount > 0)',
            '⚠️ Contract amount must be greater than zero.'
        ),
    ]


    @api.constrains('amount')
    def _check_amount_positive(self):
        """
        Ensure the contract amount is greater than zero.
        """
        for rec in self:
            if rec.amount <= 0:
                raise ValidationError(
                    _("⚠️ Contract amount must be greater than zero.")
                )

    @api.onchange('payment_line_ids')
    def _onchange_prevent_delete_paid_lines(self):
        """
        Block deleting any paid installment immediately in the UI.
        Allow deleting unpaid ones: user can then adjust rec.amount.
        """
        for rec in self:
            if not rec._origin or not rec._origin.id:
                continue
            orig_ids = rec._origin.payment_line_ids.ids
            new_ids = rec.payment_line_ids.ids
            removed_ids = set(orig_ids) - set(new_ids)
            if not removed_ids:
                continue
            removed = self.env['payment.lines'].browse(list(removed_ids))
            if any(removed.mapped('is_paid')):
                raise UserError("⚠️ You cannot delete an installment that has been paid.")
    @api.depends('contract_type_id')
    def _compute_available_stages(self):
        for rec in self:
            if rec.contract_type_id:
                approver_lines = rec.contract_type_id.approver_line_ids.sorted('sequence')
                stage_ids = [line.stage_id.id for line in approver_lines if line.stage_id]
                rec.available_stage_ids = self.env['investment.stage'].browse(stage_ids)
            else:
                rec.available_stage_ids = [(5, 0, 0)]



    can_approve = fields.Boolean(string="Can Approve", compute="_compute_can_approve")
    can_reject = fields.Boolean(string="Can Reject", compute="_compute_can_actions")


    @api.onchange('contract_type_id')
    def _onchange_contract_type_id(self):
        for rec in self:
            # أولاً: نظّفي أي مرفقات موجودة
            rec.attachment_ids = [(5, 0, 0)]
            if rec.contract_type_id:
                approver_lines = rec.contract_type_id.approver_line_ids.sorted('sequence')
                if approver_lines:
                    rec.stage_id = approver_lines[0].stage_id

                vals = []
                for tmpl in rec.contract_type_id.attachment_template_ids:
                    vals.append((0, 0, {
                        'file_name': tmpl.file_name,
                        'attach': tmpl.attach,
                        'date_end': tmpl.date_end,
                        'activity_date': tmpl.activity_date,
                    }))
                rec.attachment_ids = vals
            else:
                rec.attachment_ids = [(5, 0, 0)]

    @api.depends('payment_line_ids.amount', 'payment_line_ids.is_paid')
    def _compute_payment_totals(self):
        for rec in self:
            total_paid = sum(
                rec.payment_line_ids
                .filtered(lambda l: l.is_paid)
                .mapped('amount')
            )
            rec.paid_amount = total_paid
            rec.remaining_amount = rec.amount - total_paid

    # @api.depends('contract_type_id', 'stage_id')
    # def _compute_can_actions(self):
    #     for rec in self:
    #         rec.can_reject = False
    #         if not rec.contract_type_id or not rec.stage_id:
    #             continue
    #         approver_lines = rec.contract_type_id.approver_line_ids.sorted('sequence')
    #         user_lines = approver_lines.filtered(lambda l: rec.env.user in l.user_ids)
    #         allowed_stages = user_lines.mapped('stage_id')
    #         if rec.stage_id in allowed_stages:
    #             rec.can_reject = True
    def action_reject_stage(self):
        self.ensure_one()
        if not self.can_reject:
            raise UserError(_("⚠️ You are not allowed to reject this stage."))
        self._mark_my_todos_done(feedback=_("تمت رد الطلب"))

        return {
            'name': _('Reject Stage'),
            'type': 'ir.actions.act_window',
            'res_model': 'investment.reject.stage.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_investment_id': self.id},
        }

    show_cancel_button = fields.Boolean(
        string="Show Cancel Button",
        compute="_compute_show_cancel_button",
        help="علامة لإظهار زر الإلغاء فقط إذا لم تكن المرحلة هي مرحلة الإلغاء الفعلية"
    )

    @api.depends('contract_type_id.approver_line_ids', 'stage_id')
    def _compute_show_cancel_button(self):
        for rec in self:
            cancel_line = rec.contract_type_id.approver_line_ids.filtered('is_cancel_stage')
            if cancel_line and rec.stage_id == cancel_line.stage_id:
                rec.show_cancel_button = False
            else:
                rec.show_cancel_button = True

    def action_cancel(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Cancel Investment'),
            'res_model': 'investment.cancel.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_investment_id': self.id},
        }

    def action_generate_payments(self):
        PaymentLine = self.env['payment.lines']

        setting = self.env['setting.investment'].sudo().search([], limit=1)
        days_before = setting.duration_days_payment_before or 0
        days_after = setting.duration_days_payment_after or 0

        for rec in self:
            if not rec.amount or rec.amount <= 0:
                raise UserError(_("⚠️ يجب تحديد قيمة العقد أولاً قبل توليد الدفعات."))
            plan = rec.payment_plan_id
            start = rec.payment_start_date
            years = rec.contract_duration_years
            if not plan or not start or years <= 0:
                raise UserError(_("Please set a Payment Plan, Start Date and Contract Duration."))

            interval = plan.period_months
            total_months = years * 12
            num_periods = total_months // interval
            if interval <= 0 or num_periods < 1:
                raise UserError(_("Invalid interval (%s) or contract duration (%s years).") % (interval, years))

            total = rec.amount or 0.0
            each = float_round(total / num_periods, precision_digits=2)
            rec_ref = (getattr(rec, 'ref', False) or rec.name or rec.display_name or '').strip()

            expected = []
            for i in range(num_periods):
                dt = start + relativedelta(months=interval * i)
                amt = each if i < num_periods - 1 else \
                    float_round(total - each * (num_periods - 1), precision_digits=2)
                desc = f"{rec_ref} {i + 1}/{num_periods}" if rec_ref else f"{i + 1}/{num_periods}"
                expected.append({
                    'description': desc,
                    'payment_date': dt,
                    'amount': amt,
                })
            # approver_lines = rec.contract_type_id.approver_line_ids.sorted('sequence')
            # first_stage = approver_lines and approver_lines[0].stage_id or False
            # is_first_stage = (rec.stage_id == first_stage)
            # any_paid = any(line.is_paid for line in rec.payment_line_ids)
            #
            # if is_first_stage and not any_paid:
            #     # امسح كل الدفعات السابقة (غير مدفوعة ومدفوعة، لكن عادة لن يوجد مدفوع)
            #     rec.payment_line_ids.unlink()
            #     paid_lines = self.env['payment.lines']  # none
            # else:
            #     paid_lines = rec.payment_line_ids.filtered('is_paid')

            paid_lines = rec.payment_line_ids.filtered('is_paid')
            new_lines = [(5, 0, 0)]
            for exp in expected:
                before = exp['payment_date'] - relativedelta(days=days_before)
                after = exp['payment_date'] + relativedelta(days=days_after)

                paid = paid_lines.filtered(lambda l: l.payment_date == exp['payment_date'])
                if paid:
                    vals = {
                        'description': paid.description,
                        'payment_date': paid.payment_date,
                        'amount': paid.amount,
                        'is_paid': True,
                        'activity_date_before': paid.activity_date_before or before,
                        'activity_date_after': paid.activity_date_after or after,
                    }
                else:
                    vals = {
                        'description': exp['description'],
                        'payment_date': exp['payment_date'],
                        'amount': exp['amount'],
                        'is_paid': False,
                        'activity_date_before': before,
                        'activity_date_after': after,
                    }
                new_lines.append((0, 0, vals))

            existing = PaymentLine.search_count([('investment_id', '=', rec.id)])
            if existing:
                unpaid_actual = PaymentLine.search([
                    ('investment_id', '=', rec.id),
                    ('is_paid', '=', False)
                ], order='payment_date asc')
                unpaid_expected = [e for e in expected if e['payment_date'] not in paid_lines.mapped('payment_date')]
                if len(unpaid_actual) != len(unpaid_expected):
                    raise UserError(_("⚠️ You have modified unpaid installments; cannot regenerate."))
                for idx, line in enumerate(unpaid_actual):
                    exp = unpaid_expected[idx]
                    if (line.description != exp['description'] or
                            line.payment_date != exp['payment_date'] or
                            float_compare(line.amount, exp['amount'], precision_digits=2) != 0):
                        raise UserError(_("⚠️ You have modified unpaid installments; cannot regenerate."))

            rec = rec.with_context(skip_line_delete_validation=True)
            rec.payment_line_ids = new_lines

    @api.depends('contract_type_id', 'stage_id')
    def _compute_can_approve(self):
        for rec in self:
            rec.can_approve = False
            ct = rec.contract_type_id
            stage = rec.stage_id
            if not ct or not stage:
                continue

            lines = ct.approver_line_ids.sorted('sequence')
            cancel_idx = next((i for i, ln in enumerate(lines) if ln.is_cancel_stage), None)
            if cancel_idx is not None:
                cancel_stage = lines[cancel_idx].stage_id
                prev_stage = lines[cancel_idx - 1].stage_id if cancel_idx > 0 else False
                if stage in (cancel_stage, prev_stage):
                    continue
            last_stage = lines[-1].stage_id if lines else False
            if stage == last_stage:
                continue

            # 3) المنطق الأصلي
            user_lines = lines.filtered(lambda ln: rec.env.user in ln.user_ids)
            allowed = user_lines.mapped('stage_id')
            if stage in allowed:
                rec.can_approve = True

    @api.onchange('payment_plan_id')
    def _onchange_payment_plan_id(self):
        print("test payment plan id ")
        if self.payment_line_ids:
            self.payment_plan_id = self._origin.payment_plan_id
            return {
                'warning': {
                    'title': _('Operation not allowed'),
                    'message': _(
                        'You have already generated payment lines for this plan. '
                        'Changing the Payment Plan is not allowed.'
                    ),
                }
            }

    @api.depends('contract_type_id', 'stage_id')
    def _compute_can_actions(self):
        for rec in self:
            rec.can_reject = False
            ct = rec.contract_type_id
            stage = rec.stage_id
            if not ct or not stage:
                continue

            lines = ct.approver_line_ids.sorted('sequence')
            cancel_idx = next((i for i, ln in enumerate(lines) if ln.is_cancel_stage), None)
            if cancel_idx is not None:
                cancel_stage = lines[cancel_idx].stage_id
                prev_stage = lines[cancel_idx - 1].stage_id if cancel_idx > 0 else False
                if stage in (cancel_stage, prev_stage):
                    continue
            last_stage = lines[-1].stage_id if lines else False
            if stage == last_stage:
                continue

            user_lines = lines.filtered(lambda ln: rec.env.user in ln.user_ids)
            allowed = user_lines.mapped('stage_id')
            if stage in allowed:
                rec.can_reject = True
    # def action_approve_stage(self):
    #     for rec in self:
    #         if not rec.can_approve:
    #             raise UserError(_("⚠️ You are not allowed to approve this stage."))
    #         approver_lines = rec.contract_type_id.approver_line_ids.sorted('sequence')
    #         stage_ids = approver_lines.mapped('stage_id')
    #         try:
    #             idx = stage_ids.ids.index(rec.stage_id.id)
    #             next_stage = stage_ids[idx + 1]
    #         except (ValueError, IndexError):
    #             next_stage = False
    #         if next_stage:
    #             rec.stage_id = next_stage
    #
    #             group = self.env.ref('vs_investment.group_stage_approval_notifier', raise_if_not_found=False)
    #             if group and group.users:
    #                 summary = _("مرحلة '%s' اعتمدت على السجل %s") % (rec.stage_id.name, rec.name)
    #                 note = _("تمت اعتماد المرحلة '%s' من قبل %s.") % (rec.stage_id.name, self.env.user.name)
    #                 for user in group.users:
    #                     rec.with_context(mail_notify=False).activity_schedule(
    #                         'mail.mail_activity_data_todo',
    #                         user_id=user.id,
    #                         summary=summary,
    #                         note=note,
    #                         date_deadline=fields.Date.context_today(self),
    #                     )
    def _mark_my_todos_done(self, feedback=_("تمت المعالجة")):
        self.ensure_one()
        rec = self.with_user(self.env.user.id)
        rec.activity_feedback(
            ['mail.mail_activity_data_todo'],
            user_id=self.env.user.id,
            feedback=feedback
        )
    def action_approve_stage(self):
        for rec in self:
            if not rec.can_approve:
                raise UserError(_("⚠️ You are not allowed to approve this stage."))
            self._mark_my_todos_done(feedback=_("تمت الموافقة على الطلب"))

            approver_lines = rec.contract_type_id.approver_line_ids.sorted('sequence')
            stage_ids = approver_lines.mapped('stage_id')
            try:
                idx = stage_ids.ids.index(rec.stage_id.id)
                next_stage = stage_ids[idx + 1]
            except (ValueError, IndexError):
                next_stage = False

            prev_stage_name = rec.stage_id.name

            if next_stage:
                rec.stage_id = next_stage

                next_line = approver_lines.filtered(lambda l: l.stage_id.id == next_stage.id)
                users_to_notify = next_line.mapped('user_ids')

                summary = _("تم اعتماد المرحلة '%s' في السجل %s") % (prev_stage_name, rec.name)
                note = _("تم اعتماد المرحلة '%s' من قبل %s.") % (prev_stage_name, self.env.user.name)

                for user in users_to_notify:
                    rec.with_context(mail_notify=False).activity_schedule(
                        'mail.mail_activity_data_todo',
                        user_id=user.id,
                        summary=summary,
                        note=note,
                        date_deadline=fields.Date.context_today(self),
                    )

    def write(self, vals):
        if 'stage_id' in vals:
            for rec in self:
                if not rec.can_approve:
                    raise UserError(_("⚠️ You are not allowed to move this record to another stage."))
                if rec.stage_id.id == vals.get('stage_id'):
                    continue

                new_stage_id = vals.get('stage_id')
                new_stage = self.env['investment.stage'].browse(new_stage_id)

                # Get approver line of the new stage
                approver_line = rec.contract_type_id.approver_line_ids.filtered(
                    lambda l: l.stage_id.id == new_stage.id
                )
                users = approver_line.mapped('user_ids')
                if users:
                    summary = _("تم تحويل السجل %s إلى المرحلة '%s'") % (rec.name, new_stage.name)
                    note = _("يرجى مراجعة السجل في المرحلة '%s'.") % (new_stage.name)

                    for user in users:
                        rec.with_context(mail_notify=False).activity_schedule(
                            'mail.mail_activity_data_todo',
                            user_id=user.id,
                            summary=summary,
                            note=note,
                            date_deadline=fields.Date.context_today(self),
                        )
        if 'payment_start_date' in vals:
            for rec in self:
                if rec.payment_line_ids:
                    raise ValidationError(_(
                        "⚠️ لا يمكنك تغيير تاريخ بدء الدفعات بعد إصدارها."
                    ))
        if not self.env.context.get('skip_date_check'):
            for rec in self:
                start = vals.get('contract_start_date', rec.contract_start_date)
                end   = vals.get('contract_end_date',   rec.contract_end_date)
                if not start or not end:
                    raise ValidationError(_("⚠️ يجب تحديد تاريخي بداية ونهاية العقد."))
                if end < start:
                    raise ValidationError(_(
                        "⚠️ تاريخ نهاية العقد (%s) لا يمكن أن يكون قبل تاريخ البداية (%s)."
                    ) % (end, start))
        if 'contract_type_id' in vals or 'state_id' in vals:
            for rec in self:
                if 'contract_type_id' in vals or 'state_id' in vals:
                    raise ValidationError(_(
                        "⚠️ لا يمكنك تعديل نوع العقد أو الولاية بعد إنشاء السجل."
                    ))


        for rec in self:
            changes = []
            for field_name, new_val in vals.items():
                if field_name == 'payment_line_ids' and isinstance(new_val, list):
                    count_new = sum(1 for cmd in new_val if isinstance(cmd, tuple) and cmd[0] == 0)
                    count_old = len(rec.payment_line_ids)
                    if count_new != count_old:
                        changes.append((
                            "Installments",
                            f"{count_old} lines",
                            f"{count_new} lines"
                        ))
                    continue

                field = rec._fields.get(field_name)
                if not field:
                    continue
                label = field.string or field_name

                if field.type == 'many2one':
                    old_rec = rec[field_name]
                    old_disp = old_rec.display_name if old_rec else '—'
                    new_disp = self.env[field.comodel_name].browse(new_val).display_name if new_val else '—'
                else:
                    old_disp = rec[field_name] or '—'
                    new_disp = new_val or '—'

                if str(old_disp) != str(new_disp):
                    changes.append((label, old_disp, new_disp))
            if changes:
                body = '<b>The following fields were updated:</b><ul>'
                for label, old_disp, new_disp in changes:
                    body += (
                            '<li><strong>%s</strong>: from "%s" to "%s"</li>'
                            % (label, old_disp, new_disp)
                    )
                body += '</ul>'
                self.message_post(body=body)


        return super().write(vals)

    @api.constrains('state_id', 'property_id')
    def _check_property_state(self):
        for rec in self:
            if rec.property_id and rec.property_id.state_id != rec.state_id:
                msg = _("⚠️ يجب اختيار عقار تابع للولاية '%s'.") % rec.state_id.name
                raise ValidationError(msg)

    account_payment_ids = fields.One2many(
        'account.payment',
        'investment_id',
        string='Account Payments',
    )
    payment_count = fields.Integer(
        string="Payments",
        compute="_compute_payment_count",
        store=True,
    )

    @api.depends('payment_line_ids.payment_id.state')
    def _compute_payment_count(self):
        for rec in self:
            payments = rec.payment_line_ids.mapped('payment_id').filtered(lambda p: p.state in ['draft', 'posted'])
            rec.payment_count = len(payments)

    # def action_view_payment_lines(self):
#     self.ensure_one()
#     return {
#         'name': _('Payment Lines'),
#         'type': 'ir.actions.act_window',
#         'res_model': 'payment.lines',
#         'view_mode': 'tree,form',
#         'domain': [('investment_id', '=', self.id)],
#         'context': {'default_investment_id': self.id},
#     }


#     def action_view_account_payments(self):
#         self.ensure_one()
#         action = self.env.ref('account.action_account_payments').read()[0]
#         action.update({
#             'domain': [('investment_id', '=', self.id)],
#             'context': {'create': False},  # لمنع إنشاء دفعات يدوية من هنا إذا أردتِ
#         })
#         return action
    def action_view_account_payments(self):
        self.ensure_one()
        line_payment_ids = self.payment_line_ids.mapped('payment_id').filtered(lambda p: p.state in ['draft', 'posted'])
        domain = [('id', 'in', line_payment_ids.ids)]
        action = self.env.ref('account.action_account_payments').read()[0]
        action.update({
            'domain': domain,
            'context': {'create': False},
        })
        return action