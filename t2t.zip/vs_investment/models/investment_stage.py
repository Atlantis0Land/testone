# models/investment_stage.py
from odoo import models, fields

class InvestmentStage(models.Model):
    _name = "investment.stage"
    _description = "Contract Stage"
    _order = "sequence asc"


    name = fields.Char(string="Stage Name", required=True)
    sequence = fields.Integer(
        string="Sequence",
        default=10,
        help="Determines the order of stages"
    )

    approver_line_ids = fields.One2many('investment.approver.line', 'stage_id', string="Approvers")

