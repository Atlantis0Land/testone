from odoo import models, fields ,api ,_
from odoo.exceptions import ValidationError


class MessageType(models.Model):
    _name = "message.type"
    _description = "Investment Msg Type"

    name = fields.Char(string="Message ", required=True)

    @api.model
    def create(self, vals):
        if self.search_count([]) >= 1:
            raise ValidationError(_("لا يمكنك إنشاء أكثر من سجل واحد."))
        return super().create(vals)
