from odoo import models, fields

class InvestmentActivityType(models.Model):
    _name = "activity.type"
    _description = "Investment Activity Type"

    name = fields.Char(string="Activity Type", required=True)
