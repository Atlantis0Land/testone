# models/payment_plan_config.py
from odoo import models, fields,api,_
from odoo.exceptions import UserError


class PaymentPlanConfig(models.Model):
    _name = 'payment.plan.config'
    _description = 'Payment Plan Configuration'
    _inherit = ["mail.thread", "mail.activity.mixin"]


    name = fields.Char(
        string='Plan Name',
        required=True,
        help="e.g. 'سنوي', 'ربع سنوي', 'نصف سنوي', etc."
    )
    period_months = fields.Integer(
        string='Interval (Months)',
        required=True,
        help="Number of months between each payment (e.g. 12 for yearly, 6 for semi-annual)"
    )

    active = fields.Boolean(
        string='Active',
        default=True,
    )

    def copy(self, default=None):
        default = dict(default or {})
        default['name'] = _("%s (Copy)") % (self.name or '')
        return super().copy(default)

    def unlink(self):
        Contract = self.env['investment.record']
        for plan in self:
            used = Contract.search_count([('payment_plan_id', '=', plan.id)])
            if used:
                raise UserError(_(
                    "⚠️ لا يمكن حذف خطة الدفعات '%s' لأنها مستخدمة في %s عقد."
                ) % (plan.name, used))
        return super().unlink()