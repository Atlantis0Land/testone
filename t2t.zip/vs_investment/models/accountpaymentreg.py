from odoo import models, api

class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    def _create_payment(self, vals):
        """
        هذا الميثود هو الذي ينشئ record من account.payment
        فنحن نعيد ما يفعله الأصلي ثم نعلّم أسطرنا
        """
        payments = super()._create_payment(vals)
        # إذا فتحنا الـ wizard من زر على payment.lines
        active_model = self.env.context.get('active_model')
        active_ids   = self.env.context.get('active_ids')
        if active_model == 'payment.lines' and active_ids:
            line = self.env['payment.lines'].browse(active_ids[0])
            line.write({
                'payment_id': payments.id,
                'is_paid': True,
            })
        return payments
