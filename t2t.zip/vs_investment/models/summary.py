# models/summary_type.py
from odoo import models, fields

class SummaryType(models.Model):
    _name = 'summary.type'
    _description = 'Summary Type'

    name = fields.Char(string='Name')
    investment_id = fields.Many2one(
        'investment.record', string="Investment", ondelete='cascade')
    file_id = fields.Many2one(
        'summary.file', string="File Name", ondelete='cascade')
    attachment = fields.Binary(
        string='File',
    )
    attachment_filename = fields.Char(string='File Name')

    date = fields.Date(
        string='Date',
        default=fields.Date.context_today,
    )
