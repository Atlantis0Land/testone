from odoo import models, fields,api ,_
from odoo.exceptions import ValidationError


class InvestmentApproverLine(models.Model):
    _name = 'investment.approver.line'
    _description = 'Approver per Stage'

    contract_type_id = fields.Many2one('investment.contract.type', string="Contract Type", required=True, ondelete='cascade')
    stage_id = fields.Many2one('investment.stage', string="Stage", required=True)
    user_ids = fields.Many2many('res.users', string="Users", required=True,   domain=lambda self: [('groups_id', 'in', self.env.ref('base.group_user').ids)],
)
    sequence = fields.Integer(string="Sequence", related='stage_id.sequence')
    is_cancel_stage = fields.Boolean(
        string="Cancel Stage",
        help="Mark this line’s stage as the cancel target"
    )
    is_active_contract_stage = fields.Boolean(
        string="Active Contract Stage",
        help="Mark this stage as representing active contracts."
    )

    is_expired_contract_stage = fields.Boolean(
        string="Expired Contract Stage",
        help="Mark this stage as representing expired contracts."
    )

    is_signing_stage = fields.Boolean(
        string="Signing Stage",
        help="Mark this stage as representing the contract under signing process."
    )


    @api.constrains('is_cancel_stage')
    def _check_unique_cancel_stage(self):
        for line in self:
            if line.is_cancel_stage:
                dup = self.search([
                    ('contract_type_id', '=', line.contract_type_id.id),
                    ('is_cancel_stage', '=', True),
                    ('id', '!=', line.id),
                ], limit=1)
                if dup:
                    raise ValidationError(_("Only one Cancel Stage per contract type."))

    _sql_constraints = [
        ('unique_stage_per_contract',
         'unique(contract_type_id, stage_id)',
         'Each stage can only appear once per contract type.')
    ]

    @api.constrains('stage_id', 'contract_type_id')
    def _check_duplicate_stage(self):
        for rec in self:
            if rec.stage_id and rec.contract_type_id:
                duplicates = rec.contract_type_id.approver_line_ids.filtered(
                    lambda l: l.stage_id == rec.stage_id and l.id != rec.id
                )
                if duplicates:
                    raise ValidationError(
                        "This stage is already assigned to another approver in the same contract type.")