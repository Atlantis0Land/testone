from odoo import models, fields ,api ,_
from odoo.exceptions import ValidationError
class SettingsInvestment(models.Model):
    _name = "setting.investment"
    _description = "Investment Settings"

    duration_days_contract = fields.Integer(
        string="Contract Reminder Offset (Days)",
        help="Number of days before the contract end date to schedule the reminder."
    )
    duration_days_attachment = fields.Integer(
        string="Attachment Reminder Offset (Days)",
        help="Number of days before the Attachment end date to schedule the reminder."
    )
    duration_days_payment_before = fields.Integer(
        string="Payment Reminder Before (Days)",
        help="Number of days before the payment date to schedule the reminder."
    )
    duration_days_payment_after = fields.Integer(
        string="Payment Reminder After (Days)",
        help="Number of days after the payment date to schedule the reminder."
    )
    enable_sms = fields.Boolean(
        string="Enable SMS Notifications",
        help="If checked, the system will send SMS reminders along with Activities."
    )
    guarantee_percentage = fields.Float(
        string="Guarantee Percentage (%)",
        help="The guarantee percentage for the investment (e.g., 5 for 5%)."
    )
    api_key = fields.Char(
        string="Google Maps API Key",
        help="Enter your Google Maps JavaScript API key"
    )

    @api.model
    def create(self, vals):
        if self.search_count([]) >= 1:
            raise ValidationError(_("لا يمكنك إنشاء أكثر من سجل واحد."))
        return super().create(vals)

