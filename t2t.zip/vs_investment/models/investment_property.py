# models/investment_property.py
from odoo import models, fields,_,api
from odoo.exceptions import UserError


class InvestmentProperty(models.Model):
    _name = "investment.property"
    _description = "Investment Property"

    name = fields.Char(string="Property Name", required=True)
    code = fields.Char(string="Property Code", required=True)

    location_url = fields.Char(string="Location Link")
    map = fields.Char(string="Map")
    address_url = fields.Char(string="Location Link")

    address = fields.Char(string="Full Address")
    electricity_meter_number = fields.Char(
        string=" Electricity Meter Number")
    water_meter_number       = fields.Char(
        string="Water Meter Account Number")

    property_id = fields.Many2one('investment.property', string="Property")
    investment_record_ids = fields.One2many(
        'investment.record',
        'property_id',
        string='Investment Records'
    )
    property_type_id = fields.Many2one(
        'property.type',
        string="Property Type"
    )
    state_id = fields.Many2one(
        'res.state',
        string="State",
        help="Select the state for this property"
    )
    property_attachment_ids = fields.One2many(
        'investment.property.attachment',
        'property_id',
        string="Attachments"
    )


    def copy(self, default=None):
        default = dict(default or {})
        default['name'] = "%s (Copy)" % (self.name or '')

        vals_list = []
        for rec in self:
            data = rec.copy_data(default)[0]
            vals_list.append(data)

        return self.env['investment.property'].create(vals_list)

    @api.model
    def get_property_status_counts(self):
        Property = self.env['investment.property']
        Contract = self.env['investment.record']

        all_properties = Property.search([])
        rented_ids = set()

        active_stage_ids = self.env['investment.approver.line'].search([
            '|',
            ('is_active_contract_stage', '=', True),
            ('is_signing_stage', '=', True)
        ]).ids

        contracts = Contract.search([
            ('stage_id', 'in', active_stage_ids),
            ('property_id', '!=', False)
        ])

        for contract in contracts:
            rented_ids.add(contract.property_id.id)

        rented_count = len(rented_ids)
        available_count = len(all_properties) - rented_count

        return {
            'rented': rented_count,
            'available': available_count,
        }

    is_rented = fields.Boolean(
        string="Is Rented",
        compute="_compute_is_rented",
        store=True
    )

    @api.depends('investment_record_ids.stage_id', 'investment_record_ids.contract_type_id.approver_line_ids')
    def _compute_is_rented(self):
        for rec in self:
            is_rented = False
            for contract in rec.investment_record_ids:
                approver_line = contract.contract_type_id.approver_line_ids.filtered(
                    lambda l: l.stage_id.id == contract.stage_id.id
                )
                if approver_line.filtered(lambda l: l.is_active_contract_stage or l.is_signing_stage):
                    is_rented = True
                    break
            rec.is_rented = is_rented

    def unlink(self):
        """
        Prevent deleting any property that has at least one
        InvestmentRecord linked to it.
        """
        for prop in self:
            # count active contracts using this property
            contracts = self.env['investment.record'].search_count([
                ('property_id', '=', prop.id),
            ])
            if contracts:
                raise UserError(_(
                    "⚠️ You cannot delete Property '%s' because "
                    "it is currently under contract."
                ) % prop.name)
        return super().unlink()

# models/investment_property_attachment.py
from odoo import models, fields, api

class InvestmentPropertyAttachment(models.Model):
    _name = 'investment.property.attachment'
    _description = "Property Attachment"

    property_id = fields.Many2one('investment.property', string="Property", ondelete='cascade')
    file = fields.Binary(string="Attachment", required=True)
    file_name = fields.Char(string="File Name")





