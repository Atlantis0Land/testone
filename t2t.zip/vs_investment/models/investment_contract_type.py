from odoo import models, fields ,api


class InvestmentContractType(models.Model):
    _name = "investment.contract.type"
    _description = "Contract Type"
    _inherit = ['mail.thread', 'mail.activity.mixin']



    name = fields.Char(string="Contract Type", required=True)
    code = fields.Char(
        string="Contract Code",
        required=True,
        help="Short abbreviation for this contract type",
        tracking=True,
    )
    stage_id = fields.Many2one('investment.stage', string="Stage")
    whatsapp_template_id = fields.Char(
        string='WhatsApp Template',
        help='Template used when sending WhatsApp messages'
    )
    whatsapp_template_id_link_invest = fields.Char(
        string='WhatsApp Template Link Investment',
        help='Template used when sending WhatsApp messages'
    )
    whatsapp_notification_template = fields.Char(
        string='WhatsApp Notification  Template',
        help='the WhatsApp notification ',
        tracking=True
    )
    attachment_template_ids = fields.Many2many(
        'investment.attachment',
        'rel_contract_type_attachment',
        'contract_type_id',
        'attachment_id',
        string="Template Attachments",
    )

    approver_line_ids = fields.One2many('investment.approver.line', 'contract_type_id', string="Approvers")

   #  @api.constrains('approver_line_ids')
   #  def _check_unique_stages(self):
   #      for rec in self:
   #          stage_ids = rec.approver_line_ids.mapped('stage_id.id')
   #          if len(stage_ids) != len(set(stage_ids)):
   #              raise ValidationError("Each stage must appear only once in the Approvers list.")
   #
   #