# models/res_config_settings.py
from odoo import models, fields

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    duration_days_contract = fields.Integer(
        string="Contract Reminder Offset (Days)",
        config_parameter='vs_investment.duration_days_contract',
        help="Number of days before the contract end date to schedule the reminder."
    )
    duration_days_attachment = fields.Integer(
        string="Attachment Reminder Offset (Days)",
        config_parameter='vs_investment.duration_days_attachment',
        help="Number of days before the Attachment end date to schedule the reminder."
    )
    duration_days_payment_before = fields.Integer(
        string="Payment Reminder Before (Days)",
        config_parameter='vs_investment.duration_days_payment_before',
        help="Number of days before the payment date to schedule the reminder."
    )
    duration_days_payment_after = fields.Integer(
        string="Payment Reminder After (Days)",
        config_parameter='vs_investment.duration_days_payment_after',
        help="Number of days after the payment date to schedule the reminder."
    )
