# -*- coding: utf-8 -*-

from . import investment
from . import investment_property
from . import investment_contract_type
from . import investment_stage
from . import investment_approver_line
from . import activity_type
from . import res_state
from . import payment_lines
from . import investment_whatsapp_log
from . import investment_whatsapp_wizard
from . import payment_plan_config
from . import property_type
from . import investment_attachment
from . import setting
from . import summary
from . import summary_file
from . import message
from . import invest_reject_stage
from . import cancel_wizard
# from . import accountpaymentreg
# from . import res_config_setting

