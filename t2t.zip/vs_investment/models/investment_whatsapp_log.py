from odoo import models, fields

class InvestmentWhatsAppLog(models.Model):
    _name = 'investment.whatsapp.log'
    _description = 'Investment WhatsApp Log'


    investment_id = fields.Many2one(
        'investment.record',
        string='Investment',
        ondelete='cascade',
        required=True,
    )
    user_id = fields.Many2one(
        'res.users',
        string='Sent By',
        readonly=True,
        default=lambda self: self.env.user.id
    )
    message = fields.Text(string='Message', readonly=True)
    date_time = fields.Datetime(
        string='Date Sent',
        readonly=True,
        default=fields.Datetime.now
    )
