from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta


class InvestmentAttachment(models.Model):
    _name = 'investment.attachment'
    _description = 'Investment Attachment'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'file_name'



    investment_id  = fields.Many2one(
        'investment.record', string="Investment",  ondelete='cascade')
    file_name      = fields.Char(string="File Name", required=True)
    attachment_id  = fields.Many2one(
        'ir.attachment', string="Attachment", help="Select or upload a file")
    attachment_filename = fields.Char(string='File Name')

    attach         = fields.Binary(string="Upload File")
    date_end       = fields.Date(string="End Date")
    # activity_date  = fields.Date(string="Activity Date")
    contract_type_id = fields.Many2one(
        'investment.contract.type',
        string='Contract Type',
        ondelete='cascade',
        help="If set, this attachment is a template for that contract type."
    )
    activity_date = fields.Date(
        string="Activity Date",
        compute='_compute_activity_date',
        store=True,
    )

    @api.depends('date_end')
    def _compute_activity_date(self):
        setting = self.env['setting.investment'].sudo().search([], limit=1)
        days = setting.duration_days_attachment or 0
        for rec in self:
            if rec.date_end:
                rec.activity_date = rec.date_end - relativedelta(days=days)
            else:
                rec.activity_date = False
