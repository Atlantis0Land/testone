from odoo import models, fields, api ,_
import re
from odoo.exceptions import UserError
from odoo.addons.v16_ismart_sms.models.sms_sms import send_imsart_sms


DEFAULT_COUNTRY_CODE = '968'

def format_mobile_number(mobile, country_code="968"):
    print(f"[DEBUG] Raw input mobile: {mobile}")
    digits = re.sub(r'\D', '', str(mobile))
    if digits.startswith(country_code):
        digits = digits[len(country_code):]
    digits = digits[-8:]
    formatted = f"{country_code}{digits}"
    print(f"[DEBUG] Formatted mobile number: {formatted}")
    return formatted

class InvestmentWhatsAppWizard(models.TransientModel):
    _name = 'investment.whatsapp.wizard'
    _description = 'Send WhatsApp Message'

    investment_id = fields.Many2one(
        'investment.record',
        string='Investment',
        required=True,
        readonly=True
    )
    message = fields.Text(string='Message', required=True)

    def action_send_whatsapp(self):
        self.ensure_one()
        inv = self.investment_id

        # 1) رقم الهاتف
        raw_phone = inv.owner_id.phone or inv.partner_company_id.phone
        if not raw_phone:
            raise UserError(_("لا يوجد رقم هاتف على الشريك."))
        phone = f"+{format_mobile_number(raw_phone)}"

        # 2) إرسال WhatsApp
        template = inv.contract_type_id.whatsapp_template_id
        if not template:
            raise UserError(_("لا يوجد قالب WhatsApp في إعدادات نوع العقد."))
        wa_resp = self.env['vs.otp.gateway'].send_whatsapp_custom_template(
            number=phone,
            template_id=template,
            attribute=self.message,
        )
        if not wa_resp.get('sent'):
            raise UserError(_("فشل إرسال WhatsApp: %s") % wa_resp)

        # 3) تسجيل اللوج
        self.env['investment.whatsapp.log'].create({
            'investment_id': inv.id,
            'message': self.message,
            # 'sent_via': 'whatsapp',
        })

        # 4) إذا خيار SMS مفعّل، أرسل SMS بنفس الطريقة
        setting = self.env['setting.investment'].sudo().search([], limit=1)
        if setting.enable_sms:
            gateway = self.env['sms.gateway.config'].sudo().search([], limit=1)
            if not gateway:
                raise UserError(_("❌ لم تُعرّف إعدادات بوابة الـ SMS."))
            sms_body = self.message
            sms_resp = send_imsart_sms(
                mobile_no=phone,
                sms=sms_body,
                sms_gateway=gateway,
                lang=self.env.user.lang or 'en_US',
            )
            if not  sms_resp:
                # بعض الإصدارات ترجع True/False بدلاً من dict
                raise UserError(_("فشل إرسال SMS: %s") % sms_resp)
            # سجل ناجح
            self.env['investment.whatsapp.log'].create({
                'investment_id': inv.id,
                'message': sms_body,
                # 'sent_via': 'sms',
            })

        return {'type': 'ir.actions.act_window_close'}