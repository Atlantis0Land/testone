from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime
from odoo.addons.payment import utils as payment_utils
from odoo.exceptions import ValidationError
from odoo.addons.v16_ismart_sms.models.sms_sms import send_imsart_sms
import re
from datetime import timedelta
from collections import defaultdict




from odoo.tools.float_utils import float_compare
DEFAULT_COUNTRY_CODE = '968'

def format_mobile_number(mobile, country_code="968"):
    print(f"[DEBUG] Raw input mobile: {mobile}")
    digits = re.sub(r'\D', '', str(mobile))
    if digits.startswith(country_code):
        digits = digits[len(country_code):]
    digits = digits[-8:]
    formatted = f"{country_code}{digits}"
    print(f"[DEBUG] Formatted mobile number: {formatted}")
    return formatted

class PaymentLines(models.Model):
    _name = 'payment.lines'
    _description = 'Investment Payment Line'

    investment_id = fields.Many2one('investment.record', string="Investment", ondelete='cascade')
    description = fields.Char(string="Description", required=True)
    ref = fields.Char(related='investment_id.ref',string="Ref")
    payment_date = fields.Date(string="Date")
    is_paid = fields.Boolean(string="Paid")
    to_pay = fields.Boolean(string="Select to Pay")
    amount = fields.Float(
        string="Amount",
        digits=(16, 2),
    )
    payment_id     = fields.Many2one(
        'account.payment', string='Payment', readonly=True)
    payment_link   = fields.Char(string='Payment Link', readonly=True)
    short_link     = fields.Char(string='Short Link', readonly=True)

    owner_id = fields.Many2one(
        'res.partner', string='Partner',
        related='investment_id.owner_id', store=True)
    activity_date_before  = fields.Date(string="Activity Date Before")
    activity_date_after  = fields.Date(string="Activity Date After")
    overdue = fields.Boolean(
        string="Overdue",
        compute="_compute_overdue",
        store=True,
    )
    state = fields.Selection(
        related='payment_id.state',
        string="Payment State",
        store=True,
        readonly=True,
    )

    @api.model
    def get_monthly_revenue(self):
        results = defaultdict(float)
        today = fields.Date.today()

        lines = self.search([
            ('is_paid', '=', True),
            ('payment_date', '!=', False),
            ('payment_date', '<=', today),
        ])

        for line in lines:
            dt = fields.Date.to_date(line.payment_date)
            month_label = dt.strftime('%b %Y')  # e.g., Jul 2025
            results[month_label] += line.amount

        sorted_items = sorted(results.items(), key=lambda x: datetime.strptime(x[0], '%b %Y'))

        return [{'month': k, 'amount': v} for k, v in sorted_items]

    @api.model
    def get_payment_stats(self):
        today = fields.Date.today()
        year_start = today.replace(month=1, day=1)
        month_start = today.replace(day=1)

        all_lines = self.search([])
        overdue = all_lines.filtered(lambda l: not l.is_paid and l.payment_date and l.payment_date < today)
        unpaid_this_month = all_lines.filtered(lambda
                                                   l: not l.is_paid and l.payment_date and l.payment_date >= month_start and l.payment_date <= today.replace(
            day=28))
        paid_this_month = all_lines.filtered(lambda l: l.is_paid and l.payment_date and l.payment_date >= month_start)
        total_year_paid = all_lines.filtered(lambda l: l.is_paid and l.payment_date and l.payment_date >= year_start)

        return {
            'total': len(all_lines),
            'overdue': len(overdue),
            'expected_month': sum(unpaid_this_month.mapped('amount')),
            'actual_month': sum(paid_this_month.mapped('amount')),
            'total_annual': sum(total_year_paid.mapped('amount')),
        }

    @api.depends('payment_date', 'is_paid')
    def _compute_overdue(self):
        today = fields.Date.context_today(self)
        for rec in self:
            rec.overdue = bool(
                rec.payment_date
                and not rec.is_paid
                and today > rec.payment_date
            )

    def action_send_whatsapp_link(self):
        for rec in self:
            raw_phone = rec.owner_id.phone or rec.investment_id.owner_id.phone
            if not raw_phone:
                raise UserError(_("لا يوجد رقم هاتف للشريك."))

            formatted = format_mobile_number(raw_phone)
            phone = f"+{formatted}"
            print("phone",phone)

            link = rec.short_link or rec.payment_link
            if not link:
                raise UserError(_("لا يوجد رابط دفع لإرساله."))
            setting = self.env['setting.investment'].sudo().search([], limit=1)
            if setting.enable_sms:
                # fetch your gateway config
                gateway = self.env['sms.gateway.config'].sudo().search([], limit=1)
                if not gateway:
                    raise UserError(_("❌ لم تُعرّف إعدادات بوابة الـ SMS."))
                msg_rec = self.env['message.type'].sudo().search([], limit=1)
                if not msg_rec:
                    raise UserError(_("Please configure the Message Type record."))
                sms_body = msg_rec.name.format(link=link)
                resp = send_imsart_sms(
                    mobile_no=phone,
                    sms=sms_body,
                    sms_gateway=gateway,
                    lang=self.env.user.lang or 'en_US',
                )
                if not resp:
                    raise UserError(_("فشل إرسال SMS: %s") % resp)

            template_id = rec.investment_id.contract_type_id.whatsapp_template_id_link_invest
            if not template_id:
                raise UserError(_("لا يوجد معرّف القالب في الإعدادات."))

            response = self.env['vs.otp.gateway'].send_payment_link_notification_investment(
                number=phone,
                template_id=template_id,
                link=link,
            )
            if not response.get('sent'):
                raise UserError(_("فشل إرسال WhatsApp: %s") % response.get('text'))

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('WhatsApp'),
                'message': _('تم إرسال رابط الدفع بنجاح عبر WhatsApp.'),
                'type': 'success',
                'sticky': False,
            }
        }

    def cron_send_payment_links(self):
        today = fields.Date.context_today(self)
        setting = self.env['setting.investment'].sudo().search([], limit=1)
        days_before = setting.duration_days_payment_before if setting else 0

        lines_today = self.search([
            ('payment_date', '=', today),
            ('is_paid', '=', False)
        ])

        reminder_date = today + timedelta(days=days_before)
        lines_reminder = self.search([
            ('payment_date', '=', reminder_date),
            ('is_paid', '=', False)
        ])

        lines = (lines_today | lines_reminder).filtered(lambda l: not l.is_paid)

        print(f"🔔 [CRON] Payment lines for today ({today}): {len(lines_today)}")
        print(f"🔔 [CRON] Payment lines for reminder ({reminder_date}): {len(lines_reminder)}")
        print(f"🔔 [CRON] Total lines to notify: {len(lines)}")

        for line in lines:
            if not line.short_link:
                line.action_create_payment_link()

            raw_phone = line.owner_id.phone or line.investment_id.owner_id.phone
            if not raw_phone:
                print(f"⚠️ No phone for line {line.id}")
                continue

            formatted = format_mobile_number(raw_phone)
            phone = f"+{formatted}"
            print("phone", phone)

            link = line.short_link or line.payment_link
            if not link:
                print(f"⚠️ No payment link for line {line.id}")
                continue

            # --- SMS Notification ---
            setting = line.env['setting.investment'].sudo().search([], limit=1)
            if setting and setting.enable_sms:
                gateway = line.env['sms.gateway.config'].sudo().search([], limit=1)
                if gateway:
                    msg_type = line.env['message.type'].sudo().search([], limit=1)
                    sms_body = msg_type and msg_type.name.format(link=link) or _(
                        "يرجى سداد الدفعة عبر الرابط: %s") % link
                    try:
                        resp = send_imsart_sms(
                            mobile_no=phone,
                            sms=sms_body,
                            sms_gateway=gateway,
                            lang=line.env.user.lang or 'ar_001',
                        )
                        print(f"✅ SMS sent for line {line.id}")
                    except Exception as e:
                        print(f"❌ SMS failed for line {line.id}: {e}")
                else:
                    print(f"❌ No SMS gateway for line {line.id}")

            template_id = line.investment_id.contract_type_id.whatsapp_template_id_link_invest
            if template_id:
                try:
                    response = line.env['vs.otp.gateway'].send_payment_link_notification_investment(
                        number=phone,
                        template_id=template_id,
                        link=link,
                    )
                    if response and response.get('sent'):
                        print(f"✅ WhatsApp sent for line {line.id}")
                    else:
                        print(f"❌ WhatsApp failed for line {line.id}: {response.get('text')}")
                except Exception as e:
                    print(f"❌ WhatsApp error for line {line.id}: {e}")
            else:
                print(f"❌ No WhatsApp template for line {line.id}")

        print("✅ [CRON] Payment link notifications completed.")
    def action_create_payment_link(self):
        for line in self:
            if line.payment_id:
                raise UserError(_("رابط الدفع مُنشأ بالفعل لهذا السطر."))

            if not line.amount or line.amount <= 0:
                raise UserError(_("القيمة يجب أن تكون أكبر من صفر."))

            payment = self.env['account.payment'].create({
                'payment_type': 'inbound',
                'partner_type': 'customer',
                'partner_id': line.owner_id.id,
                'amount': line.amount,
                'currency_id': self.env.company.currency_id.id,
                'payment_method_id': self.env.ref('account.account_payment_method_manual_in').id,
                'journal_id': self.env['account.journal'].search([('type', '=', 'bank')], limit=1).id,
                'date': fields.Date.context_today(self),
                'ref': f"Investment {line.investment_id.id} / Line {line.id}",
            })
            access_token = payment_utils.generate_access_token(
                payment.partner_id.id, payment.amount, payment.currency_id.id)
            payment.access_token = access_token

            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            link = (
                f"{base_url}/payment/pay?"
                f"reference={payment.ref}&"
                f"amount={payment.amount}&"
                f"access_token={payment.access_token}&"
                f"account_payment_id={payment.id}&"
                f"partner_id={payment.partner_id.id}&"
                f"currency_id={payment.currency_id.id}&"
                f"company_id={payment.company_id.id}"
            )
            line.payment_id = payment.id
            line.payment_link = link

            Shortener = self.env['url.shortener']
            existing = Shortener.search([('long_url', '=', link)], limit=1)
            if existing:
                code = existing.name
            else:
                new = Shortener.create_short_url(link)
                code = new.name
            line.short_link = f"{base_url}/spay/{code}"

    @api.constrains('description', 'payment_date', 'amount')
    def _check_paid_not_edit(self):
        """
        Prevent modification of any installment that has already been paid.
        """
        for rec in self:
            # only compare against the original record in DB
            if rec.is_paid and rec._origin.id:
                origin = self.env['payment.lines'].browse(rec._origin.id)
                if (
                        rec.description != origin.description or
                        rec.payment_date != origin.payment_date or
                        float_compare(rec.amount, origin.amount, precision_digits=2) != 0
                ):
                    raise UserError(_("⚠️ Cannot modify an installment that has been paid."))


    @api.constrains('payment_date')
    def _constrain_unique_payment_date(self):
        for rec in self:
            if not rec.investment_id or not rec.payment_date:
                continue
            domain = [
                ('investment_id', '=', rec.investment_id.id),
                ('payment_date', '=', rec.payment_date),
                ('id', '!=', rec.id),
            ]
            if self.search(domain, limit=1):
                raise ValidationError(
                    _("⚠️ لا يمكنك تكرار نفس تاريخ الدفع (%s).") % rec.payment_date
                )

    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        required=True,
        default=lambda self: self.env.company.currency_id,
    )
    invoice_id = fields.Many2one('account.move', string='Linked Invoice')  # تمّت إعادة التسمية



    def action_invoice_and_register_payment(self):
        self.ensure_one()
        partner = self.investment_id.partner_company_id
        return {
            'type': 'ir.actions.act_window',
            'name': _('Payment'),
            'res_model': 'account.payment',
            'view_mode': 'form',
            'view_id': self.env.ref('account.view_account_payment_form').id,
            'target': 'current',  # أو 'new' لو عايزة تفتحيه في popup
            'context': {
                'default_partner_id': partner.id,
                'default_amount': self.amount,
                'default_payment_type': 'inbound',  # لو دفع وارد
                'default_payment_method_id': self.env.ref('account.account_payment_method_manual_in').id,
                'default_date': fields.Date.context_today(self),
                'default_memo': f"Investment {self.investment_id.id} / Line {self.id}",
                'default_currency_id': self.currency_id.id,
                'default_journal_id': self.env['account.journal'].search([
                    ('type', '=', 'bank'),
                    ('company_id', '=', self.env.company.id)
                ], limit=1).id,
            },
        }

    def write(self, vals):
        """
        Prevent any update on paid installments.
        """
        for rec in self:
            if rec.is_paid:
                raise UserError(_("⚠️ Cannot modify an installment that has been paid."))
        return super().write(vals)


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    investment_id = fields.Many2one(
        'investment.record',
        string='Investment',
        ondelete='set null',
        index=True,
    )

    def action_post(self):
        res = super().action_post()
        active_model = self.env.context.get('active_model')
        active_ids = self.env.context.get('active_ids') or []
        if active_model == 'payment.lines' and active_ids:
            lines = self.env['payment.lines'].browse(active_ids)
            lines.write({
                'is_paid': True,
                'payment_id': self.id,
            })
        return res
    # def action_post(self):
    #     res = super().action_post()
    #     # اقرأي من الـ context السطر الفعّال
    #     active_model = self.env.context.get('active_model')
    #     active_ids = self.env.context.get('active_ids')
    #     if active_model == 'payment.lines' and active_ids:
    #         lines = self.env['payment.lines'].browse(active_ids)
    #         for line in lines:
    #             line.payment_id = self.id
    #     return res


    @api.model
    def create(self, vals):
        payment = super().create(vals)
        active_model = self.env.context.get('active_model')
        active_ids = self.env.context.get('active_ids')
        if active_model == 'payment.lines' and active_ids:
            lines = self.env['payment.lines'].browse(active_ids)
            for line in lines:
                line.payment_id = payment.id
        return payment
# class AccountPaymentRegister(models.TransientModel):
#     _inherit = 'account.payment.register'
#
#     investment_id = fields.Many2one(
#         'investment.record', string='Investment', readonly=True)
#
#     def action_create_payments(self):
#         print(">>> context at create_payments: %s", self.env.context)
#         action = super().action_create_payments()
#
#         # اقرأ المفتاح الجديد payment_line_ids
#         line_ids = self.env.context.get('payment_line_ids') or []
#         if line_ids:
#             print("    payment_line_ids: %s", line_ids)
#             lines = self.env['payment.lines'].browse(line_ids)
#             # استخرج الدفعة المنشأة
#             payment = None
#             if action.get('res_id'):
#                 payment = self.env['account.payment'].browse(action['res_id'])
#             elif action.get('res_ids'):
#                 payment = self.env['account.payment'].browse(action['res_ids'][0])
#             print("    created payment id: %s", payment and payment.id)
#
#             if payment:
#                 print("    marking lines: is_paid, proof, payment_id")
#                 lines.write({
#                     'is_paid': True,
#                     # 'proof': True,
#                     'payment_id': payment.id,
#                 })
#                 print("    lines after write: %s",
#                               lines.read(['is_paid', 'payment_id']))
#
#         print("<<< create_payments returning %s", action)
#         return action