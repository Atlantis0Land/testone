# models/summary_type.py
from odoo import models, fields

class SummaryType(models.Model):
    _name = 'summary.file'
    _description = 'Summary file'

    name = fields.Char(string='Name', required=True)
    investment_id = fields.Many2one(
        'investment.record', string="Investment", ondelete='cascade')
    # attachment = fields.Binary(
    #     string='File',
    # )
    # date = fields.Date(
    #     string='Date',
    #     default=fields.Date.context_today,
    # )
