from odoo import models, fields

class ResState(models.Model):
    _name = "res.state"
    _description = "Investment States"

    name = fields.Char(string="State", required=True)
    code = fields.Char(
        string="State Code",
        required=True,
        help="Short abbreviation for this State ",
        tracking=True,
    )
