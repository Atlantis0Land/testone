from odoo import models, fields, api, _

class InvestmentCancelWizard(models.TransientModel):
    _name = 'investment.cancel.wizard'
    _description = 'Investment Cancel Wizard'

    reason = fields.Text(string="Reason", required=True)
    investment_id = fields.Many2one('investment.record', string="Investment", required=True)

    def action_confirm(self):
        self.ensure_one()
        investment = self.investment_id

        cancel_line = investment.contract_type_id.approver_line_ids.filtered('is_cancel_stage')[:1]
        if cancel_line:
            target_stage = cancel_line.stage_id
        else:
            stages = investment.available_stage_ids.sorted('sequence')
            target_stage = stages and stages[0] or False

        investment.stage_id = target_stage.id if target_stage else False

        msg = _("Operation cancelled by %s.<br/>Stage set to: %s.<br/><b>Reason:</b> %s") % (
            self.env.user.name,
            target_stage.name if target_stage else _("None"),
            self.reason
        )
        investment.message_post(body=msg)

        return {'type': 'ir.actions.act_window_close'}
