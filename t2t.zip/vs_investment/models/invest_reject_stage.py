from odoo import models, fields, api ,_
import re
from odoo.exceptions import UserError
class InvestmentRejectStageWizard(models.TransientModel):
    _name = 'investment.reject.stage.wizard'
    _description = 'Reject Stage Wizard'

    investment_id = fields.Many2one('investment.record', string="Investment", required=True)
    reason        = fields.Text(string="Rejection Reason", required=True)

    def action_confirm_reject(self):
        self.ensure_one()
        inv = self.investment_id

        old_stage_name = inv.stage_id.name

        stages = inv.available_stage_ids.sorted('sequence')
        idx = stages.ids.index(inv.stage_id.id)
        if idx <= 0:
            raise UserError(_("لا توجد مرحلة سابقة للعودة إليها."))

        prev_stage = stages[idx - 1]
        inv.stage_id = prev_stage.id

        inv.message_post(body=_(
            "تم رفض المرحلة <b>%s</b> من قبل %s.<br/>"
            "<b>السبب:</b> %s"
        ) % (old_stage_name, self.env.user.name, self.reason))

        return {'type': 'ir.actions.act_window_close'}
