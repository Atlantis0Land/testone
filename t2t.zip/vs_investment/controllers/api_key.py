# controllers/api_key.py
from odoo import http

class InvestmentSettingsAPI(http.Controller):

    @http.route('/investment/api_key', type='json', auth='public')
    def get_google_api_key(self):
        setting = http.request.env['setting.investment'].sudo().search([], limit=1)
        print("setting",setting)
        return {'key': setting.api_key or ''}
