/** @odoo-module **/

import { Component, onWillStart, useRef, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class InvestmentDashboard extends Component {
    setup() {
        this.rpc = useService("rpc");
        this.action = useService("action");
        this.revenueChartRef = useRef("revenueChart");
        this.revenueLineChartRef = useRef("revenueLineChart");

        this.activeCount = 0;
        this.expiredCount = 0;
        this.signingCount = 0;
        this.stageIds = {
            active: [],
            expired: [],
            signing: [],
        };
        this.propertyStats = {
            rented: 0,
            available: 0,
        };
        this.paymentStats = {
            total: 0,
            overdue: 0,
            expected_month: 0,
            actual_month: 0,
            total_annual: 0,
        };
        this.monthlyRevenue = [];

        this.openFilteredList = (stageType) => {
            const ids = this.stageIds[stageType];
            if (!ids || !ids.length) return;
            this.action.doAction({
                type: "ir.actions.act_window",
                name: `${stageType.charAt(0).toUpperCase() + stageType.slice(1)} Contracts`,
                res_model: "investment.record",
                view_mode: "tree,form",
                domain: [['stage_id', 'in', ids]],
                views: [[false, "list"], [false, "form"]],
            });
        };

        this.openPropertyList = (type) => {
            const domain = type === 'rented' ? [['is_rented', '=', true]] : [['is_rented', '=', false]];
            this.action.doAction({
                type: 'ir.actions.act_window',
                name: type === 'rented' ? 'Rented Properties' : 'Available Properties',
                res_model: 'investment.property',
                view_mode: 'tree,form',
                domain: domain,
                views: [[false, 'list'], [false, 'form']],
                target: 'current',
            });
        };

        this.openPaymentList = (type) => {
            let domain = [];
            if (type === 'overdue') {
                domain = [['payment_date', '<', moment().format('YYYY-MM-DD')], ['is_paid', '=', false]];
            } else if (type === 'expected') {
                domain = [['is_paid', '=', false], ['payment_date', '>=', moment().startOf('month').format('YYYY-MM-DD')]];
            } else if (type === 'actual') {
                domain = [['is_paid', '=', true], ['payment_date', '>=', moment().startOf('month').format('YYYY-MM-DD')]];
            } else if (type === 'total_annual') {
                domain = [['is_paid', '=', true], ['payment_date', '>=', moment().startOf('year').format('YYYY-MM-DD')]];
            }

            const nameMap = {
                overdue: 'Overdue Payments',
                expected: 'Expected Payments',
                actual: 'Actual Payments',
                total_annual: 'Annual Payments',
                total: 'All Payments',
            };

            this.action.doAction({
                type: 'ir.actions.act_window',
                name: nameMap[type] || 'Payments',
                res_model: 'payment.lines',
                view_mode: 'tree,form',
                domain: domain,
                views: [[false, 'list'], [false, 'form']],
                target: 'current',
            });
        };

        // 🟡 Fetch data before rendering
        onWillStart(async () => {
            const [contractStats, propertyStats, paymentStats, monthlyRevenue] = await Promise.all([
                this.rpc('/web/dataset/call_kw', {
                    model: 'investment.record',
                    method: 'get_contract_stage_counts',
                    args: [],
                    kwargs: {},
                }),
                this.rpc('/web/dataset/call_kw', {
                    model: 'investment.property',
                    method: 'get_property_status_counts',
                    args: [],
                    kwargs: {},
                }),
                this.rpc('/web/dataset/call_kw', {
                    model: 'payment.lines',
                    method: 'get_payment_stats',
                    args: [],
                    kwargs: {},
                }),
                this.rpc('/web/dataset/call_kw', {
                    model: 'payment.lines',
                    method: 'get_monthly_revenue',
                    args: [],
                    kwargs: {},
                }),
            ]);

            this.activeCount = contractStats.active;
            this.expiredCount = contractStats.expired;
            this.signingCount = contractStats.signing;
            this.stageIds = contractStats.stage_ids;
            this.propertyStats = propertyStats;
            this.paymentStats = paymentStats;
            this.monthlyRevenue = monthlyRevenue;
        });

        // 🟢 Draw charts
        onMounted(() => {
            setTimeout(() => {
                if (typeof Chart === "undefined") {
                    console.error("❌ Chart.js is not loaded.");
                    return;
                }

                // Bar Chart (Expected vs Actual for this month)
                const barCanvas = this.revenueChartRef.el;
                if (barCanvas) {
                    const barCtx = barCanvas.getContext("2d");
                    new Chart(barCtx, {
                        type: 'bar',
                        data: {
                            labels: ['المتوقع', 'الحقيقي'],
                            datasets: [{
                                label: 'إيرادات هذا الشهر',
                                data: [
                                    this.paymentStats.expected_month || 0,
                                    this.paymentStats.actual_month || 0
                                ],
                                backgroundColor: ['#ba68c8', '#66bb6a'],
                                borderColor: ['#ab47bc', '#43a047'],
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: { beginAtZero: true }
                            }
                        }
                    });
                }

                // Line Chart (Monthly trend from get_monthly_revenue)
                const lineCanvas = this.revenueLineChartRef.el;
                if (lineCanvas && this.monthlyRevenue.length > 0) {
                    const lineCtx = lineCanvas.getContext("2d");
                    const labels = this.monthlyRevenue.map(item => item.month);
                    const values = this.monthlyRevenue.map(item => item.amount);

                    new Chart(lineCtx, {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'الربح ',
                                data: values,
                                borderColor: '#42a5f5',
                                backgroundColor: 'rgba(66, 165, 245, 0.1)',
                                tension: 0.3,
                                fill: true
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: { beginAtZero: true }
                            }
                        }
                    });
                }
            }, 100);
        });
    }
}

InvestmentDashboard.template = "template_vs_investment_dashboard";
registry.category("actions").add("investment_record_dashboard", InvestmentDashboard);
export default InvestmentDashboard;
