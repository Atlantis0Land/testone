/** @odoo-module **/

import { Component, useRef, useState, onWillUnmount } from "@odoo/owl";
import { standardFieldProps } from "@web/views/fields/standard_field_props";
import { registry } from "@web/core/registry";
import { loadJS } from "@web/core/assets";
import { useService } from "@web/core/utils/hooks";

export class GoogleMapPickerWidget extends Component {
    static template = "vs_investment.GoogleMapPickerWidget";
    static props = { ...standardFieldProps };

    setup() {
        this.mapDivRef = useRef("mapDiv");
        this.inputRef = useRef("searchInputMap");
        this.showMap = useState({ value: false });
        this.map = null;
        this.marker = null;
        this.autocomplete = null;
        this.rpc = useService("rpc");

        onWillUnmount(() => this._destroyMap());
    }

    _destroyMap() {
        try {
            if (this.marker) { this.marker.setMap(null); }
            this.marker = null;
            this.map = null;
            this.autocomplete = null;
        } catch (_) {}
    }

    openMap = async () => {
        this.showMap.value = true;

        // حقن CSS احتياطي لو حدّثت الصفحة بدون الأصول
        const id = "gmaps-pac-style";
        if (!document.getElementById(id)) {
            const style = document.createElement("style");
            style.id = id;
            style.textContent = `
              .pac-container{z-index:999999 !important;direction:rtl;text-align:right}
              .pac-item,.pac-item-query{direction:rtl;text-align:right}
            `;
            document.head.appendChild(style);
        }

        // امنع Enter من إرسال أي فورم داخل الديالوج
        setTimeout(() => {
            const el = this.inputRef.el;
            if (el) {
                el.addEventListener("keydown", (e) => {
                    if (e.key === "Enter") e.preventDefault();
                }, { once: true });
            }
        }, 0);

        setTimeout(() => this.initMap(), 150);
    };

    closeMap = () => {
        this.showMap.value = false;
        this._destroyMap();
    };

    async initMap() {
        const response = await this.rpc("/investment/api_key");
        const apiKey = response?.key;
        // لغة/منطقة اختيارية (اجعليها he/IL لو بتكتبي عبري)
        const lang = response?.language || "ar";
        const region = response?.region || "EG";

        if (!apiKey) {
            this.env.services.notification.add(_t("API Key غير موجود! أضيفيه من الإعدادات."), { type: "danger" });
            return;
        }

        if (!window.google || !window.google.maps || !window.google.maps.places) {
            await loadJS(
                `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&language=${lang}&region=${region}`
            );
        }

        // إعدادات بداية (القاهرة)
        let startLat = 30.0444, startLng = 31.2357, zoom = 12, hasValue = false;
        const inputValue = this.props.value || "";
        if (inputValue && inputValue.includes("query=")) {
            const part = inputValue.split("query=")[1];
            const [lat, lng] = part.split(",");
            startLat = parseFloat(lat); startLng = parseFloat(lng); zoom = 15; hasValue = true;
        } else if (inputValue && inputValue.includes(",")) {
            const [lat, lng] = inputValue.split(",");
            startLat = parseFloat(lat); startLng = parseFloat(lng); zoom = 15; hasValue = true;
        }

        // إنشاء الخريطة
        this.map = new window.google.maps.Map(this.mapDivRef.el, {
            center: { lat: startLat, lng: startLng },
            zoom,
            mapTypeControl: false,
        });

        if (hasValue) {
            this.marker = new window.google.maps.Marker({
                map: this.map,
                position: { lat: startLat, lng: startLng },
            });
        }

        // إعداد الـAutocomplete
        const input = this.inputRef.el;
        if (!input) return;

        input.setAttribute("dir", "auto");
        input.setAttribute("autocomplete", "new-location-autocomplete");

        this.autocomplete = new window.google.maps.places.Autocomplete(input, {
            fields: ["geometry", "name", "formatted_address"],
            types: ["geocode", "establishment"],
        });
        this.autocomplete.bindTo("bounds", this.map);

        this.autocomplete.addListener("place_changed", () => {
            const place = this.autocomplete.getPlace();
            if (!place.geometry) {
                alert("من فضلك اختر من القائمة المنسدلة!");
                return;
            }
            const location = place.geometry.location;

            this.map.panTo(location);
            this.map.setZoom(15);

            if (this.marker) this.marker.setMap(null);
            this.marker = new window.google.maps.Marker({
                map: this.map,
                position: { lat: location.lat(), lng: location.lng() },
            });

            const lat = location.lat().toFixed(6);
            const lng = location.lng().toFixed(6);
            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
            this.props.update(mapsUrl);
            this.closeMap();
        });

        // تثبيت دبوس عند الضغط على الخريطة
        this.map.addListener("click", (e) => {
            const lat = e.latLng.lat().toFixed(6);
            const lng = e.latLng.lng().toFixed(6);

            if (this.marker) this.marker.setMap(null);
            this.marker = new window.google.maps.Marker({
                map: this.map,
                position: { lat: parseFloat(lat), lng: parseFloat(lng) },
            });

            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
            this.props.update(mapsUrl);
            this.closeMap();
        });

        // قيمة افتراضية في صندوق البحث
        input.value = hasValue ? `${startLat},${startLng}` : "";
    }
}

GoogleMapPickerWidget.supportedTypes = ["char"];
GoogleMapPickerWidget.displayName = "Google Map Picker";

registry.category("fields").add("google_map_picker_widget", GoogleMapPickerWidget);
