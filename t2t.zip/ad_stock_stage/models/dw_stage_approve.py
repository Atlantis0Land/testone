from odoo import models, fields, api, _
from odoo.exceptions import UserError


class StageStockPicking(models.Model):
    _name = 'stage.stock.picking'
    _description = 'Stock Picking Stage'

    name = fields.Char(string='Stage Name', required=True)
    sequence = fields.Integer(string='Sequence', default=10)

    @api.constrains('sequence')
    def _check_sequence(self):
        for record in self:
            if record.sequence < 0:
                raise ValueError("Sequence must be a non-negative integer.")


class DwStageApprove(models.Model):
    _name = 'dw.stage.approve'
    _description = 'Stage Approval'

    name = fields.Char(string='Approval Name', required=True)
    line_ids = fields.One2many(
        'dw.stage.approve.line', 'approve_id', string='Approval Lines'
    )


class DwStageApproveLine(models.Model):
    _name = 'dw.stage.approve.line'
    _description = 'Stage Approval Line'

    approve_id = fields.Many2one(
        'dw.stage.approve', string='Stage Approval', required=True, ondelete='cascade'
    )
    stage_id = fields.Many2one(
        'stage.stock.picking', string='Stage', required=True
    )
    prover_ids = fields.Many2many(
        'res.users', string='Approvers'
    )

    def unlink(self):
        """Prevent deletion of approval lines that are used by any stock.picking.

        We search for any stock.picking that has this approval line in its
        `stage_ids` many2many. If found, raise a UserError and list the
        affected pickings so the user can take corrective action first.
        """
        if not self:
            return super(DwStageApproveLine, self).unlink()

        StockPicking = self.env['stock.picking']
        # Find pickings that reference any of these lines via the stage_ids m2m
        pickings = StockPicking.search([('stage_ids', 'in', self.ids)])
        if pickings:
            names = ', '.join(pickings.mapped('name'))
            raise UserError(_("Cannot delete approval line(s) because they are used in stock pickings: %s") % names)

        return super(DwStageApproveLine, self).unlink()


class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    stage_approve_id = fields.Many2one(
        'dw.stage.approve', string='Stage Approval'
    )



