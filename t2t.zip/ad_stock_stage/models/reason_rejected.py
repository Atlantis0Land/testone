from odoo import models, fields, api


class ReasonRejected(models.Model):
    _name = 'dw.reason.rejected'

    rejection_reason = fields.Text(string='Rejection Reason', required=True)
    user_id = fields.Many2one('res.users', string='User', required=True, default=lambda self: self.env.uid)

    picking_id = fields.Many2one('stock.picking', string='Picking', required=True, ondelete='cascade')
    date = fields.Datetime(string='Date', default=fields.Datetime.now, required=True)
    stage_id = fields.Many2one('stage.stock.picking', string='Stage', required=True)