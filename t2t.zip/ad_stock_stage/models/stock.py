from email.policy import default

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    approval_stage_id = fields.Many2one(
        'dw.stage.approve',
        string='Approval Stage',
        related='picking_type_id.stage_approve_id',
    )
    stage_id = fields.Many2one(
        'stage.stock.picking', string='Stage', copy=False,
    )
    stage_ids = fields.Many2many('dw.stage.approve.line', string="Stages", compute='_compute_available_stages')

    show_accept_button = fields.Boolean(string="Show Accept Button", compute="_compute_button_visibility")
    show_reject_button = fields.Boolean(string="Show Reject Button", compute="_compute_button_visibility")
    show_rest_buttons = fields.Boolean(string="Show Reject Button", compute="_compute_button_visibility")

    accept_final_stage = fields.Boolean(default=False, string="Accept Final Stage")

    reason_rejected_ids = fields.One2many('dw.reason.rejected', 'picking_id', string='Rejection Reasons')

    @api.depends('stage_id', 'stage_ids')
    def _compute_button_visibility(self):
        for record in self:
            print(f"Debug: Stage IDs: {record.stage_ids}")

            # If no stages are defined, hide the buttons
            if not record.stage_ids:
                record.show_accept_button = False
                record.show_reject_button = False
                record.show_rest_buttons = True
                print("Debug: No stages defined, hiding buttons")
                continue

            # Check if the user has permission
            has_permission = record.user_has_permission()
            print(f"Debug: Has permission: {has_permission}")

            # Check if the current stage is the first or last stage in the list
            first_stage = record.stage_ids[0].stage_id
            last_stage = record.stage_ids[-1].stage_id
            print(f"Debug: First stage: {first_stage}, Last stage: {last_stage}")

            # Set button visibility
            record.show_accept_button = has_permission and record.stage_id != last_stage
            record.show_reject_button = has_permission and record.stage_id != first_stage
            record.show_rest_buttons =  not record.accept_final_stage

    @api.depends('picking_type_id')
    def _compute_available_stages(self):
        for rec in self:
            print(
                f"Debug: Entered _compute_available_stages, Picking Type: {rec.picking_type_id}, Approval Stage: {rec.approval_stage_id}")

            if rec.picking_type_id and rec.approval_stage_id:
                approver_lines = rec.approval_stage_id.line_ids.sorted('id')
                print(f"Debug: Approver lines: {approver_lines}")
                stage_ids = [line.stage_id.id for line in approver_lines if line.stage_id]
                rec.stage_ids = self.env['dw.stage.approve.line'].browse(stage_ids)
                print(f"Debug: Stage IDs set: {rec.stage_ids}")

                # Set the first stage as the current stage when picking type changes
                if rec.stage_ids:
                    if not rec.stage_id:  # Ensure we only set the first stage when stage_id is not yet set
                        rec.stage_id = rec.stage_ids[0].stage_id
                        print(f"Debug: First stage set as current: {rec.stage_id}")

            else:
                rec.stage_ids = [(5, 0, 0)]  # Clear stage_ids
                print("Debug: No approval stage or picking type, clearing stage_ids")

    def accept_stage(self):
        """ Move to the next stage in the sequence. """
        if not self.stage_ids:
            return

        sorted_stages = self.stage_ids.sorted('id')
        print(f"Debug: Sorted stages by ID: {sorted_stages}")

        current_stage_index = -1
        for index, line in enumerate(sorted_stages):
            if line.stage_id == self.stage_id:
                current_stage_index = index
                break

        if current_stage_index == -1:
            return

        last_stage = self.stage_id == self.stage_ids[-1].stage_id
        print("Debug: Current stage index:", current_stage_index)

        if current_stage_index < len(sorted_stages) - 1:
            next_stage = sorted_stages[current_stage_index + 1]
            self._schedule_stage_activities()
            self.stage_id = next_stage.stage_id

        else:
            if last_stage :
                self.accept_final_stage = True


    def _schedule_stage_activities(self):
        self.ensure_one()
        deadline = fields.Date.context_today(self)
        targets = self._approval_targets()
        for u in targets:
            self.activity_schedule(
                'mail.mail_activity_data_todo',
                user_id=u.id,
                summary=_('متابعة طلب %s') % self.name ,
                note=_('يرجى مراجعة الطلب %s') % self.name ,
                date_deadline=deadline,
            )


    def _approval_targets(self):
        self.ensure_one()
        if not self.stage_id or not self.approval_stage_id:
            return []
        approval_line = self.env['dw.stage.approve.line'].search([
            ('stage_id', '=', self.stage_id.id),
            ('approve_id', '=', self.approval_stage_id.id)
        ], limit=1)
        if approval_line:
            return approval_line.prover_ids
        return []



    def action_reject_stage(self):
        """ Reject the stage and revert to the previous stage. """

        if not self.stage_ids:
            print("Debug: No stages available, returning from reject_stage")
            return

        return {
            'type': 'ir.actions.act_window',
            'name': 'Reject Stage',
            'res_model': 'dw.stock.picking.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_picking_id': self.id,
                'default_stage_id': self.stage_id.id,
            }
        }

    def user_has_permission(self):
        """ Check if the current user has permission to approve the current stage. """
        if not self.stage_id:
            print("Debug: No current stage, returning False for permission check")
            return False

        # Find the related DwStageApproveLine record
        approval_line = self.env['dw.stage.approve.line'].search([
            ('stage_id', '=', self.stage_id.id),
            ('approve_id', '=', self.approval_stage_id.id)
        ], limit=1)

        if approval_line:
            permission = self.env.user in approval_line.prover_ids
            print(f"Debug: User has permission: {permission}")
            return permission

        print("Debug: No approval line found, returning False for permission check")
        return False
