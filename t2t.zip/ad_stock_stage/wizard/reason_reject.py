from odoo import models, fields
from odoo.exceptions import UserError


class RejectpickingWizard(models.TransientModel):
    _name = 'dw.stock.picking.reject.wizard'

    picking_id = fields.Many2one('stock.picking', required=True, string="picking")
    reason = fields.Text(string="Reason", required=True)
    stage_id = fields.Many2one('stage.stock.picking', string='Stage', required=True,
                               help="Stage to which the picking will be moved after rejection.")

    def action_submit_rejection(self):
        self.ensure_one()
        picking = self.picking_id

        if not picking.stage_id or not picking.stage_ids:
            raise UserError("Cannot determine previous stage.")


        sorted_stages = picking.stage_ids.sorted('id')
        print(f"Debug: Sorted stages: {sorted_stages}")

        # Find the current stage's index manually
        current_stage_index = -1
        for index, line in enumerate(sorted_stages):
            if line.stage_id == picking.stage_id:
                current_stage_index = index
                print(f"Debug: Current stage found at index {index}: {line.stage_id.name}")
                break

        if current_stage_index == -1:
            print("Debug: Current stage not found in the sorted stages.")
            return

        # If there is a previous stage, move to it
        if current_stage_index > 0:
            prev_stage = sorted_stages[current_stage_index - 1]
            picking.stage_id = prev_stage.stage_id

        # Post reason to chatter
        message = f"picking rejected by {self.env.user.name} with reason:\n{self.reason}"
        picking.message_post(body=message)

        # ✅ log into approval lines
        picking.reason_rejected_ids.create({
            'picking_id': picking.id,
            'user_id': self.env.user.id,
            'stage_id': self.stage_id.id,
            'date': fields.Datetime.now(),
            'rejection_reason': self.reason
        })

        # Move to previous stage
        print("picking ========>", picking)
        print("current stage:", picking.stage_id)

        # Now assign the previous stage's stage_id to the picking

        return {'type': 'ir.actions.act_window_close'}


