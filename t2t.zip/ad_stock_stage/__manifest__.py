# -*- coding: utf-8 -*-
{
    'name': "Stock Stage Approval",

    'summary': 'This module contains handling of Stock Stage Approval and Reject',

    'description': """
        This module contains handling of Stock Stage Approval and Reject
    """,

    "author": "Sysgates _ Ahmed Eldweek",
    "license": "LGPL-3",
    "website": "https://www.sysgates.com",
    # 'category': 'Accounting & Finance',
    'category': 'Uncategorized',
    'version': '16.0',


    # any module necessary for this one to work correctly
    'depends': ['base', 'stock'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/dw_stage_approve_views.xml',
        'views/stock.xml',
        'wizard/reason_reject.xml',
    ],

    'installable': True,
    'application': False,
    'auto_install': False,

}
