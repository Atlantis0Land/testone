/** @odoo-module **/

import { Component, onWillStart, useRef, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class ServiceDashboard extends Component {
    setup() {
        this.rpc = useService("rpc");
        this.action = useService("action");
        this.chartRef = useRef("svcChart");

        this.cards = { new: 0, ongoing: 0, near_end: 0 };
        this.labels = [];
        this.typeIds = [];
        this.totals = [];
        this.colors = [];

        onWillStart(async () => {
            const data = await this.rpc('/web/dataset/call_kw', {
                model: 'service.request',
                method: 'get_service_dashboard_data',
                args: [],
                kwargs: {},
            });
            this.cards = data.cards || this.cards;
            const ch = data.chart || {};
            this.labels = ch.labels || [];
            this.typeIds = ch.type_ids || [];
            this.totals = ch.totals || [];
            this.colors = ch.colors || [];
        });

        onMounted(() => {
            if (typeof Chart === "undefined") {
                console.error("Chart.js not loaded");
                return;
            }

            const palette = [
                "#4aa3ff", "#ffd24d", "#ff6b81", "#00c49f", "#8884d8",
                "#ffa600", "#ff9f40", "#36a2eb", "#9966ff", "#ff6384",
            ];
            const barColors = (this.colors && this.colors.length)
                ? this.colors
                : this.labels.map((_, i) => palette[i % palette.length]);

            const ctx = this.chartRef.el.getContext("2d");
            const self = this;

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: this.labels,
                    datasets: [
                        {
                            label: 'All Services',
                            data: this.totals,
                            backgroundColor: barColors,
                            borderColor: barColors,
                            borderWidth: 1,
                        },
                    ],
                },
                options: {
                    responsive: true,
                    scales: { y: { beginAtZero: true } },
                    onClick(evt, elements) {
                        if (!elements.length) return;
                        const idx = elements[0].index;
                        self.openByType(self.typeIds[idx], self.labels[idx]);
                    },
                },
            });
        });
    }

    openNew()     { this._openList([['stage_id.is_new', '=', true]], "New Services"); }
    openOngoing() { this._openList([['stage_id.is_ongoing', '=', true]], "Ongoing Services"); }
    openNearEnd() { this._openList([['stage_id.is_near_end', '=', true]], "Near to End Services"); }

    openByType(typeId, title) {
        this.action.doAction({
            type: "ir.actions.act_window",
            name: `Services · ${title}`,
            res_model: "service.request",
            view_mode: "tree,form",
            views: [[false, "tree"], [false, "form"]],
            domain: [['service_type_id', '=', typeId]],
            target: "current",
        });
    }

    _openList(domain, title) {
        this.action.doAction({
            type: "ir.actions.act_window",
            name: title,
            res_model: "service.request",
            view_mode: "tree,form",
            views: [[false, "tree"], [false, "form"]],
            domain,
            target: "current",
        });
    }
}

ServiceDashboard.template = "multi_service.ServiceDashboardTemplate";
registry.category("actions").add("multi_service_dashboard", ServiceDashboard);
export default ServiceDashboard;
