from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import re


class ResPartner(models.Model):
    _inherit = "res.partner"

    fcm_token = fields.Char(string='Mobile FCM Token')
