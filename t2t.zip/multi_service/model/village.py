import re
import logging
from odoo import api, fields, models, tools
from odoo.osv import expression

_logger = logging.getLogger(__name__)



class StateVillage(models.Model):
    _description = "State "
    _name = 'res.state.village'
    _order = 'code'

    state_id = fields.Many2one('res.country.state', string='State' ,domain="[('country_id.code', '=', 'OM')]")
    name = fields.Char(string='Village Name', required=True,)
    code = fields.Char(string='Village Code', help='The village code.', required=True)

    _sql_constraints = [
        ('name_code_uniq', 'unique(code)', 'The code of the village must be unique by state !')
    ]