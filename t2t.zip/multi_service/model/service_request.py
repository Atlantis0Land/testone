# -*- coding: utf-8 -*-
from datetime import datetime

from odoo.exceptions import UserError, AccessError
from collections import defaultdict
from odoo import models, fields, api, Command, _, exceptions
import re
from odoo.exceptions import ValidationError
from odoo.addons.v16_ismart_sms.models.sms_sms import send_imsart_sms
from lxml import etree
from datetime import timedelta
from odoo.addons.payment import utils as payment_utils
import secrets
import random






CATEGORY_SELECTION = [
    ('required', 'Required'),
    ('optional', 'Optional'),
    ('no', 'None')]



DEFAULT_COUNTRY_CODE = '968'

def format_mobile_number(mobile, country_code=DEFAULT_COUNTRY_CODE):
    print(f"[DEBUG] Raw input mobile: {mobile}")
    mobile = str(mobile).strip()[-8:]
    formatted = f"{country_code}{mobile}"
    print(f"[DEBUG] Formatted mobile number: {formatted}")
    return formatted

class ServiceRequest(models.Model):
    _name = 'service.request'
    _description = 'service Request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name'
    _mail_post_access = 'read'

    _check_company_auto = True


    name = fields.Char(string="service Subject", tracking=True)
    config_id = fields.Many2one('service.category.config', string="Configuration", related='service_type_id.config_id')
    config_image = fields.Binary(related='config_id.image')
    payment_state = fields.Selection([
        ('not_paid', 'Not Paid'),
        ('in_payment', 'In Payment'),
        ('paid', 'Paid')
    ], string="Payment Status", default='not_paid', tracking=True)
    # assigned_to = fields.Many2one('hr.employee', string='Assigned To',domain=lambda self: [('parent_id.user_id', '=', self.env.uid)],)
    assigned_to_ids = fields.Many2many(
        'hr.employee',
        string='Assigned To',
        domain="[('parent_id.user_id', '=', current_user_id)]"
    )

    current_user_id = fields.Integer(
        compute='_compute_current_user_id',
        store=False
    )
    company_id = fields.Many2one(
        string='Company', related='config_id.company_id',
        store=True, readonly=True, index=True)
    invoice_id = fields.Many2one('account.move', string="Customer Invoice")

    date = fields.Datetime(string="Date", default=lambda self: fields.Datetime.now())
    date_start = fields.Datetime(string="Date start")
    date_end = fields.Datetime(string="Date end")
    quantity = fields.Float(string="Quantity")
    location = fields.Char(string="Location")
    latitude = fields.Float(string="Latitude")
    longitude = fields.Float(string="Longitude")
    date_confirmed = fields.Datetime(string="Date Confirmed")
    partner_id = fields.Many2one('res.partner', string="Contact", check_company=True)
    reference = fields.Char(string="Sequence")
    amount = fields.Float(string="Amount")
    reason = fields.Html(string="Description")
    request_owner_id = fields.Many2one('res.users', string="Request Owner",
                                       default=lambda self: self.env.user,
                                       check_company=True, domain="[('company_ids', 'in', company_id)]")
    payment_link = fields.Char(string="Payment Link", compute="_compute_payment_link", store=False)
    has_access_to_request = fields.Boolean(string="Has Access To Request", compute="_compute_has_access_to_request")
    change_request_owner = fields.Boolean(string='Can Change Request Owner', compute='_compute_has_access_to_request')
    attachment_number = fields.Integer('Number of Attachments', compute='_compute_attachment_number')
    has_period = fields.Selection(related="config_id.has_period")
    has_description = fields.Selection(related="config_id.has_description")
    has_village_name = fields.Selection(related="config_id.has_village_name")
    has_phone = fields.Selection(related="config_id.has_phone")
    has_map = fields.Selection(related="config_id.has_map")
    has_from_date = fields.Selection(related="config_id.has_from_date")
    has_national_id = fields.Selection(related="config_id.has_national_id")
    has_reference = fields.Selection(related="config_id.has_reference")
    has_government_id = fields.Selection(related="config_id.has_government_id")
    has_state_id = fields.Selection(related="config_id.has_state_id")
    has_add_response = fields.Selection(related="config_id.has_add_response")
    has_create_payment = fields.Selection(related="config_id.has_create_payment")
    requirer_document = fields.Selection(related="config_id.requirer_document")
    service_minimum = fields.Integer(related="config_id.service_minimum")
    category_id = fields.Many2one('service.category', compute='_compute_main_category', store=True, readonly=False)
    sub_category_id = fields.Many2one('sub.service.category', domain="[('category_id', '=',  category_id)]")
    service_type_id = fields.Many2one('service.type', domain="[('sub_category_id', '=',  sub_category_id)]",required=True)
    service_type = fields.Selection(related="config_id.service_type")
    approver_sequence = fields.Boolean(related="config_id.approver_sequence")
    automated_sequence = fields.Boolean(related="config_id.automated_sequence")
    attachment_ids = fields.One2many('attachment.document.request', 'request_id', string="Attachments", copy=False)
    stage_id = fields.Many2one('service.stage', compute='_compute_stage_id_to_approve', store=True, readonly=False)
    stage_ids = fields.Many2many('service.stage', compute="_compute_stage_ids")
    can_approve = fields.Boolean(compute='_compute_can_approve')
    can_previous_stage = fields.Boolean(compute='_compute_can_previous_stage')
    national_id = fields.Char(string="ID", readonly=False)
    phone = fields.Char(compute="_compute_phone", readonly=False, store=True)
    government_id = fields.Many2one('res.country.government')
    country_id = fields.Many2one('res.country', related='government_id.country_id')
    state_id = fields.Many2one('res.country.state', domain="[('government_id', '=', government_id), ('country_id', '=', country_id)]")
    code = fields.Char(string="Code", related='service_type_id.code')
    test_bin = fields.Binary()
    terms_condtions_t = fields.Html(related="config_id.has_terms_condtions_t_1", string="Terms And Condtions")
    has_terms_condtions_t = fields.Selection(related="config_id.has_terms_condtions_t")
    response_line_ids = fields.One2many(
        'service.request.response.line',
        'request_id',
        string="Responses"
    )
    terms_condtions_b = fields.Boolean(related="config_id.has_terms_condtions_b_1", string="Has Terms And Condtions")
    has_terms_condtions_b = fields.Selection(related="config_id.has_terms_condtions_b")
    stage_date = fields.Date()
    village_name_id = fields.Many2one('res.state.village', string="Village")
    payment_id = fields.Many2one("account.payment", string="Payment", readonly=True)
    from_date = fields.Date(string="From Date")
    to_date = fields.Date(string="To Date")
    can_edit_request = fields.Boolean(compute='_compute_can_edit_request')



    @api.model
    def _read_group_request_status(self, stages, domain, order):
        request_status_list = dict(self._fields['request_status'].selection).keys()
        return request_status_list


    @api.depends_context('uid')
    def _compute_current_user_id(self):
        for rec in self:
            rec.current_user_id = self.env.uid

    def action_open_add_response_wizard(self):
        self.ensure_one()
        return {
            'name': 'Add Response',
            'type': 'ir.actions.act_window',
            'res_model': 'add.response.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
            }
        }
    def action_open_add_response_wizard_button(self):
        self.ensure_one()
        return {
            'name': 'Add Response',
            'type': 'ir.actions.act_window',
            'res_model': 'add.response.wizard.button',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
            }
        }

    @api.model
    def get_service_dashboard_data(self):
        SR = self.env['service.request'].with_context(active_test=False)

        cards = {
            "new": SR.search_count([('stage_id.is_new', '=', True)]),
            "ongoing": SR.search_count([('stage_id.is_ongoing', '=', True)]),
            "near_end": SR.search_count([('stage_id.is_near_end', '=', True)]),
        }

        groups = SR.read_group(
            domain=[('service_type_id', '!=', False)],
            fields=['id:count', 'service_type_id'],
            groupby=['service_type_id'],
            lazy=False,
        )

        type_map = {g['service_type_id'][0]: g['service_type_id'][1] for g in groups if g.get('service_type_id')}
        type_ids_sorted = sorted(type_map.keys(), key=lambda tid: (type_map[tid] or "").lower())

        labels = [type_map[tid] for tid in type_ids_sorted]

        def _count_from_group(g):
            return g.get('id_count') or g.get('__count') or 0

        counts_dict = {g['service_type_id'][0]: _count_from_group(g) for g in groups if g.get('service_type_id')}
        totals = [counts_dict.get(tid, 0) for tid in type_ids_sorted]

        palette = [
            "#4aa3ff", "#ffd24d", "#ff6b81", "#00c49f", "#8884d8", "#ffa600",
            "#ff9f40", "#36a2eb", "#9966ff", "#ff6384"
        ]
        colors = [palette[i % len(palette)] for i in range(len(labels))]

        return {
            "cards": cards,
            "chart": {
                "labels": labels,
                "type_ids": type_ids_sorted,
                "totals": totals,
                "colors": colors,
            }
        }


    def check_stage_date(self):
        from datetime import timedelta
        all_requests = self.search([])
        today = fields.Date.today()
        activity_todo_type = self.env.ref('mail.mail_activity_data_todo')

        print(">> Entering check_stage_date()")
        print("   Today is:", today)
        print("   Activity type (To Do) ID:", activity_todo_type.id)

        for rec in all_requests:
            print(" -- Processing Service Request:", rec.id, rec.name)
            print("    Stage:", rec.stage_id, "| last_update(stage_date):", rec.stage_date)

            config = rec.service_type_id and rec.service_type_id.config_id
            last_update = rec.stage_date
            if not last_update or not config:
                print("    >> Skipping because no stage_date or no config")
                continue

            approvers_for_stage = config.approver_ids.filtered(
                lambda a: a.stage_id.id == rec.stage_id.id
            )
            print("    Found approver lines count:", len(approvers_for_stage))
            if not approvers_for_stage:
                print("    >> No approver lines for this stage")
                continue

            days_limit = approvers_for_stage[0].num_of_days
            print("    days_limit (Number Of Days):", days_limit)
            limit_date = last_update + timedelta(days=days_limit)
            print("    limit_date:", limit_date)

            if today > limit_date:
                print("    >> Today passed limit_date, will create activities")
                users = approvers_for_stage.mapped('user_id')
                print("    Users to notify:", users.mapped('login'))

                for user in users:
                    if not user.partner_id:
                        print(f"      - Skipping user {user.login}: no partner_id")
                        continue

                    deadline_date = fields.Date.context_today(self)
                    print(f"      - Creating activity for user: {user.login} | deadline: {deadline_date}")

                    rec.activity_schedule(
                        'mail.mail_activity_data_todo',
                        user_id=user.id,
                        summary=_('متابعة طلب %s') % rec.reference,
                        note=_('يرجى مراجعة الطلب رقم %s.') % rec.reference,
                        date_deadline=deadline_date,
                    )
                    print(f"      => Activity created for user: {user.login}")
            else:
                print("    >> Today has NOT passed limit_date, no actions for this record")

        print(">> Exiting check_stage_date()")
    def _compute_payment_link(self):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        for rec in self:
            if rec.invoice_id and rec.invoice_id.access_token:
                reference = rec.invoice_id.name
                amount = rec.invoice_id.amount_total
                token = rec.invoice_id.access_token
                rec.payment_link = f"{base_url}/payment/pay?reference={reference}&amount={amount}&access_token={token}"
                print("link",rec.payment_link)
            else:
                rec.payment_link = ""

    def action_create_payment_link(self):
        for rec in self:
            if rec.payment_id:
                raise UserError(_("Payment already created for this request."))

            if not rec.partner_id:
                raise UserError(_("No partner found on the request."))

            if not rec.amount or rec.amount <= 0:
                raise UserError(_("Amount must be set before creating a payment."))

            payment = self.env['account.payment'].create({
                'payment_type': 'inbound',
                'partner_type': 'customer',
                'partner_id': rec.partner_id.id,
                'amount': rec.amount,
                'payment_method_id': self.env.ref('account.account_payment_method_manual_in').id,
                'journal_id': self.env['account.journal'].search([('type', '=', 'bank')], limit=1).id,
                'date': fields.Date.context_today(self),
                'ref': f"Service Request {rec.name}",
            })
            rec.payment_state = 'in_payment'

            # payment.action_post()
            payment.access_token = payment_utils.generate_access_token(
                payment.partner_id.id, payment.amount, payment.currency_id.id
            )


            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            link = f"{base_url}/payment/pay?" \
                   f"reference={payment.ref}" \
                   f"&amount={payment.amount}" \
                   f"&access_token={payment.access_token}" \
                   f"&account_payment_id={payment.id}" \
                   f"&partner_id={payment.partner_id.id}" \
                   f"&currency_id={payment.currency_id.id}" \
                   f"&company_id={payment.company_id.id}"
            print("link test",link)

            rec.payment_link = link
            rec.payment_id = payment.id
            Shortener = self.env['url.shortener']
            existing = Shortener.search([('long_url', '=', link)], limit=1)
            if existing:
                code = existing.name
            else:
                new = Shortener.create_short_url(link)
                code = new.name
            short_link = f"{base_url}/s/{code}"
            print(short_link, "hhh")
            # ✅ 2. تجهيز بيانات واتساب
            raw_phone = rec.partner_id.phone or rec.phone
            if not raw_phone:
                raise UserError(_("No phone number found on the request."))

            phone = f"+{format_mobile_number(raw_phone)}"

            template_id = self.env['ir.config_parameter'].sudo().get_param("multi_service.payment_template_id")
            if not template_id:
                raise UserError(_("No WhatsApp payment template ID configured."))

            response = self.env['vs.otp.gateway'].send_payment_custom_whatsapp(
                number=phone,
                template_id=template_id,
                link=short_link
            )

            if not response.get('sent'):
                raise UserError(_("WhatsApp sending failed: %s") % response.get('text'))

            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Payment Link Created'),
                    'message': short_link,
                    'type': 'success',
                    'sticky': False,
                }
            }


    def action_open_payment(self):
        self.ensure_one()
        if not self.payment_id:
            raise UserError(_("No payment linked to this request."))

        return {
            'type': 'ir.actions.act_window',
            'name': 'Payment',
            'res_model': 'account.payment',
            'view_mode': 'form',
            'res_id': self.payment_id.id,
            'target': 'current',
        }


    @api.model_create_multi
    def create(self, vals_list):
        print("🛠️ Starting create method with vals_list:", vals_list)

        for vals in vals_list:
            print("➡️ Processing vals:", vals)

            config = vals.get('config_id') and self.env['service.category.config'].browse(vals['config_id'])
            print("🔧 Config found:", config)

            if config and config.automated_sequence:
                vals['name'] = config.sequence_id.next_by_id()
                print("🔢 Generated name using sequence:", vals['name'])

            today = datetime.today()
            date_str = f"{today.year % 100:02d}{today.month:02d}{today.day:02d}"
            print("📅 Formatted date:", date_str)

            service_type = vals.get('service_type_id') and self.env['service.type'].browse(vals['service_type_id'])
            print("🔍 Service type:", service_type)

            code_value = service_type.code if service_type else ''
            print("🏷️ Code value from service type:", code_value)

            seq = self.env['ir.sequence'].next_by_code('service.request')
            print("🔁 Generated sequence:", seq)

            vals["reference"] = f"{code_value}-{date_str}-{seq}"
            print("📌 Final reference:", vals["reference"])

            if vals.get('stage_id'):
                vals['stage_date'] = fields.Date.today()
                print("📆 Assigned stage_date as today because stage_id provided:", vals['stage_date'])

        records = super(ServiceRequest, self).create(vals_list)
        print("✅ Records created:", records)

        sms_gateway = self.env['sms.gateway.config'].sudo().search([], limit=1)
        print("📡 SMS Gateway config:", sms_gateway)

        for record in records:
            print("📄 Processing record:", record)

            if not record.stage_id and record.stage_ids:
                record.stage_id = record.stage_ids.sorted(key=lambda s: s.sequence)[0]
                record.stage_date = fields.Date.today()
                print("📈 Assigned initial stage and updated stage_date:", record.stage_id, record.stage_date)
            else:
                print("ℹ️ Stage already set or no available stage_ids for record")

            phone = record.partner_id.phone
            print("📱 Partner phone:", phone)

            if phone:
                msg = f"تم استلام طلب الخدمة بنجاح. رقم المرجع: {record.reference}"
                response = send_imsart_sms(phone, msg, sms_gateway, 'ar_001')

                print("📨 SMS sent to:", phone)
                print("📩 Message content:", msg)
                print("📬 SMS response:", response)
            allowed_users = record.service_type_id.allowed_user_ids
            todo_type = 'mail.mail_activity_data_todo'
            for user in allowed_users:
                record.activity_schedule(
                    todo_type,
                    user_id=user.id,
                    summary=_('New Service Request: %s') % record.reference,
                    note=_('Please review the new service request.')
                )

            # 2) الجزء الخاص بالـ WhatsApp (يبقى بعد ذلك إذا أردت)
            icp = self.env['ir.config_parameter'].sudo()
            wa_enabled = icp.get_param('multi_service.whatsapp_service_enable') == 'True'
            wa_tmpl_id = icp.get_param('multi_service.whatsapp_service_template_id')
            wa_gateway = self.env['vs.otp.gateway']

            print("🔍 WhatsApp enable flag:", wa_enabled)
            # print("🔍 WhatsApp template ID  :", wa_tmpl_id)

            if wa_enabled :
                for user in allowed_users:
                    employees = self.env['hr.employee'].search([('user_id', '=', user.id)])
                    for emp in employees:
                        phone_emp = emp.work_phone or emp.mobile_phone
                        if not phone_emp:
                            print(f"⚠️ لا يوجد هاتف للموظف {emp.name}")
                            continue

                        number = f"+{format_mobile_number(phone_emp)}"
                        print(f"📲 Sending WhatsApp to {emp.name} at {number} using tmpl {wa_tmpl_id}")

                        res = wa_gateway.send_new_service_created_whatsapp(
                            number=number,
                            service_ref=record.reference,
                        )

                        print("📨 send_new_service_created_whatsapp response:", res)
                        if not res.get('sent'):
                            print(f"❌ فشل إرسال WhatsApp إلى {number}: {res.get('text') or res}")

        return records

    def _build_near_end_payload(self):
        """يرجع (service_code, service_name, phone, citizen_name)."""
        self.ensure_one()

        st = getattr(self, 'service_type_id', False)

        service_code = (
                getattr(self, 'service_code', None)
                or (st and (getattr(st, 'code', None) or getattr(st, 'reference', None)))
                or 'SERVICE_CODE'
        )

        service_name = (
                (st and getattr(st.sudo(), 'name', None))
                or getattr(self, 'name', None)
                or 'اسم الخدمة'
        )

        phone = (
                getattr(self, 'phone', None)
                or (self.partner_id and (self.partner_id.mobile or self.partner_id.phone))
                or 'رقم_الهاتف'
        )

        citizen_name = (
                getattr(self, 'citizen_name', None)
                or (self.partner_id and self.partner_id.name)
                or 'اسم_المواطن'
        )

        return service_code, service_name, phone, citizen_name

    def _trigger_near_end_hook_if_needed(self, previous_stage=None):
        """
        يُستدعى بعد تغيير المرحلة. ينفّذ فقط عند الانتقال لأول مرة إلى ستيج is_near_end=True.
        """
        for rec in self:
            current = rec.stage_id
            prev = previous_stage  # ممكن تبعتي الحقيقي من write لكل rec

            entered_near_end = bool(
                current and current.is_near_end and (
                        not prev or (prev.id != current.id) or not getattr(prev, 'is_near_end', False)
                )
            )
            if not entered_near_end:
                continue

            svc_code, svc_name, phone, citizen_name = rec._build_near_end_payload()
            try:
                print(
                    "Calling survey.internal.service.process_service_request for request %s with: %s, %s, %s, %s",
                    rec.id, svc_code, svc_name, phone, citizen_name
                )
                rec.env['survey.internal.service'].sudo().process_service_request(
                    svc_code, svc_name, phone, citizen_name
                )
            except Exception as e:
                print(
                    "Failed to call process_service_request on request %s: %s",
                    rec.id, e
                )

    # def write(self, vals):
    #     if 'stage_id' in vals:
    #         vals['stage_date'] = fields.Date.today()
    #
    #     stage_before = {
    #         rec.id: rec.stage_id.name
    #         for rec in self
    #     } if 'stage_id' in vals else {}
    #
    #     res = super(ServiceRequest, self).write(vals)
    #
    #     icp = self.env['ir.config_parameter'].sudo()
    #     send_sms_assign = icp.get_param('multi_service.send_sms_on_assign') == 'True'
    #     send_wa_assign = icp.get_param('multi_service.send_whatsapp_on_assign') == 'True'
    #     assign_wa_tmpl_id = icp.get_param('multi_service.assign_whatsapp_template_id')
    #     send_sms_stage = icp.get_param('multi_service.send_sms_on_stage') == 'True'
    #     send_wa_stage = icp.get_param('multi_service.send_whatsapp_on_stage') == 'True'
    #
    #     sms_gateway = self.env['sms.gateway.config'].sudo().search([], limit=1)
    #
    #     activity_to_show = None
    #     for rec in self:
    #         if 'assigned_to_ids' in vals and rec.assigned_to_ids:
    #             todo_type = 'mail.mail_activity_data_todo'
    #             for emp in rec.assigned_to_ids.filtered('user_id'):
    #                 rec.activity_schedule(
    #                     todo_type,
    #                     user_id=emp.user_id.id,
    #                     summary=_('New Service Request Assigned'),
    #                     note=('<p>%s: %s</p>') % (('You have been assigned to request'), rec.name),
    #                 )
    #             first_emp = rec.assigned_to_ids.filtered('user_id')[:1]
    #             if first_emp and not activity_to_show:
    #                 activity_to_show = {
    #                     'type': 'ir.actions.act_window',
    #                     'name': _('Schedule Activity'),
    #                     'res_model': 'mail.activity',
    #                     'view_mode': 'form',
    #                     'view_id': self.env.ref('mail.mail_activity_view_form_popup').id,
    #                     'target': 'new',
    #                     'context': {
    #                         'default_res_model': rec._name,
    #                         'default_res_id': rec.id,
    #                         'default_user_id': first_emp.user_id.id,
    #                         'default_activity_type_id': self.env.ref(todo_type).id,
    #                         'default_date_deadline': fields.Date.context_today(self),
    #                         'default_summary': _('Please follow up on your new assignment'),
    #                     }
    #                 }
    #
    #             if send_wa_assign:
    #                 if not assign_wa_tmpl_id:
    #                     raise UserError(_("لم يُعرّف قالب WhatsApp للإسناد في الإعدادات."))
    #                 for emp in rec.assigned_to_ids:
    #                     raw = emp.work_phone or emp.mobile_phone
    #                     if not raw:
    #                         continue
    #                     number = f"+{format_mobile_number(raw)}"
    #                     wa_resp = self.env['vs.otp.gateway'].send_response_appointment_custom_whatsapp(
    #                         number=number,
    #                         template_id=assign_wa_tmpl_id,
    #                         link=rec.reference,
    #                     )
    #                     if not wa_resp.get('sent'):
    #                         raise UserError(_("فشل إرسال WhatsApp إلى %s: %s") % (number, wa_resp))
    #
    #             if send_sms_assign:
    #                 if not sms_gateway:
    #                     raise UserError(_("لم تُعرّف إعدادات بوابة SMS للإسناد."))
    #                 for emp in rec.assigned_to_ids:
    #                     raw = emp.work_phone or emp.work_mobile
    #                     if not raw:
    #                         continue
    #                     sms_msg = _("تم تعيينك على طلب الخدمة رقم %s") % rec.reference
    #                     print(sms_msg, "message")
    #                     sms_resp = send_imsart_sms(
    #                         mobile_no=raw,
    #                         sms=sms_msg,
    #                         sms_gateway=sms_gateway,
    #                         lang='ar_001',
    #                     )
    #                     sent = sms_resp.get('sent') if isinstance(sms_resp, dict) else bool(sms_resp)
    #                     if not sent:
    #                         raise UserError(_("فشل إرسال SMS إلى %s: %s") % (raw, sms_resp))
    #
    #             if activity_to_show:
    #                 return activity_to_show
    #
    #         if 'stage_id' in vals:
    #             # SMS Notification
    #             if sms_gateway and send_sms_stage:
    #                 old = stage_before.get(rec.id, 'غير معروفة')
    #                 new = rec.stage_id.name
    #                 phone = rec.partner_id.phone or rec.request_owner_id.partner_id.phone
    #                 if phone and old != new:
    #                     msg = (
    #                             _("نود إفادتك بأنه تم التعامل مع الطلب %(ref)s، يرجى التحقق من المنصة لأي تحديثات. شكراً لك.")
    #                             % {'ref': rec.reference}
    #                     )
    #                     send_imsart_sms(phone, msg, sms_gateway, 'ar_001')
    #             # WhatsApp Notification
    #             if rec.stage_id.template_id and send_wa_stage:
    #                 raw = rec.partner_id.phone or rec.phone
    #                 if not raw:
    #                     raise UserError(_("لا يوجد رقم هاتف لإرسال WhatsApp عند تغيير المرحلة."))
    #                 number = f"+{format_mobile_number(raw)}"
    #                 tmpl = rec.stage_id.template_id
    #                 link_tmpl = rec.service_type_id.config_id.evaluation_link_template or ''
    #                 dynamic = link_tmpl.format(id=rec.id, reference=rec.reference) if link_tmpl else ''
    #                 wa_res = self.env['vs.otp.gateway'].send_custom_whatsapp(
    #                     number, tmpl, rec.reference, dynamic
    #                 )
    #                 if not wa_res.get('sent'):
    #                     raise UserError(_("فشل إرسال WhatsApp عند تغيير المرحلة: %s") % wa_res)
    #
    #             try:
    #                 partner = rec.partner_id
    #                 fcm_token = getattr(partner, 'fcm_token', False)
    #                 if fcm_token:
    #                     title = f"تم تغيير حالة الطلب ({rec.reference})"
    #                     body = f"تم نقل طلبك إلى المرحلة: {rec.stage_id.name}"
    #
    #                     notif = self.env['mobile.notification'].sudo().create({
    #                         'name': title,
    #                         'body': body,
    #                         'service_request_id': rec.id,
    #                         'partner_id': partner.id,
    #                         'stage_name': rec.stage_id.name,
    #                     })
    #                     notif.send_push()
    #                     print("تم إرسال إشعار push notification للموبايل")
    #             except Exception as ex:
    #                 print("خطأ في إرسال إشعار الموبايل:", ex)
    #
    #         if 'approver_ids' in vals:
    #             to_resequence = self.filtered_domain([
    #                 ('approver_sequence', '=', True),
    #                 ('request_status', '=', 'pending')
    #             ])
    #             for service in to_resequence:
    #                 if not service.approver_ids.filtered(lambda a: a.status == 'pending'):
    #                     approver = service.approver_ids.filtered(lambda a: a.status == 'waiting')
    #                     if approver:
    #                         approver[0].status = 'pending'
    #                         approver[0]._create_activity()
    #
    #     return res
    def write(self, vals):
        # عند تغيير المرحلة نخزّن التاريخ
        if 'stage_id' in vals:
            vals['stage_date'] = fields.Date.today()

        # خزّن المرحلة السابقة لكل سجل قبل الكتابة (Stage record نفسه مش الاسم)
        stage_before = {
            rec.id: rec.stage_id
            for rec in self
        } if 'stage_id' in vals else {}

        res = super(ServiceRequest, self).write(vals)

        icp = self.env['ir.config_parameter'].sudo()
        send_sms_assign = icp.get_param('multi_service.send_sms_on_assign') == 'True'
        send_wa_assign = icp.get_param('multi_service.send_whatsapp_on_assign') == 'True'
        assign_wa_tmpl_id = icp.get_param('multi_service.assign_whatsapp_template_id')
        send_sms_stage = icp.get_param('multi_service.send_sms_on_stage') == 'True'
        send_wa_stage = icp.get_param('multi_service.send_whatsapp_on_stage') == 'True'

        sms_gateway = self.env['sms.gateway.config'].sudo().search([], limit=1)

        activity_to_show = None
        for rec in self:
            # ======= إشعارات ومنشطّات عند الإسناد =======
            if 'assigned_to_ids' in vals and rec.assigned_to_ids:
                todo_type = 'mail.mail_activity_data_todo'
                for emp in rec.assigned_to_ids.filtered('user_id'):
                    rec.activity_schedule(
                        todo_type,
                        user_id=emp.user_id.id,
                        summary=_('New Service Request Assigned'),
                        note=('<p>%s: %s</p>') % (('You have been assigned to request'), rec.name),
                    )
                first_emp = rec.assigned_to_ids.filtered('user_id')[:1]
                if first_emp and not activity_to_show:
                    activity_to_show = {
                        'type': 'ir.actions.act_window',
                        'name': _('Schedule Activity'),
                        'res_model': 'mail.activity',
                        'view_mode': 'form',
                        'view_id': self.env.ref('mail.mail_activity_view_form_popup').id,
                        'target': 'new',
                        'context': {
                            'default_res_model': rec._name,
                            'default_res_id': rec.id,
                            'default_user_id': first_emp.user_id.id,
                            'default_activity_type_id': self.env.ref(todo_type).id,
                            'default_date_deadline': fields.Date.context_today(self),
                            'default_summary': _('Please follow up on your new assignment'),
                        }
                    }

                if send_wa_assign:
                    if not assign_wa_tmpl_id:
                        raise UserError(_("لم يُعرّف قالب WhatsApp للإسناد في الإعدادات."))
                    for emp in rec.assigned_to_ids:
                        raw = emp.work_phone or emp.mobile_phone
                        if not raw:
                            continue
                        number = f"+{format_mobile_number(raw)}"
                        wa_resp = self.env['vs.otp.gateway'].send_response_appointment_custom_whatsapp(
                            number=number,
                            template_id=assign_wa_tmpl_id,
                            link=rec.reference,
                        )
                        if not wa_resp.get('sent'):
                            raise UserError(_("فشل إرسال WhatsApp إلى %s: %s") % (number, wa_resp))

                if send_sms_assign:
                    if not sms_gateway:
                        raise UserError(_("لم تُعرّف إعدادات بوابة SMS للإسناد."))
                    for emp in rec.assigned_to_ids:
                        raw = emp.work_phone or emp.work_mobile
                        if not raw:
                            continue
                        sms_msg = _("تم تعيينك على طلب الخدمة رقم %s") % rec.reference
                        print(sms_msg, "message")
                        sms_resp = send_imsart_sms(
                            mobile_no=raw,
                            sms=sms_msg,
                            sms_gateway=sms_gateway,
                            lang='ar_001',
                        )
                        sent = sms_resp.get('sent') if isinstance(sms_resp, dict) else bool(sms_resp)
                        if not sent:
                            raise UserError(_("فشل إرسال SMS إلى %s: %s") % (raw, sms_resp))

                if activity_to_show:
                    return activity_to_show

            # ======= إشعارات تغيّر المرحلة + هوك Near-to-End =======
            if 'stage_id' in vals:
                # SMS Notification
                if sms_gateway and send_sms_stage:
                    old = stage_before.get(rec.id).name if stage_before.get(rec.id) else 'غير معروفة'
                    new = rec.stage_id.name
                    phone = rec.partner_id.phone or rec.request_owner_id.partner_id.phone
                    if phone and old != new:
                        msg = _(
                            "نود إفادتك بأنه تم التعامل مع الطلب %(ref)s، يرجى التحقق من المنصة لأي تحديثات. شكراً لك."
                        ) % {'ref': rec.reference}
                        send_imsart_sms(phone, msg, sms_gateway, 'ar_001')

                # WhatsApp Notification
                if rec.stage_id.template_id and send_wa_stage:
                    raw = rec.partner_id.phone or rec.phone
                    if not raw:
                        raise UserError(_("لا يوجد رقم هاتف لإرسال WhatsApp عند تغيير المرحلة."))
                    number = f"+{format_mobile_number(raw)}"
                    tmpl = rec.stage_id.template_id
                    link_tmpl = rec.service_type_id.config_id.evaluation_link_template or ''
                    dynamic = link_tmpl.format(id=rec.id, reference=rec.reference) if link_tmpl else ''
                    wa_res = self.env['vs.otp.gateway'].send_custom_whatsapp(
                        number, tmpl, rec.reference, dynamic
                    )
                    if not wa_res.get('sent'):
                        raise UserError(_("فشل إرسال WhatsApp عند تغيير المرحلة: %s") % wa_res)

                # Push notification (mobile)
                try:
                    partner = rec.partner_id
                    fcm_token = getattr(partner, 'fcm_token', False)
                    if fcm_token:
                        title = f"تم تغيير حالة الطلب ({rec.reference})"
                        body = f"تم نقل طلبك إلى المرحلة: {rec.stage_id.name}"
                        notif = self.env['mobile.notification'].sudo().create({
                            'name': title,
                            'body': body,
                            'service_request_id': rec.id,
                            'partner_id': partner.id,
                            'stage_name': rec.stage_id.name,
                        })
                        notif.send_push()
                        print("تم إرسال إشعار push notification للموبايل")
                except Exception as ex:
                    print("خطأ في إرسال إشعار الموبايل:", ex)

                # Near-to-End hook — يُستدعى فقط عند الدخول إلى مرحلة is_near_end=True
                try:
                    prev_stage = stage_before.get(rec.id)  # record أو False
                    rec._trigger_near_end_hook_if_needed(previous_stage=prev_stage)
                except Exception as e:
                    print("Failed to trigger near-end hook:", e)

            # ======= إعادة ترتيب وتفعيل أول مُعتمد في طابور الموافقات =======
            if 'approver_ids' in vals:
                to_resequence = self.filtered_domain([
                    ('approver_sequence', '=', True),
                    ('request_status', '=', 'pending')
                ])
                for service in to_resequence:
                    if not service.approver_ids.filtered(lambda a: a.status == 'pending'):
                        approver = service.approver_ids.filtered(lambda a: a.status == 'waiting')
                        if approver:
                            approver[0].status = 'pending'
                            approver[0]._create_activity()

        return res

    @api.constrains('approver_ids')
    def _check_approver_ids(self):
        for request in self:
            # make sure the approver_ids are unique per request
            if len(request.approver_ids) != len(request.approver_ids.user_id):
                raise UserError(_("You cannot assign the same approver multiple times on the same request."))

    # def action_approve(self, approver=None):
    #     config_id = self.service_type_id.config_id
    #     if not config_id:
    #         raise UserError(_("Please configure a service type for this request"))
    #
    #     # Check if the user can approve current stage
    #     user_approver_lines = config_id.approver_ids.filtered(
    #         lambda line: self.env.user in line.user_id
    #     )
    #
    #     user_approvable_stage_ids = user_approver_lines.mapped('stage_id')
    #
    #     if self.stage_id not in user_approvable_stage_ids:
    #         raise UserError(_("You do not have permission to approve this stage"))
    #
    #     # Get next stage in sequence
    #     higher_stages = self.stage_ids.filtered(lambda s: s.sequence > self.stage_id.sequence)
    #     next_stage = higher_stages.sorted(key=lambda s: s.sequence)[:1]
    #     self.stage_date = fields.Date.today()
    #     if next_stage:
    #         self.stage_id = next_stage.id
    #     elif config_id.final_stage and self.stage_id != config_id.final_stage:
    #         self.stage_id = config_id.final_stage.id
    #     else:
    #         raise UserError(_("No next stage found after current one."))

    def action_previous_stage(self):
        for record in self:
            current_stage = record.stage_id
            if not self.env.user.has_group('multi_service.group_service_user'):
                raise UserError(_("You do not have the permission to move to the previous stage."))

            if not current_stage:
                raise UserError(_("Current stage is not set."))

            # Find stages with a lower sequence
            lower_stages = record.stage_ids.filtered(lambda s: s.sequence < current_stage.sequence)

            # Get the previous stage (highest among the lower ones)
            previous_stage = lower_stages.sorted(key=lambda s: s.sequence, reverse=True)[:1]
            self.stage_date = fields.Date.today()
            if previous_stage:
                record.stage_id = previous_stage.id
            else:
                raise UserError(_("No previous stage found before the current one."))

    @api.depends()
    def _compute_can_edit_request(self):
        for rec in self:
            print("test method")
            rec.can_edit_request = self.env.user.has_group('multi_service.group_service_request_edit')
            print("rec",rec.can_edit_request)

    @api.depends('partner_id')
    def _compute_phone(self):
        for request in self:
            if request.partner_id.phone:
                request.phone = request.partner_id.phone

            elif request.phone:
                continue

            else:
                request.phone = False

    @api.depends('service_type_id.config_id.stage_ids')
    def _compute_stage_ids(self):
        draft_stage = self.env['service.stage'].search([('name', '=', 'Draft')], limit=1)
        for rec in self:
            config = rec.service_type_id.config_id
            stage_ids = config.approver_ids.mapped('stage_id')

            # Add 'Draft' stage if not already in the list
            if draft_stage and draft_stage not in stage_ids:
                stage_ids |= draft_stage

            # Add final_stage if it's not already in the list
            if config.final_stage and config.final_stage not in stage_ids:
                stage_ids |= config.final_stage

            rec.stage_ids = stage_ids

    @api.depends('stage_ids')
    def _compute_stage_id_to_approve(self):
        for rec in self:
            draft_stage = rec.stage_ids.filtered(lambda s: s.name == 'Draft')
            rec.stage_id = draft_stage[0] if draft_stage else False

    @api.depends('service_type_id')
    def _compute_main_category(self):
        for request in self:
            request.category_id = request.service_type_id.category_id or False

    @api.depends('request_owner_id')
    @api.depends_context('uid')
    def _compute_has_access_to_request(self):
        is_service_user = self.env.user.has_group('multi_service.group_service_previous_stage2')
        self.change_request_owner = is_service_user
        for request in self:
            request.has_access_to_request = request.request_owner_id == self.env.user and is_service_user

    def _compute_attachment_number(self):
        domain = [('res_model', '=', 'service.request'), ('res_id', 'in', self.ids)]
        attachment_data = self.env['ir.attachment']._read_group(domain, ['res_id'], ['res_id'])
        attachment = dict((data['res_id'], data['res_id_count']) for data in attachment_data)
        for request in self:
            request.attachment_number = attachment.get(request.id, 0)

    @api.constrains('date_start', 'date_end')
    def _check_dates(self):
        for request in self:
            if request.date_start and request.date_end and request.date_start > request.date_end:
                raise ValidationError(_("Start date should precede the end date."))


    @api.ondelete(at_uninstall=False)
    def unlink_attachments(self):
        attachment_ids = self.env['ir.attachment'].search([
            ('res_model', '=', 'service.request'),
            ('res_id', 'in', self.ids),
        ])
        if attachment_ids:
            attachment_ids.unlink()

    def unlink(self):
        # self.filtered(lambda a: a.has_product).product_line_ids.unlink()
        return super().unlink()

    def action_get_attachment_view(self):
        self.ensure_one()
        res = self.env['ir.actions.act_window']._for_xml_id('base.action_attachment')
        res['domain'] = [('res_model', '=', 'service.request'), ('res_id', 'in', self.ids)]
        res['context'] = {'default_res_model': 'service.request', 'default_res_id': self.id}
        return res

    def action_confirm(self):
        # make sure that the manager is present in the list if he is required
        self.ensure_one()
        if self.config_id.manager_service == 'required':
            employee = self.env['hr.employee'].search([('user_id', '=', self.request_owner_id.id)], limit=1)
            if not employee.parent_id:
                raise UserError(
                    _('This request needs to be approved by your manager. There is no manager linked to your employee profile.'))
            if not employee.parent_id.user_id:
                raise UserError(
                    _('This request needs to be approved by your manager. There is no user linked to your manager.'))
            if not self.approver_ids.filtered(lambda a: a.user_id.id == employee.parent_id.user_id.id):
                raise UserError(
                    _('This request needs to be approved by your manager. Your manager is not in the approvers list.'))
        if len(self.approver_ids) < self.service_minimum:
            raise UserError(_("You have to add at least %s approvers to confirm your request.", self.service_minimum))
        if self.requirer_document == 'required' and not self.attachment_number:
            raise UserError(_("You have to attach at least one document."))

        approvers = self.approver_ids
        if self.approver_sequence:
            approvers = approvers.filtered(lambda a: a.status in ['new', 'pending', 'waiting'])

            approvers[1:].sudo().write({'status': 'waiting'})
            approvers = approvers[0] if approvers and approvers[0].status != 'pending' else self.env['service.approver']
        else:
            approvers = approvers.filtered(lambda a: a.status == 'new')

        approvers._create_activity()
        approvers.sudo().write({'status': 'pending'})
        self.sudo().write({'date_confirmed': fields.Datetime.now()})

    def _get_user_service_activities(self, user):
        domain = [
            ('res_model', '=', 'service.request'),
            ('res_id', 'in', self.ids),
            ('activity_type_id', '=', self.env.ref('services.mail_activity_data_service').id),
            ('user_id', '=', user.id)
        ]
        activities = self.env['mail.activity'].search(domain)
        return activities

    def _ensure_can_approve(self):
        pass

    def _update_next_approvers(self, new_status, approver, only_next_approver, cancel_activities=False):
        approvers_updated = self.env['service.approver']
        for service in self.filtered('approver_sequence'):
            current_approver = service.approver_ids & approver
            approvers_to_update = service.approver_ids.filtered(lambda a: a.status not in ['approved', 'refused'] and (
                    a.sequence > current_approver.sequence or (
                    a.sequence == current_approver.sequence and a.id > current_approver.id)))

            if only_next_approver and approvers_to_update:
                approvers_to_update = approvers_to_update[0]
            approvers_updated |= approvers_to_update

        approvers_updated.sudo().status = new_status
        if new_status == 'pending':
            approvers_updated._create_activity()
        if cancel_activities:
            approvers_updated.request_id._cancel_activities()

    def _cancel_activities(self):
        service_activity = self.env.ref('multi_service.mail_activity_data_service')
        activities = self.activity_ids.filtered(lambda a: a.activity_type_id == service_activity)
        activities.unlink()

    def action_refuse(self, approver=None):
        if not isinstance(approver, models.BaseModel):
            approver = self.mapped('approver_ids').filtered(
                lambda approver: approver.user_id == self.env.user
            )
        approver.write({'status': 'refused'})
        self.sudo()._update_next_approvers('refused', approver, only_next_approver=False, cancel_activities=True)
        self.sudo()._get_user_service_activities(user=self.env.user).action_feedback()

    def action_withdraw(self, approver=None):
        if not isinstance(approver, models.BaseModel):
            approver = self.mapped('approver_ids').filtered(
                lambda approver: approver.user_id == self.env.user
            )
        self.sudo()._update_next_approvers('waiting', approver, only_next_approver=False, cancel_activities=True)
        approver.write({'status': 'pending'})

    def action_send_whatsapp_update(self):
        for rec in self:
            raw_phone = rec.partner_id.phone or rec.phone
            if not raw_phone:
                raise UserError(_("No phone number found on the request."))

            phone = format_mobile_number(raw_phone)
            phone = f"+{phone}"
            print("Final phone for WhatsApp: %s", phone)

            template_id = rec.service_type_id.whatsapp_template_id
            if not template_id:
                raise UserError(_("No WhatsApp template ID defined in the service type."))

            message_var = rec.reference or rec.name or "—"

            response = self.env['vs.otp.gateway'].send_whatsapp_custom_template(
                number=phone,
                template_id=template_id,
                attribute=message_var
            )

            if response.get('sent'):
                return {
                    'type': 'ir.actions.client', 'tag': 'display_notification',
                    'params': {
                        'title': 'Success',
                        'message': 'Message sent via WhatsApp.',
                        'type': 'success'
                    }
                }
            else:
                raise UserError(_("WhatsApp sending failed: %s") % response.get('text'))

    def action_draft(self):
        self.mapped('approver_ids').write({'status': 'new'})

    def action_cancel(self):
        self.sudo()._get_user_service_activities(user=self.env.user).unlink()
        self.mapped('approver_ids').write({'status': 'cancel'})

    @api.depends('approver_ids.status', 'approver_ids.required')
    def _compute_request_status(self):
        for request in self:
            status_lst = request.mapped('approver_ids.status')
            required_approved = all(a.status == 'approved' for a in request.approver_ids.filtered('required'))
            minimal_approver = request.service_minimum if len(status_lst) >= request.service_minimum else len(
                status_lst)
            if status_lst:
                if status_lst.count('cancel'):
                    status = 'cancel'
                elif status_lst.count('refused'):
                    status = 'refused'
                elif status_lst.count('new'):
                    status = 'new'
                elif status_lst.count('approved') >= minimal_approver and required_approved:
                    status = 'approved'
                else:
                    status = 'pending'
            else:
                status = 'new'
            request.request_status = status

        self.filtered_domain([('request_status', 'in', ['approved', 'refused', 'cancel'])])._cancel_activities()


    @api.constrains('approver_ids')
    def _check_approver_ids(self):
        for request in self:
            # make sure the approver_ids are unique per request
            if len(request.approver_ids) != len(request.approver_ids.user_id):
                raise UserError(_("You cannot assign the same approver multiple times on the same request."))

    def action_approve(self, approver=None):
        config_id = self.service_type_id.config_id
        if not config_id:
            raise UserError(_("Please configure a service type for this request"))

        # Check if the user can approve current stage
        user_approver_lines = config_id.approver_ids.filtered(
            lambda a: self.env.user in a.user_id        )
        user_approvable_stage_ids = user_approver_lines.mapped('stage_id')

        if self.stage_id not in user_approvable_stage_ids:
            raise UserError(_("You do not have permission to approve this stage"))

        # Get next stage in sequence
        higher_stages = self.stage_ids.filtered(lambda s: s.sequence > self.stage_id.sequence)
        next_stage = higher_stages.sorted(key=lambda s: s.sequence)[:1]

        if next_stage:
            self.stage_id = next_stage.id
        elif config_id.final_stage and self.stage_id != config_id.final_stage:
            self.stage_id = config_id.final_stage.id
        else:
            raise UserError(_("No next stage found after current one."))

    # def action_previous_stage(self):
    #     print("test action pre")
    #     for record in self:
    #         current_stage = record.stage_id
    #         if not self.env.user.has_group('multi_service.group_service_user'):
    #             raise UserError(_("You do not have the permission to move to the previous stage."))
    #
    #         if not current_stage:
    #             raise UserError(_("Current stage is not set."))
    #
    #         # Find stages with a lower sequence
    #         lower_stages = record.stage_ids.filtered(lambda s: s.sequence < current_stage.sequence)
    #
    #         # Get the previous stage (highest among the lower ones)
    #         previous_stage = lower_stages.sorted(key=lambda s: s.sequence, reverse=True)[:1]
    #
    #         if previous_stage:
    #             record.stage_id = previous_stage.id
    #         else:
    #             raise UserError(_("No previous stage found before the current one."))

    def _compute_can_approve(self):
        for record in self:
            config_id = record.service_type_id.config_id

            if not config_id:
                record.can_approve = False
                continue

            # ❌ If current stage is the final stage → can't approve anymore
            if record.stage_id == config_id.final_stage:
                record.can_approve = False
                continue

            # Filter approver lines for current user
            user_approver_lines = config_id.approver_ids.filtered(
                lambda a: record.env.user in a.user_id
            )

            # Get all the stages this user is allowed to approve
            user_approvable_stage_ids = user_approver_lines.mapped('stage_id')

            # ✅ Check if current stage is one of those and not final
            record.can_approve = record.stage_id in user_approvable_stage_ids

    def _compute_can_previous_stage(self):
        print("compute")
        for record in self:
            config_id = record.service_type_id.config_id

            if not config_id:
                record.can_previous_stage = False
                continue

            # Get stages from config
            stage_ids = config_id.approver_ids.mapped('stage_id').sorted('sequence')

            # First stage (by sequence)
            first_stage = stage_ids[0] if stage_ids else False

            # Filter approver lines for current user
            user_approver_lines = config_id.approver_ids.filtered(
                lambda a: record.env.user in a.user_id
            )

            # Get all stages the current user can approve
            user_approvable_stage_ids = user_approver_lines.mapped('stage_id')

            # ✅ Logic: must be approver and not at the first stage
            record.can_previous_stage = (
                    record.stage_id in user_approvable_stage_ids
                    and record.stage_id != first_stage
            )

class ServiceApprover(models.Model):
    _name = 'service.approver'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Approver'
    _order = 'sequence, id'

    _check_company_auto = True

    sequence = fields.Integer('Sequence', default=10)
    user_id = fields.Many2one('res.users', string="User", required=True, check_company=True,
                              domain="[('id', 'not in', existing_request_user_ids)]")
    existing_request_user_ids = fields.Many2many('res.users', compute='_compute_existing_request_user_ids')
    stage_ids = fields.Many2many('service.stage', string='Stages')
    request_id = fields.Many2one('service.request', string="Request",
                                 ondelete='cascade', check_company=True)
    company_id = fields.Many2one(
        string='Company', related='request_id.company_id',
        store=True, readonly=True, index=True)
    required = fields.Boolean(default=False, readonly=True)
    config_approver = fields.Boolean(compute='_compute_config_approver')
    can_edit = fields.Boolean(compute='_compute_can_edit')

    def action_approve(self):
        self.request_id.action_approve(self)

    def action_refuse(self):
        self.request_id.action_refuse(self)

    def _create_activity(self):
        for approver in self:
            approver.request_id.activity_schedule(
                'services.mail_activity_data_service',
                user_id=approver.user_id.id)

    @api.depends('request_id.request_owner_id', )
    def _compute_existing_request_user_ids(self):
        for approver in self:
            approver.existing_request_user_ids = \
                self.mapped('request_id.approver_ids.user_id')._origin \
                | self.request_id.request_owner_id._origin

    @api.depends('config_approver', 'user_id')
    def _compute_config_approver(self):
        for service in self:
            service.config_approver = service.user_id in service.request_id.config_id.approver_ids.user_id

    @api.depends_context('uid')
    @api.depends('user_id', 'config_approver')
    def _compute_can_edit(self):
        is_user = self.env.user.has_group('services.group_service_user')
        for service in self:
            service.can_edit = not service.user_id or not service.config_approver or is_user




class AccountPayment(models.Model):
    _inherit = 'account.payment'

    access_token = fields.Char(string="Access Token", readonly=True)

    def generate_access_token(self):
        for rec in self:
            if not rec.access_token:
                rec.access_token = secrets.token_urlsafe(32)

    def action_post(self):
        res = super().action_post()
        for payment in self:
            service = self.env['service.request'].search([('payment_id', '=', payment.id)], limit=1)
            if service:
                service.payment_state = 'paid'
        return res