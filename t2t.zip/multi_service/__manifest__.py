{
    'name': 'Service Management',
    'version': '1.0',
    'category': 'Services',
    'summary': 'Manage services, categories, and configurations',
    "author": "Sysgates _ Ahmed Eldweek ,Veronica Safwat",
    "license": "LGPL-3",
    "website": "https://www.sysgates.com",
    'depends': ['base', 'mail', 'web','account','vs_sms_whatsapp','sys_short_url','citizen_survey'],
    'data': [
        'security/ir.model.access.csv',
        'security/access.xml',
        'data/mail_activity_type_data.xml',
        'data/data.xml',
        'views/document_type.xml',
        'views/state.xml',
        'views/government.xml',
        'views/service_category_approver_views.xml',
        'views/service_request.xml',
        'views/service_category_views.xml',
        'views/service_views.xml',
        'views/stage.xml',
        'views/menu.xml',
        'views/village.xml',
        'views/res_config_setting.xml',
        'views/add_wizard.xml',
        'views/add_wizard_button.xml',
        'views/partner.xml',
        'views/dashborad.xml',
        # 'views/location_widget.xml',

    ],
    'assets': {
        'web.assets_backend': [

            'multi_service/static/src/xml/location_widget.xml',
            'multi_service/static/src/js/location_widget.js',
            'multi_service/static/src/js/lib/chart.min.js',
            'multi_service/static/src/js/dashboard.js',
            'multi_service/static/src/xml/dashboard_templates.xml',

        ],


    },

    'installable': True,
    'application': True,
}
