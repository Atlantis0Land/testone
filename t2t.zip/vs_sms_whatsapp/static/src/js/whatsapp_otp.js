odoo.define('vs_sms_whatsapp.whatsapp_otp', function (require) {
    "use strict";
    console.log('💥 whatsapp_otp.js LOADED 💥');


    $(document).ready(function () {
        $('#otp_send_whatsapp').on('click', function (e) {
const phone = $('[name="phone"]').val();
            console.log('[JS DEBUG] phone to be sent via WhatsApp:', phone);
            $('#whatsapp_phone').val(phone);  // نحطها في input hidden في الفورم الجديد
        });
    });
});
