# -*- coding: utf-8 -*-

from . import whatsapp
from . import ResConfig