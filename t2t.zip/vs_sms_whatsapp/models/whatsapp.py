from odoo import models, api , _
import requests
import logging

_logger = logging.getLogger(__name__)


class OtpGateway(models.AbstractModel):
    _name = 'vs.otp.gateway'
    _description = 'Send OTP through WhatsApp via OmniHub'

    @api.model
    def send_custom_template_online_req(self, number, template_id, link):
        """
            ترسل رسالة واتساب للقالب الذي يحتوي على حقل واحد {{1}}
            - number: رقم الهاتف كامل (+COUNTRYCODE...)
            - template_id: معرّف القالب في iOmniHub
            - link: القيمة التي تُمرّر إلى {{1}} (مثلاً short_link أو payment_link)
            """
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')

        if not token or not channel_id or not template_id:
            return {
                "status": 400,
                "json": {},
                "sent": False,
                "text": _("Missing config or template ID")
            }

        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {"1": link},
        }

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            _logger.info("📨 send_payment_link_whatsapp response: %s", data)

            success_flag = data.get('extra', {}).get('success')
            messages = data.get('extra', {}).get('report', {}).get('messages', []) or []
            accepted = any(m.get('message_status') in ('accepted', 'sent', 'delivered')
                           for m in messages)

            return {
                "status": res.status_code,
                "json": data,
                "sent": (res.status_code == 200 and success_flag and accepted),
                "text": data
            }
        except Exception as e:
            _logger.error("Error in send_payment_link_whatsapp: %s", e)
            return {
                "status": 500,
                "json": {},
                "sent": False,
                "text": str(e)
            }
    @api.model
    def send_payment_link_whatsapp(self, number, template_id, link):
        """
        ترسل رسالة واتساب للقالب الذي يحتوي على حقل واحد {{1}}
        - number: رقم الهاتف كامل (+COUNTRYCODE...)
        - template_id: معرّف القالب في iOmniHub
        - link: القيمة التي تُمرّر إلى {{1}} (مثلاً short_link أو payment_link)
        """
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')

        if not token or not channel_id or not template_id:
            return {
                "status": 400,
                "json": {},
                "sent": False,
                "text": _("Missing config or template ID")
            }

        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {"1": link},
        }

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            _logger.info("📨 send_payment_link_whatsapp response: %s", data)

            success_flag = data.get('extra', {}).get('success')
            messages = data.get('extra', {}).get('report', {}).get('messages', []) or []
            accepted = any(m.get('message_status') in ('accepted', 'sent', 'delivered')
                           for m in messages)

            return {
                "status": res.status_code,
                "json": data,
                "sent": (res.status_code == 200 and success_flag and accepted),
                "text": data
            }
        except Exception as e:
            _logger.error("Error in send_payment_link_whatsapp: %s", e)
            return {
                "status": 500,
                "json": {},
                "sent": False,
                "text": str(e)
            }

    @api.model
    def send_custom_whatsapp(self, number, template_id, attribute=None, evaluation_link=None):
        """
        هذه الميثود ترسل رسالة واتساب بناءً على:
          - number: رقم الهاتف (+COUNTRYCODE...)
          - template_id: معرّف القالب في iOmniHub
          - attribute: قيمة الحقل {{1}} (مثل reference أو غيره)
          - evaluation_link: قيمة الحقل {{2}} (للرابط إن وجد)

        تلاحظ أن بعض القوالب قد تحتوي على حقول أكثر من 1، فإذا كان القالب يستدعي حقلين،
        نمرّر "attribute" تحت المفتاح "1" و "evaluation_link" تحت المفتاح "2".
        إذا القالب لا يحتاج لحقل ثاني، نمرّر فقط المفتاح "1" بالخاصية "attribute".
        """
        # 1) جلب التوكن وقناة الواتساب من الإعدادات
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')

        if not token or not channel_id or not template_id:
            return {"status": 400, "text": _("Missing config or template ID"), "sent": False}

        attrs = {}
        if attribute is not None:
            attrs["1"] = attribute
        if evaluation_link is not None:
            attrs["2"] = evaluation_link or " "

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": attrs
        }

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            print("📨 WhatsApp send_custom_whatsapp Response: %s", data)

            success_flag = data.get('extra', {}).get('success')
            messages = data.get('extra', {}).get('report', {}).get('messages', []) or []
            accepted = any(
                m.get('message_status') in ('accepted', 'sent', 'delivered')
                for m in messages
            )

            return {
                "status": res.status_code,
                "json": data,
                "sent": (res.status_code == 200 and success_flag and accepted),
                "text": data
            }
        except Exception as e:
            print("Error in send_custom_whatsapp: %s", e)
            return {"status": 500, "text": str(e), "sent": False}
    @api.model
    def send_payment_custom_whatsapp(self, number, template_id, link=''):
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')

        if not token or not channel_id or not template_id:
            return {"status": 400, "text": "Missing config or template ID", "sent": False}

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {
                "1": link
            }
        }

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            print("📨 iOmniHub response: %s", data)

            # ✅ التعامل مع الـ status
            success = (
                    res.status_code == 200 and
                    data.get('extra', {}).get('success') is True
            )

            return {
                "status": res.status_code,
                "json": data,
                "sent": success,
                "text": data.get('message') or 'No message returned'
            }

        except Exception as e:
            print("❌ WhatsApp sending failed")
            return {
                "status": 500,
                "text": str(e),
                "sent": False
            }

    @api.model
    def send_response_custom_whatsapp(self, number, template_id, link=''):
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')

        if not token or not channel_id or not template_id:
            return {"status": 400, "text": "Missing config or template ID", "sent": False}

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {
                "1": link
            }
        }

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            print("📨 iOmniHub response: %s", data)

            # ✅ التعامل مع الـ status
            success = (
                    res.status_code == 200 and
                    data.get('extra', {}).get('success') is True
            )

            return {
                "status": res.status_code,
                "json": data,
                "sent": success,
                "text": data.get('message') or 'No message returned'
            }

        except Exception as e:
            print("❌ WhatsApp sending failed")
            return {
                "status": 500,
                "text": str(e),
                "sent": False
            }

    @api.model
    def send_response_appointment_custom_whatsapp(self, number, template_id, link=''):
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')

        if not token or not channel_id or not template_id:
            return {"status": 400, "text": "Missing config or template ID", "sent": False}

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {
                "1": link
            }
        }

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            print("📨 iOmniHub response: %s", data)

            # ✅ التعامل مع الـ status
            success = (
                    res.status_code == 200 and
                    data.get('extra', {}).get('success') is True
            )

            return {
                "status": res.status_code,
                "json": data,
                "sent": success,
                "text": data.get('message') or 'No message returned'
            }

        except Exception as e:
            print("❌ WhatsApp sending failed")
            return {
                "status": 500,
                "text": str(e),
                "sent": False
            }

    @api.model
    def send_whatsapp_custom_template(self, number, template_id, attribute):
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')
        if not token or not channel_id:
            return {"status": 400, "text": _("Missing token or channel ID."), "sent": False}

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {
                "1": attribute
            }
        }

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            print("📨 WhatsApp Response JSON test button :", data)

            success = data.get('extra', {}).get('success')
            messages = data.get('extra', {}).get('report', {}).get('messages', [])
            accepted = any(m.get('message_status') in ('accepted', 'sent', 'delivered') for m in messages)

            return {
                "status": res.status_code,
                "json": data,
                "sent": (res.status_code == 200 and success and accepted),
                "text": data
            }
        except Exception as e:
            return {"status": 500, "text": str(e), "sent": False}

    @api.model
    def send_new_service_created_whatsapp(self, number, service_ref):
        """
        يرسل إشعار واتساب عند إنشاء خدمة جديدة باستخدام القالب 'new_service_created'
        - number: رقم الهاتف كامل (+COUNTRYCODE...)
        - service_ref: قيمة الحقل {{1}} في القالب (رقم طلب الخدمة)
        """
        # 1) جلب توكن وقناة الـ WhatsApp
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        template_id = config.get_param('multi_service.whatsapp_service_template_id')
        print("tem",template_id)
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')

        if not (token and channel_id and template_id):
            return {"status": 400, "sent": False, "text": _("Missing config or template ID")}

        # 3) إعداد الـ payload حسب الصيغة
        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {
                "1": service_ref
            }
        }
        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            _logger.info("📨 new_service_created response: %s", data)

            success = (res.status_code == 200 and
                       data.get('extra', {}).get('success') is True)
            messages = data.get('extra', {}).get('report', {}).get('messages', []) or []
            sent = success and any(m.get('message_status') in ('accepted', 'sent', 'delivered')
                                   for m in messages)

            return {
                "status": res.status_code,
                "json": data,
                "sent": sent,
                "text": data.get('message') or data
            }
        except Exception as e:
            _logger.error("Error sending new_service_created: %s", e)
            return {"status": 500, "sent": False, "text": str(e)}


    @api.model
    def send_new_service_created_whatsapp_cron(self, number, template_id, service_ref=None, attributes=None):
        """
        يرسل رسالة واتساب بقالب معيّن.
        - template_id: إلزامي (من الكرون)
        - attributes: dict لمتغيرات القالب {"1": "...", "2": "...", "3": "..."}
          لو مش مبعوتة بنستخدم {"1": service_ref} كسلوك قديم.
        """
        # 1) الإعدادات
        icp = self.env['ir.config_parameter'].sudo()
        token = icp.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = icp.get_param('vs_otp_gateway.whatsapp_channel_id')
        if not (token and channel_id and template_id):
            return {"status": 400, "sent": False, "text": _("Missing config or template ID")}

        # 2) تجهيز المتغيّرات
        if attributes and isinstance(attributes, dict):
            attrs = {str(k): "" if v is None else str(v) for k, v in attributes.items()}
        else:
            attrs = {"1": "" if service_ref is None else str(service_ref)}

        # (اختياري لكن مفيد لقالبك) تأكد من وجود 1 و 2 و 3 بقيم غير فاضية
        missing = [k for k in ("1", "2", "3") if k not in attrs or not str(attrs[k]).strip()]
        if missing:
            return {
                "status": 400,
                "sent": False,
                "text": _("Missing text value for template variables: %s") %
                        ", ".join("{{%s}}" % k for k in missing),
            }

        payload = {
            "template_id": str(template_id),
            "channel_id": channel_id,
            "customer_phone": number,  # يُفضّل E.164 (+968XXXXXXXX)
            "attributes": attrs,
        }
        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"

        try:
            _logger.info("WA payload(no token): %s", {
                "template_id": payload["template_id"],
                "channel_id": payload["channel_id"],
                "customer_phone": payload["customer_phone"],
                "attributes": payload["attributes"],
            })
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            _logger.info("📨 new_service_created response: %s", data)

            success = (res.status_code == 200 and data.get('extra', {}).get('success') is True)
            messages = data.get('extra', {}).get('report', {}).get('messages', []) or []
            sent = success and any(m.get('message_status') in ('accepted', 'sent', 'delivered') for m in messages)

            return {"status": res.status_code, "json": data, "sent": sent, "text": data.get('message') or data}
        except Exception as e:
            _logger.error("Error sending new_service_created: %s", e)
            return {"status": 500, "sent": False, "text": str(e)}
    @api.model
    def send_whatsapp_with_template(self, number, template_id, service_ref):
        """
        نسخة مطابقة لسلوكك السابق لكن template_id يُمرَّر بارامتر،
        وتستخدم خانة {{1}} فقط.
        """
        return self.send_whatsapp_template(
            number=number,
            template_id=template_id,
            attributes={"1": service_ref},
        )


    @api.model
    def send_whatsapp_internal_otp(self, number, otp):
        """
        Send OTP via WhatsApp using the internal template format.
        This is a dedicated method for internal users.
        """
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        template_id = config.get_param('vs_otp_gateway.whatsapp_template_id_internal')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')
        
        if not token or not template_id or not channel_id:
            return {"status": 400, "text": _("Missing configuration."), "sent": False}

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {
                "verification_code": otp  # Using the format from the new template schema
            }
        }

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            print(f"[DEBUG] Internal template WhatsApp response: {data}")

            # Check success markers
            success_flag = data.get('extra', {}).get('success', False)
            messages = data.get('extra', {}).get('report', {}).get('messages', [])
            accepted = any(m.get('message_status') in ('accepted','sent','delivered') for m in messages)
            
            sent = (res.status_code == 200) and success_flag and accepted

            return {
                "status": res.status_code,
                "json": data,
                "sent": sent,
                "text": data
            }
        except Exception as e:
            print(f"[ERROR] Internal WhatsApp send failed: {e}")
            return {"status": 500, "text": str(e), "sent": False}

    @api.model
    def send_whatsapp(self, number, otp):
        config      = self.env['ir.config_parameter'].sudo()
        token       = config.get_param('vs_otp_gateway.whatsapp_token')
        template_id = config.get_param('vs_otp_gateway.whatsapp_template_id')
        channel_id  = config.get_param('vs_otp_gateway.whatsapp_channel_id')
        if not token or not template_id or not channel_id:
            return {"status": 400, "text": _("Missing configuration."), "sent": False}

        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"
        payload = {
            "template_id":    template_id,
            "channel_id":     channel_id,
            "customer_phone": number,
            "attributes": {
                "verification_code": otp
            }
        }

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()  # JSON مفكوك
            print("iOmniHub response JSON: %s", data)

            success_flag = data.get('extra', {}).get('success', False)

            messages = data.get('extra', {}).get('report', {}).get('messages', [])
            accepted = any(m.get('message_status') in ('accepted','sent','delivered') for m in messages)

            sent = (res.status_code == 200) and success_flag and accepted

            return {
                "status": res.status_code,
                "json":   data,
                "sent":   sent,
                "text":   data
            }
        except Exception as e:
            print("WhatsApp send failed: %s", e)
            return {"status": 500, "text": str(e), "sent": False}

    @api.model
    def send_payment_link_notification_investment(self, number, template_id, link):
        """
        يرسل إشعار WhatsApp لإتمام الدفع
        - number: رقم الهاتف كامل (+COUNTRYCODE...)
        - template_id: معرّف القالب من الـ Investment Contract Type
        - link: الرابط الذي يُضمّن في الحقل {{1}}
        """
        config = self.env['ir.config_parameter'].sudo()
        token = config.get_param('vs_otp_gateway.whatsapp_token')
        channel_id = config.get_param('vs_otp_gateway.whatsapp_channel_id')

        if not (token and channel_id and template_id):
            return {
                "status": 400,
                "sent": False,
                "text": _("Missing config or template ID")
            }

        payload = {
            "template_id": template_id,
            "channel_id": channel_id,
            "customer_phone": number,
            "attributes": {
                "1": link,
            }
        }
        url = f"https://api.iomnihub.ai/stable/open/whatsapp/send-template-message?api_key={token}"

        try:
            res = requests.post(url, json=payload, timeout=10)
            data = res.json()
            _logger.info("📨 payment_link_notification_investment response: %s", data)

            success = (res.status_code == 200 and
                       data.get('extra', {}).get('success') is True)
            messages = data.get('extra', {}).get('report', {}).get('messages', []) or []
            sent = success and any(
                m.get('message_status') in ('accepted', 'sent', 'delivered')
                for m in messages
            )

            return {
                "status": res.status_code,
                "json": data,
                "sent": sent,
                "text": data.get('message') or data
            }
        except Exception as e:
            _logger.error("Error in send_payment_link_notification_investment: %s", e)
            return {
                "status": 500,
                "sent": False,
                "text": str(e)
            }
