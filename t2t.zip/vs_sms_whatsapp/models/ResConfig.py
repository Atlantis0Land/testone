from odoo import models, fields

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    whatsapp_token = fields.Char(string="WhatsApp Token", config_parameter="vs_otp_gateway.whatsapp_token")
    whatsapp_template_id = fields.Char(string="WhatsApp Template ID", config_parameter="vs_otp_gateway.whatsapp_template_id")
    whatsapp_template_id_internal = fields.Char(string="WhatsApp Template ID (Internal Users)", config_parameter="vs_otp_gateway.whatsapp_template_id_internal")
    whatsapp_channel_id = fields.Char(string="WhatsApp Channel ID", config_parameter="vs_otp_gateway.whatsapp_channel_id")
    enable_whatsapp_login_otp = fields.Boolean(string="Enable WhatsApp Login OTP", config_parameter="vs_otp_gateway.enable_whatsapp_login_otp")


