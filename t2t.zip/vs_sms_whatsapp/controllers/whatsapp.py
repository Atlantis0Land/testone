from odoo import http
from odoo.http import request
from datetime import datetime
from dateutil.relativedelta import relativedelta
from odoo.addons.otp_authentication.controller.main import (
    is_valid_mobile,
    generate_otp,
    hash_otp,
    format_mobile_number,
)
from odoo.addons.web.controllers.home import Home
from odoo.exceptions import AccessDenied
import werkzeug.utils

class WhatsappOtpController(http.Controller):

    @http.route('/dhr/otp/login/send_whatsapp', type='http', auth='public', methods=['POST'], csrf=False, website=True)
    def send_login_otp_whatsapp(self, **post):
        phone = post.get('phone')
        print(f"[DEBUG] Received phone: {phone}")

        if not phone or not is_valid_mobile(phone):
            print(f"[DEBUG] Invalid phone number: {phone}")
            return request.render('otp_authentication.dhr_phone_login', {
                'error': '❌ رقم موبايل غير صالح',
                'phone': phone,
            })

        formatted = format_mobile_number(phone)
        otp = generate_otp()
        hashed = hash_otp(otp)
        expires = datetime.now() + relativedelta(minutes=3)

        request.env['otp.code'].sudo().create({
            'phone_num': formatted,
            'req_time': datetime.now(),
            'code_num': hashed,
        })

        print("[DEBUG] Calling WhatsApp gateway...")
        res = request.env['vs.otp.gateway'].send_whatsapp(formatted, otp)

        print(f"[DEBUG] WhatsApp Response in Controller: {res}")

        if res.get('status') == 200 or res.get('sent'):
            return request.render('otp_authentication.dhr_otp_verify_login', {
                'phone': phone,
                'otp_sent': True,
            })
        else:
            return request.render('otp_authentication.dhr_phone_login', {
                'error': res.get('text') or '❌ فشل الإرسال عبر واتساب',
                'phone': phone,
            })

# class StandardLoginOTPController(Home):
#     @http.route()
#     def web_login(self, redirect=None, **kw):
#         """Override standard login to add OTP verification via WhatsApp"""
#         response = super(StandardLoginOTPController, self).web_login(redirect=redirect, **kw)
#
#         # Only continue with OTP if login was successful and it's a POST request
#         if request.httprequest.method == 'POST' and request.params.get('login_success', False):
#             config = request.env['ir.config_parameter'].sudo()
#             enable_whatsapp_login_otp = config.get_param('vs_otp_gateway.enable_whatsapp_login_otp')
#
#             if not enable_whatsapp_login_otp:
#                 return response
#
#             # Get the user that just logged in
#             user = request.env['res.users'].sudo().browse(request.session.uid)
#
#             # Get phone number from user
#             if user.phone:
#                 phone = user.phone
#             elif user.mobile:
#                 phone = user.mobile
#             elif user.partner_id and user.partner_id.phone:
#                 phone = user.partner_id.phone
#             elif user.partner_id and user.partner_id.mobile:
#                 phone = user.partner_id.mobile
#             else:
#                 # No phone, proceed with login
#                 return response
#
#             # Format phone and generate OTP
#             formatted_phone = format_mobile_number(phone)
#             otp = generate_otp()
#             hashed = hash_otp(otp)
#             expires = datetime.now() + relativedelta(minutes=3)
#
#             # Store OTP in database
#             request.env['otp.code'].sudo().create({
#                 'phone_num': formatted_phone,
#                 'req_time': datetime.now(),
#                 'code_num': hashed,
#             })
#
#             # Store verification information in database instead of session
#             verification_data = request.env['ir.config_parameter'].sudo().set_param(
#                 f'vs_otp_gateway.verification_{formatted_phone}',
#                 str(request.session.uid)
#             )
#
#             # Logout the user until OTP is verified
#             request.session.logout(keep_db=True)
#             request.session.uid = None
#             request.session.login = None
#             request.session.session_token = None
#
#             # Send OTP via WhatsApp
#             print(f"[DEBUG] Calling WhatsApp gateway for phone {formatted_phone}")
#             res = request.env['vs.otp.gateway'].send_whatsapp_internal_otp(formatted_phone, otp)
#
#             print(f"[DEBUG] WhatsApp Response: {res}")
#
#             # Redirect to OTP verification page
#             return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
#                 'phone': phone,
#                 'otp_sent': res.get('sent', False),
#                 'error': None if res.get('sent', False) else 'Failed to send OTP via WhatsApp'
#             })
#
#         return response
#
#     @http.route('/web/login/otp/verify', type='http', auth='public', website=True, methods=['POST'], csrf=False)
#     def verify_standard_login_otp(self, **post):
#         phone = post.get('phone')
#         otp = post.get('otp')
#
#         if not phone or not otp:
#             return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
#                 'phone': phone,
#                 'error': 'Missing phone or OTP code'
#             })
#
#         formatted_phone = format_mobile_number(phone)
#         hashed = hash_otp(otp)
#         now = datetime.now()
#         req_limit = now - relativedelta(minutes=3)
#
#         record = request.env['otp.code'].sudo().search([
#             ('phone_num', '=', formatted_phone),
#             ('req_time', '>=', req_limit)
#         ], order='req_time desc', limit=1)
#
#         if record and record.code_num == hashed:
#             # Valid OTP - restore the user's session
#             config_param = request.env['ir.config_parameter'].sudo()
#             param_name = f'vs_otp_gateway.verification_{formatted_phone}'
#             uid_str = config_param.get_param(param_name, False)
#
#             if uid_str:
#                 try:
#                     uid = int(uid_str)
#                     # Manually recreate the session instead of using authenticate
#                     request.session.uid = uid
#                     user = request.env['res.users'].sudo().browse(uid)
#                     if not user.exists():
#                         raise ValueError("User not found")
#
#                     # Set required session variables
#                     request.session.login = user.login
#                     request.session.session_token = user._compute_session_token(request.session.sid)
#                     request.update_env(user=uid)
#
#                     # Clear the verification data
#                     config_param.set_param(param_name, '')
#                     record.unlink()  # Remove the OTP record
#
#                     # Redirect to home page
#                     return werkzeug.utils.redirect('/web', 303)
#                 except Exception as e:
#                     print(f"[ERROR] Session restoration failed: {str(e)}")
#                     return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
#                         'phone': phone,
#                         'error': f'حدث خطأ أثناء تسجيل الدخول: {str(e)}'
#                     })
#             else:
#                 return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
#                     'phone': phone,
#                     'error': 'انتهت صلاحية الجلسة. يرجى تسجيل الدخول من جديد.'
#                 })
#         else:
#             return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
#                 'phone': phone,
#                 'error': 'رمز التحقق غير صحيح أو انتهت صلاحيته. حاول مرة أخرى.'
#             })
#
#     @http.route('/web/login/otp/resend', type='http', auth='public', website=True, methods=['POST'], csrf=False)
#     def resend_standard_login_otp(self, **post):
#         phone = post.get('phone')
#
#         if not phone:
#             return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
#                 'error': 'Missing phone number'
#             })
#
#         formatted_phone = format_mobile_number(phone)
#         otp = generate_otp()
#         hashed = hash_otp(otp)
#
#         # Remove old OTP records for this phone
#         request.env['otp.code'].sudo().search([
#             ('phone_num', '=', formatted_phone)
#         ]).unlink()
#
#         # Create new OTP record
#         request.env['otp.code'].sudo().create({
#             'phone_num': formatted_phone,
#             'req_time': datetime.now(),
#             'code_num': hashed,
#         })
#
#         # Send OTP via WhatsApp
#         res = request.env['vs.otp.gateway'].send_whatsapp_internal_otp(formatted_phone, otp)
#
#         return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
#             'phone': phone,
#             'otp_sent': res.get('sent', False),
#             'error': None if res.get('sent', False) else 'Failed to send OTP via WhatsApp'
#         })
class StandardLoginOTPController(Home):
    @http.route('/web/login', type='http', auth='public', website=True,
                methods=['GET', 'POST'], csrf=False)
    def web_login(self, redirect=None, **kw):
        response = super(StandardLoginOTPController, self).web_login(redirect=redirect, **kw)

        if request.httprequest.method == 'POST' and request.params.get('login_success'):
            config = request.env['ir.config_parameter'].sudo()
            if not config.get_param('vs_otp_gateway.enable_whatsapp_login_otp'):
                return response

            user = request.env['res.users'].sudo().browse(request.session.uid)
            phone = (
                user.phone
                or user.mobile
                or (user.partner_id and user.partner_id.phone)
                or (user.partner_id and user.partner_id.mobile)
            )
            if not phone:
                return response

            formatted = format_mobile_number(phone)
            otp = generate_otp()
            hashed = hash_otp(otp)
            request.env['otp.code'].sudo().create({
                'phone_num': formatted,
                'req_time': datetime.now(),
                'code_num': hashed,
            })

            sent = request.env['vs.otp.gateway'] \
                          .send_whatsapp_internal_otp(formatted, otp) \
                          .get('sent', False)

            request.session['otp_phone']     = phone
            request.session['otp_formatted'] = formatted
            request.session['otp_sent']      = bool(sent)
            config.set_param(f'vs_otp_gateway.verification_{formatted}', str(request.session.uid))

            # مسح بيانات المصادقة دون مسح بقية الـ session
            request.session.uid = None
            request.session.login = None
            request.session.session_token = None

            # Redirect نظيف للصفحة
            return werkzeug.utils.redirect('/web/login/otp/verify', 303)

        return response

    @http.route('/web/login/otp/verify', type='http', auth='public', website=True,
                methods=['GET', 'POST'], csrf=False)
    def verify_standard_login_otp(self, **post):
        if request.httprequest.method == 'GET':
            phone = request.session.get('otp_phone')
            formatted = request.session.get('otp_formatted', '')
            otp_sent = bool(request.session.get('otp_sent', False))
            return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
                'phone': phone,
                'formatted_phone': formatted,
                'otp_sent': otp_sent,
                'error': False,
            })

        phone = post.get('phone') or request.session.get('otp_phone')
        otp = post.get('otp')
        if not phone or not otp:
            return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
                'phone': phone,
                'formatted_phone': request.session.get('otp_formatted', ''),
                'otp_sent': False,
                'error': 'Missing phone or OTP code',
            })

        formatted = format_mobile_number(phone)
        hashed = hash_otp(otp)
        cutoff = datetime.now() - relativedelta(minutes=3)
        record = request.env['otp.code'].sudo().search([
            ('phone_num', '=', formatted),
            ('req_time', '>=', cutoff),
        ], order='req_time desc', limit=1)

        if record and record.code_num == hashed:
            param = f'vs_otp_gateway.verification_{formatted}'
            uid_str = request.env['ir.config_parameter'].sudo().get_param(param)
            if uid_str:
                uid = int(uid_str)
                user = request.env['res.users'].sudo().browse(uid)

                request.session.uid = uid
                request.session.login = user.login
                request.session.session_token = user._compute_session_token(request.session.sid)
                request.update_env(user=uid)

                # تنظيف البيانات
                request.env['ir.config_parameter'].sudo().set_param(param, '')
                record.unlink()

                return werkzeug.utils.redirect('/web', 303)
            error = 'انتهت صلاحية الجلسة. يرجى إعادة تسجيل الدخول.'
        else:
            error = 'رمز التحقق غير صحيح أو انتهت صلاحيته.'

        return request.render('vs_sms_whatsapp.standard_login_otp_verify', {
            'phone': phone,
            'formatted_phone': formatted,
            'otp_sent': False,
            'error': error,
        })

    @http.route('/web/login/otp/resend', type='http', auth='public', website=True,
                methods=['POST'], csrf=False)
    def resend_standard_login_otp(self, **post):
        phone = post.get('phone') or request.session.get('otp_phone')
        if not phone:
            return werkzeug.utils.redirect('/web/login', 303)

        formatted = request.session.get('otp_formatted') or format_mobile_number(phone)
        otp = generate_otp()
        hashed = hash_otp(otp)
        print(f"[DEBUG] Resend Generated OTP: {otp}")
        print(f"[DEBUG] Resend Hashed OTP: {hashed}")

        request.env['otp.code'].sudo().search([('phone_num', '=', formatted)]).unlink()
        request.env['otp.code'].sudo().create({
            'phone_num': formatted,
            'req_time': datetime.now(),
            'code_num': hashed,
        })

        res = request.env['vs.otp.gateway'] \
            .send_whatsapp_internal_otp(formatted, otp)
        print(f"[DEBUG] WhatsApp resend response: {res}")

        # 5) تحديث حالة الإرسال في الجلسة
        request.session['otp_sent'] = bool(res.get('sent', False))

        # 6) Redirect نظيف للصفحة
        return werkzeug.utils.redirect('/web/login/otp/verify', 303)