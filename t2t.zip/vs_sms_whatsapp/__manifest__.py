{
    "name": "VS OTP Gateway",
    "summary": "Send OTP via SMS or WhatsApp",
    "version": "1.0",
    "category": "Tools",
    "author": "Veronica Safwat - Sysgates",
    "depends": ['base', 'website', 'otp_authentication'],
    "data": [
        "security/ir.model.access.csv",
        "views/res_config.xml",
        "views/login_view.xml",
        "views/standard_login_otp.xml",
    ],
    'assets': {
        'web.assets_frontend': [
            'vs_sms_whatsapp/static/src/js/whatsapp_otp.js',
        ],
    },
    "installable": True,
    "auto_install": False,
}
