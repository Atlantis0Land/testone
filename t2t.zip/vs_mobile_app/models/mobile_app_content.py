from odoo import models, fields,api

class MobileAppContent(models.Model):
    _name = "mobile.app.content"
    _description = "Mobile App Page (HTML Content)"
    PAGE_TYPES = [
        ('contact', 'Contact Us'),
        ('about', 'About Us'),
        ('other', 'The Other'),
        ('terms', 'Terms And Condition'),
    ]
    ID_MAP = {'contact': 1, 'about': 2, 'other': 3,'terms':4}


    name = fields.Char(string="Page Name", required=True)
    content_html = fields.Html(string="Details",)
    page_type = fields.Selection(
        selection=PAGE_TYPES,
        string="Page Type",
        required=True,
        index=True,
        help="Choose what this content represents in the mobile app."
    )
    id_record = fields.Integer(
        string="ID Record",
        compute="_compute_id_record",
        store=True,
        readonly=True,
        help="Auto-filled: 1 for Contact Us, 2 for About Us, 3 for The Other."
    )

    @api.depends('page_type')
    def _compute_id_record(self):
        for rec in self:
            rec.id_record = self.ID_MAP.get(rec.page_type or 'other', 3)

    _sql_constraints = [
        ('unique_page_type', 'unique(page_type)', 'Each page type must be unique.')
    ]
