from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from odoo.http import request

HOME_CATEGORIES_MAP = {
    'news': 1, 'services': 4, 'events': 5, 'states': 6, 'participation': 7, 'suggestions': 8,
}

class MobileAPP(models.Model):
    _name = 'mobile.app.new'
    _description = 'Vs Mobile APP'

    name = fields.Selection([
        ('news', 'News'),
        ('news_category', 'News Category'),
        ('news_home', 'News Home'),
        ('event_home', 'Event Home'),
        ('services', 'Services'),
        ('events', 'Events'),
        ('states', 'States'),
        ('participation', 'Participation'),
        ('suggestions', 'Suggestions'),
    ], string="Category Type", required=True, index=True)
    # For News Home
    blog_ids = fields.Many2many('blog.post', string="Blogs")
    blog_limit = fields.Integer(string="Number of Blogs")

    # For Event Home
    event_ids = fields.Many2many('event.event', string="Events")
    event_limit = fields.Integer(string="Number of Events")

    title = fields.Char(string="Title")

    image = fields.Image(string="Icon Image", attachment=True, max_width=512, max_height=512)

    # نمسك آخر مرفق للصورة علشان نقدر نرجّع URL عام
    image_attachment_id = fields.Many2one(
        'ir.attachment', string="Icon Attachment", readonly=True, ondelete='set null'
    )

    id_record = fields.Integer(string="Home Item ID", compute="_compute_id_record", store=True, readonly=True)
    blog_blog_id = fields.Many2one('blog.blog', string="Blog")

    category_blog_id = fields.Integer(
        string="Category ID",
        compute="_compute_category_id",
        store=True, readonly=True,
    )
    active = fields.Boolean("Active")

    @api.depends('name', 'blog_blog_id')
    def _compute_category_id(self):
        for rec in self:
            rec.category_blog_id = rec.blog_blog_id.id if (rec.name == 'news_category' and rec.blog_blog_id) else False

    @api.constrains('name')
    def _check_unique_name_except_news_category(self):
        for rec in self:
            if rec.name and rec.name != 'news_category':
                dup = self.search_count([('name', '=', rec.name), ('id', '!=', rec.id)])
                if dup:
                    raise ValidationError(_("غير مسموح بتكرار هذا النوع. التكرار مسموح فقط لـ 'News Category'."))

    @api.depends('name')
    def _compute_id_record(self):
        for rec in self:
            rec.id_record = HOME_CATEGORIES_MAP.get(rec.name) or False

    # --------- مزامنة المرفق ليكون Public ---------
    @api.model
    def create(self, vals):
        rec = super().create(vals)
        if 'image' in vals:
            rec._sync_public_image_attachment('image')
        return rec

    def write(self, vals):
        res = super().write(vals)
        if 'image' in vals:
            self._sync_public_image_attachment('image')
        return res

    def _sync_public_image_attachment(self, field_name='image'):
        """يمسك آخر مرفق للصورة ويجعله Public ثم يحفظه في image_attachment_id."""
        Att = self.env['ir.attachment'].sudo()
        for rec in self:
            if not getattr(rec, field_name):
                rec.image_attachment_id = False
                continue
            att = Att.search([
                ('res_model', '=', self._name),
                ('res_id', '=', rec.id),
                ('res_field', '=', field_name),
            ], order='id desc', limit=1)
            if att:
                att.write({'public': True})
                rec.image_attachment_id = att.id

    def _get_base_url(self):
        if request and getattr(request, 'httprequest', None) and getattr(request.httprequest, 'host_url', None):
            return request.httprequest.host_url.rstrip('/')
        return (self.env['ir.config_parameter'].sudo().get_param('web.base.url') or '').rstrip('/')

    def get_public_image_url(self):
        self.ensure_one()
        if not self.image_attachment_id:
            return None
        return f"{self._get_base_url()}/web/image/{self.image_attachment_id.id}"
