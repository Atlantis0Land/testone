from odoo import models, fields

class MobileAppConfig(models.Model):
    _name = 'mobile.app.config'
    _description = 'Mobile App Settings'

    name = fields.Char(string="Name", default="Settings", required=True)
    news_per_page = fields.Integer(string="Number Per Page", default=10)
    # events_per_page = fields.Integer(string="Events Per Page", default=10)
