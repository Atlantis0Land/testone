# -*- coding: utf-8 -*-
from odoo import http, _
from odoo.http import request, content_disposition
import json
import base64

# =========================
# i18n Helpers
# =========================

SUPPORTED_LANGS = {"en_US", "ar_001"}
DEFAULT_LANG = "en_US"

_MSG_MAP = {
    "Not found": {"ar_001": "غير موجود"},
    "Unexpected server error": {"ar_001": "خطأ غير متوقع في الخادم"},
}

def _normalize_lang(lang):
    if not lang:
        return DEFAULT_LANG
    l = str(lang).strip().lower()
    if l.startswith("ar"):
        return "ar_001"
    if l.startswith("en"):
        return "en_US"
    return DEFAULT_LANG

def _get_lang():
    lang = request.params.get("lang")
    if not lang:
        lang = request.httprequest.form.get("lang")
    if not lang:
        body = request.httprequest.get_json(silent=True) or {}
        if isinstance(body, dict):
            lang = body.get("lang")
    return _normalize_lang(lang)

def _env_lang():

    lang = _get_lang()
    return request.env(context=dict(request.env.context, lang=lang)), lang

def _translate(msg, lang):
    if msg is None:
        return msg
    entry = _MSG_MAP.get(str(msg))
    if entry:
        return entry.get(lang, msg)
    try:
        return _(msg)
    except Exception:
        return msg

# =========================
# JSON helpers (لا تغيّر شكل الـ payload)
# =========================

def _json(payload, status=200):
    """Return JSON response with UTF-8."""
    return request.make_response(
        json.dumps(payload, ensure_ascii=False),
        headers=[('Content-Type', 'application/json; charset=utf-8')],
        status=status,
    )

def _host_base():
    """Return base host URL without trailing slash."""
    return request.httprequest.host_url.rstrip('/')

def _serialize_post(p, base):
    """Serialize a digital.post record to API-friendly dict."""
    # Debug logs
    print("Serializing post ID:", p.id)
    image_url = f"{base}/api/digital/posts/{p.id}/image" if p.image else None
    pdf_url = f"{base}/api/digital/posts/{p.id}/pdf" if p.attachment_pdf else None
    print("Image URL:", image_url)
    print("PDF URL:", pdf_url)

    return {
        'id': p.id,
        'name': p.name,
        'type': p.type,
        'sliced_content': p.sliced_content or '',
        'image_url': image_url,
        'pdf_url': pdf_url,
        'url': p.url or None,
    }

class DigitalPublicAPI(http.Controller):
    """Public (unauthenticated) API for Digital Posts."""

    @http.route('/api/digital/posts', type='http', auth='public', methods=['GET'], csrf=False)
    def list_posts(self, **kw):
        """
        GET /api/digital/posts
          ?type=policies|digital_participation|digital_topic
          &q=word
          &page=1
          &page_size=20
          &lang=ar_001|en_US
        """
        env, lang = _env_lang()

        # Pagination (keep same clamping behavior)
        try:
            page = int(kw.get('page', 1))
        except Exception:
            page = 1
        try:
            page_size = int(kw.get('page_size', 10))
        except Exception:
            page_size = 10
        page_size = min(max(page_size, 1), 100)

        post_type = kw.get('type')
        q = kw.get('q')

        # Domain
        domain = []
        if post_type:
            domain.append(('type', '=', post_type))
        if q:
            # (name OR content_html OR url) ilike q
            domain += ['|', '|', ('name', 'ilike', q), ('content_html', 'ilike', q), ('url', 'ilike', q)]

        Post = env['digital.post'].sudo()
        total = Post.search_count(domain)
        posts = Post.search(domain, order='id desc', limit=page_size, offset=(page - 1) * page_size)

        base = _host_base()
        results = [_serialize_post(p, base) for p in posts]

        return _json({
            'page': page,
            'page_size': page_size,
            'total': total,
            'results': results,
        })

    @http.route('/api/digital/posts/<int:post_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def post_detail(self, post_id, **_kw):
        """
        GET /api/digital/posts/<id>
        """
        env, lang = _env_lang()

        p = env['digital.post'].sudo().browse(post_id)
        if not p.exists():
            return _json({'error': 'not_found', 'message': _translate('Not found', lang)}, status=404)

        base = _host_base()
        return _json({
            'id': p.id,
            'name': p.name,
            'type': p.type,
            'content_html': p.content_html or '',
            'sliced_content': p.sliced_content or '',
            'image_url': f"{base}/api/digital/posts/{p.id}/image" if p.image else None,
            'pdf_url': f"{base}/api/digital/posts/{p.id}/pdf" if p.attachment_pdf else None,
            'url': p.url or None,
        })

    @http.route('/api/digital/cover', type='http', auth='public', methods=['GET'], csrf=False)
    def cover(self, **_kw):
        """
        GET /api/digital/cover
        """
        env, lang = _env_lang()
        company = env.company.sudo()
        base = _host_base()
        return _json({
            'cover_url': (
                f"{base}/web/image/res.company/{company.id}/cover_digital"
                if company.cover_digital else None
            )
        })

    @http.route('/api/digital/cover', type='http', auth='public', methods=['GET'], csrf=False)
    def cover(self, **_kw):
        """
        GET /api/digital/cover
        Returns the company's digital cover image URL.
        """
        env, lang = _env_lang()
        company = env.company.sudo()
        base = _host_base()

        cover_url = f"{base}/api/digital/cover/image" if company.cover_digital else None

        return _json({'cover_url': cover_url})

    @http.route('/api/digital/cover/image', type='http', auth='public', csrf=False)
    def cover_image(self, **_kw):
        """Return the company's cover image as binary data."""
        env, lang = _env_lang()
        company = env.company.sudo()
        if not company.cover_digital:
            return request.not_found()

        data = base64.b64decode(company.cover_digital)
        return request.make_response(
            data,
            headers=[('Content-Type', 'image/png')]
        )

    @http.route('/api/digital/posts/<int:post_id>/pdf', type='http', auth='public', methods=['GET'], csrf=False)
    def post_pdf_stream(self, post_id, **_kw):
        """
        GET /api/digital/posts/<id>/pdf
        Streams the PDF stored on field `attachment_pdf`.
        """
        env, lang = _env_lang()

        p = env['digital.post'].sudo().browse(post_id)
        if not p.exists() or not p.attachment_pdf:
            return _json({'error': 'not_found', 'message': _translate('Not found', lang)}, status=404)

        data = base64.b64decode(p.attachment_pdf or b'')
        filename = (p.name or 'document').replace('/', '_') + '.pdf'
        return request.make_response(
            data,
            headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Length', str(len(data))),
                ('Content-Disposition', content_disposition(filename)),
                ('Cache-Control', 'no-store'),
            ],
        )

    @http.route('/api/digital/post_types', type='http', auth='public', methods=['GET'], csrf=False)
    def post_types(self, **_kw):
        """
        GET /api/digital/post_types
        """
        env, lang = _env_lang()
        Post = env['digital.post']
        selection = dict(Post.sudo()._fields['type'].selection)

        return _json([{'key': k, 'label': _translate(v, lang)} for k, v in selection.items()])

    @http.route('/api/digital/posts/<int:post_id>/image', type='http', auth='public', csrf=False)
    def post_image(self, post_id, **_kw):
        env, lang = _env_lang()
        print("Fetching image for post ID:", post_id)
        p = env['digital.post'].sudo().browse(post_id)
        if not p.exists() or not p.image:
            return request.not_found()
        data = base64.b64decode(p.image)
        return request.make_response(
            data,
            headers=[('Content-Type', 'image/png')]
        )
