# -*- coding: utf-8 -*-

import json
import base64
from odoo import http, _, fields
from odoo.http import request, Response
from datetime import date
from urllib.parse import quote, urlparse, urlunparse
from lxml import etree
from bs4 import BeautifulSoup
import re
from urllib.parse import quote_plus

from collections import OrderedDict

def _get_limit_or_default(key, default=10):
    try:
        config = request.env['mobile.app.config'].sudo().search([], limit=1)
        return getattr(config, key, default) or default
    except Exception:
        return default


_URL_IN_STYLE = re.compile(r"url\((['\"]?)(.+?)\1\)", re.IGNORECASE)
_SCHEME_RE = re.compile(r'^[a-zA-Z][a-zA-Z0-9+.-]*:')

_XMLID_IN_WEB_IMAGE = re.compile(r"^/web/image/([a-zA-Z0-9_.-]+)(?:$|[/?#])")
_ATT_ANY = re.compile(r"^/web/image/(\d+)(?:-[^/]+)?(?:/[^?#]+)?$")


def _abs_url(u: str, base: str) -> str:
    """حوّل أي رابط إلى absolute على نفس الدومين، واترك non-http schemes و # كما هي."""
    if not u:
        return u
    u = u.strip()
    if u.startswith(("data:", "#")):
        return u
    if _SCHEME_RE.match(u) and not u.startswith(("http://", "https://")):
        return u
    if u.startswith("//"):
        scheme = "https" if base.startswith("https") else "http"
        return f"{scheme}:{u}"
    if u.startswith(("http://", "https://")):
        return u
    if u.startswith("/"):
        return base + u
    return base + "/" + u


def _att_public_url(att_id: int, base: str) -> str:
    """رابط بسيط ثابت للمرفق بدون checksum أو اسم ملف (أنسب للـ WebView)."""
    return base.rstrip('/') + f"/web/image/{int(att_id)}"


def _force_public_att_path(u: str, base: str) -> str:
    """
    لو الرابط لأي شكل من أشكال /web/image للمرفقات، حوّله إلى /web/image/<id> فقط.
    يشتغل على روابط absolute أو relative.
    """
    if not u:
        return u
    path = urlparse(u).path or ""
    m = _ATT_ANY.match(path)
    if m:
        return _att_public_url(m.group(1), base)
    return u


def _xmlid_to_public_image_url(xmlid: str, base: str) -> str or None:
    """
    حلّي /web/image/<xmlid>:
      - لو xmlid = ir.attachment ⇒ /web/image/<id>
      - لو بيشاور على موديل عنده image_1920/image ⇒ /web/image/<model>/<id>/<field>
        (ومش دايمًا نقدر نحوله لـ /web/image/<id> إلا لو الصورة أصلاً مرفق).
    """
    try:
        imd = request.env['ir.model.data'].sudo()
        try:
            model, res_id = imd.xmlid_to_res_model_res_id(xmlid)
        except Exception:
            rec = request.env.ref(xmlid, raise_if_not_found=False)
            if not rec:
                return None
            model, res_id = rec._name, rec.id

        if model == 'ir.attachment':
            return _att_public_url(res_id, base)

        rec = request.env[model].sudo().browse(res_id)
        if not rec.exists():
            return None
        field = 'image_1920' if 'image_1920' in rec._fields and rec['image_1920'] else (
                'image' if 'image' in rec._fields and rec['image'] else None)
        if field:
            tmp = base.rstrip('/') + f"/web/image/{model}/{res_id}/{field}"
            return _force_public_att_path(tmp, base)
        return None
    except Exception:
        return None


def _normalize_srcset(srcset_val: str, base: str) -> str:
    """حوّل srcset لروابط absolute وبسيطة (/web/image/<id> متى أمكن)."""
    parts = []
    for token in (srcset_val or "").split(","):
        t = token.strip()
        if not t:
            continue
        seg = t.split()
        url = seg[0]
        rest = " ".join(seg[1:])
        url_abs = _abs_url(url, base)

        # xmlid؟ حلّيها
        mxml = _XMLID_IN_WEB_IMAGE.match(urlparse(url_abs).path or "")
        if mxml:
            resolved = _xmlid_to_public_image_url(mxml.group(1), base)
            if resolved:
                url_abs = resolved

        url_abs = _force_public_att_path(url_abs, base)
        parts.append(url_abs + (" " + rest if rest else ""))
    return ", ".join(parts)


def _rewrite_style_urls(style_val: str, base: str) -> str:
    """بدّل أي url(...) داخل الـstyle إلى absolute وبسيط (/web/image/<id> متى أمكن)."""
    def repl(m):
        q, inner = m.group(1), m.group(2)
        absu = _abs_url(inner, base)

        mxml = _XMLID_IN_WEB_IMAGE.match(urlparse(absu).path or "")
        if mxml:
            resolved = _xmlid_to_public_image_url(mxml.group(1), base)
            if resolved:
                absu = resolved

        absu = _force_public_att_path(absu, base)
        return "url(" + (q or "") + absu + (q or "") + ")"
    return _URL_IN_STYLE.sub(repl, style_val or "")

SUPPORTED_LANGS = {"en_US", "ar_001"}
DEFAULT_LANG = "en_US"

_MSG_MAP = {
    "Unexpected server error": {"ar_001": "خطأ غير متوقع في الخادم"},
    "Invalid JSON in payload_json": {"ar_001": "JSON غير صالح في الحقل payload_json"},
    "Missing token in payload_json": {"ar_001": "مفقود التوكن في payload_json"},
    "Invalid or expired token": {"ar_001": "توكن غير صالح أو منتهي الصلاحية"},
    "Missing required fields: %s": {"ar_001": "حقول مطلوبة مفقودة: %s"},
    "Service Type not found": {"ar_001": "نوع الخدمة غير موجود"},
    "Invalid category_id: %s": {"ar_001": "category_id غير صالح: %s"},
    "Invalid sub_category_id: %s": {"ar_001": "sub_category_id غير صالح: %s"},
    "Invalid service_type_id: %s": {"ar_001": "service_type_id غير صالح: %s"},
    "Field config error: %s": {"ar_001": "خطأ في إعدادات الحقول: %s"},
    "At least one document is required but no file was uploaded.": {
        "ar_001": "مطلوب مستند واحد على الأقل ولكن لم يتم رفع أي ملف."
    },
    "Service request created successfully": {"ar_001": "تم إنشاء طلب الخدمة بنجاح"},
    "Invalid JSON body": {"ar_001": "هيكل JSON غير صالح"},
    "Missing token": {"ar_001": "التوكن مفقود"},
    "User not logged in": {"ar_001": "المستخدم غير مسجّل الدخول"},
    "Blog not found": {"ar_001": "المدونة غير موجودة"},
    "Event not found": {"ar_001": "الفعالية غير موجودة"},
    "Event category not found": {"ar_001": "فئة الفعالية غير موجودة"},
    "Blog category not found": {"ar_001": "فئة المدونة غير موجودة"},
    "Missing 'id' in URL": {"ar_001": "المعرّف مفقود في الرابط"},
    "Page not found": {"ar_001": "الصفحة غير موجودة"},
    "Arch retrieval error": {"ar_001": "خطأ أثناء جلب مخطط الصفحة"},
    "Failed to send email": {"ar_001": "فشل في إرسال البريد الإلكتروني"},
    "Email sent successfully": {"ar_001": "تم إرسال البريد الإلكتروني بنجاح"},
}

def _normalize_lang(lang):
    if not lang:
        return DEFAULT_LANG
    l = str(lang).strip().lower()
    if l.startswith("ar"):
        return "ar_001"
    if l.startswith("en"):
        return "en_US"
    return DEFAULT_LANG

def _get_lang():
    lang = request.params.get("lang")
    if not lang:
        lang = request.httprequest.form.get("lang")
    if not lang:
        data = request.httprequest.get_json(silent=True) or {}
        if isinstance(data, dict):
            lang = data.get("lang")
    return _normalize_lang(lang)

def _env_lang():
    lang = _get_lang()
    return request.env(context=dict(request.env.context, lang=lang)), lang

def _translate(msg, lang):
    if not msg:
        return msg
    entry = _MSG_MAP.get(str(msg))
    if entry:
        return entry.get(lang, msg)
    try:
        return _(msg)
    except Exception:
        return msg

# =========================
# Response + small helpers
# =========================

def _json_response(payload, status=200, headers=None):
    return Response(
        json.dumps(payload, ensure_ascii=False),
        status=status,
        content_type='application/json; charset=utf-8',
        headers=headers or []
    )

def _to_float(val, default=None):
    try:
        if val is None or val == '':
            return default
        return float(str(val).strip())
    except Exception:
        return default

def _ok_list(records, status=200):
    return _json_response({"success": True, "data": {"records": records}}, status=status)

def _ok_detail(record, status=200):
    return _json_response({"success": True, "data": record}, status=status)

def _err(message, status=400, extra=None):
    _, lang = _env_lang()
    msg = _translate(message, lang)
    payload = {"success": False, "message": msg}
    if extra:
        extra = dict(extra)
        if "detail" in extra and isinstance(extra["detail"], str):
            extra["detail"] = _translate(extra["detail"], lang)
        payload.update(extra)
    return _json_response(payload, status=status)

def get_image_from_cover(post):
    image = ""
    try:
        props = json.loads(post.cover_properties or '{}')
        bg = props.get('background-image', '')
        if bg.startswith("url("):
            image = bg[4:-1].strip("'").strip('"')
    except Exception:
        pass
    return image

def get_image_from_cover_event(event):
    cover_img_url = ""
    if event.cover_properties:
        try:
            props = json.loads(event.cover_properties)
            bg_img = props.get("background-image", "")
            if bg_img.startswith("url("):
                cover_img_url = bg_img[4:-1].strip("'").strip('"')
        except Exception:
            cover_img_url = ""
    return cover_img_url

def _translate_arch_string(arch_xml, page_id, lang):
    try:
        env, _ = _env_lang()
        page = env['website.page'].sudo().browse(page_id)
        if not page or not page.view_id:
            return arch_xml
        trs = env["ir.translation"].sudo().search([
            ("lang", "=", lang),
            ("type", "=", "model_terms"),
            ("name", "=", "ir.ui.view,arch_db"),
            ("res_id", "=", page.view_id.id),
        ])
        text = arch_xml
        for t in trs:
            src = t.src or ""
            val = t.value or ""
            if src and val and src != val and src in text:
                text = text.replace(src, val)
        return text
    except Exception:
        return arch_xml

# =========================
# CONTROLLER
# =========================

class ServicePortalController(http.Controller):
    """
    API endpoints with language-aware responses via ?lang=en_US / ar_001
    """

    # 1) GET /api/main_categories
    @http.route('/api/main_categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_main_categories(self, **kw):
        try:
            env, lang = _env_lang()
            main_cats = env['service.category'].sudo().search([])
            records = [{'id': c.id, 'name': c.name} for c in main_cats]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/main_categories/<int:main_id>/sub_categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_sub_categories(self, main_id, **kw):
        try:
            env, lang = _env_lang()
            subs = env['sub.service.category'].sudo().search([('category_id', '=', main_id)])
            records = [{'id': s.id, 'name': s.name} for s in subs]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/sub_categories/<int:sub_id>/service_types', type='http', auth='public', methods=['GET'], csrf=False)
    def get_service_types(self, sub_id, **kw):
        try:
            env, lang = _env_lang()
            types = env['service.type'].sudo().search([('sub_category_id', '=', sub_id)])
            records = [{'id': st.id, 'name': st.name} for st in types]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/service_types/<int:type_id>/fields_config', type='http', auth='public', methods=['GET'], csrf=False)
    def get_fields_config(self, type_id, **kw):
        try:
            env, lang = _env_lang()
            st = env['service.type'].sudo().browse(type_id)
            if not st.exists():
                return _err("Service Type not found", 404)
            config = st.get_fields_config()
            return _ok_detail(config)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})


    @http.route('/api/create/service', type='http', auth='public', methods=['POST'], csrf=False)
    def create_service_request(self, **post):
        env, lang = _env_lang()

        raw_json = request.httprequest.form.get('payload_json')
        try:
            payload = json.loads(raw_json or '{}')
        except Exception:
            return _err('Invalid JSON in payload_json', 400)

        token = payload.get('token') or request.httprequest.form.get('token')
        if not token:
            return _err('Missing token in payload_json', 401)

        partner = env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        if not partner:
            return _err('Invalid or expired token', 401)

        category_id = payload.get('category_id')
        sub_category_id = payload.get('sub_category_id')
        service_type_id = payload.get('service_type_id')
        fields_data = payload.get('fields_data') or {}

        missing = [f for f in ('category_id', 'sub_category_id', 'service_type_id') if not payload.get(f)]
        if missing:
            return _err('Missing required fields: %s' % ', '.join(missing), 400, {"missing_fields": missing})

        category = env['service.category'].sudo().browse(int(category_id))
        sub_category = env['sub.service.category'].sudo().browse(int(sub_category_id))
        st = env['service.type'].sudo().browse(int(service_type_id))
        if not category.exists():
            return _err('Invalid category_id: %s' % category_id, 400)
        if not sub_category.exists():
            return _err('Invalid sub_category_id: %s' % sub_category_id, 400)
        if not st.exists():
            return _err('Invalid service_type_id: %s' % service_type_id, 400)

        try:
            field_config = st.get_fields_config()
            required_fields = [f['name'] for f in field_config.get('fields', []) if f.get('required')]
        except Exception as e:
            return _err('Field config error: %s' % str(e), 400)

        missing_required = []
        for fname in required_fields:
            val = fields_data.get(fname)
            if val is None or (isinstance(val, str) and not val.strip()):
                missing_required.append(fname)
        if missing_required:
            return _err('Missing required fields: %s' % ', '.join(missing_required), 400,
                        {"missing_fields": missing_required})

        try:
            national_id = fields_data.get('national_id')
            if national_id:
                partner.sudo().write({'national_id': national_id})

            phone = partner.phone or getattr(partner, 'mobile', False) or ''

            # الإحداثيات
            lat = fields_data.get('lat', fields_data.get('latitude'))
            lng = fields_data.get('lng', fields_data.get('longitude'))
            if 'lat' in request.httprequest.form and lat is None:
                lat = request.httprequest.form.get('lat')
            if 'lng' in request.httprequest.form and lng is None:
                lng = request.httprequest.form.get('lng')
            if 'latitude' in request.httprequest.form and lat is None:
                lat = request.httprequest.form.get('latitude')
            if 'longitude' in request.httprequest.form and lng is None:
                lng = request.httprequest.form.get('longitude')

            lat = _to_float(lat)
            lng = _to_float(lng)

            # ==== تكوين Google Maps URL تلقائيًا ====
            location_url = None
            location_raw = (
                    fields_data.get('location')
                    or fields_data.get('location_url')
                    or request.httprequest.form.get('location')
                    or request.httprequest.form.get('location_url')
            )

            # لو location مكتوب كنص → حوّله لرابط Google Maps
            if location_raw and isinstance(location_raw, str) and location_raw.strip():
                encoded_location = quote_plus(location_raw.strip())
                location_url = f"https://www.google.com/maps/search/?api=1&query={encoded_location}"

            # لو مفيش location ولكن فيه lat/lng → كوّن رابط
            if not location_url and lat is not None and lng is not None:
                lat_s = f"{lat:.6f}"
                lng_s = f"{lng:.6f}"
                location_url = f"https://www.google.com/maps/search/?api=1&query={lat_s},{lng_s}"

            # القيم اللي هتتسجل في الخدمة
            vals = {
                'category_id': int(category_id),
                'sub_category_id': int(sub_category_id),
                'service_type_id': int(service_type_id),
                'partner_id': partner.id,
                'phone': phone,
                'name': st.name,
                'date': date.today(),
            }

            for k, v in fields_data.items():
                if k.endswith('_id') and str(v).isdigit():
                    vals[k] = int(v)
                elif k not in [
                    'national_id', 'phone',
                    'lat', 'lng', 'latitude', 'longitude',
                    'token', 'location', 'location_url'
                ]:
                    vals[k] = v

            if lat is not None:
                vals['latitude'] = lat
            if lng is not None:
                vals['longitude'] = lng
            if location_url:
                vals['location'] = location_url

            new_req = env['service.request'].sudo().create(vals)
        except Exception as e:
            return _err(str(e), 400)

        # ========== المرفقات ==========
        attached = []
        files_list = []
        for field_name in request.httprequest.files:
            files_list.extend(request.httprequest.files.getlist(field_name))

        doc_types = st.config_id.document_type_ids
        requirer_required = st.config_id.requirer_document == 'required'
        if requirer_required and not files_list:
            return _err('At least one document is required but no file was uploaded.', 400)

        for i, fs in enumerate(files_list):
            try:
                data = fs.read()
                doc = doc_types[i] if i < len(doc_types) else None

                chatter_attachment = env['ir.attachment'].sudo().create({
                    'name': fs.filename,
                    'type': 'binary',
                    'datas': base64.b64encode(data).decode('utf-8'),
                    'res_model': 'service.request',
                    'res_id': new_req.id,
                    'mimetype': fs.mimetype,
                })

                doc_attachment_vals = {
                    'request_id': new_req.id,
                    'file_name': fs.filename,
                    'attachment_id': chatter_attachment.id,
                }
                if doc:
                    doc_attachment_vals['document_id'] = doc.id

                doc_attachment = env['attachment.document.request'].sudo().create(doc_attachment_vals)
                attached.append(doc_attachment.id)
            except Exception:
                continue

        return _ok_detail({
            'service_id': new_req.id,
            'message': _translate('Service request created successfully', lang),
            'attached_ids': attached,
        })

    @http.route('/api/my_service/services', type='http', auth='public', methods=['GET'], csrf=False)
    def myservice_all_services(self, **kw):
        """
        Return all services for this token with optional filters in query params
        (e.g. category_id, sub_category_id, service_type_id, reference)
        """
        try:
            env, lang = _env_lang()
            try:
                payload = json.loads(request.httprequest.data or '{}')
            except Exception:
                return _err('Invalid JSON body', 400)

            token = payload.get("token")
            if not token:
                return _err('Missing token', 401)

            partner = env['res.partner'].sudo().search([('token', '=', token)], limit=1)
            if not partner:
                return _err('Invalid or expired token', 401)

            domain = [('partner_id', '=', partner.id)]

            category_id = request.params.get("category_id")
            if category_id:
                domain.append(('category_id', '=', int(category_id)))

            sub_category_id = request.params.get("sub_category_id")
            if sub_category_id:
                domain.append(('sub_category_id', '=', int(sub_category_id)))

            service_type_id = request.params.get("service_type_id")
            if service_type_id:
                domain.append(('service_type_id', '=', int(service_type_id)))

            reference = request.params.get("reference")
            if reference:
                domain.append(('reference', 'ilike', reference))

                # ✅ Get limit from query param or config
            limit = _get_limit_or_default('limit', 'news_per_page', fallback=10)

            services = env['service.request'].sudo().search(domain, order='id desc', limit=limit)

            records = []
            for srv in services:
                records.append({
                    "id": srv.id,
                    "reference": srv.reference or "",
                    "name": srv.name or "",
                    "date": srv.date and srv.date.strftime("%Y-%m-%dT%H:%M:%S") or "",
                    "location": srv.location or "",
                    "latitude": srv.latitude,
                    "longitude": srv.longitude,
                    "category": (srv.category_id and {"id": srv.category_id.id, "name": srv.category_id.name}) or None,
                    "sub_category": (srv.sub_category_id and {"id": srv.sub_category_id.id, "name": srv.sub_category_id.name}) or None,
                    "service_type": (srv.service_type_id and {"id": srv.service_type_id.id, "name": srv.service_type_id.name}) or None,
                    "stage": (srv.stage_id and {"id": srv.stage_id.id, "name": srv.stage_id.name}) or None,
                })

            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/governments', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_governments(self, **kw):
        try:
            env, lang = _env_lang()
            governments = env['res.country.government'].sudo().search([])
            records = [{
                'id': g.id,
                'government_name': g.name,
                'country_id': g.country_id.id if g.country_id else False,
            } for g in governments]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/governments/<int:gov_id>/states', type='http', auth='public', methods=['GET'], csrf=False)
    def get_states_by_government(self, gov_id, **kw):
        try:
            env, lang = _env_lang()
            states = env['res.country.state'].sudo().search([('government_id', '=', gov_id)])
            records = [{'id': s.id, 'state_name': s.name, 'state_code': s.code} for s in states]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/states/<int:state_id>/villages', type='http', auth='public', methods=['GET'], csrf=False)
    def get_villages_by_state(self, state_id, **kw):
        try:
            env, lang = _env_lang()
            villages = env['res.state.village'].sudo().search([('state_id', '=', state_id)])
            records = [{'id': v.id, 'village_name': v.name, 'village_code': v.code} for v in villages]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/service_types/<int:service_type_id>/document_types', type='http', auth='public', methods=['GET'], csrf=False)
    def get_document_type_count(self, service_type_id, **kw):
        try:
            env, lang = _env_lang()
            st = env['service.type'].sudo().browse(service_type_id)
            if not st.exists():
                return _err("Invalid service_type_id: %s" % service_type_id, 404)
            docs = st.config_id.document_type_ids
            doc_list = [{'id': d.id, 'name': d.name} for d in docs]
            return _ok_detail({
                'service_type_id': service_type_id,
                'document_type_count': len(doc_list),
                'document_types': doc_list
            })
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/services', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_services(self, **kwargs):
        try:
            env, lang = _env_lang()
            limit = _get_limit_or_default('news_per_page', 10)
            services = env['service.request'].sudo().search([], order="id desc", limit=limit)

            # services = ServiceRequest.search([], order='id desc')
            records = []
            for srv in services:
                records.append({
                    'id': srv.id,
                    'reference': srv.reference or '',
                    'name': srv.name or '',
                    'date': srv.date and srv.date.strftime("%Y-%m-%dT%H:%M:%S") or False,
                    'category': {'id': srv.category_id.id, 'name': srv.category_id.name or ''} if srv.category_id else False,
                    'sub_category': {'id': srv.sub_category_id.id, 'name': srv.sub_category_id.name or ''} if srv.sub_category_id else False,
                    'service_type': {'id': srv.service_type_id.id, 'name': srv.service_type_id.name or ''} if srv.service_type_id else False,
                    'stage': {'id': srv.stage_id.id, 'name': srv.stage_id.name or ''} if srv.stage_id else None,
                    'latitude': srv.latitude,
                    'longitude': srv.longitude,
                })
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    @http.route('/api/service_request/<int:request_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_service_request_detail(self, request_id, **kwargs):
        env, lang = _env_lang()
        rec = env['service.request'].sudo().browse(request_id)
        if not rec.exists():
            return _err('Service Request ID %s not found' % request_id, 404)

        base_url = request.httprequest.host_url.rstrip('/')

        attachments = []
        for att in rec.attachment_ids:
            file_url = ''
            view_url = ''
            image_url = ''
            mimetype = 'application/octet-stream'
            filename = att.file_name or ''
            size = 0
            is_public = False

            if att.attachment_id:
                ia = att.attachment_id.sudo()
                mimetype = ia.mimetype or mimetype
                filename = filename or ia.name or ''
                size = getattr(ia, 'file_size', 0) or 0
                is_public = bool(getattr(ia, 'public', False))

                token_param = ''
                if not is_public:
                    if not ia.access_token:
                        ia.generate_access_token()
                    token_param = f"&access_token={ia.access_token}"

                view_url = f"{base_url}/web/content/{ia.id}?filename={quote(filename)}{token_param}"
                file_url = f"{base_url}/web/content/{ia.id}?download=true&filename={quote(filename)}{token_param}"
                if mimetype.startswith('image/'):
                    image_url = f"{base_url}/web/image/{ia.id}?filename={quote(filename)}{token_param}"

            attachments.append({
                'id': att.id,
                'document_type': att.document_id.name if att.document_id else '',
                'file_name': filename,
                'mimetype': mimetype,
                'file_size': size,
                'public': is_public,
                'attachment_url': file_url,
                'view_url': view_url,
                'image_url': image_url,
            })

        responses = [{
            'response': line.response,
            'date': line.date.strftime("%Y-%m-%d") if line.date else '',
            'date_time': line.date_time.strftime("%Y-%m-%d %H:%M:%S") if line.date_time else '',
        } for line in rec.response_line_ids]

        fields_config = []
        if rec.service_type_id:
            try:
                config = rec.service_type_id.get_fields_config()
                fields_config = config.get('fields', [])
            except Exception:
                fields_config = []

        return _ok_detail({
            'id': rec.id,
            'reference': rec.reference or '',
            'name': rec.name or '',
            'date': rec.date and rec.date.strftime("%Y-%m-%d") or '',
            'phone': rec.phone or '',
            'location': rec.location or '',
            'national_id': rec.national_id or '',
            'from_date': rec.from_date and rec.from_date.strftime("%Y-%m-%d") or '',
            'to_date': rec.to_date and rec.to_date.strftime("%Y-%m-%d") or '',
            'state': rec.state_id.name if rec.state_id else '',
            'government': rec.government_id.name if rec.government_id else '',
            'village': rec.village_name_id.name if rec.village_name_id else '',
            'category': rec.category_id.name if rec.category_id else '',
            'sub_category': rec.sub_category_id.name if rec.sub_category_id else '',
            'service_type': rec.service_type_id.name if rec.service_type_id else '',
            'service_type_id': rec.service_type_id.id if rec.service_type_id else False,
            'stage': rec.stage_id.name if rec.stage_id else '',
            'partner': rec.partner_id.name if rec.partner_id else '',
            'latitude': rec.latitude,
            'longitude': rec.longitude,
            'attachments': attachments,
            'responses': responses,
            'fields_config': fields_config,
        })

    @http.route('/api/user/info', type='http', auth='public', methods=['GET'], csrf=False)
    def get_logged_in_user_info(self, **kwargs):
        env, lang = _env_lang()
        uid = request.session.uid
        if not uid:
            return _err('User not logged in', 401)

        try:
            user = env['res.users'].sudo().browse(uid)
            partner = user.partner_id
            return _ok_detail({
                'user_id': user.id,
                'user_name': user.name,
                'partner_id': partner.id,
                'partner_name': partner.name,
                'national_id': partner.national_id or '',
                'phone': partner.phone or '',
            })
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # ---------- BLOGS ----------
    @http.route('/api/blogs', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_blogs(self, **kwargs):
        try:
            env, lang = _env_lang()

            search_text = kwargs.get("search")
            domain = [('website_published', '=', True)]

            if search_text:
                domain += ['|',
                           ('name', 'ilike', search_text),
                           ('blog_id.name', 'ilike', search_text)]

            limit = _get_limit_or_default('news_per_page', 10)
            posts = env['blog.post'].sudo().search(domain, order="create_date desc", limit=limit)

            records = []
            for post in posts:
                records.append({
                    "id": post.id,
                    "title": post.name,
                    "author": post.author_id.name if post.author_id else "",
                    "image": get_image_from_cover(post),
                    "date": post.create_date.strftime('%Y-%m-%d'),
                    "category": post.blog_id.name if post.blog_id else "",
                })

            return _json_response({"success": True, "data": {"records": records}}, status=200)

        except Exception as e:
            return _json_response({
                "success": False,
                "message": _translate("Unexpected server error", _get_lang()),
                "detail": str(e)
            }, status=500)

    @http.route('/api/blog/categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_blog_categories(self, **kwargs):
        try:
            env, lang = _env_lang()
            categories = env['blog.blog'].sudo().search([])
            records = [{
                "id": cat.id,
                "name": cat.name,
                "description": cat.subtitle or "",
            } for cat in categories]
            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": _translate("Unexpected server error", _get_lang()), "detail": str(e)}, status=500)

    @http.route('/api/blogs/<int:blog_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_blog_detail(self, blog_id, **kwargs):
        try:
            env, lang = _env_lang()
            post = env['blog.post'].sudo().browse(blog_id)
            if not post.exists():
                return _json_response({"success": False, "message": _translate("Blog not found", lang)}, status=404)

            base_url = request.httprequest.host_url.rstrip('/')
            record = {
                "id": post.id,
                "title": post.name,
                "content": post.content or "",
                "category": post.blog_id.name if post.blog_id else "",
                "image": get_image_from_cover(post),
                "url": f"{base_url}{post.website_url}",
            }
            return _json_response({"success": True, "data": record}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": _translate("Unexpected server error", _get_lang()), "detail": str(e)}, status=500)

    # ---------- EVENTS ----------
    @http.route('/api/events/categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_event_categories(self, **kwargs):
        try:
            env, lang = _env_lang()
            categories = env['event.type'].sudo().search([])
            records = [{"id": cat.id, "name": cat.name} for cat in categories]
            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": _translate("Unexpected server error", _get_lang()), "detail": str(e)}, status=500)

    @http.route('/api/events', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_events(self, **kwargs):
        try:
            env, lang = _env_lang()
            limit = _get_limit_or_default('news_per_page', 10)
            events = env['event.event'].sudo().search([], order="date_begin desc", limit=limit)
            records = []
            for event in events:
                records.append({
                    "id": event.id,
                    "name": event.name,
                    "date_begin": event.date_begin.strftime('%Y-%m-%d %H:%M:%S') if event.date_begin else "",
                    "date_end": event.date_end.strftime('%Y-%m-%d %H:%M:%S') if event.date_end else "",
                    "category": event.event_type_id.name if event.event_type_id else "",
                    "image": get_image_from_cover_event(event),
                    "address": event.address_id.display_name if event.address_id else "",
                    "seats_available": event.seats_available,
                    "seats_max": event.seats_max,
                })
            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": _translate("Unexpected server error", _get_lang()), "detail": str(e)}, status=500)

    @http.route('/api/events/<int:event_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_event_detail(self, event_id, **kwargs):
        try:
            env, lang = _env_lang()
            event = env['event.event'].sudo().browse(event_id)
            if not event.exists():
                return _json_response({"success": False, "message": _translate("Event not found", lang)}, status=404)

            base_url = request.httprequest.host_url.rstrip('/')
            record = {
                "id": event.id,
                "name": event.name,
                "description": event.description or "",
                "date_begin": event.date_begin.strftime('%Y-%m-%d %H:%M:%S') if event.date_begin else "",
                "date_end": event.date_end.strftime('%Y-%m-%d %H:%M:%S') if event.date_end else "",
                "category": event.event_type_id.name if event.event_type_id else "",
                "image": get_image_from_cover_event(event),
                "address": event.address_id.display_name if event.address_id else "",
                "seats_available": event.seats_available,
                "seats_max": event.seats_max,
                "website_url": f"{base_url}{event.website_url}" if event.website_url else "",
            }
            return _json_response({"success": True, "data": record}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": _translate("Unexpected server error", _get_lang()), "detail": str(e)}, status=500)

    @http.route('/api/events/categories/<int:category_id>/events', type='http', auth='public', methods=['GET'], csrf=False)
    def get_events_by_category(self, category_id, **kwargs):
        try:
            env, lang = _env_lang()
            event_category = env['event.type'].sudo().browse(category_id)
            if not event_category.exists():
                return _json_response({"success": False, "message": _translate("Event category not found", lang)}, status=404)

            events = env['event.event'].sudo().search([('event_type_id', '=', category_id)], order="date_begin desc")

            base_url = request.httprequest.host_url.rstrip('/')

            records = []
            for event in events:
                records.append({
                    "id": event.id,
                    "name": event.name,
                    "description": event.description or "",
                    "date_begin": event.date_begin.strftime('%Y-%m-%d %H:%M:%S') if event.date_begin else "",
                    "date_end": event.date_end.strftime('%Y-%m-%d %H:%M:%S') if event.date_end else "",
                    "category": event_category.name,
                    "image": get_image_from_cover_event(event),
                    "address": event.address_id.display_name if event.address_id else "",
                    "seats_available": event.seats_available,
                    "seats_max": event.seats_max,
                    "url": f"{base_url}{event.website_url}" if event.website_url else "",
                })

            return _json_response({"success": True, "data": {"category": event_category.name, "records": records}}, status=200)

        except Exception as e:
            return _json_response({"success": False, "message": _translate("Unexpected server error", _get_lang()), "detail": str(e)}, status=500)

    @http.route('/api/blog/categories/<int:category_id>/posts', type='http', auth='public', methods=['GET'], csrf=False)
    def get_blogs_by_category(self, category_id, **kwargs):
        try:
            env, lang = _env_lang()
            blog_category = env['blog.blog'].sudo().browse(category_id)
            if not blog_category.exists():
                return _json_response(
                    {"success": False, "message": _translate("Blog category not found", lang)},
                    status=404
                )

            # باراميتر البحث في العنوان فقط
            search = (request.httprequest.args.get('search') or '').strip()
            domain = [
                ('blog_id', '=', category_id),
                ('website_published', '=', True)
            ]
            if search:
                domain.append(('name', 'ilike', search))

            posts = env['blog.post'].sudo().search(domain, order="create_date desc")

            base_url = request.httprequest.host_url.rstrip('/')

            records = []
            for post in posts:
                records.append({
                    "id": post.id,
                    "title": post.name,
                    "author": post.author_id.name if post.author_id else "",
                    "image": get_image_from_cover(post),
                    "date": post.create_date.strftime('%Y-%m-%d'),
                    "category": blog_category.name,
                    "url": f"{base_url}{post.website_url}",
                })

            return _json_response(
                {"success": True, "data": {"category": blog_category.name, "records": records}},
                status=200
            )

        except Exception as e:
            return _json_response(
                {"success": False, "message": _translate("Unexpected server error", _get_lang()), "detail": str(e)},
                status=500)

    @http.route("/api/website/page/<int:page_id>", type="http", auth="public", methods=["GET"], csrf=False,
                website=True)
    def get_page(self, page_id=None, **kwargs):
        """
               format=json (default): يرجّع JSON بنفس هيكلة data.arch/images
               format=html           : يرجّع HTML كامل مناسب للـWebView
               raw=1                 : عند format=html يرجّع الـwrap فقط بدون <html> غلاف
               lang=<code>           : ar_001 / en_US ...
               """
        try:
            lang = kwargs.get('lang') or request.env.lang

            base_url = request.httprequest.host_url.rstrip('/')

            Page = request.env['website.page'].with_context(lang=lang).sudo()
            page = Page.search([
                ('id', '=', int(page_id)),
                ('website_id', '=', request.website.id),
            ], limit=1)

            if not page:
                if (kwargs.get('format') or 'json').lower() == 'html':
                    return Response("Page not found.", status=404, content_type="text/plain; charset=utf-8")
                return Response(json.dumps({
                    "success": False,
                    "message": "Page not found (wrong id or website)."
                }), status=404, content_type="application/json; charset=utf-8")

            # قابلية الظهور (زي is_visible)
            visible = page.website_published and (not page.date_publish or page.date_publish < fields.Datetime.now())
            if not visible:
                if (kwargs.get('format') or 'json').lower() == 'html':
                    return Response("Page is not published/visible.", status=403,
                                    content_type="text/plain; charset=utf-8")
                return Response(json.dumps({
                    "success": False,
                    "message": "Page is not published/visible."
                }), status=403, content_type="application/json; charset=utf-8")

            # --- خُذ الـ arch (HTML للصفحة) ---
            arch_xml = page.view_id.sudo().arch or ""
            if not arch_xml.strip():
                fmt = (kwargs.get('format') or 'json').lower()
                if fmt == 'html':
                    html = f"""<!doctype html>
        <html lang="ar" dir="auto">
        <head>
        <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{page.name or ''}</title>
        <style>img{{max-width:100%;height:auto}}body{{margin:0;padding:0}}</style>
        </head><body></body></html>"""
                    return Response(html, status=200, content_type="text/html; charset=utf-8")
                else:
                    return Response(json.dumps({
                        "success": True,
                        "data": {
                            "id": page.id,
                            "name": page.name,
                            "url": page.url or "",
                            "arch": "",
                            "images": [],
                            "base_url": base_url,
                        }
                    }), status=200, content_type="application/json; charset=utf-8")

            # --- حدد <div id="wrap"> لو موجود ---
            try:
                root = etree.fromstring(arch_xml.encode('utf-8'))
                wrap_div = root.xpath(".//div[@id='wrap']")
                raw_html = etree.tostring(wrap_div[0] if wrap_div else root, encoding='unicode', method='html')
            except Exception:
                raw_html = arch_xml

            # --- نظّف وروّح absolutize باستخدام BeautifulSoup ---
            soup = BeautifulSoup(raw_html, "html.parser")

            # 1) <img> tags: src/data-src/data-original-src/data-original-id + srcset
            for img in soup.find_all('img'):
                src = img.get('src') or img.get('data-src') or img.get('data-original-src')
                if not src and img.get('data-original-id'):
                    # fallback لو جاي رقم attachment id
                    src = f"/web/image/{img.get('data-original-id')}"
                if src:
                    src = _abs_url(src, base_url)

                    # xmlid؟ حلّيها
                    mxml = _XMLID_IN_WEB_IMAGE.match(urlparse(src).path or "")
                    if mxml:
                        resolved = _xmlid_to_public_image_url(mxml.group(1), base_url)
                        if resolved:
                            src = resolved

                    # قصّه لمسار /web/image/<id> لو كان مرفق
                    src = _force_public_att_path(src, base_url)
                    img['src'] = src

                if img.get('srcset'):
                    img['srcset'] = _normalize_srcset(img.get('srcset'), base_url)
                if img.get('data-srcset'):
                    img['srcset'] = _normalize_srcset(img.get('data-srcset'), base_url)
                    img.attrs.pop('data-srcset', None)

                # لتفادي مشاكل WebView في التحميل الكسول
                for k in ['data-src', 'data-original-src', 'data-original-id']:
                    img.attrs.pop(k, None)
                img['loading'] = 'eager'

            # 2) الخلفيات وروابط أخرى
            for el in soup.find_all(True):
                # data-bg-url -> CSS background + fallback <img>
                if el.has_attr('data-bg-url'):
                    bg = el['data-bg-url']
                    abs_bg = _abs_url(bg, base_url)

                    # xmlid؟ حلّيها
                    mxml = _XMLID_IN_WEB_IMAGE.match(urlparse(abs_bg).path or "")
                    if mxml:
                        resolved = _xmlid_to_public_image_url(mxml.group(1), base_url)
                        if resolved:
                            abs_bg = resolved

                    # قصّه لمسار /web/image/<id> لو كان مرفق
                    abs_bg = _force_public_att_path(abs_bg, base_url)

                    style = el.get('style', '')
                    if "background-image" not in style:
                        style = (style + f"; background-image: url('{abs_bg}');").strip(";")
                    el['style'] = _rewrite_style_urls(style, base_url)

                    # أضف Fallback صورة (تفيد WebView)
                    has_fallback = el.find('img', attrs={'class': '__bgimg_fallback'})
                    if not has_fallback:
                        fallback = soup.new_tag('img')
                        fallback['class'] = "__bgimg_fallback img-fluid"
                        fallback['src'] = abs_bg
                        fallback['style'] = "width:100%;height:auto;display:block;"
                        el.append(fallback)
                    el.attrs.pop('data-bg-url', None)

                # أي style فيه url(...) -> absolute + تبسيط لمسار المرفق
                if el.has_attr('style'):
                    el['style'] = _rewrite_style_urls(el['style'], base_url)

                # <source> داخل <picture>
                if el.name == 'source' and el.get('srcset'):
                    el['srcset'] = _normalize_srcset(el.get('srcset'), base_url)

                # <a href> و <link href> -> absolute (واترك # كما هو)
                if el.has_attr('href'):
                    href = el['href']
                    if href and not href.startswith("#"):
                        el['href'] = _abs_url(href, base_url)

            # اجمع كل روابط الصور النهائية (للـprefetch في الموبايل)
            image_urls = []
            for img in soup.find_all('img'):
                if img.get('src') and not img['src'].startswith('data:'):
                    image_urls.append(img['src'])
            image_urls = list(dict.fromkeys(image_urls))  # unique

            clean_html = str(soup)

            # --- إخراج حسب format ---
            fmt = (kwargs.get('format') or 'json').lower()
            if fmt == 'html':
                if kwargs.get('raw') == '1':
                    return Response(clean_html, status=200, content_type="text/html; charset=utf-8")

                html = f"""<!doctype html>
        <html lang="ar" dir="auto">
        <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{page.name or ''}</title>
        <style>
          html,body{{margin:0;padding:0}}
          img{{max-width:100%;height:auto;display:block}}
          .__bgimg_fallback{{display:block}}
        </style>
        </head>
        <body>
        {clean_html}
        </body>
        </html>"""
                return Response(html, status=200, content_type="text/html; charset=utf-8")
            else:
                payload = {
                    "success": True,
                    "data": {
                        "id": page.id,
                        "name": page.name,
                        "url": page.url or "",
                        "arch": clean_html,
                        "images": image_urls,
                        "base_url": base_url,
                    }
                }
                return Response(
                    json.dumps(payload),
                    status=200,
                    headers={
                        "Access-Control-Allow-Origin": "*",
                        "Cache-Control": "no-store",
                    },
                    content_type="application/json; charset=utf-8"
                )

        except Exception as e:
            fmt = (kwargs.get('format') or 'json').lower()
            if fmt == 'html':
                return Response(f"Error while processing page:\n{e}", status=500,
                                content_type="text/plain; charset=utf-8")
            return Response(json.dumps({
                "success": False,
                "message": "خطأ أثناء معالجة الصفحة",
                "error": str(e)
            }), status=500, content_type="application/json; charset=utf-8")
        # try:
        #     lang = kwargs.get('lang') or request.env.lang
        #     base_url = request.httprequest.host_url.rstrip('/')
        #
        #     Page = request.env['website.page'].with_context(lang=lang).sudo()
        #     page = Page.search([
        #         ('id', '=', int(page_id)),
        #         ('website_id', '=', request.website.id),
        #     ], limit=1)
        #     if not page:
        #         return Response("Page not found.", status=404, content_type="text/plain; charset=utf-8")
        #
        #     visible = page.website_published and (not page.date_publish or page.date_publish < fields.Datetime.now())
        #     if not visible:
        #         return Response("Page is not published/visible.", status=403, content_type="text/plain; charset=utf-8")
        #
        #     arch_xml = page.view_id.sudo().arch or ""
        #     if not arch_xml.strip():
        #         html = f"""<!doctype html>
        # <html lang="ar" dir="auto">
        # <head>
        # <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
        # <title>{page.name or ''}</title>
        # <style>img{{max-width:100%;height:auto}}body{{margin:0;padding:0}}</style>
        # </head><body></body></html>"""
        #         return Response(html, status=200, content_type="text/html; charset=utf-8")
        #
        #     # التزم بـ <div id="wrap"> لو موجود
        #     try:
        #         root = etree.fromstring(arch_xml.encode('utf-8'))
        #         wrap_div = root.xpath(".//div[@id='wrap']")
        #         raw_html = etree.tostring(wrap_div[0] if wrap_div else root, encoding='unicode', method='html')
        #     except Exception:
        #         raw_html = arch_xml
        #
        #     soup = BeautifulSoup(raw_html, "html.parser")
        #
        #     # IMG tags
        #     for img in soup.find_all('img'):
        #         src = img.get('src') or img.get('data-src') or img.get('data-original-src')
        #         if not src and img.get('data-original-id'):
        #             src = f"/web/image/{img.get('data-original-id')}"
        #         if src:
        #             src = _abs_url(src, base_url)
        #             src = _to_hardcache_if_xmlid(src, base_url)
        #             img['src'] = src
        #
        #         if img.get('srcset'):
        #             img['srcset'] = _normalize_srcset(img.get('srcset'), base_url)
        #         if img.get('data-srcset'):
        #             img['srcset'] = _normalize_srcset(img.get('data-srcset'), base_url)
        #             img.attrs.pop('data-srcset', None)
        #
        #         for k in ['data-src', 'data-original-src', 'data-original-id']:
        #             img.attrs.pop(k, None)
        #         img['loading'] = 'eager'
        #
        #     # الخلفيات وروابط أخرى
        #     for el in soup.find_all(True):
        #         if el.has_attr('data-bg-url'):
        #             bg = el['data-bg-url']
        #             abs_bg = _abs_url(bg, base_url)
        #             abs_bg = _to_hardcache_if_xmlid(abs_bg, base_url)
        #             style = el.get('style', '')
        #             if "background-image" not in style:
        #                 style = (style + f"; background-image: url('{abs_bg}');").strip(";")
        #             el['style'] = _rewrite_style_urls(style, base_url)
        #
        #             has_fallback = el.find('img', attrs={'class': '__bgimg_fallback'})
        #             if not has_fallback:
        #                 fallback = soup.new_tag('img')
        #                 fallback['class'] = "__bgimg_fallback img-fluid"
        #                 fallback['src'] = abs_bg
        #                 fallback['style'] = "width:100%;height:auto;display:block;"
        #                 el.append(fallback)
        #             el.attrs.pop('data-bg-url', None)
        #
        #         if el.has_attr('style'):
        #             el['style'] = _rewrite_style_urls(el['style'], base_url)
        #
        #         if el.name == 'source' and el.get('srcset'):
        #             el['srcset'] = _normalize_srcset(el.get('srcset'), base_url)
        #
        #         if el.has_attr('href'):
        #             href = el['href']
        #             if href and not href.startswith("#"):
        #                 el['href'] = _abs_url(href, base_url)
        #
        #     content = str(soup)
        #
        #     html = f"""<!doctype html>
        # <html lang="ar" dir="auto">
        # <head>
        # <meta charset="utf-8">
        # <meta name="viewport" content="width=device-width, initial-scale=1">
        # <title>{page.name or ''}</title>
        # <style>
        #   html,body{{margin:0;padding:0}}
        #   img{{max-width:100%;height:auto;display:block}}
        #   .__bgimg_fallback{{display:block}}
        # </style>
        # </head>
        # <body>
        # {content}
        # </body>
        # </html>"""
        #
        #     return Response(html, status=200, content_type="text/html; charset=utf-8")
        #
        # except Exception as e:
        #     return Response(f"Error while processing page:\n{e}", status=500, content_type="text/plain; charset=utf-8")
        # try:
        #     # --- اللغة (اختياري) ---
        #     lang = kwargs.get('lang') or request.env.lang
        #
        #     # --- قاعدة الـ URL ---
        #     base_url = request.httprequest.host_url.rstrip('/')
        #
        #     # --- احضر الصفحة وتأكد إنها تتبع نفس الموقع الحالي ومسموح نشرها ---
        #     Page = request.env['website.page'].with_context(lang=lang).sudo()
        #     page = Page.search([
        #         ('id', '=', int(page_id)),
        #         ('website_id', '=', request.website.id),
        #     ], limit=1)
        #
        #     if not page:
        #         return Response(json.dumps({
        #             "success": False,
        #             "message": "Page not found (wrong id or website)."
        #         }), status=404, content_type="application/json; charset=utf-8")
        #
        #     # قابلية الظهور (نفس منطق is_visible)
        #     visible = page.website_published and (not page.date_publish or page.date_publish < fields.Datetime.now())
        #     if not visible:
        #         return Response(json.dumps({
        #             "success": False,
        #             "message": "Page is not published/visible."
        #         }), status=403, content_type="application/json; charset=utf-8")
        #
        #     # --- خُذ الـ arch (HTML الخاص بالصفحة) ---
        #     # ملاحظة: arch هنا هو محتوى الـ view للصفحة (نفس ما يخزّنه الـ website builder)
        #     arch_xml = page.view_id.sudo().arch or ""
        #     if not arch_xml.strip():
        #         return Response(json.dumps({
        #             "success": True,
        #             "data": {
        #                 "id": page.id,
        #                 "name": page.name,
        #                 "url": page.url or "",
        #                 "arch": "",
        #                 "images": [],
        #                 "base_url": base_url,
        #             }
        #         }), status=200, content_type="application/json; charset=utf-8")
        #
        #     # --- حدد <div id="wrap"> لو موجود (ده محتوى الصفحة) ---
        #     try:
        #         root = etree.fromstring(arch_xml.encode('utf-8'))
        #         wrap_div = root.xpath(".//div[@id='wrap']")
        #         raw_html = etree.tostring(wrap_div[0] if wrap_div else root, encoding='unicode', method='html')
        #     except Exception:
        #         # لو الـ arch فيه أجزاء QWeb غير مغلقة إلخ، أعطه كما هو
        #         raw_html = arch_xml
        #
        #     # --- نظّف وروح absolutize باستخدام BeautifulSoup ---
        #     soup = BeautifulSoup(raw_html, "html.parser")
        #
        #     # 1) <img> tags: عالج data-src/data-original-src/data-original-id + srcset
        #     for img in soup.find_all('img'):
        #         src = img.get('src') or img.get('data-src') or img.get('data-original-src')
        #         if not src and img.get('data-original-id'):
        #             # fallback لو جاي رقم attachment id
        #             # /web/image/<attachment_id>
        #             src = f"/web/image/{img.get('data-original-id')}"
        #         if src:
        #             img['src'] = _abs_url(src, base_url)
        #         if img.get('srcset'):
        #             img['srcset'] = _normalize_srcset(img.get('srcset'), base_url)
        #         if img.get('data-srcset'):
        #             img['srcset'] = _normalize_srcset(img.get('data-srcset'), base_url)
        #             img.attrs.pop('data-srcset', None)
        #         # ألغِ lazy attributes التي تمنع التحميل في بعض الـ WebView
        #         for k in ['data-src', 'data-original-src', 'data-original-id', 'loading']:
        #             img.attrs.pop(k, None)
        #
        #     # 2) الخلفيات: أي عنصر فيه data-bg-url أو style فيه url(...)
        #     for el in soup.find_all(True):
        #         # data-bg-url -> طبّقها كـ background-image وأضف fallback <img>
        #         if el.has_attr('data-bg-url'):
        #             bg = el['data-bg-url']
        #             abs_bg = _abs_url(bg, base_url)
        #             style = el.get('style', '')
        #             if "background-image" not in style:
        #                 style = (style + f"; background-image: url('{abs_bg}');").strip(";")
        #             el['style'] = style
        #             # أضفFallback صورة (تفيد الـ WebView)
        #             has_fallback = el.find('img', attrs={'class': '__bgimg_fallback'})
        #             if not has_fallback:
        #                 fallback = soup.new_tag('img')
        #                 fallback['class'] = "__bgimg_fallback img-fluid"
        #                 fallback['loading'] = "lazy"
        #                 fallback['src'] = abs_bg
        #                 fallback['style'] = "width:100%;height:auto;display:block;"
        #                 el.append(fallback)
        #             el.attrs.pop('data-bg-url', None)
        #
        #         # أي style فيه url(...) -> absolute
        #         if el.has_attr('style'):
        #             el['style'] = _rewrite_style_urls(el['style'], base_url)
        #
        #         # <source> داخل <picture> (للـ responsive images)
        #         if el.name == 'source':
        #             if el.get('srcset'):
        #                 el['srcset'] = _normalize_srcset(el.get('srcset'), base_url)
        #
        #         # <a href> و <link href> -> خلّيها absolute (اختياري لكنه مفيد)
        #         if el.has_attr('href'):
        #             el['href'] = _abs_url(el['href'], base_url)
        #
        #     # اجمع كل الروابط النهائية للصور (مفيد للـ prefetch في الموبايل)
        #     image_urls = []
        #     for img in soup.find_all('img'):
        #         if img.get('src') and not img['src'].startswith('data:'):
        #             image_urls.append(img['src'])
        #
        #     clean_html = str(soup)
        #
        #     payload = {
        #         "success": True,
        #         "data": {
        #             "id": page.id,
        #             "name": page.name,
        #             "url": page.url or "",
        #             "arch": clean_html,
        #             "images": list(dict.fromkeys(image_urls)),  # unique
        #             "base_url": base_url,
        #         }
        #     }
        #     return Response(
        #         json.dumps(payload),
        #         status=200,
        #         headers={
        #             "Access-Control-Allow-Origin": "*",
        #             "Cache-Control": "no-store",
        #         },
        #         content_type="application/json; charset=utf-8"
        #     )
        # except Exception as e:
        #     return Response(json.dumps({
        #         "success": False,
        #         "message": "خطأ أثناء معالجة الصفحة",
        #         "error": str(e)
        #     }), status=500, content_type="application/json; charset=utf-8")

    @http.route('/api/contact/submit', type='http', auth='public', methods=['POST'], csrf=False, website=True)
    def submit_contact_form(self, **post):
        env, lang = _env_lang()
        data = request.httprequest.get_json(silent=True) or {}

        name = data.get("name")
        email = data.get("email")
        phone = data.get("phone", "")
        company = data.get("company", "")
        subject = data.get("subject", "Contact Form")
        message = data.get("message", "")

        if not name or not email or not message:
            return _json_response({
                "success": False,
                "message": _translate("Missing required fields: %s", lang) % "name, email, message"
            }, status=400)

        try:
            env['mail.mail'].sudo().create({
                'subject': f"Contact Us: {subject}",
                'body_html': f"""
                            <p><strong>Name:</strong> {name}</p>
                            <p><strong>Email:</strong> {email}</p>
                            <p><strong>Phone:</strong> {phone}</p>
                            <p><strong>Company:</strong> {company}</p>
                            <p><strong>Message:</strong><br/>{message}</p>
                        """,
                'email_to': "verovevo6@gmail.com",
                'email_from': email,
            }).send()

            return _json_response({
                "success": True,
                "data": {"message": _translate("Email sent successfully", lang)}
            })

        except Exception as e:
            return _json_response({
                "success": False,
                "message": _translate("Failed to send email", lang),
                "error": str(e)
            }, status=500)



    @http.route('/service/api/api_key', type='http', auth='public', methods=['GET'], csrf=False)
    def service_api_key(self, **kw):
        try:
            env, lang = _env_lang()

            setting = env['res.config.settings'].sudo().search([], limit=1)
            api_key = (getattr(setting, 'api_key', '') or '').strip()

            if not api_key:
                return _json_response({
                    "success": False,
                    "message": _translate("No API Key found", lang)
                }, status=404)

            return _json_response({
                "success": True,
                "message": _translate("API key fetched successfully", lang),
                "data": {"api_key": api_key}
            }, status=200)

        except Exception as e:
            return _json_response({
                "success": False,
                "message": _translate("Unexpected server error", _get_lang()),
                "detail": str(e)
            }, status=500)

