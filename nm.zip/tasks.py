from .extensions import celery, db, socketio
from .models import Campaign, CampaignJob, SystemSetting
from .services import normalize_phone, send_whatsapp_msg
import time
from datetime import datetime

@celery.task(bind=True)
def process_campaign(self, campaign_id, variable_mapping):
    """
    Background task to process the campaign.
    """
    with db.session.no_autoflush:
        campaign = Campaign.query.get(campaign_id)
        if not campaign:
            return
        
        # Load System Settings
        settings = SystemSetting.query.first()
        if not settings or not settings.api_key or not settings.channel_id:
            campaign.status = 'stopped' # Log error state
            db.session.commit()
            socketio.emit('campaign_update', {
                'campaign_id': campaign_id,
                'status': 'stopped - Missing Settings',
                'progress': 0, 'sent': 0, 'failed': 0, 'total': 0
            }, namespace='/')
            return

        api_key = settings.api_key
        channel_id = settings.channel_id
        base_url = settings.base_url
        
        campaign.status = 'processing'
        db.session.commit()

        jobs = CampaignJob.query.filter_by(campaign_id=campaign_id, status='queued').all()
        total = len(jobs)
        processed = 0

        # Notify start
        socketio.emit('campaign_update', {
            'campaign_id': campaign_id,
            'status': 'processing',
            'progress': 0,
            'sent': campaign.sent_count,
            'failed': campaign.failed_count,
            'total': campaign.total_contacts
        }, namespace='/')

        consecutive_failures = 0 # Circuit Breaker Counter

        for job in jobs:
            # Check if campaign was manually stopped (or stopped by circuit breaker in previous iteration logic if parallel, but here linear)
            # Re-fetch campaign status to see if user stopped it from UI
            db.session.refresh(campaign)
            if campaign.status == 'stopped':
                break

            try:
                # 1. Prepare Data
                mobile = normalize_phone(job.phone_number)
                
                # ... (Variables setup) ...
                body_vars = variable_mapping.get('body_vars', {})
                header_type = variable_mapping.get('header_type', 'none')
                header_file = variable_mapping.get('header_file_path', None)
                
                # 2. Send
                resp, status_code = send_whatsapp_msg(
                    api_key=api_key,
                    base_url=base_url,
                    channel_id=channel_id,
                    template_id=campaign.template.provider_template_id,
                    mobile=mobile,
                    body_vars=body_vars,
                    header_type=header_type,
                    header_file=header_file
                )

                # 3. Update Job Status & Check Success
                job.response_log = str(resp)
                
                is_success = False
                if status_code == 200:
                    if resp.get('success') is True:
                        is_success = True
                    elif resp.get('extra', {}).get('success') is True:
                         is_success = True
                    elif 'messages' in resp.get('extra', {}).get('report', {}):
                        is_success = True
                
                if is_success:
                    print(f"   [SUCCESS] Message sent to {mobile}")
                    job.status = 'sent'
                    campaign.sent_count += 1
                    consecutive_failures = 0 # Reset counter on success
                else:
                    print(f"   [FAILED] Message failed for {mobile}. Reason: {resp}")
                    job.status = 'failed'
                    campaign.failed_count += 1
                    consecutive_failures += 1
                    
                    # --- CIRCUIT BREAKER LOGIC ---
                    response_str = str(resp).lower()
                    
                    # Stop if template is paused OR consecutive failures >= 3
                    if "paused" in response_str or consecutive_failures >= 3:
                        print(f"   [!!!] Circuit Breaker Triggered: Stopping Campaign {campaign_id}")
                        campaign.status = 'stopped'
                        db.session.commit()
                        
                        socketio.emit('campaign_update', {
                            'campaign_id': campaign_id,
                            'status': 'stopped (Errors)',
                            'progress': int(((campaign.sent_count + campaign.failed_count) / campaign.total_contacts) * 100),
                            'sent': campaign.sent_count,
                            'failed': campaign.failed_count,
                            'total': campaign.total_contacts
                        }, namespace='/')
                        break # Exit the loop immediately
                
                job.updated_at = datetime.utcnow()
                db.session.commit()

                processed += 1
                
                # 4. Emit Real-time Progress (Every 5 items or last one to avoid flooding)
                if processed % 5 == 0 or processed == total:
                    progress_percent = int((processed / total) * 100) # This is relative to this batch
                    # Recalculate global progress
                    global_total = campaign.total_contacts
                    global_processed = campaign.sent_count + campaign.failed_count
                    global_percent = int((global_processed / global_total) * 100) if global_total > 0 else 0
                    
                    socketio.emit('campaign_update', {
                        'campaign_id': campaign_id,
                        'status': 'processing',
                        'progress': global_percent,
                        'sent': campaign.sent_count,
                        'failed': campaign.failed_count,
                        'total': global_total
                    }, namespace='/')

                # Throttling: Wait 3 seconds before next message to avoid blocking/spam flags
                time.sleep(3)
                
                # --- BATCHING LOGIC ---
                # Check if we hit the batch limit
                if campaign.batch_size > 0 and processed < total and processed % campaign.batch_size == 0:
                    delay_seconds = campaign.batch_delay
                    print(f"   [BATCH] Batch limit {campaign.batch_size} reached. Waiting {delay_seconds}s...")
                    
                    # Update status to waiting
                    socketio.emit('campaign_update', {
                        'campaign_id': campaign_id,
                        'status': f'waiting ({int(delay_seconds/60)} min)',
                        'progress': global_percent,
                        'sent': campaign.sent_count,
                        'failed': campaign.failed_count,
                        'total': global_total
                    }, namespace='/')
                    
                    # Wait
                    time.sleep(delay_seconds)
                    
                    # Resume
                    print(f"   [BATCH] Resuming after wait...")

            except Exception as e:
                job.status = 'failed'
                job.response_log = str(e)
                campaign.failed_count += 1
                db.session.commit()

        # Final Status
        campaign.status = 'completed'
        db.session.commit()
        
        socketio.emit('campaign_update', {
            'campaign_id': campaign_id,
            'status': 'completed',
            'progress': 100,
            'sent': campaign.sent_count,
            'failed': campaign.failed_count,
            'total': campaign.total_contacts
        }, namespace='/')
