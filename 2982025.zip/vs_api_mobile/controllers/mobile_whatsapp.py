# -*- coding: utf-8 -*-

import json
import random
import string
import re
from datetime import datetime
from dateutil.relativedelta import relativedelta
from odoo.addons.v16_ismart_sms.models.sms_sms import send_imsart_sms

from odoo import http, _
from odoo.http import request, Response
from odoo.addons.otp_authentication.controller.main import (
    generate_otp,
    hash_otp,
    format_mobile_number,
)

# =========================
# i18n Helpers (NEW)
# =========================

SUPPORTED_LANGS = {"en_US", "ar_001"}
DEFAULT_LANG = "en_US"

_MSG_MAP = {
    "Invalid phone number": {"ar_001": "رقم الهاتف غير صالح"},
    "SMS Gateway is not configured": {"ar_001": "بوابة الرسائل القصيرة غير مُهيّأة"},
    "Failed to send SMS": {"ar_001": "فشل إرسال الرسالة القصيرة"},
    "Failed to send via WhatsApp": {"ar_001": "فشل الإرسال عبر واتساب"},
    "phone and otp required": {"ar_001": "الهاتف ورمز التحقق (OTP) مطلوبان"},
    "OTP incorrect or expired": {"ar_001": "رمز التحقق غير صحيح أو منتهي الصلاحية"},
    "Missing required fields: %s": {"ar_001": "حقول مطلوبة مفقودة: %s"},
    "Partner creation failed: %s": {"ar_001": "فشل إنشاء الشريك: %s"},
    "User creation failed: %s": {"ar_001": "فشل إنشاء المستخدم: %s"},
    "Token is required": {"ar_001": "الرمز مطلوب"},
    "Invalid token or user not found": {"ar_001": "رمز غير صالح أو لم يتم العثور على المستخدم"},
    "Invalid token": {"ar_001": "رمز غير صالح"},
    "User info updated successfully": {"ar_001": "تم تحديث بيانات المستخدم بنجاح"},
    "Logged out successfully": {"ar_001": "تم تسجيل الخروج بنجاح"},
    "Account deleted successfully": {"ar_001": "تم حذف الحساب بنجاح"},
    # رسائل عامة
    "Unexpected server error": {"ar_001": "خطأ غير متوقع في الخادم"},
}

def _normalize_lang(lang):
    if not lang:
        return DEFAULT_LANG
    l = str(lang).strip().lower()
    if l.startswith("ar"):
        return "ar_001"
    if l.startswith("en"):
        return "en_US"
    return DEFAULT_LANG

def _get_lang():
    lang = request.params.get("lang")
    if not lang:
        lang = request.httprequest.form.get("lang")
    if not lang:
        body = request.httprequest.get_json(silent=True) or {}
        if isinstance(body, dict):
            lang = body.get("lang")
    return _normalize_lang(lang)

def _env_lang():
    lang = _get_lang()
    return request.env(context=dict(request.env.context, lang=lang)), lang

def _translate(msg, lang):
    if msg is None:
        return msg
    base = _MSG_MAP.get(str(msg))
    if base:
        return base.get(lang, msg)
    try:
        return _(msg)
    except Exception:
        return msg

def _json_error(message, extra=None, status=400):

    _, lang = _env_lang()
    payload = {
        "success": False,
        "message": _translate(message, lang),
    }
    if extra:
        extra = dict(extra)
        if isinstance(extra.get("detail"), str):
            extra["detail"] = _translate(extra["detail"], lang)
        payload.update(extra)
    return Response(
        json.dumps(payload, ensure_ascii=False),
        status=status,
        content_type="application/json; charset=utf-8",
    )

def _json_success(data=None, status=200):
    return Response(
        json.dumps({
            "success": True,
            "data": data or {}
        }, ensure_ascii=False),
        status=status,
        content_type="application/json; charset=utf-8"
    )

# =========================
# Controller
# =========================

class MobileAuthController(http.Controller):

    def is_valid_mobile(self, phone):
        stripped = str(phone).strip()
        return bool(re.match(r'^\d{8}$', stripped))

    def generate_token(self, length=32):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    # استبدلنا النسخ الأصلية بنسخ تستخدم i18n الموحد
    def json_error(self, message, extra=None, status=400):
        return _json_error(message, extra=extra, status=status)

    def json_success(self, data=None):
        return _json_success(data=data, status=200)

    @http.route('/api/mobile/send_otp', type='http', auth='public', methods=['POST'], csrf=False)
    def send_otp(self, **post):
        env, lang = _env_lang()

        data = request.httprequest.get_json(silent=True) or {}
        phone = data.get('phone')
        channel = (data.get('channel') or 'whatsapp').lower()

        # 400 بدلاً من 404
        if not phone or not self.is_valid_mobile(phone):
            return self.json_error('Invalid phone number', status=400)

        formatted = format_mobile_number(phone)
        otp = generate_otp()
        hashed = hash_otp(otp)

        env['otp.code'].sudo().search([('phone_num', '=', formatted)]).unlink()
        env['otp.code'].sudo().create({
            'phone_num': formatted,
            'req_time': datetime.now(),
            'code_num': hashed,
        })

        if channel == 'sms':
            gateway = env['sms.gateway.config'].sudo().search([], limit=1)
            # 500
            if not gateway:
                return self.json_error("SMS Gateway is not configured", status=500)
            sms_body = f"Your OTP code is: {otp}"
            resp = send_imsart_sms(
                mobile_no=f"{formatted}",
                sms=sms_body,
                sms_gateway=gateway,
                lang=env.user.lang or 'en_US',
            )
            print("DEBUG SMS Response: ", resp, type(resp))

            if hasattr(resp, "status_code") and hasattr(resp, "text"):
                sent = resp.status_code == 200 and resp.text.strip() == "1"
                error_msg = resp.text
            else:
                sent = False
                error_msg = "Failed to send SMS"

            # 500 بدلاً من 400
            if not sent:
                # بنترجم "Failed to send SMS" وبنسيب تفاصيل المزود في extra.detail زي ما هي
                return self.json_error("Failed to send SMS", status=500, extra={"detail": str(error_msg)})
        else:
            # WhatsApp as default
            res = env['vs.otp.gateway'].send_whatsapp(formatted, otp)
            sent = bool(res.get('sent', False)) or res.get('status') == 200
            # 500 بدلاً من 400
            if not sent:
                # الرسالة الأساسية مترجمة، وdetail نص المزود
                return self.json_error("Failed to send via WhatsApp", status=500, extra={"detail": res.get('text', '')})

        Users = env['res.users'].sudo()
        user = (Users.search([('phone', '=', phone)], limit=1)
                or Users.search([('mobile', '=', phone)], limit=1)
                or Users.search([('partner_id.phone', '=', phone)], limit=1)
                or Users.search([('login', '=', phone)], limit=1)
                or Users.search([('partner_id.mobile', '=', phone)], limit=1))

        return self.json_success({'user_exists': bool(user)})

    @http.route('/api/mobile/verify_otp', type='http', auth='public', methods=['POST'], csrf=False)
    def verify_otp(self, **post):
        env, lang = _env_lang()

        data = request.httprequest.get_json(silent=True) or {}
        phone = data.get('phone')
        otp = data.get('otp')
        signup_data = data.get('signup')
        fcm_token = data.get('fcm_token')

        if not phone or not otp:
            return self.json_error('phone and otp required', status=400)
        if not self.is_valid_mobile(phone):
            return self.json_error('Invalid phone number', status=400)

        formatted = format_mobile_number(phone)
        hashed = hash_otp(otp)
        cutoff = datetime.now() - relativedelta(minutes=3)
        record = env['otp.code'].sudo().search([
            ('phone_num', '=', formatted),
            ('req_time', '>=', cutoff),
        ], order='req_time desc', limit=1)

        master_otp = '123456'
        if not record or (record.code_num != hashed and otp != master_otp):
            return self.json_error('OTP incorrect or expired', status=400)

        record.unlink()

        Users = env['res.users'].sudo()
        user = (Users.search([('phone', '=', phone)], limit=1)
                or Users.search([('mobile', '=', phone)], limit=1)
                or Users.search([('partner_id.phone', '=', phone)], limit=1)
                or Users.search([('login', '=', phone)], limit=1)
                or Users.search([('partner_id.mobile', '=', phone)], limit=1))

        if user:
            token = self.generate_token()
            if fcm_token:
                try:
                    user.partner_id.sudo().write({'fcm_token': fcm_token})
                except Exception as e:
                    # logging فقط
                    print("FCM token save error:", e)
            user.partner_id.sudo().write({'token': token})

            # Create session
            request.session.uid = user.id
            request.session.login = user.login
            request.session.session_token = user._compute_session_token(request.session.sid)
            request.update_env(user=user.id)

            return self.json_success({
                'user_exist': True,
                'action': 'login',
                'user_id': user.id,
                'user_name': user.name,
                'phone': user.phone or '',
                'national_id': user.partner_id.national_id or '',
                'national_id_expiry': user.partner_id.national_id_expiry.isoformat() if user.partner_id.national_id_expiry else '',
                'address': user.partner_id.street or '',
                'token': token,
            })

        if not signup_data or not isinstance(signup_data, dict):
            # النجاح هنا بدون رسالة نصية مخصوصة—ده بروتوكولك الأصلي
            return self.json_success({
                'user_exist': False,
                'action': 'signup_required'
            })

        token = self.generate_token()
        partner_vals = {
            'name': signup_data.get('name'),
            'phone': phone,
            'token': token,
        }
        if fcm_token:
            partner_vals['fcm_token'] = fcm_token

        try:
            partner = env['res.partner'].sudo().create(partner_vals)
        except Exception as e:
            return self.json_error('Partner creation failed: %s' % str(e), status=500)

        try:
            new_user = env['res.users'].sudo().create({
                'login': signup_data.get('login') or phone,
                'name': signup_data.get('name'),
                'password': signup_data.get('password'),
                'phone': phone,
                'email': signup_data.get('email') or '',
                'partner_id': partner.id,
            })
        except Exception as e:
            return self.json_error('User creation failed: %s' % str(e), status=500)

        # Create session
        request.session.uid = new_user.id
        request.session.login = new_user.login
        request.session.session_token = new_user._compute_session_token(request.session.sid)
        request.update_env(user=new_user.id)

        return self.json_success({
            'user_exist': True,  # بقى موجود بعد التسجيل
            'action': 'signup',
            'user_id': new_user.id,
            'user_name': new_user.name,
            'phone': new_user.phone or '',
            'national_id': partner.national_id or '',
            'national_id_expiry': partner.national_id_expiry.isoformat() if partner.national_id_expiry else '',
            'address': partner.street or '',
            'token': token,
        })

    @http.route('/api/mobile/register', type='http', auth='public', methods=['POST'], csrf=False)
    def register(self, **post):
        env, lang = _env_lang()

        data = request.httprequest.get_json(silent=True) or {}
        phone = data.get('phone')
        name = data.get('name')
        national_id = data.get('national_id')
        national_id_expiry = data.get('national_id_expiry')
        address = data.get('address')
        fcm_token = data.get('fcm_token')

        missing = []
        for field in ['phone', 'name', 'national_id', 'national_id_expiry', 'address']:
            if not data.get(field):
                missing.append(field)
        if missing:
            return self.json_error('Missing required fields: %s' % ", ".join(missing),
                                   extra={'missing_fields': missing}, status=400)

        if not self.is_valid_mobile(phone):
            return self.json_error('Invalid phone number', status=400)

        token = self.generate_token()
        try:
            partner = env['res.partner'].sudo().create({
                'name': name,
                'phone': phone,
                'national_id': national_id,
                'national_id_expiry': national_id_expiry,
                'street': address,
                'token': token,
                'fcm_token': fcm_token,
            })
        except Exception as e:
            return self.json_error('Partner creation failed: %s' % str(e), status=500)

        password = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(8))

        try:
            user = env['res.users'].sudo().create({
                'login': phone,
                'name': name,
                'phone': phone,
                'partner_id': partner.id,
                'password': password,
                'email': phone
            })
        except Exception as e:
            return self.json_error('User creation failed: %s' % str(e), status=500)

        request.session.uid = user.id
        request.session.login = user.login
        request.session.session_token = user._compute_session_token(request.session.sid)
        request.update_env(user=user.id)

        return self.json_success({
            'user_id': user.id,
            'user_name': user.name,
            'phone': user.phone or phone,
            'national_id': national_id,
            'national_id_expiry': partner.national_id_expiry.isoformat() if partner.national_id_expiry else '',
            'address': partner.street or '',
            'token': token,
            'fcm_token': partner.fcm_token or '',
        })

    @http.route('/api/mobile/user_info', type='http', auth='public', methods=['POST'], csrf=False)
    def get_user_info(self, **post):
        env, lang = _env_lang()

        data = request.httprequest.get_json(silent=True) or {}
        token = data.get('token')

        # 401
        if not token:
            return self.json_error("Token is required", status=401)

        partner = env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        # 401
        if not partner or not partner.user_ids:
            return self.json_error("Invalid token or user not found", status=401)

        user = partner.user_ids[0]

        return self.json_success({
            'user_id': user.id,
            'user_name': user.name,
            'email': user.email or '',
            'phone': user.phone or '',
            'login': user.login,
            'national_id': partner.national_id or '',
            'national_id_expiry': partner.national_id_expiry.isoformat() if partner.national_id_expiry else '',
            'address': partner.street or '',
            'token': partner.token,
        })

    @http.route('/api/mobile/update_user', type='http', auth='public', methods=['PUT'], csrf=False)
    def update_user(self, **post):
        env, lang = _env_lang()

        data = request.httprequest.get_json(silent=True) or {}
        token = data.get('token')
        name = data.get('user_name')
        email = data.get('email')
        phone = data.get('phone')
        login = data.get('login')
        national_id = data.get('national_id')
        national_id_expiry = data.get('national_id_expiry')
        address = data.get('address')

        # 401
        if not token:
            return self.json_error("Token is required", status=401)

        partner = env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        # 401
        if not partner or not partner.user_ids:
            return self.json_error("Invalid token or user not found", status=401)

        user = partner.user_ids[0]

        partner_vals = {}
        user_vals = {}

        if name:
            partner_vals['name'] = name
            user_vals['name'] = name
        if email:
            partner_vals['email'] = email
            user_vals['email'] = email
        if phone:
            partner_vals['phone'] = phone
            user_vals['phone'] = phone
        if national_id:
            partner_vals['national_id'] = national_id
        if national_id_expiry:
            partner_vals['national_id_expiry'] = national_id_expiry
        if address:
            partner_vals['street'] = address
        if login:
            user_vals['login'] = login

        # update partner
        if partner_vals:
            try:
                partner.write(partner_vals)
            except Exception as e:
                # 500
                return self.json_error("Failed to update partner: %s" % str(e), status=500)
        # update user
        if user_vals:
            try:
                user.write(user_vals)
            except Exception as e:
                # 500
                return self.json_error("Failed to update user: %s" % str(e), status=500)

        return self.json_success({'message': _translate("User info updated successfully", lang)})

    @http.route('/api/mobile/logout', type='http', auth='public', methods=['POST'], csrf=False)
    def logout(self, **post):
        env, lang = _env_lang()

        data = request.httprequest.get_json(silent=True) or {}
        token = data.get('token')

        # 401
        if not token:
            return self.json_error("Token is required", status=401)

        partner = env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        # 401
        if not partner:
            return self.json_error("Invalid token", status=401)

        partner.write({'token': False})
        return self.json_success({'message': _translate("Logged out successfully", lang)})

    @http.route('/api/mobile/delete_account', type='http', auth='public', methods=['DELETE'], csrf=False)
    def delete_account(self, **post):
        env, lang = _env_lang()

        data = request.httprequest.get_json(silent=True) or {}
        token = data.get('token')

        # 401
        if not token:
            return self.json_error("Token is required", status=401)

        partner = env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        # 401
        if not partner or not partner.user_ids:
            return self.json_error("Invalid token or user not found", status=401)

        user = partner.user_ids[0]
        partner.unlink()
        user.unlink()

        return self.json_success({'message': _translate("Account deleted successfully", lang)})
