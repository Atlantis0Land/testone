# models/mobile_app_page.py
from odoo import models, fields, api
from odoo.http import request


class MobileAppPage(models.Model):
    _name = "mobile.page"
    _description = "Mobile App Page"

    page_type = fields.Selection([
        ('website_page', 'Website Page'),
        ('redirect', 'Enable Redirection'),
    ], string="Page Type", default='website_page', required=True)

    website_page_id = fields.Many2one("website.page", string="Website Page")
    page_id = fields.Integer(related="website_page_id.id", store=True, readonly=True)
    name = fields.Char(related="website_page_id.name", store=True, readonly=True)
    name_redirect = fields.Char()
    page_url = fields.Char(related="website_page_id.url", store=True, readonly=True)
    page_url_re = fields.Char()
    view_id = fields.Many2one("ir.ui.view", related="website_page_id.view_id", store=True, readonly=True)

    # مهم: نخليها Image أو Binary مع attachment=True
    image_cover = fields.Image(string="Image Cover", attachment=True, max_width=1024, max_height=1024)
    image_attachment_id = fields.Many2one('ir.attachment', string="Cover Attachment", readonly=True, ondelete='set null')

    description = fields.Text(string="Description")

    @api.model
    def create(self, vals):
        rec = super().create(vals)
        if 'image_cover' in vals:
            rec._sync_public_image_attachment('image_cover')
        return rec

    def write(self, vals):
        res = super().write(vals)
        if 'image_cover' in vals:
            self._sync_public_image_attachment('image_cover')
        return res

    def _sync_public_image_attachment(self, field_name):
        """يمسك آخر مرفق للصورة ويجعله Public ثم يحفظه في image_attachment_id."""
        Att = self.env['ir.attachment'].sudo()
        for rec in self:
            if not getattr(rec, field_name):
                rec.image_attachment_id = False
                continue
            att = Att.search([
                ('res_model', '=', self._name),
                ('res_id', '=', rec.id),
                ('res_field', '=', field_name),
            ], order='id desc', limit=1)
            if att:
                att.write({'public': True})
                rec.image_attachment_id = att.id

    def _get_base_url(self):
        """Prefer current request host (scheme+domain+port), fallback to web.base.url."""
        if request and getattr(request, 'httprequest', None) and getattr(request.httprequest, 'host_url', None):
            return request.httprequest.host_url.rstrip('/')
        base = self.env['ir.config_parameter'].sudo().get_param('web.base.url') or ''
        return base.rstrip('/')

    def get_public_image_url(self):
        self.ensure_one()
        if not self.image_attachment_id:
            return None
        base = self._get_base_url()
        return f"{base}/web/image/{self.image_attachment_id.id}"