from odoo.http import Controller, route, request, Response
from odoo import _
import json

class MobileAppAPI(Controller):

    # === Helpers: HTTP JSON responses ===
    def _http_success(self, data=None, status=200, headers=None):
        payload = {"success": True}
        if data is not None:
            payload["data"] = data
        body = json.dumps(payload, ensure_ascii=False)
        return Response(
            body,
            status=status,
            content_type='application/json; charset=utf-8',
            headers=headers or []
        )

    def _http_error(self, message, status=400, extra=None, headers=None):
        payload = {"success": False, "message": _(message)}
        if extra:
            payload.update(extra)
        body = json.dumps(payload, ensure_ascii=False)
        return Response(
            body,
            status=status,
            content_type='application/json; charset=utf-8',
            headers=headers or []
        )

    def _get_token(self):
        return request.httprequest.headers.get("X-Api-Token") or request.params.get("token")

    def _is_token_valid(self, token):
        expected = request.env['ir.config_parameter'].sudo().get_param('mobile_app.api_token')
        return bool(expected) and token == expected

    @route('/api/mobile_app/home_items', type='http', auth='public', csrf=False, methods=['GET'])
    def get_home_items(self, **kwargs):
        try:
            Home = request.env['mobile.app.new'].sudo()
            name = kwargs.get('name')
            domain = [('name', '=', name)] if name else []
            records = Home.search(domain, order='id asc')

            base = request.httprequest.host_url.rstrip('/')
            data = []

            for rec in records:
                record_data = {
                    "id": rec.id,
                    "name": rec.name or "",
                    "title": rec.title or "",
                    "icon_image_url": rec.get_public_image_url(),
                    "id_record": rec.id_record or None,
                    "category_blog_id": rec.category_blog_id or None,
                    "blog": (
                        {"id": rec.blog_blog_id.id, "name": rec.blog_blog_id.name}
                        if rec.blog_blog_id else None
                    ),
                    "active": rec.active,
                }

                if rec.name == "news_home":
                    record_data.update({
                        "blog_limit": rec.blog_limit,
                        "blog_ids": [
                            {"id": b.id, "title": b.name}
                            for b in rec.blog_ids
                        ]
                    })

                elif rec.name == "event_home":
                    record_data.update({
                        "event_limit": rec.event_limit,
                        "event_ids": [
                            {"id": e.id, "name": e.name}
                            for e in rec.event_ids
                        ]
                    })

                data.append(record_data)

            return self._http_success({"records": data}, status=200)

        except Exception as e:
            return self._http_error("Unexpected server error", status=500, extra={"detail": str(e)})

    @route('/api/mobile_app/pages', type='http', auth='public', csrf=False, methods=['GET'])
    def get_all_mobile_app_pages(self, **kwargs):
        try:
            records = request.env['mobile.page'].sudo().search([])
            data = []

            for rec in records:
                img_url = rec.get_public_image_url()

                base_data = {
                    "id": rec.id,
                    "page_type": rec.page_type,
                    "name_re": rec.name_redirect or "",
                    "page_url_re": rec.page_url_re or "",
                    "image": img_url,
                }

                if rec.page_type == 'website_page':
                    base_data.update({
                        "page_id": rec.page_id or "",
                        "name": rec.name or "",
                        "page_url": rec.page_url or "",
                        "description": rec.description or "",
                    })

                data.append(base_data)

            return self._http_success({"records": data}, status=200)

        except Exception as e:
            return self._http_error("Unexpected server error", status=500, extra={"detail": str(e)})

    @route('/api/mobile_app/contents', type='http', auth='public', csrf=False, methods=['GET'])
    def get_all_mobile_app_contents(self, **kwargs):
        try:
            Mobile = request.env['mobile.app.content'].sudo()

            domain = []
            if kwargs.get('page_type'):
                domain.append(('page_type', '=', kwargs['page_type']))

            records = Mobile.search(domain)

            # Get selection labels (translated if available in context)
            fld_info = Mobile.fields_get(allfields=['page_type']).get('page_type', {})
            selection_list = fld_info.get('selection', []) or list(Mobile._fields['page_type'].selection)
            page_type_labels = dict(selection_list)

            data = []
            for rec in records:
                data.append({
                    "id": rec.id,
                    "name": rec.name or "",
                    "page_type": rec.page_type or "",
                    "page_type_label": page_type_labels.get(rec.page_type, "") if rec.page_type else "",
                    "id_record": (rec.id_record if rec.id_record not in (False, None) else None),
                    "content_html": rec.content_html or "",
                })

            return self._http_success({"records": data, "meta": {"count": len(data)}}, status=200)

        except Exception as e:
            return self._http_error("Unexpected server error", status=500, extra={"detail": str(e)})

