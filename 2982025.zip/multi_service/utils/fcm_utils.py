# -*- coding: utf-8 -*-
import firebase_admin
from firebase_admin import credentials, messaging
import os
import logging


_logger = logging.getLogger(__name__)

# ================================
# 🔧 إعدادات المسار لملف JSON
# ================================
BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SERVICE_ACCOUNT_PATH = os.path.join(BASE_PATH, 'static/config/appdhr-e9c12-firebase-adminsdk-fbsvc-d102e0fdcf.json')


if not firebase_admin._apps:
    cred = credentials.Certificate(SERVICE_ACCOUNT_PATH)
    firebase_admin.initialize_app(cred)
    _logger.info("✅ Firebase Initialized")

# ================================
# 📲 دالة إرسال الإشعار
# ================================
def send_push_notification(user_fcm_token, title, body, data_payload=None):
    _logger.info("🔔 Preparing to send push notification...")

    # تحقق من صحة التوكن
    if not user_fcm_token or len(user_fcm_token) < 80:
        _logger.warning("❌ Invalid-looking FCM token")
        return False

    _logger.info(f"📲 Token: {user_fcm_token[:10]}... len={len(user_fcm_token)}")
    _logger.info(f"📝 Title: {title}")
    _logger.info(f"📝 Body: {body}")
    _logger.info(f"📦 Payload: {data_payload}")

    # تأكد أن الـ payload عبارة عن سترنجات فقط
    if data_payload:
        data_payload = {key: str(value) for key, value in data_payload.items()}

    # بناء الرسالة
    message = messaging.Message(
        notification=messaging.Notification(title=title, body=body),
        token=user_fcm_token,
        data=data_payload or {}
    )

    # إرسال الإشعار
    try:
        response = messaging.send(message)
        _logger.info(f"✅ Successfully sent message: {response}")
        return True
    except Exception as e:
        _logger.error(f"❌ Failed to send message: {e}")
        return False
