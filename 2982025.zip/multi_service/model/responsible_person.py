from odoo import models, fields

class ResponsiblePerson(models.Model):
    _name = 'responsible.person'


    name = fields.Char(string="Name", required=True, translate=True)
    active = fields.Boolean(string="Active", default=True)
    description = fields.Text(string="Description")
    partner_id = fields.Many2one('res.partner', string="Partner")
    user_id = fields.Many2one('res.users', string="User")

