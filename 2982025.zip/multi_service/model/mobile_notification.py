# models/mobile_notification.py
from odoo import models, fields, api
import requests
from datetime import datetime


class MobileNotification(models.Model):
    _name = 'mobile.notification'
    _description = 'Mobile Push Notification Log'

    name = fields.Char(string='Title')
    body = fields.Text(string='Message')
    service_request_id = fields.Many2one('service.request', string='Related Service Request')
    partner_id = fields.Many2one('res.partner', string='Target Partner')
    sent = fields.Boolean(string='Sent', default=False)
    response = fields.Text(string='Response')
    sent_date = fields.Datetime(string='Sent Date')
    stage_name = fields.Char(string='Stage')


    # @api.model
    # def send_push_notification(self,user_fcm_token, title, body, data_payload=None):
    #     print("🔔 Preparing to send push notification...")
    #     print(f"📲 Token: {user_fcm_token}")
    #     print(f"📝 Title: {title}")
    #     print(f"📝 Body: {body}")
    #     print(f"📦 Payload: {data_payload}")
    #
    #     if data_payload:
    #         data_payload = {key: str(value) for key, value in data_payload.items()}
    #
    #     message = messaging.Message(
    #         notification=messaging.Notification(
    #             title=title,
    #             body=body,
    #         ),
    #         token=user_fcm_token,
    #         data=data_payload or {}
    #     )
    #
    #     try:
    #         response = messaging.send(message)
    #         print("✅ Successfully sent message:", response)
    #         return response
    #     except Exception as e:
    #         print("❌ Failed to send message:", e)
    #         return str(e)
