from odoo import models, fields, api
from odoo.addons.multi_service.utils.fcm_utils import send_push_notification


DEFAULT_COUNTRY_CODE = '968'

def format_mobile_number(mobile, country_code=DEFAULT_COUNTRY_CODE):
    print(f"[DEBUG] Raw input mobile: {mobile}")
    mobile = str(mobile).strip()[-8:]
    formatted = f"{country_code}{mobile}"
    print(f"[DEBUG] Formatted mobile number: {formatted}")
    return formatted



class AddResponseWizard(models.TransientModel):
    _name = 'add.response.wizard'
    _description = 'Add Response Wizard'

    response = fields.Text(string="Response", required=True)
    date = fields.Date(string="Date", required=True, default=fields.Date.context_today,readonly=1)
    request_id = fields.Many2one('service.request', string="Service Request")

    def action_add_response(self):
        self.ensure_one()

        # 1) سجّل سطر الرد
        line = self.env['service.request.response.line'].create({
            'request_id': self.request_id.id,
            'response': self.response,
            'date': self.date,
        })
        print("[ADD_RESPONSE] Created response line:", line.id)

        # 2) بعت واتساب حسب الإعدادات الحالية (نفس لوجيكك)
        raw_phone = self.request_id.partner_id.phone or self.request_id.phone
        if raw_phone:
            phone = f"+{format_mobile_number(raw_phone)}"
            template_id = self.env['ir.config_parameter'].sudo().get_param("multi_service.response_template_id")
            if template_id:
                sanitized_response = ' '.join((self.response or '').strip().split())
                message_text = f"{sanitized_response}"
                try:
                    wa_res = self.env['vs.otp.gateway'].send_response_custom_whatsapp(
                        number=phone,
                        template_id=template_id,
                        link=message_text
                    )
                    print("[ADD_RESPONSE] WhatsApp result:", wa_res)
                except Exception as e:
                    print("[ADD_RESPONSE] WhatsApp error:", e)

        try:
            partner = self.request_id.partner_id
            token = getattr(partner, 'fcm_token', False)
            if token:
                title = f"رد جديد على طلبك ({self.request_id.reference or self.request_id.name or ''})"
                body_txt = (' '.join((self.response or '').split()))[:240]

                notif = self.env['mobile.notification'].sudo().create({
                    'name': title,
                    'body': body_txt,
                    'service_request_id': self.request_id.id,
                    'partner_id': partner.id,
                    'stage_name': self.request_id.stage_id.name or '',
                })
                print("[ADD_RESPONSE] Created mobile.notification:", notif.id)
                send_push_notification(
                    token,
                    title,
                    body_txt,
                    {
                        'request_id': str(notif.service_request_id.id),
                        'notification_id': str(notif.id),
                        'stage': notif.stage_name or '',
                    }
                )
                print("[ADD_RESPONSE] Push sent?", notif.sent, "| resp:", (notif.response or '')[:120])
            else:
                print("[ADD_RESPONSE] No FCM token on partner -> skip push")
        except Exception as e:
            print("[ADD_RESPONSE] Push error:", e)

        # 4) ارجعي لفورم الطلب
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'service.request',
            'res_id': self.request_id.id,
            'view_mode': 'form',
            'target': 'current',
        }
