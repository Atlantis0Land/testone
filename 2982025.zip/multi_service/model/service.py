from odoo import models, fields, api ,_
from odoo.exceptions import ValidationError



class ServiceCategory(models.Model):
    _name = 'service.category'
    _description = 'Service Category'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'

    name = fields.Char(string='Name', required=True)
    code = fields.Char(string='Code', required=True, unique=True)

    _sql_constraints = [
        ('code_unique', 'unique(code)', 'The code must be unique!')
    ]


class SubServiceCategory(models.Model):
    _name = 'sub.service.category'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Sub Service Category'
    _rec_name = 'name'

    name = fields.Char(string='Name', required=True)
    code = fields.Char(string='Code', required=True)
    category_id = fields.Many2one('service.category', string='Service Category', required=True)

    _sql_constraints = [
        ('sub_code_unique', 'unique(code)', 'The code must be unique!')
    ]


class ServiceType(models.Model):
    _name = 'service.type'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Service Type'
    _rec_name = 'name'

    name = fields.Char(string='Name', required=True)
    category_id = fields.Many2one('service.category', string='Service Category', required=True)
    sub_category_id = fields.Many2one('sub.service.category', string='Sub Service Category',
                                      required=True, domain="[('category_id', '=',  category_id)]")
    allowed_user_ids = fields.Many2many('res.users', string='Allowed Users')
    config_id = fields.Many2one('service.category.config', string='Service Configuration')
    code = fields.Char(string='Code', required=True)
    whatsapp_template_id = fields.Char(string='WhatsApp Template ID', help="Template ID used for WhatsApp messages")
    is_published = fields.Boolean(string='Published', default=False, tracking=True)

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Code must be unique!'),
    ]

    def get_fields_config(self):
        self.ensure_one()
        config = self.config_id
        if not config:
            raise ValidationError(_("No configuration record is set on this Service Type."))

        result_fields = []

        def add_field(name, label, field_type, config_value, relation=None):
            result = {
                'name': name,
                'label': label,
                'type': field_type,
                'required': config_value == 'required',
                'optional': config_value == 'optional',
                'no': config_value == 'no',
                'status': config_value,
            }
            if relation:
                result['relation'] = relation
            result_fields.append(result)


        add_field('government_id', _('Government'), 'many2one', config.has_government_id,
                  relation='res.country.government')

        add_field('state_id', _('State'), 'many2one', config.has_state_id, relation='res.country.state')

        add_field('village_name_id', _('Village Name'), 'many2one', config.has_village_name,
                  relation='res.state.village')

        # 5) Phone (char)
        # add_field('phone', _('Phone Number'), 'char', config.has_phone)

        # 6) National ID (char)
        # add_field('national_id', _('ID'), 'char', config.has_national_id)

        # 7) Reference (char)
        add_field('reference', _('Reference'), 'char', config.has_reference)

        # 8) From / To Dates
        add_field('from_date', _('From Date'), 'date', config.has_from_date)
        add_field('to_date', _('To Date'), 'date', config.has_from_date)

        # 9) Location
        add_field('location', _('Location'), 'char', config.has_map)

        return {
            'service_type_id': self.id,
            'fields': result_fields,
        }


class ServiceConfiguration(models.Model):
    _name = 'service.configuration'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Service Configuration'

    name = fields.Char(string='Configuration Name')



