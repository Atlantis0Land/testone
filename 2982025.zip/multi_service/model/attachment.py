import mimetypes
import base64

from odoo import models, fields, api
from odoo.exceptions import ValidationError


class AttachmentDocument(models.Model):
    _name = 'attachment.document.request'

    document_id = fields.Many2one('document.type')
    request_id = fields.Many2one('service.request')
    attachment_id = fields.Many2one('ir.attachment', )
    attachment = fields.Binary("Attachment", related='attachment_id.datas')
    attachment_filename = fields.Char("Filename")
    file_name = fields.Char("File name")




class IrAttachment(models.Model):
    _inherit = 'ir.attachment'

    file_name = fields.Char()

    def _get_allowed_mime_types(self):
        return [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'video/mp4',
            'video/x-msvideo',
            'video/x-matroska',
            'image/jpeg',
            'image/png',
            'image/gif',
        ]

    @api.constrains('mimetype')
    def _check_mimetype(self):

        for record in self:
            if record.res_model == 'attachment.document.request' and record.mimetype not in self._get_allowed_mime_types():
                raise ValidationError("Only PDF, Word, JPEG, PNG, GIF, or MP4/AVI/MKV files are allowed.")

    @api.model_create_multi
    def create(self, vals_list):
        res = super(IrAttachment, self).create(vals_list)

        for r in res:
            if r.res_model == 'attachment.document.request':
                attachment = self.env['attachment.document.request'].search([('id', '=', r.res_id)])
                attachment.attachment_id = r.id
                r.file_name = attachment.file_name

        return res
