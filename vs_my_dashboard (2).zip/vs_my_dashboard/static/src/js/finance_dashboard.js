/** @odoo-module **/

import { Component, onWillStart, onMounted, useRef } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class FinanceDashboard extends Component {
    setup() {
        this.rpc = useService("rpc");
        this.actionService = useService("action");

        // المراجع
        this.canvasRef       = useRef("chartCanvas");   // Bar
        this.piePracticalRef = useRef("piePractical");  // Doughnut Practical
        this.piePlannedRef   = useRef("piePlanned");    // Doughnut Planned
        this.legendRef       = useRef("sharedLegend");  // legend مشترك

        // ألوان ثابتة للسلاسل (أغمق شوية)
        this.dsColors = [
            { key: "planned",   label: "Planned",   bg: "rgba(100, 181, 246, 0.80)", border: "#1976D2", text: "#1976D2" }, // لبني
            { key: "practical", label: "Practical", bg: "rgba(244, 143, 177, 0.80)", border: "#D81B60", text: "#D81B60" }, // بنبي
            { key: "reserved",  label: "Reserved",  bg: "rgba(255, 183, 77,  0.80)", border: "#EF6C00", text: "#EF6C00" }, // برتقالي
            { key: "remaining", label: "Remaining", bg: "rgba(255, 238, 88,  0.80)", border: "#F9A825", text: "#F9A825" }, // أصفر
        ];

        this.state = {
            active: "finance",
            justOpened: false,
            loading: true,
            budgets: [],
            selectedBudgetId: null,
            labels: [],
            series: { planned: [], practical: [], reserved: [], remaining: [] },
        };

        onWillStart(async () => {
            const budgets = await this.rpc("/web/dataset/call_kw", {
                model: "crossovered.budget",
                method: "search_read",
                args: [],
                kwargs: { fields: ["name"], domain: [], order: "id desc", limit: 50 },
            });
            this.state.budgets = budgets;
            if (budgets.length) {
                this.state.selectedBudgetId = budgets[0].id;
                await this._loadBudgetData();
            }
            this.state.loading = false;
        });

        onMounted(() => {
            if (this.canvasRef.el)       this._renderBarChart();
            if (this.piePracticalRef.el) this._renderPie("practical", this.piePracticalRef);
            if (this.piePlannedRef.el)   this._renderPie("planned",   this.piePlannedRef);
            this._renderSharedLegend();
        });
    }

    // تحميل وتجهيز البيانات
    async _loadBudgetData() {
        const model = "crossovered.budget.lines";

        // تحقق من الحقول المخزنة
        const fieldsInfo = await this.rpc("/web/dataset/call_kw", {
            model,
            method: "fields_get",
            args: [],
            kwargs: { attributes: ["store"] },
        });

        const aggFields = ["planned_amount:sum", "practical_amount:sum"];
        const hasReserved = !!(fieldsInfo.reserved_amount && fieldsInfo.reserved_amount.store);
        if (hasReserved) aggFields.push("reserved_amount:sum");

        const rg = await this.rpc("/web/dataset/call_kw", {
            model,
            method: "read_group",
            args: [],
            kwargs: {
                domain: [["crossovered_budget_id", "=", this.state.selectedBudgetId]],
                fields: [...aggFields, "analytic_account_id"],
                groupby: ["analytic_account_id"],
                lazy: false,
            },
        });

        const labels = [], planned = [], practical = [], reserved = [], remaining = [];
        for (const row of rg) {
            const name = row.analytic_account_id?.[1] || "—";
            const pPlanned   = row.planned_amount_sum   ?? row.planned_amount   ?? 0;
            const pPractical = row.practical_amount_sum ?? row.practical_amount ?? 0;
            const pReserved  = hasReserved ? (row.reserved_amount_sum ?? row.reserved_amount ?? 0) : 0;

            labels.push(name);
            planned.push(pPlanned);
            practical.push(pPractical);
            reserved.push(pReserved);
            remaining.push(pPlanned - pPractical - pReserved); // حساب المتبقي على الفرونت
        }

        this.state.labels = labels;
        this.state.series = { planned, practical, reserved, remaining };

        // إعادة الرسم
        this._renderBarChart();
        this._renderPie("practical", this.piePracticalRef);
        this._renderPie("planned",   this.piePlannedRef);
        this._renderSharedLegend();
    }

    // تغيير الميزانية
    async onBudgetChange(ev) {
        this.state.selectedBudgetId = parseInt(ev.target.value);
        await this._loadBudgetData();
    }

    // legend مشترك أعلى الصفحة
    _renderSharedLegend() {
        if (!this.legendRef.el) return;
        const itemsHTML = this.dsColors.map(c => {
            const swatch = `display:inline-block;width:14px;height:14px;border-radius:3px;
                            background:${c.bg};border:2px solid ${c.border};margin-inline-end:6px;`;
            const label  = `<span style="color:${c.text};font-weight:600">${c.label}</span>`;
            return `<span class="legend-item" style="display:inline-flex;align-items:center;gap:4px;">
                      <span style="${swatch}"></span>${label}
                    </span>`;
        }).join('<span style="width:10px;"></span>');
        this.legendRef.el.innerHTML = itemsHTML;
    }

    // جراف عمودي + أرقام على كل عمود
    _renderBarChart() {
        if (!this.canvasRef.el || !window.Chart) return;
        if (this._bar) this._bar.destroy();

        const [cPln, cPrac, cRes, cRem] = this.dsColors;

        // Plugin يكتب قيمة كل عمود لكل Dataset
        const valueLabelAll = {
            id: "valueLabelAll",
            afterDatasetsDraw: (chart, args, opts) => {
                const { ctx } = chart;
                const nf = new Intl.NumberFormat();
                ctx.save();
                ctx.textAlign = "center";
                ctx.font = (opts.fontSize || 10) + "px sans-serif";

                chart.data.datasets.forEach((ds, dsIndex) => {
                    const meta = chart.getDatasetMeta(dsIndex);
                    if (meta.hidden) return;
                    const textColor = (opts.colors && opts.colors[dsIndex]) || "#333";

                    meta.data.forEach((bar, i) => {
                        const v = ds.data[i];
                        if (v === null || v === undefined) return;
                        const pos = bar.tooltipPosition();
                        const offset = v >= 0 ? -6 : 12;
                        ctx.fillStyle = textColor;
                        ctx.fillText(nf.format(v), pos.x, pos.y + offset);
                    });
                });

                ctx.restore();
            },
        };

        const data = {
            labels: this.state.labels,
            datasets: [
                { label: cPln.label,  data: this.state.series.planned,   backgroundColor: cPln.bg,  borderColor: cPln.border,  borderWidth: 2 },
                { label: cPrac.label, data: this.state.series.practical, backgroundColor: cPrac.bg, borderColor: cPrac.border, borderWidth: 2 },
                { label: cRes.label,  data: this.state.series.reserved,  backgroundColor: cRes.bg,  borderColor: cRes.border,  borderWidth: 2 },
                { label: cRem.label,  data: this.state.series.remaining, backgroundColor: cRem.bg,  borderColor: cRem.border,  borderWidth: 2 },
            ],
        };

        this._bar = new Chart(this.canvasRef.el.getContext("2d"), {
            type: "bar",
            data,
            plugins: [valueLabelAll],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }, // بنستخدم legend المشترك
                    tooltip: { mode: "index", intersect: false },
                    valueLabelAll: {
                        colors: [cPln.border, cPrac.border, cRes.border, cRem.border],
                        fontSize: 11,
                    },
                },
                scales: {
                    x: { stacked: false, ticks: { autoSkip: false, maxRotation: 45, minRotation: 0 } },
                    y: { beginAtZero: true },
                },
            },
        });
    }

    // دالة مساعدة: ارسم الدائرتين
    _renderPies() {
        this._renderPie("practical", this.piePracticalRef);
        this._renderPie("planned",   this.piePlannedRef);
    }

    // جراف دائري عام (metric: practical | planned)
    _renderPie(metric, ref) {
        if (!ref.el || !window.Chart) return;

        const key = metric === "practical" ? "_piePractical" : "_piePlanned";
        if (this[key]) this[key].destroy();

        const rawValues = metric === "practical" ? this.state.series.practical : this.state.series.planned;
        const values = (rawValues || []).map(v => Math.max(0, v || 0));
        const labels = this.state.labels || [];
        const total  = values.reduce((a, b) => a + b, 0);

        const maxIdx  = values.length ? values.indexOf(Math.max(...values)) : -1;
        const offsets = values.map((_, i) => (i === maxIdx ? 10 : 0));

        const palette = ["#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd","#8c564b","#e377c2","#7f7f7f","#bcbd22","#17becf"];
        const sliceColors = values.map((_, i) => palette[i % palette.length]);

        const doughnutLabels = {
            id: "doughnutLabels",
            afterDatasetsDraw: (chart, args, opts) => {
                if (!total) return;
                const { ctx } = chart;
                const meta = chart.getDatasetMeta(0);
                const data = chart.data.datasets[0].data;
                ctx.save();
                ctx.font = "11px sans-serif";
                ctx.textAlign = "center";
                ctx.fillStyle = "#222";
                const minPct = opts?.minPercent || 3;
                meta.data.forEach((arc, i) => {
                    const v = data[i] || 0;
                    const pct = (v / total) * 100;
                    if (pct < minPct) return;
                    const p = arc.tooltipPosition();
                    ctx.fillText(`${pct.toFixed(1)}%`, p.x, p.y);
                });
                ctx.restore();
            },
        };

        const nf = new Intl.NumberFormat();
        this[key] = new Chart(ref.el.getContext("2d"), {
            type: "doughnut",
            data: {
                labels,
                datasets: [{
                    label: metric === "practical" ? "Practical Amount" : "Planned Amount",
                    data: values,
                    backgroundColor: sliceColors,
                    borderColor: "#fff",
                    borderWidth: 1,
                    offset: offsets,
                }],
            },
            plugins: [doughnutLabels],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "45%",
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => {
                                const v = ctx.parsed || 0;
                                const pct = total ? ((v / total) * 100).toFixed(1) : 0;
                                return `${ctx.label}: ${nf.format(v)} (${pct}%)`;
                            },
                            title: () => (metric === "practical" ? "Practical Amount" : "Planned Amount"),
                        },
                    },
                    doughnutLabels: { minPercent: 3 },
                },
            },
        });
    }

    static template = "vs_my_dashboard_template";
}

registry.category("actions").add("vs_my_dashboard", FinanceDashboard);
export default FinanceDashboard;
