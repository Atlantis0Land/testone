{
    "name": "my_dashboard_tabs",
    "version": "16.0.1.0.0",
    "summary": "One menu with tabs to open multiple dashboards",
    "depends": ["ad_internal_request", "stock","vs_investment","web","inventory_stock_dashboard","account"],
    "data": [
        "views/finance_dashboard_action.xml",

        "views/menus.xml",
    ],
"assets": {
    "web.assets_backend": [
        "vs_my_dashborad/static/src/js/lib/chart.min.js",
        "vs_my_dashboard/static/src/js/finance_dashboard.js",
        "vs_my_dashboard/static/src/xml/finance_chart.xml",
    ],
},


    "license": "LGPL-3",
}
