from odoo import http, fields
from odoo.http import request, Response
import json

class MobileNotificationController(http.Controller):

    @http.route('/api/notifications/create', type='json', auth='user', methods=['POST'], csrf=False)
    def create_notification(self):
        raw_data = request.httprequest.data
        try:
            data = json.loads(raw_data)
        except json.JSONDecodeError:
            return {'error': 'Invalid JSON format'}

        """
        Create and send a push notification to a mobile app user (by partner_id).
        Also logs the notification in 'mobile.notification' model.
        You must send: partner_id, title, and body in the request.
        """
        partner_id = data.get('partner_id')
        title = data.get('title', 'New Notification')
        body = data.get('body', 'You have a new notification')
        extra_data = data.get('extra_data') or {}

        if not partner_id:
            return {'success': False, 'error': 'No partner_id'}

        partner = request.env['res.partner'].sudo().browse(partner_id)
        if not partner.exists() or not partner.fcm_token:
            return {'success': False, 'error': 'No FCM token for this partner'}

        notif = request.env['mobile.notification'].sudo().create({
            'name': title,
            'body': body,
            'partner_id': partner_id,
            'service_request_id': data.get('service_request_id'),
            'stage_name': data.get('stage_name'),
        })

        try:
            notif.send_push()  # Just call notif.send_push() with no args!
            notif.write({'sent': True, 'sent_date': fields.Datetime.now()})
        except Exception as ex:
            notif.write({'response': str(ex)})
            return {'success': False, 'error': str(ex)}

        return {'success': True, 'notification_id': notif.id}

    @http.route('/api/notifications/user/<int:partner_id>', type='http', auth='user', methods=['GET'], csrf=False)
    def get_user_notifications(self, partner_id):
        try:
            user = request.env.user
            # تحقق من أن اليوزر له صلاحية يشوف النوتيفيكشنز
            if partner_id != (user.partner_id.id or 0) and not user.has_group('base.group_system'):
                return Response(
                    json.dumps({'success': False, 'message': 'Access Denied'}),
                    status=403,
                    content_type='application/json'
                )

            # جلب النوتيفيكشنز
            recs = request.env['mobile.notification'].sudo().search(
                [('partner_id', '=', partner_id)], order='sent_date desc'
            )

            # تجهيز البيانات
            notifications = [{
                'id': r.id,
                'title': r.name or '',
                'body': r.body or '',
                'sent': bool(r.sent),
                'sent_date': r.sent_date and r.sent_date.strftime("%Y-%m-%d %H:%M:%S"),
                'stage_name': r.stage_name or '',
                'service_request_id': r.service_request_id.id if r.service_request_id else None,
            } for r in recs]

            # لو مفيش بيانات
            if not notifications:
                return Response(
                    json.dumps({'success': False, 'message': 'No notifications found'}),
                    status=200,
                    content_type='application/json'
                )

            # نجاح مع بيانات
            return Response(
                json.dumps({'success': True, 'data': notifications}),
                status=200,
                content_type='application/json'
            )

        except Exception as e:
            return Response(
                json.dumps({'success': False, 'message': str(e)}),
                status=500,
                content_type='application/json'
            )