# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class serviceCategoryApprover(models.Model):
    """ Intermediate model between service.category and res.users
        To know whether an approver for this category is required or not
    """
    _name = 'service.category.approver.config'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    _description = 'service Type Approver'
    _rec_name = 'user_id'
    _order = 'sequence'

    sequence = fields.Integer('Sequence', default=10)
    category_id = fields.Many2one('service.category.config', string='service Type', ondelete='cascade', required=True)
    company_id = fields.Many2one('res.company', related='category_id.company_id')
    user_id = fields.Many2many('res.users', string='User', ondelete='cascade', required=True,
                               check_company=True)
    required = fields.Boolean(default=True)
    stage_id = fields.Many2one(
        'service.stage',
        string='Stages',
    )
    num_of_days = fields.Integer("Number Of Days")


    existing_user_ids = fields.Many2many('res.users', compute='_compute_existing_user_ids')

    @api.depends('category_id')
    def _compute_existing_user_ids(self):
        for record in self:
            record.existing_user_ids = record.category_id.approver_ids.user_id


    @api.onchange('category_id')
    def _onchange_category_id(self):
        if self.category_id:
            return {
                'domain': {
                    'stage_ids': [('id', 'in', self.category_id.stage_ids.ids)]
                }
            }
        return {
            'domain': {
                'stage_ids': []
            }
        }
