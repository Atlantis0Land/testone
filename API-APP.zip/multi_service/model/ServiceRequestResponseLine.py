from odoo import models, fields

class ServiceRequestResponseLine(models.Model):
    _name = 'service.request.response.line'
    _description = 'Service Request Response Line'

    request_id = fields.Many2one('service.request', string="Request")
    response = fields.Text(string="Response")
    date = fields.Date(string="Date")
    date_time = fields.Datetime(string="Date And Time")
