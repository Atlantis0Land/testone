from odoo import models, fields, api


class CountryState(models.Model):
    _inherit = 'res.country.state'

    government_id = fields.Many2one('res.country.government', string='Government')

    @api.model_create_multi
    def create(self, vals_list):
        country_id = self.env['res.country'].search([('code', '=', 'OM')], limit=1)
        for vals in vals_list:
            vals['country_id'] = country_id.id
        return super().create(vals_list)