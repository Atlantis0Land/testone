from odoo import models, fields, _, api
from odoo.exceptions import UserError, ValidationError


class Stage(models.Model):
    _name = 'service.stage'
    _description = 'service Stage'

    name = fields.Char(string="Name", required=True, translate=True)
    active = fields.Boolean(string="Active", default=True)
    fold = fields.Boolean('Folded by Default')
    sequence = fields.Integer(string="Sequence", default=10, help="Used to order stages. Lower is better.")
    is_sent_whatsapp = fields.Boolean(string="Whatsapp Stage", default=False)
    template_id = fields.Char(string="WhatsApp Template ID")

    @api.constrains('sequence')
    def _check_unique_sequence(self):
        for record in self:
            duplicate = self.search([
                ('sequence', '=', record.sequence),
                ('id', '!=', record.id),
            ], limit=1)
            if duplicate:
                raise ValidationError("The stage sequence must be unique!")

    def unlink(self):
        for rec in self:
            if rec.name == 'Draft' or rec.fold:
                raise UserError(_("You cannot delete this stage"))
        return super(Stage, self).unlink()
