from odoo import models, fields, api

DEFAULT_COUNTRY_CODE = '968'

def format_mobile_number(mobile, country_code=DEFAULT_COUNTRY_CODE):
    print(f"[DEBUG] Raw input mobile: {mobile}")
    mobile = str(mobile).strip()[-8:]
    formatted = f"{country_code}{mobile}"
    print(f"[DEBUG] Formatted mobile number: {formatted}")
    return formatted


class AddResponseWizardButton(models.TransientModel):
    _name = 'add.response.wizard.button'
    _description = 'Add Response Wizard'

    response = fields.Text(string="Response", required=True)
    date = fields.Datetime(string="Date & Time", required=True,)
    date_today = fields.Datetime(string="Date & Time", required=True, default=fields.Date.context_today,readonly=1)
    request_id = fields.Many2one('service.request', string="Service Request")

    def action_add_response(self):
        self.ensure_one()
        self.env['service.request.response.line'].create({
            'request_id': self.request_id.id,
            'response': self.response,
            'date': self.date_today,
            'date_time': self.date,
        })
        # 2. Prepare WhatsApp sending
        raw_phone = self.request_id.partner_id.phone or self.request_id.phone
        if raw_phone:
            phone = f"+{format_mobile_number(raw_phone)}"
            template_id = self.env['ir.config_parameter'].sudo().get_param("multi_service.response_Appointment_template_id")
            if template_id:
                # Combine response + date (formatted)
                sanitized_response = ' '.join(self.response.strip().split())
                sanitized_date = fields.Datetime.to_string(self.date)

                message_text = f"{sanitized_response} - {sanitized_date}"
                self.env['vs.otp.gateway'].send_response_appointment_custom_whatsapp(
                    number=phone,
                    template_id=template_id,
                    link=message_text  # sent as {{1}} in template
                )
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'service.request',
            'res_id': self.request_id.id,
            'view_mode': 'form',
            'target': 'current',
        }
