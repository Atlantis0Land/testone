# models/mobile_notification.py
from odoo import models, fields, api
import requests
from datetime import datetime

class MobileNotification(models.Model):
    _name = 'mobile.notification'
    _description = 'Mobile Push Notification Log'

    name = fields.Char(string='Title')
    body = fields.Text(string='Message')
    service_request_id = fields.Many2one('service.request', string='Related Service Request')
    partner_id = fields.Many2one('res.partner', string='Target Partner')
    sent = fields.Boolean(string='Sent', default=False)
    response = fields.Text(string='Response')
    sent_date = fields.Datetime(string='Sent Date')
    stage_name = fields.Char(string='Stage')

    def send_push(self):
        """
        Send FCM push notification.
        Requires the partner to have an FCM token.
        """
        for notif in self:
            fcm_token = notif.partner_id.fcm_token
            if not fcm_token:
                notif.response = "No FCM token for partner"
                notif.sent = False
                continue

            server_key = "AAAA1aJGZbE:APA91bGun7F5GC4pKKd2RdhwzoaN2fa5roSCKjrKXpSnYCePQ8DRbgyBn-_6kFGEflnOsqJRyjdzfFAVuxlkZM5-yfWY7mDxZUep3ds-_92T-NoVZiKyZKpLMiZ2KUszGH9p6SK-eFIy"
            headers = {
                "Authorization": f"key={server_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "to": fcm_token,
                "notification": {
                    "title": notif.name,
                    "body": notif.body
                },
                "data": {
                    "service_request_id": notif.service_request_id.id if notif.service_request_id else None,
                    "stage_name": notif.stage_name,
                }
            }
            url = "https://fcm.googleapis.com/fcm/send"
            try:
                resp = requests.post(url, json=payload, headers=headers, timeout=10)
                notif.response = resp.text
                notif.sent = resp.status_code == 200
                notif.sent_date = fields.Datetime.now()
            except Exception as e:
                notif.response = str(e)
                notif.sent = False
                notif.sent_date = fields.Datetime.now()