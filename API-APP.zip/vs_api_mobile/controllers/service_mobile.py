import json
import base64
from odoo import http, _, fields
from odoo.http import request,Response
from datetime import date

def _json_response(payload, status=200, headers=None):
    return Response(
        json.dumps(payload, ensure_ascii=False),
        status=status,
        content_type='application/json; charset=utf-8',
        headers=headers or []
    )

def _ok_list(records, status=200):
    return _json_response({"success": True, "data": {"records": records}}, status=status)

def _ok_detail(record, status=200):
    return _json_response({"success": True, "data": record}, status=status)

def _err(message, status=400, extra=None):
    payload = {"success": False, "message": message}
    if extra:
        payload.update(extra)
    return _json_response(payload, status=status)


def get_image_from_cover(post):
    image = ""
    try:
        props = json.loads(post.cover_properties or '{}')
        bg = props.get('background-image', '')
        if bg.startswith("url("):
            image = bg[4:-1].strip("'").strip('"')
    except Exception:
        pass
    return image
def get_image_from_cover_event(event):
    """
    Extracts the cover image URL from event.cover_properties.
    """
    import json
    cover_img_url = ""
    if event.cover_properties:
        try:
            props = json.loads(event.cover_properties)
            bg_img = props.get("background-image", "")
            # مثال الناتج: url('/web/image/event.event/2/image_cover')
            if bg_img.startswith("url("):
                cover_img_url = bg_img[4:-1].strip("'").strip('"')
        except Exception:
            cover_img_url = ""
    return cover_img_url



class ServicePortalController(http.Controller):
    """
    This controller defines all the API endpoints needed for the “Add New Service” flow.
    """

    # -----------------------------------------
    # 1) GET /api/main_categories
    # -----------------------------------------
    # 1) GET /api/main_categories
    @http.route('/api/main_categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_main_categories(self, **kw):
        try:
            main_cats = request.env['service.category'].sudo().search([])
            records = [{'id': c.id, 'name': c.name} for c in main_cats]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 2) GET /api/main_categories/<main_id>/sub_categories
    @http.route('/api/main_categories/<int:main_id>/sub_categories', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_sub_categories(self, main_id, **kw):
        try:
            subs = request.env['sub.service.category'].sudo().search([('category_id', '=', main_id)])
            records = [{'id': s.id, 'name': s.name} for s in subs]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 3) GET /api/sub_categories/<sub_id>/service_types
    @http.route('/api/sub_categories/<int:sub_id>/service_types', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_service_types(self, sub_id, **kw):
        try:
            types = request.env['service.type'].sudo().search([('sub_category_id', '=', sub_id)])
            records = [{'id': st.id, 'name': st.name} for st in types]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 4) GET /api/service_types/<type_id>/fields_config
    @http.route('/api/service_types/<int:type_id>/fields_config', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_fields_config(self, type_id, **kw):
        try:
            st = request.env['service.type'].sudo().browse(type_id)
            if not st.exists():
                return _err("Service Type not found", 404)
            config = st.get_fields_config()  # متوقع dict جاهز
            # لو حابة نفس الشكل بالظبط: data = {"service_type_id": type_id, "fields": [...]}
            return _ok_detail(config)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # ======== POST يبقى كما هو ========
    @http.route('/api/create/service', type='http', auth='public', methods=['POST'], csrf=False)
    def create_service_request(self, **post):
        user = request.env.user
        if not user or not user.partner_id:
            return _err(_('No partner found.'), 400)

        raw_json = request.httprequest.form.get('payload_json')
        try:
            payload = json.loads(raw_json or '{}')
        except Exception:
            return _err(_('Invalid JSON in payload_json'), 400)

        category_id = payload.get('category_id')
        sub_category_id = payload.get('sub_category_id')
        service_type_id = payload.get('service_type_id')
        fields_data = payload.get('fields_data') or {}

        missing = [f for f in ('category_id', 'sub_category_id', 'service_type_id') if not payload.get(f)]
        if missing:
            return _err(_('Missing required fields: %s') % ', '.join(missing), 400, {"missing_fields": missing})

        category = request.env['service.category'].sudo().browse(int(category_id))
        sub_category = request.env['sub.service.category'].sudo().browse(int(sub_category_id))
        st = request.env['service.type'].sudo().browse(int(service_type_id))
        if not category.exists():
            return _err(_('Invalid category_id: %s') % category_id, 400)
        if not sub_category.exists():
            return _err(_('Invalid sub_category_id: %s') % sub_category_id, 400)
        if not st.exists():
            return _err(_('Invalid service_type_id: %s') % service_type_id, 400)

        try:
            field_config = st.get_fields_config()
            required_fields = [f['name'] for f in field_config.get('fields', []) if f.get('required')]
        except Exception as e:
            return _err(f'Field config error: {str(e)}', 400)

        missing_required = []
        for fname in required_fields:
            val = fields_data.get(fname)
            if val is None or (isinstance(val, str) and not val.strip()):
                missing_required.append(fname)
        if missing_required:
            return _err(_('Missing required fields: %s') % ', '.join(missing_required), 400,
                        {"missing_fields": missing_required})

        # إنشاء الطلب
        try:
            phone = user.login
            national_id = fields_data.get('national_id')

            user.partner_id.write({
                'phone': phone,
                'national_id': national_id or user.partner_id.national_id,
            })

            vals = {
                'category_id': int(category_id),
                'sub_category_id': int(sub_category_id),
                'service_type_id': int(service_type_id),
                'partner_id': user.partner_id.id,
                'phone': phone,
                'name': st.name,
                'date': date.today(),
            }
            for k, v in fields_data.items():
                if k.endswith('_id') and str(v).isdigit():
                    vals[k] = int(v)
                elif k not in ['national_id', 'phone']:
                    vals[k] = v

            new_req = request.env['service.request'].sudo().create(vals)
        except Exception as e:
            return _err(str(e), 400)

        # مرفقات
        attached = []
        files_list = []
        for field_name in request.httprequest.files:
            files_list.extend(request.httprequest.files.getlist(field_name))

        doc_types = st.config_id.document_type_ids
        requirer_required = st.config_id.requirer_document == 'required'
        if requirer_required and not files_list:
            return _err(_('At least one document is required but no file was uploaded.'), 400)

        for i, fs in enumerate(files_list):
            try:
                data = fs.read()
                doc = doc_types[i] if i < len(doc_types) else None

                chatter_attachment = request.env['ir.attachment'].sudo().create({
                    'name': fs.filename,
                    'type': 'binary',
                    'datas': base64.b64encode(data).decode('utf-8'),
                    'res_model': 'service.request',
                    'res_id': new_req.id,
                    'mimetype': fs.mimetype,
                })

                doc_attachment_vals = {
                    'request_id': new_req.id,
                    'file_name': fs.filename,
                    'attachment_id': chatter_attachment.id,
                }
                if doc:
                    doc_attachment_vals['document_id'] = doc.id

                doc_attachment = request.env['attachment.document.request'].sudo().create(doc_attachment_vals)
                attached.append(doc_attachment.id)
            except Exception:
                continue

        return _ok_detail({
            'service_id': new_req.id,
            'message': _('Service request created successfully'),
            'attached_ids': attached,
        })

    # 5) GET /api/governments
    @http.route('/api/governments', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_governments(self, **kw):
        try:
            governments = request.env['res.country.government'].sudo().search([])
            records = [{
                'id': g.id,
                'government_name': g.name,
                'country_id': g.country_id.id if g.country_id else False,
            } for g in governments]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 6) GET /api/governments/<gov_id>/states
    @http.route('/api/governments/<int:gov_id>/states', type='http', auth='public', methods=['GET'], csrf=False)
    def get_states_by_government(self, gov_id, **kw):
        try:
            states = request.env['res.country.state'].sudo().search([('government_id', '=', gov_id)])
            records = [{'id': s.id, 'state_name': s.name, 'state_code': s.code} for s in states]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 7) GET /api/states/<state_id>/villages
    @http.route('/api/states/<int:state_id>/villages', type='http', auth='public', methods=['GET'], csrf=False)
    def get_villages_by_state(self, state_id, **kw):
        try:
            villages = request.env['res.state.village'].sudo().search([('state_id', '=', state_id)])
            records = [{'id': v.id, 'village_name': v.name, 'village_code': v.code} for v in villages]
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 8) GET /api/service_types/<service_type_id>/document_types
    @http.route('/api/service_types/<int:service_type_id>/document_types', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_document_type_count(self, service_type_id, **kw):
        try:
            st = request.env['service.type'].sudo().browse(service_type_id)
            if not st.exists():
                return _err(_("Invalid service_type_id: %s") % service_type_id, 404)
            docs = st.config_id.document_type_ids
            doc_list = [{'id': d.id, 'name': d.name} for d in docs]
            return _ok_detail({
                'service_type_id': service_type_id,
                'document_type_count': len(doc_list),
                'document_types': doc_list
            })
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 9) GET /api/services
    @http.route('/api/services', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_services(self, **kwargs):
        try:
            ServiceRequest = request.env['service.request'].sudo()
            services = ServiceRequest.search([], order='id desc')
            records = []
            for srv in services:
                records.append({
                    'id': srv.id,
                    'reference': srv.reference or '',
                    'name': srv.name or '',
                    'date': srv.date and srv.date.strftime("%Y-%m-%dT%H:%M:%S") or False,
                    'category': {'id': srv.category_id.id,
                                 'name': srv.category_id.name or ''} if srv.category_id else False,
                    'sub_category': {'id': srv.sub_category_id.id,
                                     'name': srv.sub_category_id.name or ''} if srv.sub_category_id else False,
                    'service_type': {'id': srv.service_type_id.id,
                                     'name': srv.service_type_id.name or ''} if srv.service_type_id else False,
                    'stage': {'id': srv.stage_id.id, 'name': srv.stage_id.name or ''} if srv.stage_id else False,
                })
            return _ok_list(records)
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})

    # 10) GET /api/service_request/<request_id>
    @http.route('/api/service_request/<int:request_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_service_request_detail(self, request_id, **kwargs):
        rec = request.env['service.request'].sudo().browse(request_id)
        if not rec.exists():
            return _err(f'Service Request ID {request_id} not found', 404)

        attachments = []
        for att in rec.attachment_ids:
            file_url = ''
            image_url = ''
            if att.attachment_id:
                file_url = f'/web/content/{att.attachment_id._name}/{att.attachment_id.id}/datas?download=true'
                if att.attachment_id.mimetype and att.attachment_id.mimetype.startswith('image/'):
                    image_url = f'/web/image/{att.attachment_id._name}/{att.attachment_id.id}/datas'
            attachments.append({
                'id': att.id,
                'document_type': att.document_id.name if att.document_id else '',
                'file_name': att.file_name,
                'attachment_url': file_url,
                'image_url': image_url,
                'mimetype': att.attachment_id.mimetype if att.attachment_id else '',
            })

        responses = [{
            'response': line.response,
            'date': line.date.strftime("%Y-%m-%d") if line.date else '',
            'date_time': line.date_time.strftime("%Y-%m-%d %H:%M:%S") if line.date_time else '',
        } for line in rec.response_line_ids]

        fields_config = []
        if rec.service_type_id:
            try:
                config = rec.service_type_id.get_fields_config()
                fields_config = config.get('fields', [])
            except Exception:
                fields_config = []

        return _ok_detail({
            'id': rec.id,
            'reference': rec.reference or '',
            'name': rec.name or '',
            'date': rec.date and rec.date.strftime("%Y-%m-%d") or '',
            'phone': rec.phone or '',
            'location': rec.location or '',
            'national_id': rec.national_id or '',
            'from_date': rec.from_date and rec.from_date.strftime("%Y-%m-%d") or '',
            'to_date': rec.to_date and rec.to_date.strftime("%Y-%m-%d") or '',
            'state': rec.state_id.name if rec.state_id else '',
            'government': rec.government_id.name if rec.government_id else '',
            'village': rec.village_name_id.name if rec.village_name_id else '',
            'category': rec.category_id.name if rec.category_id else '',
            'sub_category': rec.sub_category_id.name if rec.sub_category_id else '',
            'service_type': rec.service_type_id.name if rec.service_type_id else '',
            'service_type_id': rec.service_type_id.id if rec.service_type_id else False,
            'stage': rec.stage_id.name if rec.stage_id else '',
            'partner': rec.partner_id.name if rec.partner_id else '',
            'attachments': attachments,
            'responses': responses,
            'fields_config': fields_config
        })

    # 11) GET /api/user/info
    @http.route('/api/user/info', type='http', auth='public', methods=['GET'], csrf=False)
    def get_logged_in_user_info(self, **kwargs):
        uid = request.session.uid
        if not uid:
            return _err('User not logged in', 401)

        try:
            user = request.env['res.users'].sudo().browse(uid)
            partner = user.partner_id
            return _ok_detail({
                'user_id': user.id,
                'user_name': user.name,
                'partner_id': partner.id,
                'partner_name': partner.name,
                'national_id': partner.national_id or '',
                'phone': partner.phone or '',
            })
        except Exception as e:
            return _err("Unexpected server error", 500, {"detail": str(e)})


    @http.route('/api/blogs', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_blogs(self, **kwargs):
        try:
            posts = request.env['blog.post'].sudo().search(
                [('website_published', '=', True)],
                order="create_date desc"
            )
            base_url = request.httprequest.host_url.rstrip('/')

            records = []
            for post in posts:
                records.append({
                    "id": post.id,
                    "title": post.name,
                    "author": post.author_id.name if post.author_id else "",
                    "image": get_image_from_cover(post),
                    "date": post.create_date.strftime('%Y-%m-%d'),
                    "category": post.blog_id.name if post.blog_id else "",
                    # "image": f"{base_url}/web/image/blog.post/{post.id}/image_1920" if post.image_1920 else "",
                })

            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/blog/categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_blog_categories(self, **kwargs):
        try:
            categories = request.env['blog.blog'].sudo().search([])
            records = [{
                "id": cat.id,
                "name": cat.name,
                "description": cat.subtitle or "",
            } for cat in categories]
            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/blogs/<int:blog_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_blog_detail(self, blog_id, **kwargs):
        try:
            post = request.env['blog.post'].sudo().browse(blog_id)
            if not post.exists():
                return _json_response({"success": False, "message": "Blog not found"}, status=404)

            base_url = request.httprequest.host_url.rstrip('/')
            record = {
                "id": post.id,
                "title": post.name,
                "content": post.content or "",
                "category": post.blog_id.name if post.blog_id else "",
                "image": get_image_from_cover(post),
                "url": f"{base_url}{post.website_url}",
            }
            return _json_response({"success": True, "data": record}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    # ---------- EVENTS ----------
    @http.route('/api/events/categories', type='http', auth='public', methods=['GET'], csrf=False)
    def get_event_categories(self, **kwargs):
        try:
            categories = request.env['event.type'].sudo().search([])
            records = [{"id": cat.id, "name": cat.name} for cat in categories]
            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/events', type='http', auth='public', methods=['GET'], csrf=False)
    def get_all_events(self, **kwargs):
        try:
            events = request.env['event.event'].sudo().search([], order="date_begin desc")
            base_url = request.httprequest.host_url.rstrip('/')

            records = []
            for event in events:
                records.append({
                    "id": event.id,
                    "name": event.name,
                    "date_begin": event.date_begin.strftime('%Y-%m-%d %H:%M:%S') if event.date_begin else "",
                    "date_end": event.date_end.strftime('%Y-%m-%d %H:%M:%S') if event.date_end else "",
                    "category": event.event_type_id.name if event.event_type_id else "",
                    "image": get_image_from_cover_event(event),
                    "address": event.address_id.display_name if event.address_id else "",
                    "seats_available": event.seats_available,
                    "seats_max": event.seats_max,
                    # "image": f"{base_url}/web/image/event.event/{event.id}/image_1920" if event.image_1920 else "",
                })

            return _json_response({"success": True, "data": {"records": records}}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)

    @http.route('/api/events/<int:event_id>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_event_detail(self, event_id, **kwargs):
        try:
            event = request.env['event.event'].sudo().browse(event_id)
            if not event.exists():
                return _json_response({"success": False, "message": "Event not found"}, status=404)

            base_url = request.httprequest.host_url.rstrip('/')
            record = {
                "id": event.id,
                "name": event.name,
                "description": event.description or "",
                "date_begin": event.date_begin.strftime('%Y-%m-%d %H:%M:%S') if event.date_begin else "",
                "date_end": event.date_end.strftime('%Y-%m-%d %H:%M:%S') if event.date_end else "",
                "category": event.event_type_id.name if event.event_type_id else "",
                "image": get_image_from_cover_event(event),
                "address": event.address_id.display_name if event.address_id else "",
                "seats_available": event.seats_available,
                "seats_max": event.seats_max,
                "website_url": f"{base_url}{event.website_url}" if event.website_url else "",
            }
            return _json_response({"success": True, "data": record}, status=200)
        except Exception as e:
            return _json_response({"success": False, "message": "Unexpected server error", "detail": str(e)},
                                  status=500)