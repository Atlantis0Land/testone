import json
import random
import string
import re
from datetime import datetime
from dateutil.relativedelta import relativedelta
from odoo.addons.v16_ismart_sms.models.sms_sms import send_imsart_sms

from odoo import http, _
from odoo.http import request, Response
from odoo.addons.otp_authentication.controller.main import (
    generate_otp,
    hash_otp,
    format_mobile_number,
)


class MobileAuthController(http.Controller):

    def is_valid_mobile(self, phone):
        stripped = str(phone).strip()
        return bool(re.match(r'^\d{8}$', stripped))

    def generate_token(self, length=32):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    def json_error(self, message, extra=None, status=400):
        payload = {
            'success': False,
            'message': _(message),
        }
        if extra:
            payload.update(extra)
        return Response(
            json.dumps(payload),
            status=status,
            content_type='application/json'
        )

    def json_success(self, data=None):
        return Response(
            json.dumps({
                'success': True,
                'data': data or {}
            }),
            status=200,
            content_type='application/json'
        )

    @http.route('/api/mobile/send_otp', type='http', auth='public', methods=['POST'], csrf=False)
    def send_otp(self, **post):
        data = request.httprequest.get_json(silent=True) or {}
        phone = data.get('phone')
        channel = (data.get('channel') or 'whatsapp').lower()  # default WhatsApp لو مفيش

        # 400 بدلاً من 404
        if not phone or not self.is_valid_mobile(phone):
            return self.json_error('Invalid phone number', status=400)

        formatted = format_mobile_number(phone)
        otp = generate_otp()
        hashed = hash_otp(otp)

        request.env['otp.code'].sudo().search([('phone_num', '=', formatted)]).unlink()
        request.env['otp.code'].sudo().create({
            'phone_num': formatted,
            'req_time': datetime.now(),
            'code_num': hashed,
        })

        if channel == 'sms':
            gateway = request.env['sms.gateway.config'].sudo().search([], limit=1)
            # 500
            if not gateway:
                return self.json_error("SMS Gateway is not configured", status=500)
            sms_body = f"Your OTP code is: {otp}"
            resp = send_imsart_sms(
                mobile_no=f"{formatted}",
                sms=sms_body,
                sms_gateway=gateway,
                lang=request.env.user.lang or 'en_US',
            )
            print("DEBUG SMS Response: ", resp, type(resp))

            if hasattr(resp, "status_code") and hasattr(resp, "text"):
                sent = resp.status_code == 200 and resp.text.strip() == "1"
                error_msg = resp.text
            else:
                sent = False
                error_msg = "Failed to send SMS (unknown response)"

            # 500 بدلاً من 400
            if not sent:
                return self.json_error(f"Failed to send SMS: {error_msg}", status=500)
        else:
            # WhatsApp as default
            res = request.env['vs.otp.gateway'].send_whatsapp(formatted, otp)
            sent = bool(res.get('sent', False)) or res.get('status') == 200
            # 500 بدلاً من 400
            if not sent:
                return self.json_error(res.get('text', 'Failed to send via WhatsApp'), status=500)

        Users = request.env['res.users'].sudo()
        user = Users.search([('phone', '=', phone)], limit=1) \
               or Users.search([('mobile', '=', phone)], limit=1) \
               or Users.search([('partner_id.phone', '=', phone)], limit=1) \
               or Users.search([('login', '=', phone)], limit=1) \
               or Users.search([('partner_id.mobile', '=', phone)], limit=1)

        return self.json_success({'user_exists': bool(user)})

    @http.route('/api/mobile/verify_otp', type='http', auth='public', methods=['POST'], csrf=False)
    def verify_otp(self, **post):
        data = request.httprequest.get_json(silent=True) or {}
        phone = data.get('phone')
        otp = data.get('otp')
        signup_data = data.get('signup')
        fcm_token = data.get('fcm_token')

        # 400
        if not phone or not otp:
            return self.json_error('phone and otp required', status=400)

        # 400
        if not self.is_valid_mobile(phone):
            return self.json_error('Invalid phone number', status=400)

        formatted = format_mobile_number(phone)
        hashed = hash_otp(otp)
        cutoff = datetime.now() - relativedelta(minutes=3)
        record = request.env['otp.code'].sudo().search([
            ('phone_num', '=', formatted),
            ('req_time', '>=', cutoff),
        ], order='req_time desc', limit=1)

        master_otp = '123456'
        # 401
        if not record or (record.code_num != hashed and otp != master_otp):
            return self.json_error('OTP incorrect or expired', status=401)

        record.unlink()

        Users = request.env['res.users'].sudo()
        user = Users.search([('phone', '=', phone)], limit=1) \
               or Users.search([('mobile', '=', phone)], limit=1) \
               or Users.search([('partner_id.phone', '=', phone)], limit=1) \
               or Users.search([('login', '=', phone)], limit=1) \
               or Users.search([('partner_id.mobile', '=', phone)], limit=1)

        if user:
            token = self.generate_token()
            if fcm_token:
                try:
                    user.partner_id.sudo().write({'fcm_token': fcm_token})
                except Exception as e:
                    print("FCM token save error:", e)
            user.partner_id.sudo().write({'token': token})

            request.session.uid = user.id
            request.session.login = user.login
            request.session.session_token = user._compute_session_token(request.session.sid)
            request.update_env(user=user.id)
            return self.json_success({
                'action': 'login',
                'user_id': user.id,
                'user_name': user.name,
                'phone': user.phone or '',
                'national_id': user.partner_id.national_id or '',
                'national_id_expiry': user.national_id_expiry.isoformat() if user.national_id_expiry else '',
                'address': user.street or '',
                'token': token,
            })

        # 404
        if not signup_data or not isinstance(signup_data, dict):
            return self.json_error('Signup required', status=404)

        token = self.generate_token()
        partner = request.env['res.partner'].sudo().create({
            'name': signup_data.get('name'),
            'phone': phone,
            'token': token,
        })

        new_user = Users.create({
            'login': signup_data.get('login') or phone,
            'name': signup_data.get('name'),
            'password': signup_data.get('password'),
            'phone': phone,
            'email': signup_data.get('email') or '',
            'partner_id': partner.id,
        })

        request.session.uid = new_user.id
        request.session.login = new_user.login
        request.session.session_token = new_user._compute_session_token(request.session.sid)
        request.update_env(user=new_user.id)

        return self.json_success({
            'action': 'signup',
            'user_id': new_user.id,
            'user_name': new_user.name,
            'phone': new_user.phone or '',
            'national_id': new_user.partner_id.national_id or '',
            'national_id_expiry': partner.national_id_expiry.isoformat() if partner.national_id_expiry else '',
            'address': partner.street or '',
            'token': token,
        })

    @http.route('/api/mobile/register', type='http', auth='public', methods=['POST'], csrf=False)
    def register(self, **post):
        data = request.httprequest.get_json(silent=True) or {}
        phone = data.get('phone')
        name = data.get('name')
        national_id = data.get('national_id')
        national_id_expiry = data.get('national_id_expiry')
        address = data.get('address')
        fcm_token = data.get('fcm_token')

        missing = []
        for field in ['phone', 'name', 'national_id', 'national_id_expiry', 'address']:
            if not data.get(field):
                missing.append(field)
        if missing:
            return self.json_error(
                f'Missing required fields: {", ".join(missing)}',
                extra={'missing_fields': missing},
                status=400
            )

        if not self.is_valid_mobile(phone):
            return self.json_error('Invalid phone number', status=400)

        token = self.generate_token()
        try:
            partner = request.env['res.partner'].sudo().create({
                'name': name,
                'phone': phone,
                'national_id': national_id,
                'national_id_expiry': national_id_expiry,
                'street': address,
                'token': token,
                'fcm_token': fcm_token,
            })
        except Exception as e:
            return self.json_error(f'Partner creation failed: {str(e)}', status=500)

        password = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(8))

        try:
            user = request.env['res.users'].sudo().create({
                'login': phone,
                'name': name,
                'phone': phone,
                'partner_id': partner.id,
                'password': password,
                'email': phone
            })
        except Exception as e:
            return self.json_error(f'User creation failed: {str(e)}', status=500)

        request.session.uid = user.id
        request.session.login = user.login
        request.session.session_token = user._compute_session_token(request.session.sid)
        request.update_env(user=user.id)

        return self.json_success({
            'user_id': user.id,
            'user_name': user.name,
            'phone': user.phone or phone,
            'national_id': national_id,
            'national_id_expiry': partner.national_id_expiry.isoformat() if partner.national_id_expiry else '',
            'address': partner.street or '',
            'token': token,
            'fcm_token': partner.fcm_token or '',
        })

    @http.route('/api/mobile/user_info', type='http', auth='public', methods=['POST'], csrf=False)
    def get_user_info(self, **post):
        data = request.httprequest.get_json(silent=True) or {}
        token = data.get('token')

        # 401
        if not token:
            return self.json_error("Token is required", status=401)

        partner = request.env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        # 401
        if not partner or not partner.user_ids:
            return self.json_error("Invalid token or user not found", status=401)

        user = partner.user_ids[0]

        return self.json_success({
            'user_id': user.id,
            'user_name': user.name,
            'email': user.email or '',
            'phone': user.phone or '',
            'login': user.login,
            'national_id': partner.national_id or '',
            'national_id_expiry': partner.national_id_expiry.isoformat() if partner.national_id_expiry else '',
            'address': partner.street or '',
            'token': partner.token,
        })

    @http.route('/api/mobile/update_user', type='http', auth='public', methods=['PUT'], csrf=False)
    def update_user(self, **post):
        data = request.httprequest.get_json(silent=True) or {}
        token = data.get('token')
        name = data.get('user_name')
        email = data.get('email')
        phone = data.get('phone')
        login = data.get('login')
        national_id = data.get('national_id')
        national_id_expiry = data.get('national_id_expiry')
        address = data.get('address')

        # 401
        if not token:
            return self.json_error("Token is required", status=401)

        partner = request.env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        # 401
        if not partner or not partner.user_ids:
            return self.json_error("Invalid token or user not found", status=401)

        user = partner.user_ids[0]

        partner_vals = {}
        user_vals = {}

        if name:
            partner_vals['name'] = name
            user_vals['name'] = name
        if email:
            partner_vals['email'] = email
            user_vals['email'] = email
        if phone:
            partner_vals['phone'] = phone
            user_vals['phone'] = phone
        if national_id:
            partner_vals['national_id'] = national_id
        if national_id_expiry:
            partner_vals['national_id_expiry'] = national_id_expiry
        if address:
            partner_vals['street'] = address
        if login:
            user_vals['login'] = login

        # update partner
        if partner_vals:
            try:
                partner.write(partner_vals)
            except Exception as e:
                # 500
                return self.json_error(f"Failed to update partner: {str(e)}", status=500)
        # update user
        if user_vals:
            try:
                user.write(user_vals)
            except Exception as e:
                # 500
                return self.json_error(f"Failed to update user: {str(e)}", status=500)

        return self.json_success({'message': "User info updated successfully"})

    @http.route('/api/mobile/logout', type='http', auth='public', methods=['POST'], csrf=False)
    def logout(self, **post):
        data = request.httprequest.get_json(silent=True) or {}
        token = data.get('token')

        # 401
        if not token:
            return self.json_error("Token is required", status=401)

        partner = request.env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        # 401
        if not partner:
            return self.json_error("Invalid token", status=401)

        partner.write({'token': False})
        return self.json_success({'message': "Logged out successfully"})

    @http.route('/api/mobile/delete_account', type='http', auth='public', methods=['DELETE'], csrf=False)
    def delete_account(self, **post):
        data = request.httprequest.get_json(silent=True) or {}
        token = data.get('token')

        # 401
        if not token:
            return self.json_error("Token is required", status=401)

        partner = request.env['res.partner'].sudo().search([('token', '=', token)], limit=1)
        # 401
        if not partner or not partner.user_ids:
            return self.json_error("Invalid token or user not found", status=401)

        user = partner.user_ids[0]
        partner.unlink()
        user.unlink()

        return self.json_success({'message': "Account deleted successfully"})
