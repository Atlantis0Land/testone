{
    "name": "VS API Mobile Integration",
    "summary": "Seamless mobile and WhatsApp OTP integration with website-like service request APIs.",
    "description": """
        This module provides a full-featured API layer for mobile applications, enabling:
        - OTP-based authentication via WhatsApp
        - Mobile-first registration and login
        - Service request creation similar to website workflows
        - JSON-based secure communication with mobile frontends
        - Partner and user auto-creation with validation
    """,
    "version": "1.0.0",
    "category": "Tools",
    "author": "Veronica Safwat | Sysgates",
    "website": "https://www.sysgates.com",
    "depends": [
        "base",
        "website",
        "otp_authentication",'website_blog','v16_ismart_sms','website_event'
    ],
    "data": [
        # XML/CSV files go here if needed
    ],
    "license": "LGPL-3",
    "installable": True,
    "auto_install": False,
    "application": False,
}
