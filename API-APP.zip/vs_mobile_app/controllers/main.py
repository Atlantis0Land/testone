from odoo.http import Controller, route, request, Response
from odoo import _
import json

class MobileAppAPI(Controller):

    # === Helpers: HTTP JSON responses ===
    def _http_success(self, data=None, status=200, headers=None):
        payload = {"success": True}
        if data is not None:
            payload["data"] = data
        body = json.dumps(payload, ensure_ascii=False)
        return Response(
            body,
            status=status,
            content_type='application/json; charset=utf-8',
            headers=headers or []
        )

    def _http_error(self, message, status=400, extra=None, headers=None):
        payload = {"success": False, "message": _(message)}
        if extra:
            payload.update(extra)
        body = json.dumps(payload, ensure_ascii=False)
        return Response(
            body,
            status=status,
            content_type='application/json; charset=utf-8',
            headers=headers or []
        )

    def _get_token(self):
        return request.httprequest.headers.get("X-Api-Token") or request.params.get("token")

    def _is_token_valid(self, token):
        expected = request.env['ir.config_parameter'].sudo().get_param('mobile_app.api_token')
        return bool(expected) and token == expected

    @route('/api/mobile_app/records', type='http', auth='public', csrf=False, methods=['GET'])
    def get_all_mobile_app_records(self, **kwargs):
        try:
            # (اختياري لكنه مُستحسن) فحص التوكن


            records = request.env['mobile.app'].sudo().search([])
            data = []
            for rec in records:
                data.append({
                    'id': rec.id,
                    'news_name': rec.news_name,
                    'news_id': rec.news_id,
                    'news_category': rec.news_category,
                    'news_category_id': rec.news_category_id,
                    'news_active': rec.news_active,
                    'service_name': rec.service_name,
                    'service_id': rec.service_id,
                    'service_category': rec.service_category,
                    'service_category_id': rec.service_category_id,
                    'service_active': rec.service_active,
                    'project_name': rec.project_name,
                    'project_id': rec.project_id,
                    'project_category': rec.project_category,
                    'project_category_id': rec.project_category_id,
                    'project_active': rec.project_active,
                    'event_name': rec.event_name,
                    'event_id': rec.event_id,
                    'event_category': rec.event_category,
                    'event_category_id': rec.event_category_id,
                    'event_active': rec.event_active,
                    'wilayat_name': rec.wilayat_name,
                    'wilayat_id': rec.wilayat_id,
                    'wilayat_category': rec.wilayat_category,
                    'wilayat_category_id': rec.wilayat_category_id,
                    'wilayat_active': rec.wilayat_active,
                    'tourism_name': rec.tourism_name,
                    'tourism_id': rec.tourism_id,
                    'tourism_category': rec.tourism_category,
                    'tourism_category_id': rec.tourism_category_id,
                    'tourism_active': rec.tourism_active,
                    'suggestion_title': rec.suggestion_title,
                    'suggestion_id': rec.suggestion_id,
                    'suggestion_category': rec.suggestion_category,
                    'suggestion_category_id': rec.suggestion_category_id,
                    'suggestion_active': rec.suggestion_active,
                    'participation_title': rec.participation_title,
                    'participation_id': rec.participation_id,
                    'participation_category': rec.participation_category,
                    'participation_category_id': rec.participation_category_id,
                    'participation_active': rec.participation_active,
                    'news_of_home_name': rec.news_of_home_name,
                    'news_of_home_id': rec.news_of_home_id,
                    'news_of_home_count': rec.news_of_home_count,
                    'event2_name': rec.event2_name,
                    'event2_id': rec.event2_id,
                    'event2_count': rec.event2_count,
                })


            return self._http_success({"records": data}, status=200)

        except Exception as e:
            # شكل الفشل:
            return self._http_error("Unexpected server error", status=500, extra={"detail": str(e)})
