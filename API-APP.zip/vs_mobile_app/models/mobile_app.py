from odoo import models, fields

class MobileAPP(models.Model):
    _name = 'mobile.app'
    _description = 'Vs Mobile APP'

    news_name = fields.Char(string="News Title")
    news_id = fields.Char(string="News ID")
    news_category = fields.Char(string="News Category")
    news_category_id = fields.Char(string="News Category ID")
    news_active = fields.Boolean(string="News Active") 

    service_name = fields.Char(string="Service Name")
    service_id = fields.Char(string="Service ID")
    service_category = fields.Char(string="Service Category")
    service_category_id = fields.Char(string="Service Category ID")
    service_active = fields.Boolean(string="Service Active") 

    project_name = fields.Char(string="Project Name")
    project_id = fields.Char(string="Project ID")
    project_category = fields.Char(string="Project Category")
    project_category_id = fields.Char(string="Project Category ID")
    project_active = fields.Boolean(string="Project Active") 

    event_name = fields.Char(string="Event Name")
    event_id = fields.Char(string="Event ID")
    event_category = fields.Char(string="Event Category")
    event_category_id = fields.Char(string="Event Category ID")
    event_active = fields.Boolean(string="Event Active") 

    wilayat_name = fields.Char(string="Wilayat Name")
    wilayat_id = fields.Char(string="Wilayat ID")
    wilayat_category = fields.Char(string="Wilayat Category")
    wilayat_category_id = fields.Char(string="Wilayat Category ID")
    wilayat_active = fields.Boolean(string="Wilayat Active") 

    tourism_name = fields.Char(string="Tourism Name")
    tourism_id = fields.Char(string="Tourism ID")
    tourism_category = fields.Char(string="Tourism Category")
    tourism_category_id = fields.Char(string="Tourism Category ID")
    tourism_active = fields.Boolean(string="Tourism Active") 

    suggestion_title = fields.Char(string="Suggestion Title")
    suggestion_id = fields.Char(string="Suggestion ID")
    suggestion_category = fields.Char(string="Suggestion Category")
    suggestion_category_id = fields.Char(string="Suggestion Category ID")
    suggestion_active = fields.Boolean(string="Suggestion Active") 

    participation_title = fields.Char(string="Participation Title")
    participation_id = fields.Char(string="Participation ID")
    participation_category = fields.Char(string="Participation Category")
    participation_category_id = fields.Char(string="Participation Category ID")
    participation_active = fields.Boolean(string="Participation Active")

    news_of_home_name = fields.Char(string="News of Home Name")
    news_of_home_id = fields.Char(string="News of Home ID")
    news_of_home_count = fields.Integer(string="News of Home Count")

    event2_name = fields.Char(string="Event Name")
    event2_id = fields.Char(string="Event ID")
    event2_count = fields.Integer(string="Event Count")

